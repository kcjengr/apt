# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'zero_xy.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QPushButton,
    QSizePolicy, QVBoxLayout, QWidget)

from qtpyvcp.widgets.button_widgets.mdi_button import MDIButton
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(384, 247)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)
        self.horizontalLayout = QHBoxLayout(Dialog)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.statuslabel = StatusLabel(Dialog)
        self.statuslabel.setObjectName(u"statuslabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.statuslabel.sizePolicy().hasHeightForWidth())
        self.statuslabel.setSizePolicy(sizePolicy1)
        self.statuslabel.setAlignment(Qt.AlignCenter)

        self.verticalLayout_2.addWidget(self.statuslabel)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(-1, 10, 0, 10)
        self.close_button = QPushButton(Dialog)
        self.close_button.setObjectName(u"close_button")
        self.close_button.setMaximumSize(QSize(72, 64))

        self.horizontalLayout_2.addWidget(self.close_button)

        self.zero_xy_button = MDIButton(Dialog)
        self.zero_xy_button.setObjectName(u"zero_xy_button")
        self.zero_xy_button.setEnabled(False)
        self.zero_xy_button.setMaximumSize(QSize(72, 64))

        self.horizontalLayout_2.addWidget(self.zero_xy_button)


        self.verticalLayout_2.addLayout(self.horizontalLayout_2)


        self.verticalLayout.addLayout(self.verticalLayout_2)


        self.horizontalLayout.addLayout(self.verticalLayout)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Frame", None))
        self.statuslabel.setText(QCoreApplication.translate("Dialog", u"Do you want to set X and Y to ZERO?\n"
" WCS G53 P0", None))
        self.statuslabel.setProperty(u"rules", QCoreApplication.translate("Dialog", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"Do you want to set X and Y to ZERO?\\\\n WCS G5{} P{}\\\".format(3+ch[0], ch[0])\", \"name\": \"Active WCS\"}]", None))
        self.close_button.setText(QCoreApplication.translate("Dialog", u"CLOSE", None))
        self.zero_xy_button.setText(QCoreApplication.translate("Dialog", u"OK", None))
        self.zero_xy_button.setProperty(u"rules", QCoreApplication.translate("Dialog", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_xy_button.setProperty(u"MDICommand", QCoreApplication.translate("Dialog", u"G10 L20 P{ch[0]} X0.0 Y0.0", None))
    # retranslateUi

