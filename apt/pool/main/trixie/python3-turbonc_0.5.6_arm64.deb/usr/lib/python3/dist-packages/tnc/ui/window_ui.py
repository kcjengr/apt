# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'window.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QButtonGroup, QFormLayout,
    QFrame, QGridLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QLabel, QLayout, QPushButton,
    QSizePolicy, QSpacerItem, QStackedWidget, QTabWidget,
    QVBoxLayout, QWidget)

from gcodeeditor import GCodeEditor
from qtpyvcp.widgets.button_widgets.action_button import ActionButton
from qtpyvcp.widgets.button_widgets.dialog_button import DialogButton
from qtpyvcp.widgets.button_widgets.subcall_button import SubCallButton
from qtpyvcp.widgets.db_widgets.tool_model import ToolSTLField
from qtpyvcp.widgets.display_widgets.designer_plugins import VTKBackPlot
from qtpyvcp.widgets.display_widgets.dro_label import DROLabel
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel
from qtpyvcp.widgets.form_widgets.main_window import VCPMainWindow
from qtpyvcp.widgets.hal_widgets.hal_bar_indicator import HalBarIndicator
from qtpyvcp.widgets.hal_widgets.hal_button import HalButton
from qtpyvcp.widgets.hal_widgets.hal_led import HalLedIndicator
from qtpyvcp.widgets.input_widgets.action_combobox import ActionComboBox
from qtpyvcp.widgets.input_widgets.action_slider import ActionSlider
from qtpyvcp.widgets.input_widgets.file_system import (FileSystemTable, RemovableDeviceComboBox)
from qtpyvcp.widgets.input_widgets.line_edit import VCPLineEdit
from qtpyvcp.widgets.input_widgets.mdientry_widget import MDIEntry
from qtpyvcp.widgets.input_widgets.recent_file_combobox import RecentFileComboBox
from qtpyvcp.widgets.input_widgets.setting_slider import VCPSettingsLineEdit
from qtpyvcp.widgets.input_widgets.tool_table import ToolTable
import resources_rc
import resources_rc
import resources_rc
import resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1318, 868)
        MainWindow.setMinimumSize(QSize(1024, 768))
        MainWindow.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        icon = QIcon()
        icon.addFile(u":/images/logo.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        MainWindow.setWindowIcon(icon)
        MainWindow.setToolTipDuration(-1)
        MainWindow.setProperty(u"promptAtExit", False)
        MainWindow.setProperty(u"promot_on_exit", False)
        self.actionExit = QAction(MainWindow)
        self.actionExit.setObjectName(u"actionExit")
        self.actionOpen = QAction(MainWindow)
        self.actionOpen.setObjectName(u"actionOpen")
        self.actionClose = QAction(MainWindow)
        self.actionClose.setObjectName(u"actionClose")
        self.actionReload = QAction(MainWindow)
        self.actionReload.setObjectName(u"actionReload")
        self.actionSave_As = QAction(MainWindow)
        self.actionSave_As.setObjectName(u"actionSave_As")
        self.actionHome_X = QAction(MainWindow)
        self.actionHome_X.setObjectName(u"actionHome_X")
        self.actionHome_Y = QAction(MainWindow)
        self.actionHome_Y.setObjectName(u"actionHome_Y")
        self.actionHome_Z = QAction(MainWindow)
        self.actionHome_Z.setObjectName(u"actionHome_Z")
        self.action_EmergencyStop_toggle = QAction(MainWindow)
        self.action_EmergencyStop_toggle.setObjectName(u"action_EmergencyStop_toggle")
        self.action_MachinePower_toggle = QAction(MainWindow)
        self.action_MachinePower_toggle.setObjectName(u"action_MachinePower_toggle")
        self.actionHome_All = QAction(MainWindow)
        self.actionHome_All.setObjectName(u"actionHome_All")
        self.actionRun_Program = QAction(MainWindow)
        self.actionRun_Program.setObjectName(u"actionRun_Program")
        self.actionFile1 = QAction(MainWindow)
        self.actionFile1.setObjectName(u"actionFile1")
        self.actionReport_Actual_Position = QAction(MainWindow)
        self.actionReport_Actual_Position.setObjectName(u"actionReport_Actual_Position")
        self.actionReport_Actual_Position.setCheckable(True)
        self.actionTest = QAction(MainWindow)
        self.actionTest.setObjectName(u"actionTest")
        self.action_Mist_toggle = QAction(MainWindow)
        self.action_Mist_toggle.setObjectName(u"action_Mist_toggle")
        self.action_Mist_toggle.setCheckable(True)
        self.action_Flood_toggle = QAction(MainWindow)
        self.action_Flood_toggle.setObjectName(u"action_Flood_toggle")
        self.action_Flood_toggle.setCheckable(True)
        self.action_program_run = QAction(MainWindow)
        self.action_program_run.setObjectName(u"action_program_run")
        self.action_coolant_floodToggle = QAction(MainWindow)
        self.action_coolant_floodToggle.setObjectName(u"action_coolant_floodToggle")
        self.action_coolant_floodToggle.setCheckable(True)
        self.actionHalshow = QAction(MainWindow)
        self.actionHalshow.setObjectName(u"actionHalshow")
        self.actionHalmeter = QAction(MainWindow)
        self.actionHalmeter.setObjectName(u"actionHalmeter")
        self.actionHAL_Scope = QAction(MainWindow)
        self.actionHAL_Scope.setObjectName(u"actionHAL_Scope")
        self.actionCalibration = QAction(MainWindow)
        self.actionCalibration.setObjectName(u"actionCalibration")
        self.actionOverride_Limits = QAction(MainWindow)
        self.actionOverride_Limits.setObjectName(u"actionOverride_Limits")
        self.actionOverride_Limits_2 = QAction(MainWindow)
        self.actionOverride_Limits_2.setObjectName(u"actionOverride_Limits_2")
        self.actionRun_From_Line = QAction(MainWindow)
        self.actionRun_From_Line.setObjectName(u"actionRun_From_Line")
        self.actionStep = QAction(MainWindow)
        self.actionStep.setObjectName(u"actionStep")
        self.actionPause = QAction(MainWindow)
        self.actionPause.setObjectName(u"actionPause")
        self.actionStop = QAction(MainWindow)
        self.actionStop.setObjectName(u"actionStop")
        self.actionResume = QAction(MainWindow)
        self.actionResume.setObjectName(u"actionResume")
        self.actionPause_at_M1 = QAction(MainWindow)
        self.actionPause_at_M1.setObjectName(u"actionPause_at_M1")
        self.actionSkip_lines_with = QAction(MainWindow)
        self.actionSkip_lines_with.setObjectName(u"actionSkip_lines_with")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.Tabs = QTabWidget(self.centralwidget)
        self.Tabs.setObjectName(u"Tabs")
        font = QFont()
        font.setFamilies([u"3270 Semi-Condensed"])
        font.setBold(True)
        self.Tabs.setFont(font)
        self.Tabs.setTabPosition(QTabWidget.TabPosition.South)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.verticalLayout_9 = QVBoxLayout(self.tab)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setSpacing(6)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(5, 0, 3, 15)
        self.horizontalLayout_10 = QHBoxLayout()
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.statuslabel_13 = StatusLabel(self.tab)
        self.statuslabel_13.setObjectName(u"statuslabel_13")
        self.statuslabel_13.setEnabled(True)
        font1 = QFont()
        font1.setFamilies([u"3270 Semi-Condensed"])
        font1.setPointSize(12)
        font1.setBold(True)
        self.statuslabel_13.setFont(font1)

        self.horizontalLayout_10.addWidget(self.statuslabel_13)

        self.statuslabel_14 = StatusLabel(self.tab)
        self.statuslabel_14.setObjectName(u"statuslabel_14")
        self.statuslabel_14.setFont(font1)

        self.horizontalLayout_10.addWidget(self.statuslabel_14)


        self.verticalLayout_4.addLayout(self.horizontalLayout_10)

        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.tabWidget = QTabWidget(self.tab)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setMaximumSize(QSize(340, 16777215))
        self.tabWidget.setFont(font1)
        self.tabWidget.setTabPosition(QTabWidget.TabPosition.North)
        self.tabWidget.setTabShape(QTabWidget.TabShape.Rounded)
        self.tabWidget.setElideMode(Qt.TextElideMode.ElideNone)
        self.tabWidget.setTabsClosable(False)
        self.tab_8 = QWidget()
        self.tab_8.setObjectName(u"tab_8")
        self.verticalLayout_13 = QVBoxLayout(self.tab_8)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_22 = QVBoxLayout()
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.label_3 = QLabel(self.tab_8)
        self.label_3.setObjectName(u"label_3")
        font2 = QFont()
        font2.setFamilies([u"3270 Semi-Condensed"])
        font2.setPointSize(38)
        font2.setBold(False)
        self.label_3.setFont(font2)
        self.label_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.label_3.setFrameShadow(QFrame.Shadow.Sunken)
        self.label_3.setLineWidth(3)
        self.label_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_23.addWidget(self.label_3)

        self.drolabel_10 = DROLabel(self.tab_8)
        self.drolabel_10.setObjectName(u"drolabel_10")
        font3 = QFont()
        font3.setFamilies([u"3270 Semi-Condensed"])
        font3.setPointSize(38)
        font3.setBold(True)
        self.drolabel_10.setFont(font3)
        self.drolabel_10.setFrameShape(QFrame.Shape.StyledPanel)
        self.drolabel_10.setFrameShadow(QFrame.Shadow.Sunken)
        self.drolabel_10.setLineWidth(3)
        self.drolabel_10.setMidLineWidth(0)
        self.drolabel_10.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_10.setProperty(u"referenceType", 1)
        self.drolabel_10.setProperty(u"axisNumber", 0)
        self.drolabel_10.setProperty(u"latheMode", 0)

        self.horizontalLayout_23.addWidget(self.drolabel_10)


        self.verticalLayout_22.addLayout(self.horizontalLayout_23)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.label_5 = QLabel(self.tab_8)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font2)
        self.label_5.setFrameShape(QFrame.Shape.StyledPanel)
        self.label_5.setFrameShadow(QFrame.Shadow.Sunken)
        self.label_5.setLineWidth(3)
        self.label_5.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_24.addWidget(self.label_5)

        self.drolabel_15 = DROLabel(self.tab_8)
        self.drolabel_15.setObjectName(u"drolabel_15")
        self.drolabel_15.setFont(font3)
        self.drolabel_15.setFrameShape(QFrame.Shape.StyledPanel)
        self.drolabel_15.setFrameShadow(QFrame.Shadow.Sunken)
        self.drolabel_15.setLineWidth(3)
        self.drolabel_15.setMidLineWidth(0)
        self.drolabel_15.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_15.setProperty(u"referenceType", 1)
        self.drolabel_15.setProperty(u"axisNumber", 1)
        self.drolabel_15.setProperty(u"latheMode", 0)

        self.horizontalLayout_24.addWidget(self.drolabel_15)


        self.verticalLayout_22.addLayout(self.horizontalLayout_24)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_6 = QLabel(self.tab_8)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setFont(font2)
        self.label_6.setFrameShape(QFrame.Shape.StyledPanel)
        self.label_6.setFrameShadow(QFrame.Shadow.Sunken)
        self.label_6.setLineWidth(3)
        self.label_6.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_25.addWidget(self.label_6)

        self.drolabel_16 = DROLabel(self.tab_8)
        self.drolabel_16.setObjectName(u"drolabel_16")
        self.drolabel_16.setFont(font3)
        self.drolabel_16.setFrameShape(QFrame.Shape.StyledPanel)
        self.drolabel_16.setFrameShadow(QFrame.Shadow.Sunken)
        self.drolabel_16.setLineWidth(3)
        self.drolabel_16.setMidLineWidth(0)
        self.drolabel_16.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_16.setProperty(u"referenceType", 1)
        self.drolabel_16.setProperty(u"axisNumber", 2)
        self.drolabel_16.setProperty(u"latheMode", 0)

        self.horizontalLayout_25.addWidget(self.drolabel_16)


        self.verticalLayout_22.addLayout(self.horizontalLayout_25)


        self.verticalLayout_13.addLayout(self.verticalLayout_22)

        self.tabWidget.addTab(self.tab_8, "")
        self.tab_7 = QWidget()
        self.tab_7.setObjectName(u"tab_7")
        self.verticalLayout_20 = QVBoxLayout(self.tab_7)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.verticalLayout_18 = QVBoxLayout()
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_7 = QLabel(self.tab_7)
        self.label_7.setObjectName(u"label_7")
        font4 = QFont()
        font4.setFamilies([u"Noto Sans"])
        font4.setPointSize(32)
        font4.setBold(True)
        self.label_7.setFont(font4)
        self.label_7.setFrameShape(QFrame.Shape.StyledPanel)
        self.label_7.setFrameShadow(QFrame.Shadow.Sunken)
        self.label_7.setLineWidth(3)
        self.label_7.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_26.addWidget(self.label_7)

        self.drolabel_7 = DROLabel(self.tab_7)
        self.drolabel_7.setObjectName(u"drolabel_7")
        font5 = QFont()
        font5.setFamilies([u"Noto Sans"])
        font5.setPointSize(32)
        font5.setBold(True)
        font5.setUnderline(False)
        self.drolabel_7.setFont(font5)
        self.drolabel_7.setFrameShape(QFrame.Shape.StyledPanel)
        self.drolabel_7.setFrameShadow(QFrame.Shadow.Sunken)
        self.drolabel_7.setLineWidth(3)
        self.drolabel_7.setMidLineWidth(0)
        self.drolabel_7.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_7.setProperty(u"referenceType", 0)
        self.drolabel_7.setProperty(u"axisNumber", 0)
        self.drolabel_7.setProperty(u"latheMode", 0)

        self.horizontalLayout_26.addWidget(self.drolabel_7)


        self.verticalLayout_18.addLayout(self.horizontalLayout_26)

        self.horizontalLayout_27 = QHBoxLayout()
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.label_8 = QLabel(self.tab_7)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font4)
        self.label_8.setFrameShape(QFrame.Shape.StyledPanel)
        self.label_8.setFrameShadow(QFrame.Shadow.Sunken)
        self.label_8.setLineWidth(3)
        self.label_8.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_27.addWidget(self.label_8)

        self.drolabel_8 = DROLabel(self.tab_7)
        self.drolabel_8.setObjectName(u"drolabel_8")
        self.drolabel_8.setFont(font5)
        self.drolabel_8.setFrameShape(QFrame.Shape.StyledPanel)
        self.drolabel_8.setFrameShadow(QFrame.Shadow.Sunken)
        self.drolabel_8.setLineWidth(3)
        self.drolabel_8.setMidLineWidth(0)
        self.drolabel_8.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_8.setProperty(u"referenceType", 0)
        self.drolabel_8.setProperty(u"axisNumber", 1)
        self.drolabel_8.setProperty(u"latheMode", 0)

        self.horizontalLayout_27.addWidget(self.drolabel_8)


        self.verticalLayout_18.addLayout(self.horizontalLayout_27)

        self.horizontalLayout_29 = QHBoxLayout()
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.label_9 = QLabel(self.tab_7)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font4)
        self.label_9.setFrameShape(QFrame.Shape.StyledPanel)
        self.label_9.setFrameShadow(QFrame.Shadow.Sunken)
        self.label_9.setLineWidth(3)
        self.label_9.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_29.addWidget(self.label_9)

        self.drolabel_9 = DROLabel(self.tab_7)
        self.drolabel_9.setObjectName(u"drolabel_9")
        self.drolabel_9.setFont(font5)
        self.drolabel_9.setFrameShape(QFrame.Shape.StyledPanel)
        self.drolabel_9.setFrameShadow(QFrame.Shadow.Sunken)
        self.drolabel_9.setLineWidth(3)
        self.drolabel_9.setMidLineWidth(0)
        self.drolabel_9.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_9.setProperty(u"referenceType", 0)
        self.drolabel_9.setProperty(u"axisNumber", 2)
        self.drolabel_9.setProperty(u"latheMode", 0)

        self.horizontalLayout_29.addWidget(self.drolabel_9)


        self.verticalLayout_18.addLayout(self.horizontalLayout_29)


        self.verticalLayout_20.addLayout(self.verticalLayout_18)

        self.tabWidget.addTab(self.tab_7, "")

        self.horizontalLayout_18.addWidget(self.tabWidget)

        self.horizontalWidget = QWidget(self.tab)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.horizontalWidget.sizePolicy().hasHeightForWidth())
        self.horizontalWidget.setSizePolicy(sizePolicy)
        self.horizontalWidget.setMinimumSize(QSize(60, 0))
        self.horizontalWidget.setSizeIncrement(QSize(0, 0))
        font6 = QFont()
        font6.setFamilies([u"3270 Semi-Condensed"])
        font6.setBold(False)
        self.horizontalWidget.setFont(font6)
        self.horizontalWidget.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.verticalLayout_6 = QVBoxLayout(self.horizontalWidget)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.clear_view = QPushButton(self.horizontalWidget)
        self.clear_view.setObjectName(u"clear_view")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.clear_view.sizePolicy().hasHeightForWidth())
        self.clear_view.setSizePolicy(sizePolicy1)
        self.clear_view.setMinimumSize(QSize(64, 32))
        self.clear_view.setMaximumSize(QSize(64, 16777215))
        self.clear_view.setFont(font1)

        self.verticalLayout_6.addWidget(self.clear_view)

        self.pan_view = QPushButton(self.horizontalWidget)
        self.pan_view.setObjectName(u"pan_view")
        sizePolicy1.setHeightForWidth(self.pan_view.sizePolicy().hasHeightForWidth())
        self.pan_view.setSizePolicy(sizePolicy1)
        self.pan_view.setMinimumSize(QSize(64, 32))
        self.pan_view.setMaximumSize(QSize(64, 16777215))
        self.pan_view.setFont(font1)
        self.pan_view.setCheckable(True)
        self.pan_view.setChecked(False)

        self.verticalLayout_6.addWidget(self.pan_view)

        self.machine_view = QPushButton(self.horizontalWidget)
        self.machine_view.setObjectName(u"machine_view")
        sizePolicy1.setHeightForWidth(self.machine_view.sizePolicy().hasHeightForWidth())
        self.machine_view.setSizePolicy(sizePolicy1)
        self.machine_view.setMinimumSize(QSize(64, 32))
        self.machine_view.setMaximumSize(QSize(64, 16777215))
        self.machine_view.setFont(font1)

        self.verticalLayout_6.addWidget(self.machine_view)

        self.program_view = QPushButton(self.horizontalWidget)
        self.program_view.setObjectName(u"program_view")
        sizePolicy1.setHeightForWidth(self.program_view.sizePolicy().hasHeightForWidth())
        self.program_view.setSizePolicy(sizePolicy1)
        self.program_view.setMinimumSize(QSize(64, 32))
        self.program_view.setMaximumSize(QSize(64, 16777215))
        self.program_view.setFont(font1)
        self.program_view.setCheckable(False)
        self.program_view.setAutoExclusive(False)

        self.verticalLayout_6.addWidget(self.program_view)

        self.path_view = QPushButton(self.horizontalWidget)
        self.path_view.setObjectName(u"path_view")
        sizePolicy1.setHeightForWidth(self.path_view.sizePolicy().hasHeightForWidth())
        self.path_view.setSizePolicy(sizePolicy1)
        self.path_view.setMinimumSize(QSize(64, 32))
        self.path_view.setMaximumSize(QSize(64, 16777215))
        self.path_view.setFont(font1)

        self.verticalLayout_6.addWidget(self.path_view)

        self.zoom_out = QPushButton(self.horizontalWidget)
        self.zoom_out.setObjectName(u"zoom_out")
        sizePolicy1.setHeightForWidth(self.zoom_out.sizePolicy().hasHeightForWidth())
        self.zoom_out.setSizePolicy(sizePolicy1)
        self.zoom_out.setMinimumSize(QSize(64, 32))
        self.zoom_out.setMaximumSize(QSize(64, 16777215))
        self.zoom_out.setFont(font1)

        self.verticalLayout_6.addWidget(self.zoom_out)

        self.zoom_in = QPushButton(self.horizontalWidget)
        self.zoom_in.setObjectName(u"zoom_in")
        sizePolicy1.setHeightForWidth(self.zoom_in.sizePolicy().hasHeightForWidth())
        self.zoom_in.setSizePolicy(sizePolicy1)
        self.zoom_in.setMinimumSize(QSize(64, 32))
        self.zoom_in.setMaximumSize(QSize(64, 16777215))
        self.zoom_in.setFont(font1)

        self.verticalLayout_6.addWidget(self.zoom_in)

        self.plotX = QPushButton(self.horizontalWidget)
        self.plotX.setObjectName(u"plotX")
        sizePolicy1.setHeightForWidth(self.plotX.sizePolicy().hasHeightForWidth())
        self.plotX.setSizePolicy(sizePolicy1)
        self.plotX.setMinimumSize(QSize(64, 32))
        self.plotX.setMaximumSize(QSize(64, 16777215))
        self.plotX.setFont(font1)
        self.plotX.setCheckable(False)
        self.plotX.setAutoExclusive(False)

        self.verticalLayout_6.addWidget(self.plotX)

        self.plotY = QPushButton(self.horizontalWidget)
        self.plotY.setObjectName(u"plotY")
        sizePolicy1.setHeightForWidth(self.plotY.sizePolicy().hasHeightForWidth())
        self.plotY.setSizePolicy(sizePolicy1)
        self.plotY.setMinimumSize(QSize(64, 32))
        self.plotY.setMaximumSize(QSize(64, 16777215))
        self.plotY.setFont(font1)
        self.plotY.setCheckable(False)
        self.plotY.setAutoExclusive(False)

        self.verticalLayout_6.addWidget(self.plotY)

        self.plotZ = QPushButton(self.horizontalWidget)
        self.plotZ.setObjectName(u"plotZ")
        sizePolicy1.setHeightForWidth(self.plotZ.sizePolicy().hasHeightForWidth())
        self.plotZ.setSizePolicy(sizePolicy1)
        self.plotZ.setMinimumSize(QSize(64, 32))
        self.plotZ.setMaximumSize(QSize(64, 16777215))
        self.plotZ.setFont(font1)
        self.plotZ.setCheckable(False)
        self.plotZ.setChecked(False)
        self.plotZ.setAutoExclusive(False)

        self.verticalLayout_6.addWidget(self.plotZ)

        self.plotP = QPushButton(self.horizontalWidget)
        self.plotP.setObjectName(u"plotP")
        sizePolicy1.setHeightForWidth(self.plotP.sizePolicy().hasHeightForWidth())
        self.plotP.setSizePolicy(sizePolicy1)
        self.plotP.setMinimumSize(QSize(64, 32))
        self.plotP.setMaximumSize(QSize(64, 16777215))
        self.plotP.setFont(font1)
        self.plotP.setCheckable(False)
        self.plotP.setAutoExclusive(False)

        self.verticalLayout_6.addWidget(self.plotP)

        self.actioncombobox = ActionComboBox(self.horizontalWidget)
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.addItem("")
        self.actioncombobox.setObjectName(u"actioncombobox")
        self.actioncombobox.setFont(font)

        self.verticalLayout_6.addWidget(self.actioncombobox)


        self.horizontalLayout_18.addWidget(self.horizontalWidget)

        self.vtk = VTKBackPlot(self.tab)
        self.vtk.setObjectName(u"vtk")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.vtk.sizePolicy().hasHeightForWidth())
        self.vtk.setSizePolicy(sizePolicy2)

        self.horizontalLayout_18.addWidget(self.vtk)

        self.gcodeEditor_2 = GCodeEditor(self.tab)
        self.gcodeEditor_2.setObjectName(u"gcodeEditor_2")
        sizePolicy2.setHeightForWidth(self.gcodeEditor_2.sizePolicy().hasHeightForWidth())
        self.gcodeEditor_2.setSizePolicy(sizePolicy2)
        self.gcodeEditor_2.setReadOnly(True)

        self.horizontalLayout_18.addWidget(self.gcodeEditor_2)


        self.verticalLayout_4.addLayout(self.horizontalLayout_18)

        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.label = QLabel(self.tab)
        self.label.setObjectName(u"label")
        self.label.setFont(font)

        self.horizontalLayout_13.addWidget(self.label)

        self.mdientry = MDIEntry(self.tab)
        self.mdientry.setObjectName(u"mdientry")
        self.mdientry.setFont(font6)

        self.horizontalLayout_13.addWidget(self.mdientry)


        self.verticalLayout_4.addLayout(self.horizontalLayout_13)


        self.horizontalLayout.addLayout(self.verticalLayout_4)


        self.verticalLayout_9.addLayout(self.horizontalLayout)

        self.Tabs.addTab(self.tab, "")
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.verticalLayout_14 = QVBoxLayout(self.tab_4)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.dialogbutton_2 = DialogButton(self.tab_4)
        self.dialogbutton_2.setObjectName(u"dialogbutton_2")
        self.dialogbutton_2.setMinimumSize(QSize(80, 0))
        self.dialogbutton_2.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.dialogbutton_2)

        self.pushButton = QPushButton(self.tab_4)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setMinimumSize(QSize(80, 0))
        self.pushButton.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.pushButton)

        self.pushButton_5 = QPushButton(self.tab_4)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setMinimumSize(QSize(80, 0))
        self.pushButton_5.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.pushButton_5)

        self.pushButton_3 = QPushButton(self.tab_4)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setMinimumSize(QSize(80, 0))
        self.pushButton_3.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.pushButton_3)

        self.pushButton_6 = QPushButton(self.tab_4)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setMinimumSize(QSize(80, 0))
        self.pushButton_6.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.pushButton_6)

        self.pushButton_14 = QPushButton(self.tab_4)
        self.pushButton_14.setObjectName(u"pushButton_14")
        self.pushButton_14.setMinimumSize(QSize(80, 0))
        self.pushButton_14.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.pushButton_14)

        self.pushButton_7 = QPushButton(self.tab_4)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setMinimumSize(QSize(80, 0))
        self.pushButton_7.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.pushButton_7)

        self.pushButton_13 = QPushButton(self.tab_4)
        self.pushButton_13.setObjectName(u"pushButton_13")
        self.pushButton_13.setMinimumSize(QSize(80, 0))
        self.pushButton_13.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_15.addWidget(self.pushButton_13)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_15.addItem(self.horizontalSpacer)


        self.verticalLayout_14.addLayout(self.horizontalLayout_15)

        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.gcodeEditor = GCodeEditor(self.tab_4)
        self.gcodeEditor.setObjectName(u"gcodeEditor")
        self.gcodeEditor.setEnabled(True)
        font7 = QFont()
        font7.setFamilies([u"FreeMono"])
        font7.setBold(True)
        self.gcodeEditor.setFont(font7)
        self.gcodeEditor.setFrameShape(QFrame.Shape.NoFrame)
        self.gcodeEditor.setFrameShadow(QFrame.Shadow.Plain)
        self.gcodeEditor.setSyntaxHighlightingEnabled(True)
        self.gcodeEditor.setCurrentLineHighlightEnabled(False)
        self.gcodeEditor.setProperty(u"gCodeHighlightEnabled", False)
        self.gcodeEditor.setProperty(u"mCodeHighlightEnabled", False)
        self.gcodeEditor.setProperty(u"parameterHighlightEnabled", False)
        self.gcodeEditor.setProperty(u"numberHighlightEnabled", False)
        self.gcodeEditor.setProperty(u"commentHighlightEnabled", False)
        self.gcodeEditor.setProperty(u"stringHighlightEnabled", False)

        self.horizontalLayout_12.addWidget(self.gcodeEditor)


        self.verticalLayout_14.addLayout(self.horizontalLayout_12)

        self.find_dialog = QPushButton(self.tab_4)
        self.find_dialog.setObjectName(u"find_dialog")

        self.verticalLayout_14.addWidget(self.find_dialog)

        self.gridLayout_3 = QGridLayout()
        self.gridLayout_3.setObjectName(u"gridLayout_3")

        self.verticalLayout_14.addLayout(self.gridLayout_3)

        self.Tabs.addTab(self.tab_4, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.horizontalLayout_9 = QHBoxLayout(self.tab_2)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.frame_34 = QFrame(self.tab_2)
        self.frame_34.setObjectName(u"frame_34")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.frame_34.sizePolicy().hasHeightForWidth())
        self.frame_34.setSizePolicy(sizePolicy3)
        self.frame_34.setMinimumSize(QSize(450, 0))
        self.frame_34.setMaximumSize(QSize(500, 16777215))
        self.frame_34.setStyleSheet(u"")
        self.frame_34.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_34.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_35 = QVBoxLayout(self.frame_34)
        self.verticalLayout_35.setObjectName(u"verticalLayout_35")
        self.horizontalLayout_121 = QHBoxLayout()
        self.horizontalLayout_121.setObjectName(u"horizontalLayout_121")
        self.horizontalLayout_121.setContentsMargins(5, -1, 5, -1)
        self.main_folder_up_button = QPushButton(self.frame_34)
        self.main_folder_up_button.setObjectName(u"main_folder_up_button")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.main_folder_up_button.sizePolicy().hasHeightForWidth())
        self.main_folder_up_button.setSizePolicy(sizePolicy4)
        self.main_folder_up_button.setMinimumSize(QSize(110, 30))
        self.main_folder_up_button.setMaximumSize(QSize(110, 30))
        self.main_folder_up_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_folder_up_button.setStyleSheet(u"")
        icon1 = QIcon()
        icon1.addFile(u":/images/folder_up.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.main_folder_up_button.setIcon(icon1)
        self.main_folder_up_button.setIconSize(QSize(30, 17))

        self.horizontalLayout_121.addWidget(self.main_folder_up_button)

        self.recentfilecombobox_2 = RecentFileComboBox(self.frame_34)
        self.recentfilecombobox_2.setObjectName(u"recentfilecombobox_2")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(1)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.recentfilecombobox_2.sizePolicy().hasHeightForWidth())
        self.recentfilecombobox_2.setSizePolicy(sizePolicy5)
        self.recentfilecombobox_2.setMinimumSize(QSize(0, 30))
        self.recentfilecombobox_2.setMaximumSize(QSize(16777215, 30))

        self.horizontalLayout_121.addWidget(self.recentfilecombobox_2)

        self.main_load_gcode_button = QPushButton(self.frame_34)
        self.main_load_gcode_button.setObjectName(u"main_load_gcode_button")
        sizePolicy4.setHeightForWidth(self.main_load_gcode_button.sizePolicy().hasHeightForWidth())
        self.main_load_gcode_button.setSizePolicy(sizePolicy4)
        self.main_load_gcode_button.setMinimumSize(QSize(100, 30))
        self.main_load_gcode_button.setMaximumSize(QSize(100, 30))
        self.main_load_gcode_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_load_gcode_button.setStyleSheet(u"")

        self.horizontalLayout_121.addWidget(self.main_load_gcode_button)


        self.verticalLayout_35.addLayout(self.horizontalLayout_121)

        self.horizontalLayout_122 = QHBoxLayout()
        self.horizontalLayout_122.setObjectName(u"horizontalLayout_122")
        self.filesystemtable = FileSystemTable(self.frame_34)
        self.filesystemtable.setObjectName(u"filesystemtable")
        self.filesystemtable.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.filesystemtable.setStyleSheet(u"FileSystemTable {\n"
"	color: black;\n"
"   	border: 4px;\n"
"	border-color: rgb(120, 120, 120);\n"
"	border-style: solid;\n"
"	background-color: rgb(238, 238, 236);\n"
"    font: 12pt \"Bebas Kai\";\n"
"}\n"
"\n"
"QHeaderView {\n"
"    background-color: rgb(220, 220, 220);\n"
"	color: black;\n"
"    border: none;\n"
"	border-radius:none;\n"
"	border-style: none;\n"
"	font: 13pt \"Bebas Kai\";\n"
"}")
        self.filesystemtable.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.filesystemtable.setShowGrid(False)

        self.horizontalLayout_122.addWidget(self.filesystemtable)


        self.verticalLayout_35.addLayout(self.horizontalLayout_122)

        self.horizontalLayout_123 = QHBoxLayout()
        self.horizontalLayout_123.setObjectName(u"horizontalLayout_123")
        self.main_delete_item_button = QPushButton(self.frame_34)
        self.main_delete_item_button.setObjectName(u"main_delete_item_button")
        sizePolicy4.setHeightForWidth(self.main_delete_item_button.sizePolicy().hasHeightForWidth())
        self.main_delete_item_button.setSizePolicy(sizePolicy4)
        self.main_delete_item_button.setMinimumSize(QSize(90, 30))
        self.main_delete_item_button.setMaximumSize(QSize(90, 30))
        self.main_delete_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_delete_item_button.setStyleSheet(u"")
        icon2 = QIcon()
        icon2.addFile(u":/images/delete.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.main_delete_item_button.setIcon(icon2)
        self.main_delete_item_button.setIconSize(QSize(14, 14))

        self.horizontalLayout_123.addWidget(self.main_delete_item_button)

        self.main_new_file_button = QPushButton(self.frame_34)
        self.main_new_file_button.setObjectName(u"main_new_file_button")
        sizePolicy4.setHeightForWidth(self.main_new_file_button.sizePolicy().hasHeightForWidth())
        self.main_new_file_button.setSizePolicy(sizePolicy4)
        self.main_new_file_button.setMinimumSize(QSize(100, 30))
        self.main_new_file_button.setMaximumSize(QSize(100, 30))
        self.main_new_file_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_new_file_button.setStyleSheet(u"")
        icon3 = QIcon()
        icon3.addFile(u":/images/new_file.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.main_new_file_button.setIcon(icon3)
        self.main_new_file_button.setIconSize(QSize(12, 16))

        self.horizontalLayout_123.addWidget(self.main_new_file_button)

        self.main_new_folder_button = QPushButton(self.frame_34)
        self.main_new_folder_button.setObjectName(u"main_new_folder_button")
        sizePolicy4.setHeightForWidth(self.main_new_folder_button.sizePolicy().hasHeightForWidth())
        self.main_new_folder_button.setSizePolicy(sizePolicy4)
        self.main_new_folder_button.setMinimumSize(QSize(125, 30))
        self.main_new_folder_button.setMaximumSize(QSize(125, 30))
        self.main_new_folder_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_new_folder_button.setStyleSheet(u"")
        icon4 = QIcon()
        icon4.addFile(u":/images/new_folder.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.main_new_folder_button.setIcon(icon4)
        self.main_new_folder_button.setIconSize(QSize(28, 15))

        self.horizontalLayout_123.addWidget(self.main_new_folder_button)

        self.main_rename_item_button = QPushButton(self.frame_34)
        self.main_rename_item_button.setObjectName(u"main_rename_item_button")
        sizePolicy4.setHeightForWidth(self.main_rename_item_button.sizePolicy().hasHeightForWidth())
        self.main_rename_item_button.setSizePolicy(sizePolicy4)
        self.main_rename_item_button.setMinimumSize(QSize(90, 30))
        self.main_rename_item_button.setMaximumSize(QSize(90, 30))
        self.main_rename_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_rename_item_button.setStyleSheet(u"")

        self.horizontalLayout_123.addWidget(self.main_rename_item_button)


        self.verticalLayout_35.addLayout(self.horizontalLayout_123)


        self.horizontalLayout_9.addWidget(self.frame_34)

        self.verticalLayout_12 = QVBoxLayout()
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.copy_from_usb = QPushButton(self.tab_2)
        self.copy_from_usb.setObjectName(u"copy_from_usb")
        sizePolicy4.setHeightForWidth(self.copy_from_usb.sizePolicy().hasHeightForWidth())
        self.copy_from_usb.setSizePolicy(sizePolicy4)
        self.copy_from_usb.setMinimumSize(QSize(60, 89))
        self.copy_from_usb.setMaximumSize(QSize(60, 90))
        self.copy_from_usb.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.copy_from_usb.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.copy_from_usb.setStyleSheet(u"")
        self.copy_from_usb.setAutoDefault(False)

        self.verticalLayout_12.addWidget(self.copy_from_usb)

        self.copy_to_usb = QPushButton(self.tab_2)
        self.copy_to_usb.setObjectName(u"copy_to_usb")
        sizePolicy4.setHeightForWidth(self.copy_to_usb.sizePolicy().hasHeightForWidth())
        self.copy_to_usb.setSizePolicy(sizePolicy4)
        self.copy_to_usb.setMinimumSize(QSize(60, 90))
        self.copy_to_usb.setMaximumSize(QSize(60, 90))
        self.copy_to_usb.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.verticalLayout_12.addWidget(self.copy_to_usb)


        self.horizontalLayout_9.addLayout(self.verticalLayout_12)

        self.frame_35 = QFrame(self.tab_2)
        self.frame_35.setObjectName(u"frame_35")
        sizePolicy3.setHeightForWidth(self.frame_35.sizePolicy().hasHeightForWidth())
        self.frame_35.setSizePolicy(sizePolicy3)
        self.frame_35.setMinimumSize(QSize(450, 0))
        self.frame_35.setMaximumSize(QSize(500, 16777215))
        self.frame_35.setStyleSheet(u"")
        self.frame_35.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_35.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_37 = QVBoxLayout(self.frame_35)
        self.verticalLayout_37.setObjectName(u"verticalLayout_37")
        self.horizontalLayout_124 = QHBoxLayout()
        self.horizontalLayout_124.setObjectName(u"horizontalLayout_124")
        self.horizontalLayout_124.setContentsMargins(5, -1, 5, -1)
        self.device_folder_up_button = QPushButton(self.frame_35)
        self.device_folder_up_button.setObjectName(u"device_folder_up_button")
        sizePolicy4.setHeightForWidth(self.device_folder_up_button.sizePolicy().hasHeightForWidth())
        self.device_folder_up_button.setSizePolicy(sizePolicy4)
        self.device_folder_up_button.setMinimumSize(QSize(110, 30))
        self.device_folder_up_button.setMaximumSize(QSize(110, 30))
        self.device_folder_up_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_folder_up_button.setStyleSheet(u"")
        self.device_folder_up_button.setIcon(icon1)
        self.device_folder_up_button.setIconSize(QSize(30, 17))

        self.horizontalLayout_124.addWidget(self.device_folder_up_button)

        self.removabledevicecombobox = RemovableDeviceComboBox(self.frame_35)
        self.removabledevicecombobox.setObjectName(u"removabledevicecombobox")
        sizePolicy5.setHeightForWidth(self.removabledevicecombobox.sizePolicy().hasHeightForWidth())
        self.removabledevicecombobox.setSizePolicy(sizePolicy5)
        self.removabledevicecombobox.setMinimumSize(QSize(0, 30))
        self.removabledevicecombobox.setMaximumSize(QSize(16777215, 30))

        self.horizontalLayout_124.addWidget(self.removabledevicecombobox)

        self.device_eject_usb_button = QPushButton(self.frame_35)
        self.device_eject_usb_button.setObjectName(u"device_eject_usb_button")
        sizePolicy4.setHeightForWidth(self.device_eject_usb_button.sizePolicy().hasHeightForWidth())
        self.device_eject_usb_button.setSizePolicy(sizePolicy4)
        self.device_eject_usb_button.setMinimumSize(QSize(100, 30))
        self.device_eject_usb_button.setMaximumSize(QSize(100, 30))
        self.device_eject_usb_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_eject_usb_button.setStyleSheet(u"")

        self.horizontalLayout_124.addWidget(self.device_eject_usb_button)


        self.verticalLayout_37.addLayout(self.horizontalLayout_124)

        self.horizontalLayout_125 = QHBoxLayout()
        self.horizontalLayout_125.setObjectName(u"horizontalLayout_125")
        self.filesystemtable_2 = FileSystemTable(self.frame_35)
        self.filesystemtable_2.setObjectName(u"filesystemtable_2")
        self.filesystemtable_2.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.filesystemtable_2.setStyleSheet(u"FileSystemTable {\n"
"	color: black;\n"
"   	border: 4px;\n"
"	border-color: rgb(120, 120, 120);\n"
"	border-style: solid;\n"
"	background-color: rgb(238, 238, 236);\n"
"    font: 12pt \"Bebas Kai\";\n"
"}\n"
"\n"
"QHeaderView {\n"
"    background-color: rgb(220, 220, 220);\n"
"	color: black;\n"
"    border: none;\n"
"	border-radius:none;\n"
"	border-style: none;\n"
"	font: 13pt \"Bebas Kai\";\n"
"}")
        self.filesystemtable_2.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.filesystemtable_2.setShowGrid(False)

        self.horizontalLayout_125.addWidget(self.filesystemtable_2)


        self.verticalLayout_37.addLayout(self.horizontalLayout_125)

        self.horizontalLayout_126 = QHBoxLayout()
        self.horizontalLayout_126.setObjectName(u"horizontalLayout_126")
        self.device_delete_item_button = QPushButton(self.frame_35)
        self.device_delete_item_button.setObjectName(u"device_delete_item_button")
        sizePolicy4.setHeightForWidth(self.device_delete_item_button.sizePolicy().hasHeightForWidth())
        self.device_delete_item_button.setSizePolicy(sizePolicy4)
        self.device_delete_item_button.setMinimumSize(QSize(90, 30))
        self.device_delete_item_button.setMaximumSize(QSize(90, 30))
        self.device_delete_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_delete_item_button.setStyleSheet(u"")
        self.device_delete_item_button.setIcon(icon2)
        self.device_delete_item_button.setIconSize(QSize(14, 14))

        self.horizontalLayout_126.addWidget(self.device_delete_item_button)

        self.device_new_file_button = QPushButton(self.frame_35)
        self.device_new_file_button.setObjectName(u"device_new_file_button")
        sizePolicy4.setHeightForWidth(self.device_new_file_button.sizePolicy().hasHeightForWidth())
        self.device_new_file_button.setSizePolicy(sizePolicy4)
        self.device_new_file_button.setMinimumSize(QSize(100, 30))
        self.device_new_file_button.setMaximumSize(QSize(100, 30))
        self.device_new_file_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_new_file_button.setStyleSheet(u"")
        self.device_new_file_button.setIcon(icon3)
        self.device_new_file_button.setIconSize(QSize(12, 16))

        self.horizontalLayout_126.addWidget(self.device_new_file_button)

        self.device_new_folder_button = QPushButton(self.frame_35)
        self.device_new_folder_button.setObjectName(u"device_new_folder_button")
        sizePolicy4.setHeightForWidth(self.device_new_folder_button.sizePolicy().hasHeightForWidth())
        self.device_new_folder_button.setSizePolicy(sizePolicy4)
        self.device_new_folder_button.setMinimumSize(QSize(125, 30))
        self.device_new_folder_button.setMaximumSize(QSize(125, 30))
        self.device_new_folder_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_new_folder_button.setStyleSheet(u"")
        self.device_new_folder_button.setIcon(icon4)
        self.device_new_folder_button.setIconSize(QSize(28, 15))

        self.horizontalLayout_126.addWidget(self.device_new_folder_button)

        self.device_rename_item_button = QPushButton(self.frame_35)
        self.device_rename_item_button.setObjectName(u"device_rename_item_button")
        sizePolicy4.setHeightForWidth(self.device_rename_item_button.sizePolicy().hasHeightForWidth())
        self.device_rename_item_button.setSizePolicy(sizePolicy4)
        self.device_rename_item_button.setMinimumSize(QSize(90, 30))
        self.device_rename_item_button.setMaximumSize(QSize(90, 30))
        self.device_rename_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_rename_item_button.setStyleSheet(u"")

        self.horizontalLayout_126.addWidget(self.device_rename_item_button)


        self.verticalLayout_37.addLayout(self.horizontalLayout_126)


        self.horizontalLayout_9.addWidget(self.frame_35)

        self.Tabs.addTab(self.tab_2, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.verticalLayout_11 = QVBoxLayout(self.tab_3)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.tooltable = ToolTable(self.tab_3)
        self.tooltable.setObjectName(u"tooltable")
        self.tooltable.setMinimumSize(QSize(800, 0))
        self.tooltable.setMaximumSize(QSize(16777215, 16777215))
        self.tooltable.setGridStyle(Qt.PenStyle.DashLine)

        self.horizontalLayout_17.addWidget(self.tooltable)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label_2 = QLabel(self.tab_3)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMaximumSize(QSize(16777215, 16777215))
        font8 = QFont()
        font8.setFamilies([u"Noto Sans"])
        font8.setPointSize(14)
        font8.setBold(True)
        self.label_2.setFont(font8)
        self.label_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_2.addWidget(self.label_2)

        self.toolmodel = ToolSTLField(self.tab_3)
        self.toolmodel.setObjectName(u"toolmodel")
        self.toolmodel.setMaximumSize(QSize(16777215, 16777215))

        self.verticalLayout_2.addWidget(self.toolmodel)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.save_tool_properties = QPushButton(self.tab_3)
        self.save_tool_properties.setObjectName(u"save_tool_properties")
        self.save_tool_properties.setMaximumSize(QSize(16777215, 16777215))

        self.verticalLayout_2.addWidget(self.save_tool_properties)


        self.horizontalLayout_17.addLayout(self.verticalLayout_2)


        self.verticalLayout_11.addLayout(self.horizontalLayout_17)

        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.pushButton_17 = QPushButton(self.tab_3)
        self.pushButton_17.setObjectName(u"pushButton_17")

        self.horizontalLayout_16.addWidget(self.pushButton_17)

        self.pushButton_18 = QPushButton(self.tab_3)
        self.pushButton_18.setObjectName(u"pushButton_18")

        self.horizontalLayout_16.addWidget(self.pushButton_18)

        self.pushButton_15 = QPushButton(self.tab_3)
        self.pushButton_15.setObjectName(u"pushButton_15")

        self.horizontalLayout_16.addWidget(self.pushButton_15)

        self.pushButton_12 = QPushButton(self.tab_3)
        self.pushButton_12.setObjectName(u"pushButton_12")

        self.horizontalLayout_16.addWidget(self.pushButton_12)


        self.verticalLayout_11.addLayout(self.horizontalLayout_16)

        self.Tabs.addTab(self.tab_3, "")
        self.tab_6 = QWidget()
        self.tab_6.setObjectName(u"tab_6")
        self.horizontalLayout_22 = QHBoxLayout(self.tab_6)
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.widget_45 = QWidget(self.tab_6)
        self.widget_45.setObjectName(u"widget_45")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy6.setHorizontalStretch(1)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.widget_45.sizePolicy().hasHeightForWidth())
        self.widget_45.setSizePolicy(sizePolicy6)
        self.widget_45.setMinimumSize(QSize(530, 0))
        self.widget_45.setMaximumSize(QSize(540, 16777215))
        self.widget_45.setStyleSheet(u"")
        self.verticalLayout_43 = QVBoxLayout(self.widget_45)
        self.verticalLayout_43.setObjectName(u"verticalLayout_43")
        self.verticalLayout_43.setContentsMargins(-1, 6, 6, 9)
        self.label_89 = QLabel(self.widget_45)
        self.label_89.setObjectName(u"label_89")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.label_89.sizePolicy().hasHeightForWidth())
        self.label_89.setSizePolicy(sizePolicy7)
        self.label_89.setMinimumSize(QSize(0, 27))
        self.label_89.setMaximumSize(QSize(16777215, 27))
        self.label_89.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.label_89.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_43.addWidget(self.label_89)

        self.widget_16 = QWidget(self.widget_45)
        self.widget_16.setObjectName(u"widget_16")
        self.widget_16.setMinimumSize(QSize(112, 90))
        self.widget_16.setMaximumSize(QSize(16777215, 100))
        self.verticalLayout_17 = QVBoxLayout(self.widget_16)
        self.verticalLayout_17.setSpacing(0)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(9, 0, 9, 0)
        self.horizontalWidget_4 = QWidget(self.widget_16)
        self.horizontalWidget_4.setObjectName(u"horizontalWidget_4")
        sizePolicy1.setHeightForWidth(self.horizontalWidget_4.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_4.setSizePolicy(sizePolicy1)
        self.horizontalWidget_4.setMinimumSize(QSize(440, 0))
        self.horizontalLayout_47 = QHBoxLayout(self.horizontalWidget_4)
        self.horizontalLayout_47.setSpacing(9)
        self.horizontalLayout_47.setObjectName(u"horizontalLayout_47")
        self.horizontalLayout_47.setContentsMargins(1, 1, 1, 1)
        self.actionbutton_31 = ActionButton(self.horizontalWidget_4)
        self.actionbutton_31.setObjectName(u"actionbutton_31")
        sizePolicy4.setHeightForWidth(self.actionbutton_31.sizePolicy().hasHeightForWidth())
        self.actionbutton_31.setSizePolicy(sizePolicy4)
        self.actionbutton_31.setMinimumSize(QSize(75, 38))
        self.actionbutton_31.setMaximumSize(QSize(70, 38))
        self.actionbutton_31.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_31.setStyleSheet(u"")
        self.actionbutton_31.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_31)

        self.actionbutton_32 = ActionButton(self.horizontalWidget_4)
        self.actionbutton_32.setObjectName(u"actionbutton_32")
        sizePolicy4.setHeightForWidth(self.actionbutton_32.sizePolicy().hasHeightForWidth())
        self.actionbutton_32.setSizePolicy(sizePolicy4)
        self.actionbutton_32.setMinimumSize(QSize(75, 38))
        self.actionbutton_32.setMaximumSize(QSize(70, 38))
        self.actionbutton_32.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_32.setStyleSheet(u"")
        self.actionbutton_32.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_32)

        self.actionbutton_33 = ActionButton(self.horizontalWidget_4)
        self.actionbutton_33.setObjectName(u"actionbutton_33")
        sizePolicy4.setHeightForWidth(self.actionbutton_33.sizePolicy().hasHeightForWidth())
        self.actionbutton_33.setSizePolicy(sizePolicy4)
        self.actionbutton_33.setMinimumSize(QSize(75, 38))
        self.actionbutton_33.setMaximumSize(QSize(70, 38))
        self.actionbutton_33.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_33.setStyleSheet(u"")
        self.actionbutton_33.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_33)

        self.actionbutton_34 = ActionButton(self.horizontalWidget_4)
        self.actionbutton_34.setObjectName(u"actionbutton_34")
        sizePolicy4.setHeightForWidth(self.actionbutton_34.sizePolicy().hasHeightForWidth())
        self.actionbutton_34.setSizePolicy(sizePolicy4)
        self.actionbutton_34.setMinimumSize(QSize(75, 38))
        self.actionbutton_34.setMaximumSize(QSize(70, 38))
        self.actionbutton_34.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_34.setStyleSheet(u"")
        self.actionbutton_34.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_34)

        self.actionbutton_35 = ActionButton(self.horizontalWidget_4)
        self.actionbutton_35.setObjectName(u"actionbutton_35")
        sizePolicy4.setHeightForWidth(self.actionbutton_35.sizePolicy().hasHeightForWidth())
        self.actionbutton_35.setSizePolicy(sizePolicy4)
        self.actionbutton_35.setMinimumSize(QSize(75, 38))
        self.actionbutton_35.setMaximumSize(QSize(70, 38))
        self.actionbutton_35.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_35.setStyleSheet(u"")
        self.actionbutton_35.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_35)

        self.actionbutton_36 = ActionButton(self.horizontalWidget_4)
        self.actionbutton_36.setObjectName(u"actionbutton_36")
        sizePolicy4.setHeightForWidth(self.actionbutton_36.sizePolicy().hasHeightForWidth())
        self.actionbutton_36.setSizePolicy(sizePolicy4)
        self.actionbutton_36.setMinimumSize(QSize(75, 38))
        self.actionbutton_36.setMaximumSize(QSize(70, 38))
        self.actionbutton_36.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_36.setStyleSheet(u"")
        self.actionbutton_36.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_36)


        self.verticalLayout_17.addWidget(self.horizontalWidget_4)

        self.horizontalWidget_5 = QWidget(self.widget_16)
        self.horizontalWidget_5.setObjectName(u"horizontalWidget_5")
        sizePolicy1.setHeightForWidth(self.horizontalWidget_5.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_5.setSizePolicy(sizePolicy1)
        self.horizontalWidget_5.setMinimumSize(QSize(440, 0))
        self.horizontalLayout_48 = QHBoxLayout(self.horizontalWidget_5)
        self.horizontalLayout_48.setSpacing(9)
        self.horizontalLayout_48.setObjectName(u"horizontalLayout_48")
        self.horizontalLayout_48.setContentsMargins(1, 1, 1, 1)
        self.actionbutton_37 = ActionButton(self.horizontalWidget_5)
        self.actionbutton_37.setObjectName(u"actionbutton_37")
        sizePolicy4.setHeightForWidth(self.actionbutton_37.sizePolicy().hasHeightForWidth())
        self.actionbutton_37.setSizePolicy(sizePolicy4)
        self.actionbutton_37.setMinimumSize(QSize(75, 38))
        self.actionbutton_37.setMaximumSize(QSize(70, 38))
        self.actionbutton_37.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_37.setStyleSheet(u"")
        self.actionbutton_37.setAutoExclusive(True)

        self.horizontalLayout_48.addWidget(self.actionbutton_37)

        self.actionbutton_38 = ActionButton(self.horizontalWidget_5)
        self.actionbutton_38.setObjectName(u"actionbutton_38")
        sizePolicy4.setHeightForWidth(self.actionbutton_38.sizePolicy().hasHeightForWidth())
        self.actionbutton_38.setSizePolicy(sizePolicy4)
        self.actionbutton_38.setMinimumSize(QSize(75, 38))
        self.actionbutton_38.setMaximumSize(QSize(70, 38))
        self.actionbutton_38.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_38.setStyleSheet(u"")
        self.actionbutton_38.setAutoExclusive(True)

        self.horizontalLayout_48.addWidget(self.actionbutton_38)

        self.actionbutton_39 = ActionButton(self.horizontalWidget_5)
        self.actionbutton_39.setObjectName(u"actionbutton_39")
        sizePolicy4.setHeightForWidth(self.actionbutton_39.sizePolicy().hasHeightForWidth())
        self.actionbutton_39.setSizePolicy(sizePolicy4)
        self.actionbutton_39.setMinimumSize(QSize(75, 38))
        self.actionbutton_39.setMaximumSize(QSize(70, 38))
        self.actionbutton_39.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_39.setStyleSheet(u"")
        self.actionbutton_39.setAutoExclusive(True)

        self.horizontalLayout_48.addWidget(self.actionbutton_39)

        self.probe_wco_2 = QPushButton(self.horizontalWidget_5)
        self.probe_wco_2.setObjectName(u"probe_wco_2")
        sizePolicy8 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy8.setHorizontalStretch(156)
        sizePolicy8.setVerticalStretch(0)
        sizePolicy8.setHeightForWidth(self.probe_wco_2.sizePolicy().hasHeightForWidth())
        self.probe_wco_2.setSizePolicy(sizePolicy8)
        self.probe_wco_2.setMinimumSize(QSize(118, 38))
        self.probe_wco_2.setMaximumSize(QSize(16777215, 38))
        self.probe_wco_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_wco_2.setStyleSheet(u"")
        self.probe_wco_2.setCheckable(True)
        self.probe_wco_2.setChecked(True)
        self.probe_wco_2.setAutoExclusive(True)

        self.horizontalLayout_48.addWidget(self.probe_wco_2)

        self.probe_Position_only_2 = QPushButton(self.horizontalWidget_5)
        self.probe_Position_only_2.setObjectName(u"probe_Position_only_2")
        sizePolicy8.setHeightForWidth(self.probe_Position_only_2.sizePolicy().hasHeightForWidth())
        self.probe_Position_only_2.setSizePolicy(sizePolicy8)
        self.probe_Position_only_2.setMinimumSize(QSize(118, 38))
        self.probe_Position_only_2.setMaximumSize(QSize(16777215, 38))
        self.probe_Position_only_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_Position_only_2.setStyleSheet(u"")
        self.probe_Position_only_2.setCheckable(True)

        self.horizontalLayout_48.addWidget(self.probe_Position_only_2)


        self.verticalLayout_17.addWidget(self.horizontalWidget_5)


        self.verticalLayout_43.addWidget(self.widget_16)

        self.label_93 = QLabel(self.widget_45)
        self.label_93.setObjectName(u"label_93")
        sizePolicy7.setHeightForWidth(self.label_93.sizePolicy().hasHeightForWidth())
        self.label_93.setSizePolicy(sizePolicy7)
        self.label_93.setMinimumSize(QSize(0, 27))
        self.label_93.setMaximumSize(QSize(16777215, 27))
        self.label_93.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")

        self.verticalLayout_43.addWidget(self.label_93)

        self.verticalLayout_23 = QVBoxLayout()
        self.verticalLayout_23.setSpacing(6)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.verticalLayout_23.setContentsMargins(-1, 0, 9, -1)
        self.horizontalLayout_159 = QHBoxLayout()
        self.horizontalLayout_159.setObjectName(u"horizontalLayout_159")
        self.horizontalLayout_159.setContentsMargins(-1, 1, -1, 1)
        self.ref_coilumn_header_24 = QLabel(self.widget_45)
        self.ref_coilumn_header_24.setObjectName(u"ref_coilumn_header_24")
        sizePolicy1.setHeightForWidth(self.ref_coilumn_header_24.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_24.setSizePolicy(sizePolicy1)
        self.ref_coilumn_header_24.setStyleSheet(u"")
        self.ref_coilumn_header_24.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_159.addWidget(self.ref_coilumn_header_24)

        self.label_103 = QLabel(self.widget_45)
        self.label_103.setObjectName(u"label_103")
        sizePolicy4.setHeightForWidth(self.label_103.sizePolicy().hasHeightForWidth())
        self.label_103.setSizePolicy(sizePolicy4)
        self.label_103.setMinimumSize(QSize(140, 31))
        self.label_103.setMaximumSize(QSize(150, 31))
        self.label_103.setStyleSheet(u"")
        self.label_103.setLineWidth(0)
        self.label_103.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_103.setIndent(0)

        self.horizontalLayout_159.addWidget(self.label_103)

        self.probe_tool_number_2 = VCPSettingsLineEdit(self.widget_45)
        self.probe_tool_number_2.setObjectName(u"probe_tool_number_2")
        sizePolicy4.setHeightForWidth(self.probe_tool_number_2.sizePolicy().hasHeightForWidth())
        self.probe_tool_number_2.setSizePolicy(sizePolicy4)
        self.probe_tool_number_2.setMinimumSize(QSize(100, 31))
        self.probe_tool_number_2.setMaximumSize(QSize(100, 31))
        self.probe_tool_number_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.probe_tool_number_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_159.addWidget(self.probe_tool_number_2)

        self.label_104 = QLabel(self.widget_45)
        self.label_104.setObjectName(u"label_104")
        sizePolicy4.setHeightForWidth(self.label_104.sizePolicy().hasHeightForWidth())
        self.label_104.setSizePolicy(sizePolicy4)
        self.label_104.setMinimumSize(QSize(140, 31))
        self.label_104.setMaximumSize(QSize(140, 31))
        self.label_104.setBaseSize(QSize(140, 30))
        self.label_104.setStyleSheet(u"")
        self.label_104.setLineWidth(0)
        self.label_104.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_104.setIndent(0)

        self.horizontalLayout_159.addWidget(self.label_104)

        self.step_off_width_2 = VCPSettingsLineEdit(self.widget_45)
        self.step_off_width_2.setObjectName(u"step_off_width_2")
        sizePolicy4.setHeightForWidth(self.step_off_width_2.sizePolicy().hasHeightForWidth())
        self.step_off_width_2.setSizePolicy(sizePolicy4)
        self.step_off_width_2.setMinimumSize(QSize(100, 31))
        self.step_off_width_2.setMaximumSize(QSize(100, 31))
        self.step_off_width_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.step_off_width_2.setStyleSheet(u"")
        self.step_off_width_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_159.addWidget(self.step_off_width_2)


        self.verticalLayout_23.addLayout(self.horizontalLayout_159)

        self.horizontalLayout_163 = QHBoxLayout()
        self.horizontalLayout_163.setObjectName(u"horizontalLayout_163")
        self.horizontalLayout_163.setContentsMargins(-1, 1, -1, 1)
        self.ref_coilumn_header_25 = QLabel(self.widget_45)
        self.ref_coilumn_header_25.setObjectName(u"ref_coilumn_header_25")
        sizePolicy1.setHeightForWidth(self.ref_coilumn_header_25.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_25.setSizePolicy(sizePolicy1)
        self.ref_coilumn_header_25.setStyleSheet(u"")
        self.ref_coilumn_header_25.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_163.addWidget(self.ref_coilumn_header_25)

        self.label_105 = QLabel(self.widget_45)
        self.label_105.setObjectName(u"label_105")
        sizePolicy4.setHeightForWidth(self.label_105.sizePolicy().hasHeightForWidth())
        self.label_105.setSizePolicy(sizePolicy4)
        self.label_105.setMinimumSize(QSize(140, 31))
        self.label_105.setMaximumSize(QSize(150, 31))
        self.label_105.setStyleSheet(u"")
        self.label_105.setLineWidth(0)
        self.label_105.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_105.setIndent(0)

        self.horizontalLayout_163.addWidget(self.label_105)

        self.probe_fast_fr_2 = VCPSettingsLineEdit(self.widget_45)
        self.probe_fast_fr_2.setObjectName(u"probe_fast_fr_2")
        sizePolicy4.setHeightForWidth(self.probe_fast_fr_2.sizePolicy().hasHeightForWidth())
        self.probe_fast_fr_2.setSizePolicy(sizePolicy4)
        self.probe_fast_fr_2.setMinimumSize(QSize(100, 31))
        self.probe_fast_fr_2.setMaximumSize(QSize(100, 31))
        self.probe_fast_fr_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.probe_fast_fr_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_163.addWidget(self.probe_fast_fr_2)

        self.label_106 = QLabel(self.widget_45)
        self.label_106.setObjectName(u"label_106")
        sizePolicy4.setHeightForWidth(self.label_106.sizePolicy().hasHeightForWidth())
        self.label_106.setSizePolicy(sizePolicy4)
        self.label_106.setMinimumSize(QSize(140, 31))
        self.label_106.setMaximumSize(QSize(140, 31))
        self.label_106.setBaseSize(QSize(140, 30))
        self.label_106.setStyleSheet(u"")
        self.label_106.setLineWidth(0)
        self.label_106.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_106.setIndent(0)

        self.horizontalLayout_163.addWidget(self.label_106)

        self.probe_slow_fr_2 = VCPSettingsLineEdit(self.widget_45)
        self.probe_slow_fr_2.setObjectName(u"probe_slow_fr_2")
        sizePolicy4.setHeightForWidth(self.probe_slow_fr_2.sizePolicy().hasHeightForWidth())
        self.probe_slow_fr_2.setSizePolicy(sizePolicy4)
        self.probe_slow_fr_2.setMinimumSize(QSize(100, 31))
        self.probe_slow_fr_2.setMaximumSize(QSize(100, 31))
        self.probe_slow_fr_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.probe_slow_fr_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_163.addWidget(self.probe_slow_fr_2)


        self.verticalLayout_23.addLayout(self.horizontalLayout_163)

        self.horizontalLayout_164 = QHBoxLayout()
        self.horizontalLayout_164.setObjectName(u"horizontalLayout_164")
        self.horizontalLayout_164.setContentsMargins(-1, 1, -1, 1)
        self.ref_coilumn_header_26 = QLabel(self.widget_45)
        self.ref_coilumn_header_26.setObjectName(u"ref_coilumn_header_26")
        sizePolicy1.setHeightForWidth(self.ref_coilumn_header_26.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_26.setSizePolicy(sizePolicy1)
        self.ref_coilumn_header_26.setStyleSheet(u"")
        self.ref_coilumn_header_26.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_164.addWidget(self.ref_coilumn_header_26)

        self.label_107 = QLabel(self.widget_45)
        self.label_107.setObjectName(u"label_107")
        sizePolicy4.setHeightForWidth(self.label_107.sizePolicy().hasHeightForWidth())
        self.label_107.setSizePolicy(sizePolicy4)
        self.label_107.setMinimumSize(QSize(140, 31))
        self.label_107.setMaximumSize(QSize(150, 31))
        self.label_107.setStyleSheet(u"")
        self.label_107.setLineWidth(0)
        self.label_107.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_107.setIndent(0)

        self.horizontalLayout_164.addWidget(self.label_107)

        self.max_xy_distance_2 = VCPSettingsLineEdit(self.widget_45)
        self.max_xy_distance_2.setObjectName(u"max_xy_distance_2")
        sizePolicy4.setHeightForWidth(self.max_xy_distance_2.sizePolicy().hasHeightForWidth())
        self.max_xy_distance_2.setSizePolicy(sizePolicy4)
        self.max_xy_distance_2.setMinimumSize(QSize(100, 31))
        self.max_xy_distance_2.setMaximumSize(QSize(100, 31))
        self.max_xy_distance_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.max_xy_distance_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_164.addWidget(self.max_xy_distance_2)

        self.label_111 = QLabel(self.widget_45)
        self.label_111.setObjectName(u"label_111")
        sizePolicy4.setHeightForWidth(self.label_111.sizePolicy().hasHeightForWidth())
        self.label_111.setSizePolicy(sizePolicy4)
        self.label_111.setMinimumSize(QSize(140, 31))
        self.label_111.setMaximumSize(QSize(140, 31))
        self.label_111.setBaseSize(QSize(140, 30))
        self.label_111.setStyleSheet(u"")
        self.label_111.setLineWidth(0)
        self.label_111.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_111.setIndent(0)

        self.horizontalLayout_164.addWidget(self.label_111)

        self.xy_clearance_2 = VCPSettingsLineEdit(self.widget_45)
        self.xy_clearance_2.setObjectName(u"xy_clearance_2")
        sizePolicy4.setHeightForWidth(self.xy_clearance_2.sizePolicy().hasHeightForWidth())
        self.xy_clearance_2.setSizePolicy(sizePolicy4)
        self.xy_clearance_2.setMinimumSize(QSize(100, 31))
        self.xy_clearance_2.setMaximumSize(QSize(100, 31))
        self.xy_clearance_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.xy_clearance_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_164.addWidget(self.xy_clearance_2)


        self.verticalLayout_23.addLayout(self.horizontalLayout_164)

        self.horizontalLayout_165 = QHBoxLayout()
        self.horizontalLayout_165.setObjectName(u"horizontalLayout_165")
        self.horizontalLayout_165.setContentsMargins(-1, 1, -1, 1)
        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")

        self.horizontalLayout_165.addLayout(self.verticalLayout_8)

        self.ref_coilumn_header_27 = QLabel(self.widget_45)
        self.ref_coilumn_header_27.setObjectName(u"ref_coilumn_header_27")
        sizePolicy1.setHeightForWidth(self.ref_coilumn_header_27.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_27.setSizePolicy(sizePolicy1)
        self.ref_coilumn_header_27.setStyleSheet(u"")
        self.ref_coilumn_header_27.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_165.addWidget(self.ref_coilumn_header_27)

        self.label_112 = QLabel(self.widget_45)
        self.label_112.setObjectName(u"label_112")
        sizePolicy4.setHeightForWidth(self.label_112.sizePolicy().hasHeightForWidth())
        self.label_112.setSizePolicy(sizePolicy4)
        self.label_112.setMinimumSize(QSize(140, 31))
        self.label_112.setMaximumSize(QSize(150, 31))
        self.label_112.setStyleSheet(u"")
        self.label_112.setLineWidth(0)
        self.label_112.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_112.setIndent(0)

        self.horizontalLayout_165.addWidget(self.label_112)

        self.max_z_distance_2 = VCPSettingsLineEdit(self.widget_45)
        self.max_z_distance_2.setObjectName(u"max_z_distance_2")
        sizePolicy4.setHeightForWidth(self.max_z_distance_2.sizePolicy().hasHeightForWidth())
        self.max_z_distance_2.setSizePolicy(sizePolicy4)
        self.max_z_distance_2.setMinimumSize(QSize(100, 31))
        self.max_z_distance_2.setMaximumSize(QSize(100, 31))
        self.max_z_distance_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.max_z_distance_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_165.addWidget(self.max_z_distance_2)

        self.label_115 = QLabel(self.widget_45)
        self.label_115.setObjectName(u"label_115")
        sizePolicy4.setHeightForWidth(self.label_115.sizePolicy().hasHeightForWidth())
        self.label_115.setSizePolicy(sizePolicy4)
        self.label_115.setMinimumSize(QSize(140, 31))
        self.label_115.setMaximumSize(QSize(140, 31))
        self.label_115.setBaseSize(QSize(140, 30))
        self.label_115.setStyleSheet(u"")
        self.label_115.setLineWidth(0)
        self.label_115.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_115.setIndent(0)

        self.horizontalLayout_165.addWidget(self.label_115)

        self.z_clearance_2 = VCPSettingsLineEdit(self.widget_45)
        self.z_clearance_2.setObjectName(u"z_clearance_2")
        sizePolicy4.setHeightForWidth(self.z_clearance_2.sizePolicy().hasHeightForWidth())
        self.z_clearance_2.setSizePolicy(sizePolicy4)
        self.z_clearance_2.setMinimumSize(QSize(100, 31))
        self.z_clearance_2.setMaximumSize(QSize(100, 31))
        self.z_clearance_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_clearance_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_165.addWidget(self.z_clearance_2)


        self.verticalLayout_23.addLayout(self.horizontalLayout_165)

        self.horizontalLayout_166 = QHBoxLayout()
        self.horizontalLayout_166.setObjectName(u"horizontalLayout_166")
        self.horizontalLayout_166.setContentsMargins(1, 1, 1, 1)
        self.ref_coilumn_header_28 = QLabel(self.widget_45)
        self.ref_coilumn_header_28.setObjectName(u"ref_coilumn_header_28")
        sizePolicy1.setHeightForWidth(self.ref_coilumn_header_28.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_28.setSizePolicy(sizePolicy1)
        self.ref_coilumn_header_28.setStyleSheet(u"")
        self.ref_coilumn_header_28.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_166.addWidget(self.ref_coilumn_header_28)

        self.label_116 = QLabel(self.widget_45)
        self.label_116.setObjectName(u"label_116")
        sizePolicy4.setHeightForWidth(self.label_116.sizePolicy().hasHeightForWidth())
        self.label_116.setSizePolicy(sizePolicy4)
        self.label_116.setMinimumSize(QSize(140, 31))
        self.label_116.setMaximumSize(QSize(150, 31))
        self.label_116.setStyleSheet(u"")
        self.label_116.setLineWidth(0)
        self.label_116.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_116.setIndent(0)

        self.horizontalLayout_166.addWidget(self.label_116)

        self.extra_probe_depth_2 = VCPSettingsLineEdit(self.widget_45)
        self.extra_probe_depth_2.setObjectName(u"extra_probe_depth_2")
        sizePolicy4.setHeightForWidth(self.extra_probe_depth_2.sizePolicy().hasHeightForWidth())
        self.extra_probe_depth_2.setSizePolicy(sizePolicy4)
        self.extra_probe_depth_2.setMinimumSize(QSize(100, 31))
        self.extra_probe_depth_2.setMaximumSize(QSize(100, 31))
        self.extra_probe_depth_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.extra_probe_depth_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_166.addWidget(self.extra_probe_depth_2)

        self.label_117 = QLabel(self.widget_45)
        self.label_117.setObjectName(u"label_117")
        sizePolicy4.setHeightForWidth(self.label_117.sizePolicy().hasHeightForWidth())
        self.label_117.setSizePolicy(sizePolicy4)
        self.label_117.setMinimumSize(QSize(140, 31))
        self.label_117.setMaximumSize(QSize(140, 31))
        self.label_117.setBaseSize(QSize(140, 30))
        self.label_117.setStyleSheet(u"")
        self.label_117.setLineWidth(0)
        self.label_117.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_117.setIndent(0)

        self.horizontalLayout_166.addWidget(self.label_117)

        self.edge_width_2 = VCPSettingsLineEdit(self.widget_45)
        self.edge_width_2.setObjectName(u"edge_width_2")
        sizePolicy4.setHeightForWidth(self.edge_width_2.sizePolicy().hasHeightForWidth())
        self.edge_width_2.setSizePolicy(sizePolicy4)
        self.edge_width_2.setMinimumSize(QSize(100, 31))
        self.edge_width_2.setMaximumSize(QSize(100, 31))
        self.edge_width_2.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.edge_width_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_166.addWidget(self.edge_width_2)


        self.verticalLayout_23.addLayout(self.horizontalLayout_166)


        self.verticalLayout_43.addLayout(self.verticalLayout_23)

        self.widget_20 = QWidget(self.widget_45)
        self.widget_20.setObjectName(u"widget_20")
        sizePolicy7.setHeightForWidth(self.widget_20.sizePolicy().hasHeightForWidth())
        self.widget_20.setSizePolicy(sizePolicy7)
        self.widget_20.setMinimumSize(QSize(0, 33))
        self.widget_20.setMaximumSize(QSize(16777215, 33))
        self.horizontalLayout_58 = QHBoxLayout(self.widget_20)
        self.horizontalLayout_58.setSpacing(1)
        self.horizontalLayout_58.setObjectName(u"horizontalLayout_58")
        self.horizontalLayout_58.setContentsMargins(0, 0, 0, 0)
        self.label_118 = QLabel(self.widget_20)
        self.label_118.setObjectName(u"label_118")
        sizePolicy7.setHeightForWidth(self.label_118.sizePolicy().hasHeightForWidth())
        self.label_118.setSizePolicy(sizePolicy7)
        self.label_118.setMinimumSize(QSize(0, 27))
        self.label_118.setMaximumSize(QSize(16777215, 27))
        self.label_118.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-top-left-radius: 5px;\n"
"    border-bottom-left-radius: 5px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")

        self.horizontalLayout_58.addWidget(self.label_118)

        self.reset_all_data_2 = SubCallButton(self.widget_20)
        self.reset_all_data_2.setObjectName(u"reset_all_data_2")
        sizePolicy4.setHeightForWidth(self.reset_all_data_2.sizePolicy().hasHeightForWidth())
        self.reset_all_data_2.setSizePolicy(sizePolicy4)
        self.reset_all_data_2.setMinimumSize(QSize(120, 27))
        self.reset_all_data_2.setMaximumSize(QSize(120, 27))
        self.reset_all_data_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.reset_all_data_2.setStyleSheet(u".SubCallButton{\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, st"
                        "op:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_58.addWidget(self.reset_all_data_2)

        self.x_data_reset1_2 = SubCallButton(self.widget_20)
        self.x_data_reset1_2.setObjectName(u"x_data_reset1_2")
        sizePolicy4.setHeightForWidth(self.x_data_reset1_2.sizePolicy().hasHeightForWidth())
        self.x_data_reset1_2.setSizePolicy(sizePolicy4)
        self.x_data_reset1_2.setMinimumSize(QSize(110, 27))
        self.x_data_reset1_2.setMaximumSize(QSize(110, 27))
        self.x_data_reset1_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.x_data_reset1_2.setStyleSheet(u".SubCallButton{\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, st"
                        "op:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_58.addWidget(self.x_data_reset1_2)

        self.y_data_reset1_2 = SubCallButton(self.widget_20)
        self.y_data_reset1_2.setObjectName(u"y_data_reset1_2")
        sizePolicy4.setHeightForWidth(self.y_data_reset1_2.sizePolicy().hasHeightForWidth())
        self.y_data_reset1_2.setSizePolicy(sizePolicy4)
        self.y_data_reset1_2.setMinimumSize(QSize(110, 27))
        self.y_data_reset1_2.setMaximumSize(QSize(110, 27))
        self.y_data_reset1_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.y_data_reset1_2.setStyleSheet(u"SubCallButton{\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-top-right-radius: 5px;\n"
"    border-bottom-right-radius: 5px;\n"
"  	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop"
                        ":0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_58.addWidget(self.y_data_reset1_2)


        self.verticalLayout_43.addWidget(self.widget_20)

        self.verticalLayout_44 = QVBoxLayout()
        self.verticalLayout_44.setSpacing(6)
        self.verticalLayout_44.setObjectName(u"verticalLayout_44")
        self.verticalLayout_44.setContentsMargins(-1, 0, 9, 3)
        self.horizontalLayout_167 = QHBoxLayout()
        self.horizontalLayout_167.setObjectName(u"horizontalLayout_167")
        self.horizontalLayout_167.setContentsMargins(1, 1, 1, 1)
        self.label_119 = QLabel(self.widget_45)
        self.label_119.setObjectName(u"label_119")
        sizePolicy7.setHeightForWidth(self.label_119.sizePolicy().hasHeightForWidth())
        self.label_119.setSizePolicy(sizePolicy7)
        self.label_119.setMinimumSize(QSize(0, 31))
        self.label_119.setMaximumSize(QSize(16777215, 31))
        self.label_119.setStyleSheet(u"")
        self.label_119.setFrameShape(QFrame.Shape.NoFrame)
        self.label_119.setLineWidth(0)
        self.label_119.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_119.setIndent(0)

        self.horizontalLayout_167.addWidget(self.label_119)

        self.x_minus_probed_position_2 = StatusLabel(self.widget_45)
        self.x_minus_probed_position_2.setObjectName(u"x_minus_probed_position_2")
        sizePolicy4.setHeightForWidth(self.x_minus_probed_position_2.sizePolicy().hasHeightForWidth())
        self.x_minus_probed_position_2.setSizePolicy(sizePolicy4)
        self.x_minus_probed_position_2.setMinimumSize(QSize(80, 31))
        self.x_minus_probed_position_2.setMaximumSize(QSize(80, 31))
        self.x_minus_probed_position_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.x_minus_probed_position_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_167.addWidget(self.x_minus_probed_position_2)

        self.label_120 = QLabel(self.widget_45)
        self.label_120.setObjectName(u"label_120")
        sizePolicy4.setHeightForWidth(self.label_120.sizePolicy().hasHeightForWidth())
        self.label_120.setSizePolicy(sizePolicy4)
        self.label_120.setMinimumSize(QSize(80, 31))
        self.label_120.setMaximumSize(QSize(80, 31))
        self.label_120.setStyleSheet(u"")
        self.label_120.setFrameShape(QFrame.Shape.NoFrame)
        self.label_120.setLineWidth(0)
        self.label_120.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_120.setIndent(0)

        self.horizontalLayout_167.addWidget(self.label_120)

        self.x_plus_probed_position_2 = StatusLabel(self.widget_45)
        self.x_plus_probed_position_2.setObjectName(u"x_plus_probed_position_2")
        sizePolicy4.setHeightForWidth(self.x_plus_probed_position_2.sizePolicy().hasHeightForWidth())
        self.x_plus_probed_position_2.setSizePolicy(sizePolicy4)
        self.x_plus_probed_position_2.setMinimumSize(QSize(80, 31))
        self.x_plus_probed_position_2.setMaximumSize(QSize(80, 31))
        self.x_plus_probed_position_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.x_plus_probed_position_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_167.addWidget(self.x_plus_probed_position_2)

        self.label_121 = QLabel(self.widget_45)
        self.label_121.setObjectName(u"label_121")
        sizePolicy4.setHeightForWidth(self.label_121.sizePolicy().hasHeightForWidth())
        self.label_121.setSizePolicy(sizePolicy4)
        self.label_121.setMinimumSize(QSize(80, 31))
        self.label_121.setMaximumSize(QSize(80, 31))
        self.label_121.setStyleSheet(u"")
        self.label_121.setLineWidth(0)
        self.label_121.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_121.setIndent(0)

        self.horizontalLayout_167.addWidget(self.label_121)

        self.x_probed_width_2 = StatusLabel(self.widget_45)
        self.x_probed_width_2.setObjectName(u"x_probed_width_2")
        sizePolicy4.setHeightForWidth(self.x_probed_width_2.sizePolicy().hasHeightForWidth())
        self.x_probed_width_2.setSizePolicy(sizePolicy4)
        self.x_probed_width_2.setMinimumSize(QSize(80, 31))
        self.x_probed_width_2.setMaximumSize(QSize(80, 31))
        self.x_probed_width_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.x_probed_width_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_167.addWidget(self.x_probed_width_2)


        self.verticalLayout_44.addLayout(self.horizontalLayout_167)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.horizontalLayout_30.setContentsMargins(1, 1, 1, 1)
        self.label_122 = QLabel(self.widget_45)
        self.label_122.setObjectName(u"label_122")
        sizePolicy7.setHeightForWidth(self.label_122.sizePolicy().hasHeightForWidth())
        self.label_122.setSizePolicy(sizePolicy7)
        self.label_122.setMinimumSize(QSize(0, 31))
        self.label_122.setMaximumSize(QSize(16777215, 31))
        self.label_122.setStyleSheet(u"")
        self.label_122.setLineWidth(0)
        self.label_122.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_122.setIndent(0)

        self.horizontalLayout_30.addWidget(self.label_122)

        self.y_minus_probed_position_2 = StatusLabel(self.widget_45)
        self.y_minus_probed_position_2.setObjectName(u"y_minus_probed_position_2")
        sizePolicy4.setHeightForWidth(self.y_minus_probed_position_2.sizePolicy().hasHeightForWidth())
        self.y_minus_probed_position_2.setSizePolicy(sizePolicy4)
        self.y_minus_probed_position_2.setMinimumSize(QSize(80, 31))
        self.y_minus_probed_position_2.setMaximumSize(QSize(80, 31))
        self.y_minus_probed_position_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.y_minus_probed_position_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_30.addWidget(self.y_minus_probed_position_2)

        self.label_123 = QLabel(self.widget_45)
        self.label_123.setObjectName(u"label_123")
        sizePolicy4.setHeightForWidth(self.label_123.sizePolicy().hasHeightForWidth())
        self.label_123.setSizePolicy(sizePolicy4)
        self.label_123.setMinimumSize(QSize(80, 31))
        self.label_123.setMaximumSize(QSize(80, 31))
        self.label_123.setStyleSheet(u"")
        self.label_123.setLineWidth(0)
        self.label_123.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_123.setIndent(0)

        self.horizontalLayout_30.addWidget(self.label_123)

        self.y_plus_probed_position_2 = StatusLabel(self.widget_45)
        self.y_plus_probed_position_2.setObjectName(u"y_plus_probed_position_2")
        sizePolicy4.setHeightForWidth(self.y_plus_probed_position_2.sizePolicy().hasHeightForWidth())
        self.y_plus_probed_position_2.setSizePolicy(sizePolicy4)
        self.y_plus_probed_position_2.setMinimumSize(QSize(80, 31))
        self.y_plus_probed_position_2.setMaximumSize(QSize(80, 31))
        self.y_plus_probed_position_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.y_plus_probed_position_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_30.addWidget(self.y_plus_probed_position_2)

        self.label_124 = QLabel(self.widget_45)
        self.label_124.setObjectName(u"label_124")
        sizePolicy4.setHeightForWidth(self.label_124.sizePolicy().hasHeightForWidth())
        self.label_124.setSizePolicy(sizePolicy4)
        self.label_124.setMinimumSize(QSize(80, 31))
        self.label_124.setMaximumSize(QSize(80, 31))
        self.label_124.setStyleSheet(u"")
        self.label_124.setLineWidth(0)
        self.label_124.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_124.setIndent(0)

        self.horizontalLayout_30.addWidget(self.label_124)

        self.y_probed_width_2 = StatusLabel(self.widget_45)
        self.y_probed_width_2.setObjectName(u"y_probed_width_2")
        sizePolicy4.setHeightForWidth(self.y_probed_width_2.sizePolicy().hasHeightForWidth())
        self.y_probed_width_2.setSizePolicy(sizePolicy4)
        self.y_probed_width_2.setMinimumSize(QSize(80, 31))
        self.y_probed_width_2.setMaximumSize(QSize(80, 31))
        self.y_probed_width_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.y_probed_width_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_30.addWidget(self.y_probed_width_2)


        self.verticalLayout_44.addLayout(self.horizontalLayout_30)

        self.horizontalLayout_168 = QHBoxLayout()
        self.horizontalLayout_168.setObjectName(u"horizontalLayout_168")
        self.horizontalLayout_168.setContentsMargins(1, 1, 1, 1)
        self.label_125 = QLabel(self.widget_45)
        self.label_125.setObjectName(u"label_125")
        sizePolicy7.setHeightForWidth(self.label_125.sizePolicy().hasHeightForWidth())
        self.label_125.setSizePolicy(sizePolicy7)
        self.label_125.setMinimumSize(QSize(0, 31))
        self.label_125.setMaximumSize(QSize(16777215, 31))
        self.label_125.setStyleSheet(u"")
        self.label_125.setLineWidth(0)
        self.label_125.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_125.setIndent(0)

        self.horizontalLayout_168.addWidget(self.label_125)

        self.z_minus_probed_position_2 = StatusLabel(self.widget_45)
        self.z_minus_probed_position_2.setObjectName(u"z_minus_probed_position_2")
        sizePolicy4.setHeightForWidth(self.z_minus_probed_position_2.sizePolicy().hasHeightForWidth())
        self.z_minus_probed_position_2.setSizePolicy(sizePolicy4)
        self.z_minus_probed_position_2.setMinimumSize(QSize(80, 31))
        self.z_minus_probed_position_2.setMaximumSize(QSize(80, 31))
        self.z_minus_probed_position_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.z_minus_probed_position_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.z_minus_probed_position_2.setMargin(2)

        self.horizontalLayout_168.addWidget(self.z_minus_probed_position_2)

        self.label_126 = QLabel(self.widget_45)
        self.label_126.setObjectName(u"label_126")
        sizePolicy4.setHeightForWidth(self.label_126.sizePolicy().hasHeightForWidth())
        self.label_126.setSizePolicy(sizePolicy4)
        self.label_126.setMinimumSize(QSize(80, 31))
        self.label_126.setMaximumSize(QSize(80, 31))
        self.label_126.setStyleSheet(u"")
        self.label_126.setLineWidth(0)
        self.label_126.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_126.setIndent(0)

        self.horizontalLayout_168.addWidget(self.label_126)

        self.averaged_diam_2 = StatusLabel(self.widget_45)
        self.averaged_diam_2.setObjectName(u"averaged_diam_2")
        sizePolicy4.setHeightForWidth(self.averaged_diam_2.sizePolicy().hasHeightForWidth())
        self.averaged_diam_2.setSizePolicy(sizePolicy4)
        self.averaged_diam_2.setMinimumSize(QSize(80, 31))
        self.averaged_diam_2.setMaximumSize(QSize(80, 31))
        self.averaged_diam_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.averaged_diam_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_168.addWidget(self.averaged_diam_2)

        self.label_127 = QLabel(self.widget_45)
        self.label_127.setObjectName(u"label_127")
        sizePolicy4.setHeightForWidth(self.label_127.sizePolicy().hasHeightForWidth())
        self.label_127.setSizePolicy(sizePolicy4)
        self.label_127.setMinimumSize(QSize(80, 31))
        self.label_127.setMaximumSize(QSize(80, 31))
        self.label_127.setStyleSheet(u"")
        self.label_127.setLineWidth(0)
        self.label_127.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_127.setIndent(0)

        self.horizontalLayout_168.addWidget(self.label_127)

        self.x_center_probed_2 = StatusLabel(self.widget_45)
        self.x_center_probed_2.setObjectName(u"x_center_probed_2")
        sizePolicy4.setHeightForWidth(self.x_center_probed_2.sizePolicy().hasHeightForWidth())
        self.x_center_probed_2.setSizePolicy(sizePolicy4)
        self.x_center_probed_2.setMinimumSize(QSize(80, 31))
        self.x_center_probed_2.setMaximumSize(QSize(80, 31))
        self.x_center_probed_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.x_center_probed_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.x_center_probed_2.setMargin(2)

        self.horizontalLayout_168.addWidget(self.x_center_probed_2)


        self.verticalLayout_44.addLayout(self.horizontalLayout_168)

        self.horizontalLayout_169 = QHBoxLayout()
        self.horizontalLayout_169.setObjectName(u"horizontalLayout_169")
        self.horizontalLayout_169.setContentsMargins(1, 1, 1, 1)
        self.label_128 = QLabel(self.widget_45)
        self.label_128.setObjectName(u"label_128")
        sizePolicy7.setHeightForWidth(self.label_128.sizePolicy().hasHeightForWidth())
        self.label_128.setSizePolicy(sizePolicy7)
        self.label_128.setMinimumSize(QSize(0, 31))
        self.label_128.setMaximumSize(QSize(16777215, 31))
        self.label_128.setStyleSheet(u"")
        self.label_128.setLineWidth(0)
        self.label_128.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_128.setIndent(0)

        self.horizontalLayout_169.addWidget(self.label_128)

        self.edge_delta_2 = StatusLabel(self.widget_45)
        self.edge_delta_2.setObjectName(u"edge_delta_2")
        sizePolicy4.setHeightForWidth(self.edge_delta_2.sizePolicy().hasHeightForWidth())
        self.edge_delta_2.setSizePolicy(sizePolicy4)
        self.edge_delta_2.setMinimumSize(QSize(80, 31))
        self.edge_delta_2.setMaximumSize(QSize(80, 31))
        self.edge_delta_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.edge_delta_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_169.addWidget(self.edge_delta_2)

        self.label_129 = QLabel(self.widget_45)
        self.label_129.setObjectName(u"label_129")
        sizePolicy4.setHeightForWidth(self.label_129.sizePolicy().hasHeightForWidth())
        self.label_129.setSizePolicy(sizePolicy4)
        self.label_129.setMinimumSize(QSize(80, 31))
        self.label_129.setMaximumSize(QSize(80, 31))
        self.label_129.setStyleSheet(u"")
        self.label_129.setLineWidth(0)
        self.label_129.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_129.setIndent(0)

        self.horizontalLayout_169.addWidget(self.label_129)

        self.edge_angle_2 = StatusLabel(self.widget_45)
        self.edge_angle_2.setObjectName(u"edge_angle_2")
        sizePolicy4.setHeightForWidth(self.edge_angle_2.sizePolicy().hasHeightForWidth())
        self.edge_angle_2.setSizePolicy(sizePolicy4)
        self.edge_angle_2.setMinimumSize(QSize(80, 31))
        self.edge_angle_2.setMaximumSize(QSize(80, 31))
        self.edge_angle_2.setMouseTracking(True)
        self.edge_angle_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.edge_angle_2.setTextFormat(Qt.TextFormat.RichText)
        self.edge_angle_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_169.addWidget(self.edge_angle_2)

        self.label_130 = QLabel(self.widget_45)
        self.label_130.setObjectName(u"label_130")
        sizePolicy4.setHeightForWidth(self.label_130.sizePolicy().hasHeightForWidth())
        self.label_130.setSizePolicy(sizePolicy4)
        self.label_130.setMinimumSize(QSize(80, 31))
        self.label_130.setMaximumSize(QSize(80, 31))
        self.label_130.setStyleSheet(u"QLabel{\n"
"}")
        self.label_130.setLineWidth(0)
        self.label_130.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_130.setIndent(0)

        self.horizontalLayout_169.addWidget(self.label_130)

        self.y_center_probed_2 = StatusLabel(self.widget_45)
        self.y_center_probed_2.setObjectName(u"y_center_probed_2")
        sizePolicy4.setHeightForWidth(self.y_center_probed_2.sizePolicy().hasHeightForWidth())
        self.y_center_probed_2.setSizePolicy(sizePolicy4)
        self.y_center_probed_2.setMinimumSize(QSize(80, 31))
        self.y_center_probed_2.setMaximumSize(QSize(80, 31))
        self.y_center_probed_2.setStyleSheet(u"QLabel {\n"
"    border-style: transparent;\n"
"    border-color: rgb(134, 136, 138);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: black;\n"
"    background: white;\n"
"}")
        self.y_center_probed_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.y_center_probed_2.setMargin(2)

        self.horizontalLayout_169.addWidget(self.y_center_probed_2)


        self.verticalLayout_44.addLayout(self.horizontalLayout_169)


        self.verticalLayout_43.addLayout(self.verticalLayout_44)

        self.mdi_entry_box_6 = MDIEntry(self.widget_45)
        self.mdi_entry_box_6.setObjectName(u"mdi_entry_box_6")
        self.mdi_entry_box_6.setMinimumSize(QSize(0, 42))
        self.mdi_entry_box_6.setMaximumSize(QSize(16777215, 42))
        font9 = QFont()
        font9.setFamilies([u"Bebas Kai"])
        font9.setPointSize(15)
        font9.setBold(False)
        font9.setItalic(False)
        self.mdi_entry_box_6.setFont(font9)
        self.mdi_entry_box_6.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self.verticalLayout_43.addWidget(self.mdi_entry_box_6)


        self.horizontalLayout_22.addWidget(self.widget_45)

        self.widget_13 = QWidget(self.tab_6)
        self.widget_13.setObjectName(u"widget_13")
        self.verticalLayout_45 = QVBoxLayout(self.widget_13)
        self.verticalLayout_45.setObjectName(u"verticalLayout_45")
        self.verticalLayout_45.setContentsMargins(0, 0, 0, 0)
        self.probe_group_select = QWidget(self.widget_13)
        self.probe_group_select.setObjectName(u"probe_group_select")
        self.probe_group_select.setStyleSheet(u"")
        self.horizontalLayout_31 = QHBoxLayout(self.probe_group_select)
        self.horizontalLayout_31.setSpacing(0)
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.horizontalLayout_31.setContentsMargins(20, 3, 20, 6)
        self.outside_corners = QPushButton(self.probe_group_select)
        self.probeTabGroup = QButtonGroup(MainWindow)
        self.probeTabGroup.setObjectName(u"probeTabGroup")
        self.probeTabGroup.addButton(self.outside_corners)
        self.outside_corners.setObjectName(u"outside_corners")
        self.outside_corners.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.outside_corners.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 2px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 4px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 4px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.outside_corners.setCheckable(True)
        self.outside_corners.setChecked(True)
        self.outside_corners.setAutoExclusive(True)
        self.outside_corners.setProperty(u"page", 0)

        self.horizontalLayout_31.addWidget(self.outside_corners)

        self.inside_corners = QPushButton(self.probe_group_select)
        self.probeTabGroup.addButton(self.inside_corners)
        self.inside_corners.setObjectName(u"inside_corners")
        self.inside_corners.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.inside_corners.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.inside_corners.setCheckable(True)
        self.inside_corners.setAutoExclusive(True)
        self.inside_corners.setProperty(u"page", 1)

        self.horizontalLayout_31.addWidget(self.inside_corners)

        self.boss_and_pocket = QPushButton(self.probe_group_select)
        self.probeTabGroup.addButton(self.boss_and_pocket)
        self.boss_and_pocket.setObjectName(u"boss_and_pocket")
        self.boss_and_pocket.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.boss_and_pocket.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.boss_and_pocket.setCheckable(True)
        self.boss_and_pocket.setAutoExclusive(True)
        self.boss_and_pocket.setProperty(u"page", 2)

        self.horizontalLayout_31.addWidget(self.boss_and_pocket)

        self.ridge_and_valley = QPushButton(self.probe_group_select)
        self.probeTabGroup.addButton(self.ridge_and_valley)
        self.ridge_and_valley.setObjectName(u"ridge_and_valley")
        self.ridge_and_valley.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.ridge_and_valley.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.ridge_and_valley.setCheckable(True)
        self.ridge_and_valley.setAutoExclusive(True)
        self.ridge_and_valley.setProperty(u"page", 3)

        self.horizontalLayout_31.addWidget(self.ridge_and_valley)

        self.rotation_angle = QPushButton(self.probe_group_select)
        self.probeTabGroup.addButton(self.rotation_angle)
        self.rotation_angle.setObjectName(u"rotation_angle")
        self.rotation_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.rotation_angle.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.rotation_angle.setCheckable(True)
        self.rotation_angle.setAutoExclusive(True)
        self.rotation_angle.setProperty(u"page", 4)

        self.horizontalLayout_31.addWidget(self.rotation_angle)

        self.rotary_axis_2 = QPushButton(self.probe_group_select)
        self.probeTabGroup.addButton(self.rotary_axis_2)
        self.rotary_axis_2.setObjectName(u"rotary_axis_2")
        self.rotary_axis_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.rotary_axis_2.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.rotary_axis_2.setCheckable(True)
        self.rotary_axis_2.setAutoExclusive(True)
        self.rotary_axis_2.setProperty(u"page", 5)

        self.horizontalLayout_31.addWidget(self.rotary_axis_2)

        self.calibrate = QPushButton(self.probe_group_select)
        self.probeTabGroup.addButton(self.calibrate)
        self.calibrate.setObjectName(u"calibrate")
        self.calibrate.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.calibrate.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.calibrate.setCheckable(True)
        self.calibrate.setAutoExclusive(True)
        self.calibrate.setProperty(u"page", 6)

        self.horizontalLayout_31.addWidget(self.calibrate)

        self.probe_help = QPushButton(self.probe_group_select)
        self.probeTabGroup.addButton(self.probe_help)
        self.probe_help.setObjectName(u"probe_help")
        self.probe_help.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_help.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 2px;\n"
"    border-left-width: 1px;\n"
"    min-width: 10ex;\n"
"    min-height: 25;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 4px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 4px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 25"
                        "5), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.probe_help.setCheckable(True)
        self.probe_help.setAutoExclusive(True)
        self.probe_help.setProperty(u"page", 7)

        self.horizontalLayout_31.addWidget(self.probe_help)


        self.verticalLayout_45.addWidget(self.probe_group_select)

        self.widget_11 = QWidget(self.widget_13)
        self.widget_11.setObjectName(u"widget_11")
        self.horizontalLayout_32 = QHBoxLayout(self.widget_11)
        self.horizontalLayout_32.setObjectName(u"horizontalLayout_32")
        self.widget_62 = QWidget(self.widget_11)
        self.widget_62.setObjectName(u"widget_62")
        sizePolicy3.setHeightForWidth(self.widget_62.sizePolicy().hasHeightForWidth())
        self.widget_62.setSizePolicy(sizePolicy3)
        self.widget_62.setMinimumSize(QSize(380, 0))
        self.label_19 = QLabel(self.widget_62)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setGeometry(QRect(159, 43, 128, 450))
        sizePolicy1.setHeightForWidth(self.label_19.sizePolicy().hasHeightForWidth())
        self.label_19.setSizePolicy(sizePolicy1)
        self.label_19.setPixmap(QPixmap(u":/images/touch_probe.png"))
        self.label_19.setScaledContents(True)
        self.probe_led = HalLedIndicator(self.widget_62)
        self.probe_led.setObjectName(u"probe_led")
        self.probe_led.setGeometry(QRect(213, 333, 20, 20))
        sizePolicy4.setHeightForWidth(self.probe_led.sizePolicy().hasHeightForWidth())
        self.probe_led.setSizePolicy(sizePolicy4)
        self.probe_led.setProperty(u"diameter", 20)
        self.probe_led.setProperty(u"color", QColor(44, 41, 255))
        self.probe_led.setProperty(u"state", False)
        self.halbutton = HalButton(self.widget_62)
        self.halbutton.setObjectName(u"halbutton")
        self.halbutton.setGeometry(QRect(182, 450, 80, 70))
        sizePolicy4.setHeightForWidth(self.halbutton.sizePolicy().hasHeightForWidth())
        self.halbutton.setSizePolicy(sizePolicy4)
        self.halbutton.setStyleSheet(u".HalButton{\n"
"background: transparent;\n"
"border: none;\n"
"}")
        self.halbutton.setFlat(False)

        self.horizontalLayout_32.addWidget(self.widget_62)

        self.verticalLayout_10 = QVBoxLayout()
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(-1, 0, -1, 9)
        self.probe_tab_widget = QStackedWidget(self.widget_11)
        self.probe_tab_widget.setObjectName(u"probe_tab_widget")
        sizePolicy9 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy9.setHorizontalStretch(3)
        sizePolicy9.setVerticalStretch(0)
        sizePolicy9.setHeightForWidth(self.probe_tab_widget.sizePolicy().hasHeightForWidth())
        self.probe_tab_widget.setSizePolicy(sizePolicy9)
        self.probe_tab_widget.setMinimumSize(QSize(550, 0))
        font10 = QFont()
        font10.setFamilies([u"Bebas Kai"])
        font10.setPointSize(13)
        font10.setBold(True)
        self.probe_tab_widget.setFont(font10)
        self.probe_tab_widget.setStyleSheet(u"")
        self.Page1 = QWidget()
        self.Page1.setObjectName(u"Page1")
        self.horizontalLayout_132 = QHBoxLayout(self.Page1)
        self.horizontalLayout_132.setObjectName(u"horizontalLayout_132")
        self.widget_40 = QWidget(self.Page1)
        self.widget_40.setObjectName(u"widget_40")
        sizePolicy4.setHeightForWidth(self.widget_40.sizePolicy().hasHeightForWidth())
        self.widget_40.setSizePolicy(sizePolicy4)
        self.widget_40.setMinimumSize(QSize(465, 465))
        self.widget_40.setMaximumSize(QSize(465, 465))
        self.widget_40.setStyleSheet(u"")
        self.gridLayout_7 = QGridLayout(self.widget_40)
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.probe_back_left_top_corner = SubCallButton(self.widget_40)
        self.probe_back_left_top_corner.setObjectName(u"probe_back_left_top_corner")
        sizePolicy4.setHeightForWidth(self.probe_back_left_top_corner.sizePolicy().hasHeightForWidth())
        self.probe_back_left_top_corner.setSizePolicy(sizePolicy4)
        self.probe_back_left_top_corner.setMinimumSize(QSize(140, 140))
        self.probe_back_left_top_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon5 = QIcon()
        icon5.addFile(u":/images/back_left_outside_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_back_left_top_corner.setIcon(icon5)
        self.probe_back_left_top_corner.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_back_left_top_corner, 0, 0, 1, 1)

        self.probe_back_right_top_corner = SubCallButton(self.widget_40)
        self.probe_back_right_top_corner.setObjectName(u"probe_back_right_top_corner")
        sizePolicy4.setHeightForWidth(self.probe_back_right_top_corner.sizePolicy().hasHeightForWidth())
        self.probe_back_right_top_corner.setSizePolicy(sizePolicy4)
        self.probe_back_right_top_corner.setMinimumSize(QSize(140, 140))
        self.probe_back_right_top_corner.setMaximumSize(QSize(140, 140))
        self.probe_back_right_top_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_back_right_top_corner.setStyleSheet(u"")
        icon6 = QIcon()
        icon6.addFile(u":/images/back_right_outside_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_back_right_top_corner.setIcon(icon6)
        self.probe_back_right_top_corner.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_back_right_top_corner, 0, 4, 1, 1)

        self.probe_right_top_side = SubCallButton(self.widget_40)
        self.probe_right_top_side.setObjectName(u"probe_right_top_side")
        sizePolicy4.setHeightForWidth(self.probe_right_top_side.sizePolicy().hasHeightForWidth())
        self.probe_right_top_side.setSizePolicy(sizePolicy4)
        self.probe_right_top_side.setMinimumSize(QSize(140, 140))
        self.probe_right_top_side.setMaximumSize(QSize(140, 140))
        self.probe_right_top_side.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_right_top_side.setStyleSheet(u"")
        icon7 = QIcon()
        icon7.addFile(u":/images/right_side_edge.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        icon7.addFile(u":/images/right_side_edge.png", QSize(), QIcon.Mode.Normal, QIcon.State.On)
        self.probe_right_top_side.setIcon(icon7)
        self.probe_right_top_side.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_right_top_side, 1, 4, 1, 1)

        self.probe_z_minus_wco_edge = SubCallButton(self.widget_40)
        self.probe_z_minus_wco_edge.setObjectName(u"probe_z_minus_wco_edge")
        sizePolicy4.setHeightForWidth(self.probe_z_minus_wco_edge.sizePolicy().hasHeightForWidth())
        self.probe_z_minus_wco_edge.setSizePolicy(sizePolicy4)
        self.probe_z_minus_wco_edge.setMinimumSize(QSize(140, 140))
        self.probe_z_minus_wco_edge.setMaximumSize(QSize(140, 140))
        self.probe_z_minus_wco_edge.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_z_minus_wco_edge.setStyleSheet(u"")
        icon8 = QIcon()
        icon8.addFile(u":/images/z_top.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_z_minus_wco_edge.setIcon(icon8)
        self.probe_z_minus_wco_edge.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_z_minus_wco_edge, 1, 3, 1, 1)

        self.probe_front_top_side = SubCallButton(self.widget_40)
        self.probe_front_top_side.setObjectName(u"probe_front_top_side")
        sizePolicy4.setHeightForWidth(self.probe_front_top_side.sizePolicy().hasHeightForWidth())
        self.probe_front_top_side.setSizePolicy(sizePolicy4)
        self.probe_front_top_side.setMinimumSize(QSize(140, 140))
        self.probe_front_top_side.setMaximumSize(QSize(140, 140))
        self.probe_front_top_side.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_front_top_side.setStyleSheet(u"")
        icon9 = QIcon()
        icon9.addFile(u":/images/front_middle_edge.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_front_top_side.setIcon(icon9)
        self.probe_front_top_side.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_front_top_side, 2, 3, 1, 1)

        self.probe_back_top_side = SubCallButton(self.widget_40)
        self.probe_back_top_side.setObjectName(u"probe_back_top_side")
        sizePolicy4.setHeightForWidth(self.probe_back_top_side.sizePolicy().hasHeightForWidth())
        self.probe_back_top_side.setSizePolicy(sizePolicy4)
        self.probe_back_top_side.setMinimumSize(QSize(140, 140))
        self.probe_back_top_side.setMaximumSize(QSize(140, 140))
        self.probe_back_top_side.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_back_top_side.setStyleSheet(u"")
        icon10 = QIcon()
        icon10.addFile(u":/images/back_middle_outside_edge.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_back_top_side.setIcon(icon10)
        self.probe_back_top_side.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_back_top_side, 0, 3, 1, 1)

        self.probe_front_left_top_corner = SubCallButton(self.widget_40)
        self.probe_front_left_top_corner.setObjectName(u"probe_front_left_top_corner")
        sizePolicy4.setHeightForWidth(self.probe_front_left_top_corner.sizePolicy().hasHeightForWidth())
        self.probe_front_left_top_corner.setSizePolicy(sizePolicy4)
        self.probe_front_left_top_corner.setMinimumSize(QSize(140, 140))
        self.probe_front_left_top_corner.setMaximumSize(QSize(140, 140))
        self.probe_front_left_top_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_front_left_top_corner.setStyleSheet(u"")
        icon11 = QIcon()
        icon11.addFile(u":/images/front_left_outside_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_front_left_top_corner.setIcon(icon11)
        self.probe_front_left_top_corner.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_front_left_top_corner, 2, 0, 1, 1)

        self.probe_front_right_top_corner = SubCallButton(self.widget_40)
        self.probe_front_right_top_corner.setObjectName(u"probe_front_right_top_corner")
        sizePolicy4.setHeightForWidth(self.probe_front_right_top_corner.sizePolicy().hasHeightForWidth())
        self.probe_front_right_top_corner.setSizePolicy(sizePolicy4)
        self.probe_front_right_top_corner.setMinimumSize(QSize(140, 140))
        self.probe_front_right_top_corner.setMaximumSize(QSize(140, 140))
        self.probe_front_right_top_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_front_right_top_corner.setStyleSheet(u"")
        icon12 = QIcon()
        icon12.addFile(u":/images/front_right_outside_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_front_right_top_corner.setIcon(icon12)
        self.probe_front_right_top_corner.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_front_right_top_corner, 2, 4, 1, 1)

        self.probe_left_top_side = SubCallButton(self.widget_40)
        self.probe_left_top_side.setObjectName(u"probe_left_top_side")
        sizePolicy4.setHeightForWidth(self.probe_left_top_side.sizePolicy().hasHeightForWidth())
        self.probe_left_top_side.setSizePolicy(sizePolicy4)
        self.probe_left_top_side.setMinimumSize(QSize(140, 140))
        self.probe_left_top_side.setMaximumSize(QSize(140, 140))
        self.probe_left_top_side.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_left_top_side.setStyleSheet(u"")
        icon13 = QIcon()
        icon13.addFile(u":/images/left_side_edge.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_left_top_side.setIcon(icon13)
        self.probe_left_top_side.setIconSize(QSize(130, 130))

        self.gridLayout_7.addWidget(self.probe_left_top_side, 1, 0, 1, 1)


        self.horizontalLayout_132.addWidget(self.widget_40)

        self.probe_tab_widget.addWidget(self.Page1)
        self.Page2 = QWidget()
        self.Page2.setObjectName(u"Page2")
        self.horizontalLayout_135 = QHBoxLayout(self.Page2)
        self.horizontalLayout_135.setObjectName(u"horizontalLayout_135")
        self.widget_41 = QWidget(self.Page2)
        self.widget_41.setObjectName(u"widget_41")
        sizePolicy4.setHeightForWidth(self.widget_41.sizePolicy().hasHeightForWidth())
        self.widget_41.setSizePolicy(sizePolicy4)
        self.widget_41.setMinimumSize(QSize(465, 465))
        self.widget_41.setMaximumSize(QSize(465, 465))
        self.widget_41.setStyleSheet(u"QFrame {\n"
"    border: none;\n"
"}")
        self.gridLayout_16 = QGridLayout(self.widget_41)
        self.gridLayout_16.setObjectName(u"gridLayout_16")
        self.probe_front_right_inside_corner = SubCallButton(self.widget_41)
        self.probe_front_right_inside_corner.setObjectName(u"probe_front_right_inside_corner")
        sizePolicy4.setHeightForWidth(self.probe_front_right_inside_corner.sizePolicy().hasHeightForWidth())
        self.probe_front_right_inside_corner.setSizePolicy(sizePolicy4)
        self.probe_front_right_inside_corner.setMinimumSize(QSize(140, 140))
        self.probe_front_right_inside_corner.setMaximumSize(QSize(140, 140))
        self.probe_front_right_inside_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon14 = QIcon()
        icon14.addFile(u":/images/inside_front_right_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_front_right_inside_corner.setIcon(icon14)
        self.probe_front_right_inside_corner.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_front_right_inside_corner, 3, 4, 1, 1)

        self.probe_y_plus_wco = SubCallButton(self.widget_41)
        self.probe_y_plus_wco.setObjectName(u"probe_y_plus_wco")
        sizePolicy4.setHeightForWidth(self.probe_y_plus_wco.sizePolicy().hasHeightForWidth())
        self.probe_y_plus_wco.setSizePolicy(sizePolicy4)
        self.probe_y_plus_wco.setMinimumSize(QSize(140, 140))
        self.probe_y_plus_wco.setMaximumSize(QSize(140, 140))
        self.probe_y_plus_wco.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon15 = QIcon()
        icon15.addFile(u":/images/y_plus.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_y_plus_wco.setIcon(icon15)
        self.probe_y_plus_wco.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_y_plus_wco, 0, 3, 1, 1)

        self.probe_back_right_inside_corner = SubCallButton(self.widget_41)
        self.probe_back_right_inside_corner.setObjectName(u"probe_back_right_inside_corner")
        sizePolicy4.setHeightForWidth(self.probe_back_right_inside_corner.sizePolicy().hasHeightForWidth())
        self.probe_back_right_inside_corner.setSizePolicy(sizePolicy4)
        self.probe_back_right_inside_corner.setMinimumSize(QSize(140, 140))
        self.probe_back_right_inside_corner.setMaximumSize(QSize(140, 140))
        self.probe_back_right_inside_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon16 = QIcon()
        icon16.addFile(u":/images/inside_back_right_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_back_right_inside_corner.setIcon(icon16)
        self.probe_back_right_inside_corner.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_back_right_inside_corner, 0, 4, 1, 1)

        self.probe_front_left_inside_corner = SubCallButton(self.widget_41)
        self.probe_front_left_inside_corner.setObjectName(u"probe_front_left_inside_corner")
        sizePolicy4.setHeightForWidth(self.probe_front_left_inside_corner.sizePolicy().hasHeightForWidth())
        self.probe_front_left_inside_corner.setSizePolicy(sizePolicy4)
        self.probe_front_left_inside_corner.setMinimumSize(QSize(140, 140))
        self.probe_front_left_inside_corner.setMaximumSize(QSize(140, 140))
        self.probe_front_left_inside_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon17 = QIcon()
        icon17.addFile(u":/images/inside_front_left_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_front_left_inside_corner.setIcon(icon17)
        self.probe_front_left_inside_corner.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_front_left_inside_corner, 3, 0, 1, 1)

        self.probe_z_minus_wco_inside = SubCallButton(self.widget_41)
        self.probe_z_minus_wco_inside.setObjectName(u"probe_z_minus_wco_inside")
        sizePolicy4.setHeightForWidth(self.probe_z_minus_wco_inside.sizePolicy().hasHeightForWidth())
        self.probe_z_minus_wco_inside.setSizePolicy(sizePolicy4)
        self.probe_z_minus_wco_inside.setMinimumSize(QSize(140, 140))
        self.probe_z_minus_wco_inside.setMaximumSize(QSize(140, 140))
        self.probe_z_minus_wco_inside.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_z_minus_wco_inside.setIcon(icon8)
        self.probe_z_minus_wco_inside.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_z_minus_wco_inside, 1, 3, 1, 1)

        self.probe_back_left_inside_corner = SubCallButton(self.widget_41)
        self.probe_back_left_inside_corner.setObjectName(u"probe_back_left_inside_corner")
        sizePolicy4.setHeightForWidth(self.probe_back_left_inside_corner.sizePolicy().hasHeightForWidth())
        self.probe_back_left_inside_corner.setSizePolicy(sizePolicy4)
        self.probe_back_left_inside_corner.setMinimumSize(QSize(140, 140))
        self.probe_back_left_inside_corner.setMaximumSize(QSize(140, 140))
        self.probe_back_left_inside_corner.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon18 = QIcon()
        icon18.addFile(u":/images/inside_back_left_corner.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_back_left_inside_corner.setIcon(icon18)
        self.probe_back_left_inside_corner.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_back_left_inside_corner, 0, 0, 1, 1)

        self.probe_x_minus_wco = SubCallButton(self.widget_41)
        self.probe_x_minus_wco.setObjectName(u"probe_x_minus_wco")
        sizePolicy4.setHeightForWidth(self.probe_x_minus_wco.sizePolicy().hasHeightForWidth())
        self.probe_x_minus_wco.setSizePolicy(sizePolicy4)
        self.probe_x_minus_wco.setMinimumSize(QSize(140, 140))
        self.probe_x_minus_wco.setMaximumSize(QSize(140, 140))
        self.probe_x_minus_wco.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon19 = QIcon()
        icon19.addFile(u":/images/x_minus.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_x_minus_wco.setIcon(icon19)
        self.probe_x_minus_wco.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_x_minus_wco, 1, 0, 1, 1)

        self.probe_x_plus_wco = SubCallButton(self.widget_41)
        self.probe_x_plus_wco.setObjectName(u"probe_x_plus_wco")
        sizePolicy4.setHeightForWidth(self.probe_x_plus_wco.sizePolicy().hasHeightForWidth())
        self.probe_x_plus_wco.setSizePolicy(sizePolicy4)
        self.probe_x_plus_wco.setMinimumSize(QSize(140, 140))
        self.probe_x_plus_wco.setMaximumSize(QSize(140, 140))
        self.probe_x_plus_wco.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon20 = QIcon()
        icon20.addFile(u":/images/x_plus.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_x_plus_wco.setIcon(icon20)
        self.probe_x_plus_wco.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_x_plus_wco, 1, 4, 1, 1)

        self.probe_y_minus_wco = SubCallButton(self.widget_41)
        self.probe_y_minus_wco.setObjectName(u"probe_y_minus_wco")
        sizePolicy4.setHeightForWidth(self.probe_y_minus_wco.sizePolicy().hasHeightForWidth())
        self.probe_y_minus_wco.setSizePolicy(sizePolicy4)
        self.probe_y_minus_wco.setMinimumSize(QSize(140, 140))
        self.probe_y_minus_wco.setMaximumSize(QSize(140, 140))
        self.probe_y_minus_wco.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon21 = QIcon()
        icon21.addFile(u":/images/y_minus.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_y_minus_wco.setIcon(icon21)
        self.probe_y_minus_wco.setIconSize(QSize(125, 125))

        self.gridLayout_16.addWidget(self.probe_y_minus_wco, 3, 3, 1, 1)


        self.horizontalLayout_135.addWidget(self.widget_41)

        self.probe_tab_widget.addWidget(self.Page2)
        self.Page3 = QWidget()
        self.Page3.setObjectName(u"Page3")
        self.horizontalLayout_138 = QHBoxLayout(self.Page3)
        self.horizontalLayout_138.setObjectName(u"horizontalLayout_138")
        self.widget_42 = QWidget(self.Page3)
        self.widget_42.setObjectName(u"widget_42")
        sizePolicy4.setHeightForWidth(self.widget_42.sizePolicy().hasHeightForWidth())
        self.widget_42.setSizePolicy(sizePolicy4)
        self.widget_42.setMinimumSize(QSize(465, 461))
        self.widget_42.setMaximumSize(QSize(465, 461))
        self.widget_42.setStyleSheet(u"QFrame {\n"
"    border: none;\n"
"}")
        self.gridWidget_8 = QWidget(self.widget_42)
        self.gridWidget_8.setObjectName(u"gridWidget_8")
        self.gridWidget_8.setGeometry(QRect(53, 1, 364, 364))
        self.gridLayout_10 = QGridLayout(self.gridWidget_8)
        self.gridLayout_10.setSpacing(10)
        self.gridLayout_10.setObjectName(u"gridLayout_10")
        self.probe_round_boss = SubCallButton(self.gridWidget_8)
        self.probe_round_boss.setObjectName(u"probe_round_boss")
        self.probe_round_boss.setMinimumSize(QSize(170, 170))
        self.probe_round_boss.setMaximumSize(QSize(170, 170))
        self.probe_round_boss.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_round_boss.setStyleSheet(u"")
        icon22 = QIcon()
        icon22.addFile(u":/images/boss_round.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_round_boss.setIcon(icon22)
        self.probe_round_boss.setIconSize(QSize(170, 170))

        self.gridLayout_10.addWidget(self.probe_round_boss, 0, 0, 1, 1)

        self.probe_round_pocket = SubCallButton(self.gridWidget_8)
        self.probe_round_pocket.setObjectName(u"probe_round_pocket")
        self.probe_round_pocket.setMinimumSize(QSize(170, 170))
        self.probe_round_pocket.setMaximumSize(QSize(170, 170))
        self.probe_round_pocket.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_round_pocket.setStyleSheet(u"")
        icon23 = QIcon()
        icon23.addFile(u":/images/round_pocket.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_round_pocket.setIcon(icon23)
        self.probe_round_pocket.setIconSize(QSize(145, 145))

        self.gridLayout_10.addWidget(self.probe_round_pocket, 0, 1, 1, 1)

        self.probe_rect_boss = SubCallButton(self.gridWidget_8)
        self.probe_rect_boss.setObjectName(u"probe_rect_boss")
        self.probe_rect_boss.setMinimumSize(QSize(170, 170))
        self.probe_rect_boss.setMaximumSize(QSize(170, 170))
        self.probe_rect_boss.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_rect_boss.setStyleSheet(u"")
        icon24 = QIcon()
        icon24.addFile(u":/images/rect_boss.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_rect_boss.setIcon(icon24)
        self.probe_rect_boss.setIconSize(QSize(170, 170))

        self.gridLayout_10.addWidget(self.probe_rect_boss, 1, 0, 1, 1)

        self.probe_rect_pocket = SubCallButton(self.gridWidget_8)
        self.probe_rect_pocket.setObjectName(u"probe_rect_pocket")
        self.probe_rect_pocket.setMinimumSize(QSize(170, 170))
        self.probe_rect_pocket.setMaximumSize(QSize(170, 170))
        self.probe_rect_pocket.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_rect_pocket.setStyleSheet(u"")
        icon25 = QIcon()
        icon25.addFile(u":/images/rect_pocket.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_rect_pocket.setIcon(icon25)
        self.probe_rect_pocket.setIconSize(QSize(145, 145))

        self.gridLayout_10.addWidget(self.probe_rect_pocket, 1, 1, 1, 1)

        self.frame_8 = QFrame(self.widget_42)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setGeometry(QRect(3, 392, 460, 65))
        sizePolicy4.setHeightForWidth(self.frame_8.sizePolicy().hasHeightForWidth())
        self.frame_8.setSizePolicy(sizePolicy4)
        self.frame_8.setMinimumSize(QSize(460, 65))
        self.frame_8.setMaximumSize(QSize(460, 65))
        self.frame_8.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_49 = QHBoxLayout(self.frame_8)
        self.horizontalLayout_49.setObjectName(u"horizontalLayout_49")
        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setSpacing(0)
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.hint_label = QLabel(self.frame_8)
        self.hint_label.setObjectName(u"hint_label")
        self.hint_label.setMinimumSize(QSize(60, 40))
        self.hint_label.setMaximumSize(QSize(60, 40))
        self.hint_label.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(191, 191, 191);\n"
"    border-width: 1px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"}")
        self.hint_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_20.addWidget(self.hint_label)

        self.label_70 = QLabel(self.frame_8)
        self.label_70.setObjectName(u"label_70")
        self.label_70.setMinimumSize(QSize(50, 0))
        self.label_70.setMaximumSize(QSize(50, 16777215))
        self.label_70.setStyleSheet(u"QLabel{\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 1px;\n"
"padding-left: 5px;\n"
"}")
        self.label_70.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_70.setIndent(0)

        self.horizontalLayout_20.addWidget(self.label_70)

        self.diameter_hint = VCPLineEdit(self.frame_8)
        self.diameter_hint.setObjectName(u"diameter_hint")
        sizePolicy10 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy10.setHorizontalStretch(0)
        sizePolicy10.setVerticalStretch(0)
        sizePolicy10.setHeightForWidth(self.diameter_hint.sizePolicy().hasHeightForWidth())
        self.diameter_hint.setSizePolicy(sizePolicy10)
        self.diameter_hint.setMinimumSize(QSize(80, 40))
        self.diameter_hint.setMaximumSize(QSize(80, 40))
        self.diameter_hint.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.diameter_hint.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_20.addWidget(self.diameter_hint)

        self.label_71 = QLabel(self.frame_8)
        self.label_71.setObjectName(u"label_71")
        self.label_71.setMinimumSize(QSize(30, 0))
        self.label_71.setMaximumSize(QSize(30, 16777215))
        self.label_71.setStyleSheet(u"QLabel{\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 1px;\n"
"padding-left: 5px;\n"
"}")
        self.label_71.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_71.setIndent(0)

        self.horizontalLayout_20.addWidget(self.label_71)

        self.x_hint_0 = VCPLineEdit(self.frame_8)
        self.x_hint_0.setObjectName(u"x_hint_0")
        sizePolicy10.setHeightForWidth(self.x_hint_0.sizePolicy().hasHeightForWidth())
        self.x_hint_0.setSizePolicy(sizePolicy10)
        self.x_hint_0.setMinimumSize(QSize(80, 40))
        self.x_hint_0.setMaximumSize(QSize(80, 40))
        self.x_hint_0.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_hint_0.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_20.addWidget(self.x_hint_0)

        self.label_72 = QLabel(self.frame_8)
        self.label_72.setObjectName(u"label_72")
        self.label_72.setMinimumSize(QSize(30, 0))
        self.label_72.setMaximumSize(QSize(30, 16777215))
        self.label_72.setStyleSheet(u"QLabel{\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 1px;\n"
"padding-left: 5px;\n"
"}")
        self.label_72.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_72.setIndent(0)

        self.horizontalLayout_20.addWidget(self.label_72)

        self.y_hint_0 = VCPLineEdit(self.frame_8)
        self.y_hint_0.setObjectName(u"y_hint_0")
        sizePolicy10.setHeightForWidth(self.y_hint_0.sizePolicy().hasHeightForWidth())
        self.y_hint_0.setSizePolicy(sizePolicy10)
        self.y_hint_0.setMinimumSize(QSize(80, 40))
        self.y_hint_0.setMaximumSize(QSize(80, 40))
        self.y_hint_0.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.y_hint_0.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_20.addWidget(self.y_hint_0)


        self.horizontalLayout_49.addLayout(self.horizontalLayout_20)


        self.horizontalLayout_138.addWidget(self.widget_42)

        self.probe_tab_widget.addWidget(self.Page3)
        self.Page4 = QWidget()
        self.Page4.setObjectName(u"Page4")
        self.horizontalLayout_141 = QHBoxLayout(self.Page4)
        self.horizontalLayout_141.setObjectName(u"horizontalLayout_141")
        self.widget_43 = QWidget(self.Page4)
        self.widget_43.setObjectName(u"widget_43")
        sizePolicy4.setHeightForWidth(self.widget_43.sizePolicy().hasHeightForWidth())
        self.widget_43.setSizePolicy(sizePolicy4)
        self.widget_43.setMinimumSize(QSize(405, 461))
        self.widget_43.setMaximumSize(QSize(405, 461))
        self.widget_43.setStyleSheet(u"")
        self.gridWidget_9 = QWidget(self.widget_43)
        self.gridWidget_9.setObjectName(u"gridWidget_9")
        self.gridWidget_9.setGeometry(QRect(23, 1, 364, 364))
        self.gridLayout_9 = QGridLayout(self.gridWidget_9)
        self.gridLayout_9.setSpacing(10)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.probe_valley_x = SubCallButton(self.gridWidget_9)
        self.probe_valley_x.setObjectName(u"probe_valley_x")
        self.probe_valley_x.setMinimumSize(QSize(170, 170))
        self.probe_valley_x.setMaximumSize(QSize(170, 170))
        self.probe_valley_x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_valley_x.setStyleSheet(u"")
        icon26 = QIcon()
        icon26.addFile(u":/images/probe_x_valley.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_valley_x.setIcon(icon26)
        self.probe_valley_x.setIconSize(QSize(150, 150))

        self.gridLayout_9.addWidget(self.probe_valley_x, 0, 0, 1, 1)

        self.probe_valley_y = SubCallButton(self.gridWidget_9)
        self.probe_valley_y.setObjectName(u"probe_valley_y")
        self.probe_valley_y.setMinimumSize(QSize(170, 170))
        self.probe_valley_y.setMaximumSize(QSize(170, 170))
        self.probe_valley_y.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_valley_y.setStyleSheet(u"")
        icon27 = QIcon()
        icon27.addFile(u":/images/probe_y_valley.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_valley_y.setIcon(icon27)
        self.probe_valley_y.setIconSize(QSize(150, 150))

        self.gridLayout_9.addWidget(self.probe_valley_y, 0, 1, 1, 1)

        self.probe_ridge_x = SubCallButton(self.gridWidget_9)
        self.probe_ridge_x.setObjectName(u"probe_ridge_x")
        self.probe_ridge_x.setMinimumSize(QSize(170, 170))
        self.probe_ridge_x.setMaximumSize(QSize(170, 170))
        self.probe_ridge_x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_ridge_x.setStyleSheet(u"")
        icon28 = QIcon()
        icon28.addFile(u":/images/probe_x_ridge.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_ridge_x.setIcon(icon28)
        self.probe_ridge_x.setIconSize(QSize(150, 150))

        self.gridLayout_9.addWidget(self.probe_ridge_x, 1, 0, 1, 1)

        self.probe_ridge_y = SubCallButton(self.gridWidget_9)
        self.probe_ridge_y.setObjectName(u"probe_ridge_y")
        self.probe_ridge_y.setMinimumSize(QSize(170, 170))
        self.probe_ridge_y.setMaximumSize(QSize(170, 170))
        self.probe_ridge_y.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_ridge_y.setStyleSheet(u"")
        icon29 = QIcon()
        icon29.addFile(u":/images/probe_y_ridge.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_ridge_y.setIcon(icon29)
        self.probe_ridge_y.setIconSize(QSize(150, 150))

        self.gridLayout_9.addWidget(self.probe_ridge_y, 1, 1, 1, 1)

        self.frame_9 = QFrame(self.widget_43)
        self.frame_9.setObjectName(u"frame_9")
        self.frame_9.setGeometry(QRect(3, 392, 400, 65))
        sizePolicy4.setHeightForWidth(self.frame_9.sizePolicy().hasHeightForWidth())
        self.frame_9.setSizePolicy(sizePolicy4)
        self.frame_9.setMinimumSize(QSize(400, 65))
        self.frame_9.setMaximumSize(QSize(400, 65))
        self.frame_9.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"	border-width: 2px;\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_143 = QHBoxLayout(self.frame_9)
        self.horizontalLayout_143.setObjectName(u"horizontalLayout_143")
        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setSpacing(0)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.hint_label_2 = QLabel(self.frame_9)
        self.hint_label_2.setObjectName(u"hint_label_2")
        self.hint_label_2.setMinimumSize(QSize(115, 40))
        self.hint_label_2.setMaximumSize(QSize(115, 40))
        self.hint_label_2.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(191, 191, 191);\n"
"    border-width: 1px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"}")
        self.hint_label_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_28.addWidget(self.hint_label_2)

        self.label_74 = QLabel(self.frame_9)
        self.label_74.setObjectName(u"label_74")
        self.label_74.setMinimumSize(QSize(50, 0))
        self.label_74.setMaximumSize(QSize(50, 16777215))
        self.label_74.setStyleSheet(u"QLabel{\n"
"    color: rgb(255, 255, 255);\n"
"    padding-right: 1px;\n"
"    padding-left: 5px;\n"
"}")
        self.label_74.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_74.setIndent(0)

        self.horizontalLayout_28.addWidget(self.label_74)

        self.x_hint = VCPLineEdit(self.frame_9)
        self.x_hint.setObjectName(u"x_hint")
        sizePolicy10.setHeightForWidth(self.x_hint.sizePolicy().hasHeightForWidth())
        self.x_hint.setSizePolicy(sizePolicy10)
        self.x_hint.setMinimumSize(QSize(80, 40))
        self.x_hint.setMaximumSize(QSize(80, 40))
        self.x_hint.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_hint.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_28.addWidget(self.x_hint)

        self.label_75 = QLabel(self.frame_9)
        self.label_75.setObjectName(u"label_75")
        self.label_75.setMinimumSize(QSize(50, 0))
        self.label_75.setMaximumSize(QSize(50, 16777215))
        self.label_75.setStyleSheet(u"QLabel{\n"
"    color: rgb(255, 255, 255);\n"
"    padding-right: 1px;\n"
"    padding-left: 5px;\n"
"}")
        self.label_75.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_75.setIndent(0)

        self.horizontalLayout_28.addWidget(self.label_75)

        self.y_hint = VCPLineEdit(self.frame_9)
        self.y_hint.setObjectName(u"y_hint")
        sizePolicy10.setHeightForWidth(self.y_hint.sizePolicy().hasHeightForWidth())
        self.y_hint.setSizePolicy(sizePolicy10)
        self.y_hint.setMinimumSize(QSize(80, 40))
        self.y_hint.setMaximumSize(QSize(80, 40))
        self.y_hint.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.y_hint.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_28.addWidget(self.y_hint)


        self.horizontalLayout_143.addLayout(self.horizontalLayout_28)


        self.horizontalLayout_141.addWidget(self.widget_43)

        self.probe_tab_widget.addWidget(self.Page4)
        self.Page5 = QWidget()
        self.Page5.setObjectName(u"Page5")
        self.horizontalLayout_19 = QHBoxLayout(self.Page5)
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.widget_17 = QWidget(self.Page5)
        self.widget_17.setObjectName(u"widget_17")
        sizePolicy4.setHeightForWidth(self.widget_17.sizePolicy().hasHeightForWidth())
        self.widget_17.setSizePolicy(sizePolicy4)
        self.verticalLayout_26 = QVBoxLayout(self.widget_17)
        self.verticalLayout_26.setSpacing(9)
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.verticalLayout_26.setContentsMargins(0, 0, 0, 0)
        self.widget_46 = QWidget(self.widget_17)
        self.widget_46.setObjectName(u"widget_46")
        sizePolicy4.setHeightForWidth(self.widget_46.sizePolicy().hasHeightForWidth())
        self.widget_46.setSizePolicy(sizePolicy4)
        self.widget_46.setMinimumSize(QSize(465, 465))
        self.widget_46.setMaximumSize(QSize(465, 465))
        self.widget_46.setStyleSheet(u"")
        self.gridLayout_8 = QGridLayout(self.widget_46)
        self.gridLayout_8.setObjectName(u"gridLayout_8")
        self.probe_top_left_edge_angle = SubCallButton(self.widget_46)
        self.probe_top_left_edge_angle.setObjectName(u"probe_top_left_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_top_left_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_top_left_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_top_left_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_top_left_edge_angle.setMaximumSize(QSize(140, 140))
        self.probe_top_left_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_top_left_edge_angle.setStyleSheet(u"")
        icon30 = QIcon()
        icon30.addFile(u":/images/probe_top_left_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_top_left_edge_angle.setIcon(icon30)
        self.probe_top_left_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_top_left_edge_angle, 2, 0, 1, 1)

        self.probe_corner_y_plus_edge_angle = SubCallButton(self.widget_46)
        self.probe_corner_y_plus_edge_angle.setObjectName(u"probe_corner_y_plus_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_corner_y_plus_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_corner_y_plus_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_corner_y_plus_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_corner_y_plus_edge_angle.setMaximumSize(QSize(140, 140))
        self.probe_corner_y_plus_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_corner_y_plus_edge_angle.setStyleSheet(u"")
        icon31 = QIcon()
        icon31.addFile(u":/images/probe_corner_y_plus_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_corner_y_plus_edge_angle.setIcon(icon31)
        self.probe_corner_y_plus_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_corner_y_plus_edge_angle, 3, 0, 1, 1)

        self.probe_corner_x_plus_edge_angle = SubCallButton(self.widget_46)
        self.probe_corner_x_plus_edge_angle.setObjectName(u"probe_corner_x_plus_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_corner_x_plus_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_corner_x_plus_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_corner_x_plus_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_corner_x_plus_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon32 = QIcon()
        icon32.addFile(u":/images/probe_corner_x_plus_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_corner_x_plus_edge_angle.setIcon(icon32)
        self.probe_corner_x_plus_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_corner_x_plus_edge_angle, 1, 0, 1, 1)

        self.probe_corner_y_minus_edge_angle = SubCallButton(self.widget_46)
        self.probe_corner_y_minus_edge_angle.setObjectName(u"probe_corner_y_minus_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_corner_y_minus_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_corner_y_minus_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_corner_y_minus_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_corner_y_minus_edge_angle.setMaximumSize(QSize(140, 140))
        self.probe_corner_y_minus_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_corner_y_minus_edge_angle.setStyleSheet(u"")
        icon33 = QIcon()
        icon33.addFile(u":/images/probe_corner_y_minus_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_corner_y_minus_edge_angle.setIcon(icon33)
        self.probe_corner_y_minus_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_corner_y_minus_edge_angle, 1, 2, 1, 1)

        self.probe_z_minus_edge = SubCallButton(self.widget_46)
        self.probe_z_minus_edge.setObjectName(u"probe_z_minus_edge")
        sizePolicy4.setHeightForWidth(self.probe_z_minus_edge.sizePolicy().hasHeightForWidth())
        self.probe_z_minus_edge.setSizePolicy(sizePolicy4)
        self.probe_z_minus_edge.setMinimumSize(QSize(140, 140))
        self.probe_z_minus_edge.setMaximumSize(QSize(140, 140))
        self.probe_z_minus_edge.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_z_minus_edge.setStyleSheet(u"")
        icon34 = QIcon()
        icon34.addFile(u":/images/z_top_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_z_minus_edge.setIcon(icon34)
        self.probe_z_minus_edge.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_z_minus_edge, 2, 1, 1, 1)

        self.probe_corner_x_minus_edge_angle = SubCallButton(self.widget_46)
        self.probe_corner_x_minus_edge_angle.setObjectName(u"probe_corner_x_minus_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_corner_x_minus_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_corner_x_minus_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_corner_x_minus_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_corner_x_minus_edge_angle.setMaximumSize(QSize(140, 140))
        self.probe_corner_x_minus_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_corner_x_minus_edge_angle.setStyleSheet(u"")
        icon35 = QIcon()
        icon35.addFile(u":/images/probe_corner_x_minus_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_corner_x_minus_edge_angle.setIcon(icon35)
        self.probe_corner_x_minus_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_corner_x_minus_edge_angle, 3, 2, 1, 1)

        self.probe_top_right_edge_angle = SubCallButton(self.widget_46)
        self.probe_top_right_edge_angle.setObjectName(u"probe_top_right_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_top_right_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_top_right_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_top_right_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_top_right_edge_angle.setMaximumSize(QSize(140, 140))
        self.probe_top_right_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_top_right_edge_angle.setStyleSheet(u"")
        icon36 = QIcon()
        icon36.addFile(u":/images/probe_top_right_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_top_right_edge_angle.setIcon(icon36)
        self.probe_top_right_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_top_right_edge_angle, 2, 2, 1, 1)

        self.probe_top_back_edge_angle = SubCallButton(self.widget_46)
        self.probe_top_back_edge_angle.setObjectName(u"probe_top_back_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_top_back_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_top_back_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_top_back_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_top_back_edge_angle.setMaximumSize(QSize(140, 140))
        self.probe_top_back_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_top_back_edge_angle.setStyleSheet(u"")
        icon37 = QIcon()
        icon37.addFile(u":/images/probe_top_back_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_top_back_edge_angle.setIcon(icon37)
        self.probe_top_back_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_top_back_edge_angle, 1, 1, 1, 1)

        self.probe_top_front_edge_angle = SubCallButton(self.widget_46)
        self.probe_top_front_edge_angle.setObjectName(u"probe_top_front_edge_angle")
        sizePolicy4.setHeightForWidth(self.probe_top_front_edge_angle.sizePolicy().hasHeightForWidth())
        self.probe_top_front_edge_angle.setSizePolicy(sizePolicy4)
        self.probe_top_front_edge_angle.setMinimumSize(QSize(140, 140))
        self.probe_top_front_edge_angle.setMaximumSize(QSize(140, 140))
        self.probe_top_front_edge_angle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_top_front_edge_angle.setStyleSheet(u"")
        icon38 = QIcon()
        icon38.addFile(u":/images/probe_top_front_edge_angle_r.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_top_front_edge_angle.setIcon(icon38)
        self.probe_top_front_edge_angle.setIconSize(QSize(130, 130))

        self.gridLayout_8.addWidget(self.probe_top_front_edge_angle, 3, 1, 1, 1)


        self.verticalLayout_26.addWidget(self.widget_46)

        self.widget_18 = QWidget(self.widget_17)
        self.widget_18.setObjectName(u"widget_18")
        sizePolicy7.setHeightForWidth(self.widget_18.sizePolicy().hasHeightForWidth())
        self.widget_18.setSizePolicy(sizePolicy7)
        self.widget_18.setMinimumSize(QSize(0, 42))
        self.widget_18.setMaximumSize(QSize(16777215, 42))
        self.horizontalLayout_54 = QHBoxLayout(self.widget_18)
        self.horizontalLayout_54.setSpacing(0)
        self.horizontalLayout_54.setObjectName(u"horizontalLayout_54")
        self.horizontalLayout_54.setContentsMargins(0, 1, 0, 1)
        self.set_wco_offset_Btn = QPushButton(self.widget_18)
        self.set_wco_offset_Btn.setObjectName(u"set_wco_offset_Btn")
        sizePolicy11 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy11.setHorizontalStretch(1)
        sizePolicy11.setVerticalStretch(0)
        sizePolicy11.setHeightForWidth(self.set_wco_offset_Btn.sizePolicy().hasHeightForWidth())
        self.set_wco_offset_Btn.setSizePolicy(sizePolicy11)
        self.set_wco_offset_Btn.setMinimumSize(QSize(400, 38))
        self.set_wco_offset_Btn.setMaximumSize(QSize(16777215, 38))
        self.set_wco_offset_Btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.set_wco_offset_Btn.setStyleSheet(u"")
        self.set_wco_offset_Btn.setCheckable(True)
        self.set_wco_offset_Btn.setChecked(False)
        self.set_wco_offset_Btn.setAutoExclusive(True)

        self.horizontalLayout_54.addWidget(self.set_wco_offset_Btn)


        self.verticalLayout_26.addWidget(self.widget_18)


        self.horizontalLayout_19.addWidget(self.widget_17)

        self.probe_tab_widget.addWidget(self.Page5)
        self.Page6 = QWidget()
        self.Page6.setObjectName(u"Page6")
        self.probe_tab_widget.addWidget(self.Page6)
        self.Page7 = QWidget()
        self.Page7.setObjectName(u"Page7")
        self.horizontalLayout_55 = QHBoxLayout(self.Page7)
        self.horizontalLayout_55.setObjectName(u"horizontalLayout_55")
        self.frame_47 = QFrame(self.Page7)
        self.frame_47.setObjectName(u"frame_47")
        sizePolicy3.setHeightForWidth(self.frame_47.sizePolicy().hasHeightForWidth())
        self.frame_47.setSizePolicy(sizePolicy3)
        self.frame_47.setMaximumSize(QSize(520, 520))
        self.frame_47.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: rgb(206, 209, 202);\n"
"    background-color: rgb(57, 63, 65);\n"
"    border-radius: 8px;\n"
"}\n"
"")
        self.verticalLayout_46 = QVBoxLayout(self.frame_47)
        self.verticalLayout_46.setSpacing(9)
        self.verticalLayout_46.setObjectName(u"verticalLayout_46")
        self.verticalLayout_46.setContentsMargins(9, 12, 9, 18)
        self.horizontalLayout_61 = QHBoxLayout()
        self.horizontalLayout_61.setSpacing(6)
        self.horizontalLayout_61.setObjectName(u"horizontalLayout_61")
        self.horizontalLayout_61.setContentsMargins(9, 3, 9, 3)
        self.label_94 = QLabel(self.frame_47)
        self.label_94.setObjectName(u"label_94")
        sizePolicy4.setHeightForWidth(self.label_94.sizePolicy().hasHeightForWidth())
        self.label_94.setSizePolicy(sizePolicy4)
        self.label_94.setMinimumSize(QSize(210, 30))
        self.label_94.setMaximumSize(QSize(210, 30))
        self.label_94.setBaseSize(QSize(140, 30))
        self.label_94.setStyleSheet(u"QLabel{\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_94.setLineWidth(0)
        self.label_94.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_94.setIndent(0)

        self.horizontalLayout_61.addWidget(self.label_94)

        self.calibration_offset = VCPSettingsLineEdit(self.frame_47)
        self.calibration_offset.setObjectName(u"calibration_offset")
        sizePolicy4.setHeightForWidth(self.calibration_offset.sizePolicy().hasHeightForWidth())
        self.calibration_offset.setSizePolicy(sizePolicy4)
        self.calibration_offset.setMinimumSize(QSize(100, 35))
        self.calibration_offset.setMaximumSize(QSize(100, 35))
        self.calibration_offset.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.calibration_offset.setStyleSheet(u"")
        self.calibration_offset.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.calibration_offset.setReadOnly(False)
        self.calibration_offset.setClearButtonEnabled(False)

        self.horizontalLayout_61.addWidget(self.calibration_offset)

        self.probe_cal_reset = SubCallButton(self.frame_47)
        self.probe_cal_reset.setObjectName(u"probe_cal_reset")
        sizePolicy4.setHeightForWidth(self.probe_cal_reset.sizePolicy().hasHeightForWidth())
        self.probe_cal_reset.setSizePolicy(sizePolicy4)
        self.probe_cal_reset.setMinimumSize(QSize(150, 37))
        self.probe_cal_reset.setMaximumSize(QSize(150, 37))
        self.probe_cal_reset.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_cal_reset.setStyleSheet(u"SubCallButton{\n"
"    border-radius: 5px;  \n"
"  	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: black;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallBut"
                        "ton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_61.addWidget(self.probe_cal_reset)


        self.verticalLayout_46.addLayout(self.horizontalLayout_61)

        self.horizontalLayout_60 = QHBoxLayout()
        self.horizontalLayout_60.setSpacing(21)
        self.horizontalLayout_60.setObjectName(u"horizontalLayout_60")
        self.horizontalLayout_60.setContentsMargins(9, 3, -1, 3)
        self.probe_cal_round_pocket = SubCallButton(self.frame_47)
        self.probe_cal_round_pocket.setObjectName(u"probe_cal_round_pocket")
        self.probe_cal_round_pocket.setMinimumSize(QSize(150, 150))
        self.probe_cal_round_pocket.setMaximumSize(QSize(150, 150))
        self.probe_cal_round_pocket.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_cal_round_pocket.setStyleSheet(u"")
        icon39 = QIcon()
        icon39.addFile(u":/images/probe_cal_round_pocket.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_cal_round_pocket.setIcon(icon39)
        self.probe_cal_round_pocket.setIconSize(QSize(135, 135))

        self.horizontalLayout_60.addWidget(self.probe_cal_round_pocket)

        self.probe_cal_round_boss = SubCallButton(self.frame_47)
        self.probe_cal_round_boss.setObjectName(u"probe_cal_round_boss")
        self.probe_cal_round_boss.setMinimumSize(QSize(150, 150))
        self.probe_cal_round_boss.setMaximumSize(QSize(150, 150))
        self.probe_cal_round_boss.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_cal_round_boss.setStyleSheet(u"")
        icon40 = QIcon()
        icon40.addFile(u":/images/probe_cal_round_boss.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_cal_round_boss.setIcon(icon40)
        self.probe_cal_round_boss.setIconSize(QSize(140, 140))
        self.probe_cal_round_boss.setAutoDefault(False)

        self.horizontalLayout_60.addWidget(self.probe_cal_round_boss)

        self.widget_21 = QWidget(self.frame_47)
        self.widget_21.setObjectName(u"widget_21")
        sizePolicy4.setHeightForWidth(self.widget_21.sizePolicy().hasHeightForWidth())
        self.widget_21.setSizePolicy(sizePolicy4)
        self.widget_21.setMinimumSize(QSize(130, 150))
        self.widget_21.setMaximumSize(QSize(130, 150))
        self.widget_21.setSizeIncrement(QSize(0, 0))
        self.widget_21.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.formLayout_2 = QFormLayout(self.widget_21)
        self.formLayout_2.setObjectName(u"formLayout_2")
        self.formLayout_2.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.formLayout_2.setRowWrapPolicy(QFormLayout.RowWrapPolicy.DontWrapRows)
        self.formLayout_2.setLabelAlignment(Qt.AlignmentFlag.AlignCenter)
        self.formLayout_2.setFormAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.formLayout_2.setHorizontalSpacing(0)
        self.formLayout_2.setVerticalSpacing(15)
        self.formLayout_2.setContentsMargins(1, 0, 1, 9)
        self.hint_label_4 = QLabel(self.widget_21)
        self.hint_label_4.setObjectName(u"hint_label_4")
        sizePolicy4.setHeightForWidth(self.hint_label_4.sizePolicy().hasHeightForWidth())
        self.hint_label_4.setSizePolicy(sizePolicy4)
        self.hint_label_4.setMinimumSize(QSize(130, 58))
        self.hint_label_4.setMaximumSize(QSize(130, 58))
        self.hint_label_4.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"}")
        self.hint_label_4.setTextFormat(Qt.TextFormat.RichText)
        self.hint_label_4.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hint_label_4.setWordWrap(True)

        self.formLayout_2.setWidget(0, QFormLayout.LabelRole, self.hint_label_4)

        self.cal_diameter = VCPLineEdit(self.widget_21)
        self.cal_diameter.setObjectName(u"cal_diameter")
        sizePolicy10.setHeightForWidth(self.cal_diameter.sizePolicy().hasHeightForWidth())
        self.cal_diameter.setSizePolicy(sizePolicy10)
        self.cal_diameter.setMinimumSize(QSize(130, 35))
        self.cal_diameter.setMaximumSize(QSize(130, 35))
        self.cal_diameter.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.cal_diameter.setStyleSheet(u"margin-right: 14px;\n"
"margin-left: 14px;")
        self.cal_diameter.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout_2.setWidget(1, QFormLayout.FieldRole, self.cal_diameter)


        self.horizontalLayout_60.addWidget(self.widget_21)


        self.verticalLayout_46.addLayout(self.horizontalLayout_60)

        self.horizontalLayout_56 = QHBoxLayout()
        self.horizontalLayout_56.setSpacing(9)
        self.horizontalLayout_56.setObjectName(u"horizontalLayout_56")
        self.horizontalLayout_56.setContentsMargins(3, 3, 3, 3)
        self.cal_avg_error = QPushButton(self.frame_47)
        self.cal_avg_error.setObjectName(u"cal_avg_error")
        sizePolicy4.setHeightForWidth(self.cal_avg_error.sizePolicy().hasHeightForWidth())
        self.cal_avg_error.setSizePolicy(sizePolicy4)
        self.cal_avg_error.setMinimumSize(QSize(165, 37))
        self.cal_avg_error.setMaximumSize(QSize(165, 37))
        self.cal_avg_error.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.cal_avg_error.setStyleSheet(u"")
        self.cal_avg_error.setCheckable(True)
        self.cal_avg_error.setChecked(True)
        self.cal_avg_error.setAutoExclusive(True)

        self.horizontalLayout_56.addWidget(self.cal_avg_error)

        self.cal_x_error = QPushButton(self.frame_47)
        self.cal_x_error.setObjectName(u"cal_x_error")
        sizePolicy4.setHeightForWidth(self.cal_x_error.sizePolicy().hasHeightForWidth())
        self.cal_x_error.setSizePolicy(sizePolicy4)
        self.cal_x_error.setMinimumSize(QSize(140, 37))
        self.cal_x_error.setMaximumSize(QSize(140, 37))
        self.cal_x_error.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.cal_x_error.setCheckable(True)
        self.cal_x_error.setChecked(False)
        self.cal_x_error.setAutoExclusive(True)

        self.horizontalLayout_56.addWidget(self.cal_x_error)

        self.cal_y_error = QPushButton(self.frame_47)
        self.cal_y_error.setObjectName(u"cal_y_error")
        sizePolicy4.setHeightForWidth(self.cal_y_error.sizePolicy().hasHeightForWidth())
        self.cal_y_error.setSizePolicy(sizePolicy4)
        self.cal_y_error.setMinimumSize(QSize(140, 37))
        self.cal_y_error.setMaximumSize(QSize(140, 37))
        self.cal_y_error.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.cal_y_error.setStyleSheet(u"")
        self.cal_y_error.setCheckable(True)
        self.cal_y_error.setAutoExclusive(True)

        self.horizontalLayout_56.addWidget(self.cal_y_error)


        self.verticalLayout_46.addLayout(self.horizontalLayout_56)

        self.horizontalLayout_62 = QHBoxLayout()
        self.horizontalLayout_62.setSpacing(21)
        self.horizontalLayout_62.setObjectName(u"horizontalLayout_62")
        self.horizontalLayout_62.setContentsMargins(9, 3, -1, 6)
        self.probe_cal_square_pocket = SubCallButton(self.frame_47)
        self.probe_cal_square_pocket.setObjectName(u"probe_cal_square_pocket")
        self.probe_cal_square_pocket.setMinimumSize(QSize(150, 150))
        self.probe_cal_square_pocket.setMaximumSize(QSize(150, 150))
        self.probe_cal_square_pocket.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_cal_square_pocket.setStyleSheet(u"")
        icon41 = QIcon()
        icon41.addFile(u":/images/probe_cal_square_pocket.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_cal_square_pocket.setIcon(icon41)
        self.probe_cal_square_pocket.setIconSize(QSize(135, 135))

        self.horizontalLayout_62.addWidget(self.probe_cal_square_pocket)

        self.probe_cal_square_boss = SubCallButton(self.frame_47)
        self.probe_cal_square_boss.setObjectName(u"probe_cal_square_boss")
        self.probe_cal_square_boss.setMinimumSize(QSize(150, 150))
        self.probe_cal_square_boss.setMaximumSize(QSize(150, 150))
        self.probe_cal_square_boss.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_cal_square_boss.setStyleSheet(u"")
        icon42 = QIcon()
        icon42.addFile(u":/images/probe_cal_square_boss.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_cal_square_boss.setIcon(icon42)
        self.probe_cal_square_boss.setIconSize(QSize(140, 140))

        self.horizontalLayout_62.addWidget(self.probe_cal_square_boss)

        self.widget_19 = QWidget(self.frame_47)
        self.widget_19.setObjectName(u"widget_19")
        sizePolicy7.setHeightForWidth(self.widget_19.sizePolicy().hasHeightForWidth())
        self.widget_19.setSizePolicy(sizePolicy7)
        self.widget_19.setMinimumSize(QSize(130, 150))
        self.widget_19.setMaximumSize(QSize(130, 150))
        self.formLayout = QFormLayout(self.widget_19)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setLabelAlignment(Qt.AlignmentFlag.AlignCenter)
        self.formLayout.setFormAlignment(Qt.AlignmentFlag.AlignCenter)
        self.formLayout.setVerticalSpacing(15)
        self.formLayout.setContentsMargins(1, 0, 1, 9)
        self.hint_label_3 = QLabel(self.widget_19)
        self.hint_label_3.setObjectName(u"hint_label_3")
        sizePolicy4.setHeightForWidth(self.hint_label_3.sizePolicy().hasHeightForWidth())
        self.hint_label_3.setSizePolicy(sizePolicy4)
        self.hint_label_3.setMinimumSize(QSize(120, 23))
        self.hint_label_3.setMaximumSize(QSize(130, 0))
        self.hint_label_3.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"}")
        self.hint_label_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.formLayout.setWidget(0, QFormLayout.SpanningRole, self.hint_label_3)

        self.label_108 = QLabel(self.widget_19)
        self.label_108.setObjectName(u"label_108")
        sizePolicy4.setHeightForWidth(self.label_108.sizePolicy().hasHeightForWidth())
        self.label_108.setSizePolicy(sizePolicy4)
        self.label_108.setMinimumSize(QSize(23, 31))
        self.label_108.setMaximumSize(QSize(23, 31))
        self.label_108.setStyleSheet(u"QLabel{\n"
"color: white;\n"
"}")
        self.label_108.setLineWidth(0)
        self.label_108.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_108.setIndent(0)

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_108)

        self.label_109 = QLabel(self.widget_19)
        self.label_109.setObjectName(u"label_109")
        sizePolicy4.setHeightForWidth(self.label_109.sizePolicy().hasHeightForWidth())
        self.label_109.setSizePolicy(sizePolicy4)
        self.label_109.setMinimumSize(QSize(23, 31))
        self.label_109.setMaximumSize(QSize(23, 31))
        self.label_109.setStyleSheet(u"QLabel{\n"
"color: white;\n"
"}")
        self.label_109.setLineWidth(0)
        self.label_109.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_109.setIndent(0)

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.label_109)

        self.x_cal_width = VCPLineEdit(self.widget_19)
        self.x_cal_width.setObjectName(u"x_cal_width")
        sizePolicy10.setHeightForWidth(self.x_cal_width.sizePolicy().hasHeightForWidth())
        self.x_cal_width.setSizePolicy(sizePolicy10)
        self.x_cal_width.setMinimumSize(QSize(87, 35))
        self.x_cal_width.setMaximumSize(QSize(87, 35))
        self.x_cal_width.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_cal_width.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.x_cal_width)

        self.y_cal_width = VCPLineEdit(self.widget_19)
        self.y_cal_width.setObjectName(u"y_cal_width")
        sizePolicy10.setHeightForWidth(self.y_cal_width.sizePolicy().hasHeightForWidth())
        self.y_cal_width.setSizePolicy(sizePolicy10)
        self.y_cal_width.setMinimumSize(QSize(87, 35))
        self.y_cal_width.setMaximumSize(QSize(87, 35))
        self.y_cal_width.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.y_cal_width.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.y_cal_width)


        self.horizontalLayout_62.addWidget(self.widget_19)


        self.verticalLayout_46.addLayout(self.horizontalLayout_62)


        self.horizontalLayout_55.addWidget(self.frame_47)

        self.probe_tab_widget.addWidget(self.Page7)
        self.Page8 = QWidget()
        self.Page8.setObjectName(u"Page8")
        self.horizontalLayout_21 = QHBoxLayout(self.Page8)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.frame = QFrame(self.Page8)
        self.frame.setObjectName(u"frame")
        sizePolicy4.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy4)
        self.frame.setMinimumSize(QSize(520, 480))
        self.frame.setMaximumSize(QSize(520, 480))
        self.frame.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: rgb(206, 209, 202);\n"
"    background-color: rgb(51, 57, 59);\n"
"    border-radius: 8px;\n"
"}")
        self.verticalLayout_21 = QVBoxLayout(self.frame)
        self.verticalLayout_21.setSpacing(6)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.verticalLayout_21.setContentsMargins(3, 6, 3, 12)
        self.probe_help_widget = QStackedWidget(self.frame)
        self.probe_help_widget.setObjectName(u"probe_help_widget")
        sizePolicy10.setHeightForWidth(self.probe_help_widget.sizePolicy().hasHeightForWidth())
        self.probe_help_widget.setSizePolicy(sizePolicy10)
        self.probe_help_widget.setMinimumSize(QSize(0, 410))
        self.probe_help_widget.setMaximumSize(QSize(16777215, 410))
        font11 = QFont()
        font11.setFamilies([u"Bebas Kai"])
        font11.setPointSize(13)
        self.probe_help_widget.setFont(font11)
        self.probe_help_widget.setStyleSheet(u"QStackedWidget{\n"
"border: none;\n"
"background: transparent;\n"
"}")
        self.probe_help_widget.setFrameShape(QFrame.Shape.NoFrame)
        self.probe_help_widget.setLineWidth(0)
        self.stackedWidget_4Page1 = QWidget()
        self.stackedWidget_4Page1.setObjectName(u"stackedWidget_4Page1")
        self.horizontalLayout_146 = QHBoxLayout(self.stackedWidget_4Page1)
        self.horizontalLayout_146.setObjectName(u"horizontalLayout_146")
        self.label_77 = QLabel(self.stackedWidget_4Page1)
        self.label_77.setObjectName(u"label_77")
        sizePolicy7.setHeightForWidth(self.label_77.sizePolicy().hasHeightForWidth())
        self.label_77.setSizePolicy(sizePolicy7)
        self.label_77.setMinimumSize(QSize(450, 400))
        self.label_77.setMaximumSize(QSize(450, 400))
        self.label_77.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/step_off_width.png);\n"
"}")
        self.label_77.setScaledContents(True)
        self.label_77.setIndent(0)

        self.horizontalLayout_146.addWidget(self.label_77)

        self.probe_help_widget.addWidget(self.stackedWidget_4Page1)
        self.stackedWidget_4Page2 = QWidget()
        self.stackedWidget_4Page2.setObjectName(u"stackedWidget_4Page2")
        self.horizontalLayout_148 = QHBoxLayout(self.stackedWidget_4Page2)
        self.horizontalLayout_148.setObjectName(u"horizontalLayout_148")
        self.label_78 = QLabel(self.stackedWidget_4Page2)
        self.label_78.setObjectName(u"label_78")
        sizePolicy7.setHeightForWidth(self.label_78.sizePolicy().hasHeightForWidth())
        self.label_78.setSizePolicy(sizePolicy7)
        self.label_78.setMinimumSize(QSize(500, 400))
        self.label_78.setMaximumSize(QSize(500, 400))
        self.label_78.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/extra_probe_depth.png);\n"
"}")
        self.label_78.setScaledContents(True)
        self.label_78.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_78.setWordWrap(True)
        self.label_78.setIndent(0)

        self.horizontalLayout_148.addWidget(self.label_78)

        self.probe_help_widget.addWidget(self.stackedWidget_4Page2)
        self.stackedWidget_4Page3 = QWidget()
        self.stackedWidget_4Page3.setObjectName(u"stackedWidget_4Page3")
        self.horizontalLayout_39 = QHBoxLayout(self.stackedWidget_4Page3)
        self.horizontalLayout_39.setObjectName(u"horizontalLayout_39")
        self.label_79 = QLabel(self.stackedWidget_4Page3)
        self.label_79.setObjectName(u"label_79")
        sizePolicy7.setHeightForWidth(self.label_79.sizePolicy().hasHeightForWidth())
        self.label_79.setSizePolicy(sizePolicy7)
        self.label_79.setMinimumSize(QSize(440, 400))
        self.label_79.setMaximumSize(QSize(440, 400))
        self.label_79.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/max_z_distance.png);\n"
"}")
        self.label_79.setScaledContents(True)
        self.label_79.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_79.setWordWrap(True)
        self.label_79.setIndent(0)

        self.horizontalLayout_39.addWidget(self.label_79)

        self.probe_help_widget.addWidget(self.stackedWidget_4Page3)
        self.stackedWidget_4Page4 = QWidget()
        self.stackedWidget_4Page4.setObjectName(u"stackedWidget_4Page4")
        self.horizontalLayout_34 = QHBoxLayout(self.stackedWidget_4Page4)
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.label_110 = QLabel(self.stackedWidget_4Page4)
        self.label_110.setObjectName(u"label_110")
        sizePolicy7.setHeightForWidth(self.label_110.sizePolicy().hasHeightForWidth())
        self.label_110.setSizePolicy(sizePolicy7)
        self.label_110.setMinimumSize(QSize(470, 400))
        self.label_110.setMaximumSize(QSize(470, 400))
        self.label_110.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/max_xy_distance.png);\n"
"}")
        self.label_110.setScaledContents(True)
        self.label_110.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_110.setWordWrap(True)
        self.label_110.setIndent(0)

        self.horizontalLayout_34.addWidget(self.label_110)

        self.probe_help_widget.addWidget(self.stackedWidget_4Page4)
        self.stackedWidget_4Page5 = QWidget()
        self.stackedWidget_4Page5.setObjectName(u"stackedWidget_4Page5")
        self.horizontalLayout_42 = QHBoxLayout(self.stackedWidget_4Page5)
        self.horizontalLayout_42.setObjectName(u"horizontalLayout_42")
        self.label_80 = QLabel(self.stackedWidget_4Page5)
        self.label_80.setObjectName(u"label_80")
        sizePolicy7.setHeightForWidth(self.label_80.sizePolicy().hasHeightForWidth())
        self.label_80.setSizePolicy(sizePolicy7)
        self.label_80.setMinimumSize(QSize(450, 400))
        self.label_80.setMaximumSize(QSize(450, 400))
        self.label_80.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/z_clearance.png);\n"
"}")
        self.label_80.setScaledContents(True)
        self.label_80.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_80.setWordWrap(True)
        self.label_80.setIndent(0)

        self.horizontalLayout_42.addWidget(self.label_80)

        self.probe_help_widget.addWidget(self.stackedWidget_4Page5)
        self.stackedWidget_4Page6 = QWidget()
        self.stackedWidget_4Page6.setObjectName(u"stackedWidget_4Page6")
        self.horizontalLayout_35 = QHBoxLayout(self.stackedWidget_4Page6)
        self.horizontalLayout_35.setObjectName(u"horizontalLayout_35")
        self.label_113 = QLabel(self.stackedWidget_4Page6)
        self.label_113.setObjectName(u"label_113")
        sizePolicy7.setHeightForWidth(self.label_113.sizePolicy().hasHeightForWidth())
        self.label_113.setSizePolicy(sizePolicy7)
        self.label_113.setMinimumSize(QSize(480, 400))
        self.label_113.setMaximumSize(QSize(480, 400))
        self.label_113.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/xy_clearance.png);\n"
"}")
        self.label_113.setScaledContents(True)
        self.label_113.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_113.setWordWrap(True)
        self.label_113.setIndent(0)

        self.horizontalLayout_35.addWidget(self.label_113)

        self.probe_help_widget.addWidget(self.stackedWidget_4Page6)

        self.verticalLayout_21.addWidget(self.probe_help_widget, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)

        self.probe_help_Group_select = QWidget(self.frame)
        self.probe_help_Group_select.setObjectName(u"probe_help_Group_select")
        sizePolicy10.setHeightForWidth(self.probe_help_Group_select.sizePolicy().hasHeightForWidth())
        self.probe_help_Group_select.setSizePolicy(sizePolicy10)
        self.probe_help_Group_select.setMinimumSize(QSize(0, 40))
        self.probe_help_Group_select.setMaximumSize(QSize(16777215, 40))
        self.probe_help_Group_select.setStyleSheet(u"")
        self.horizontalLayout_44 = QHBoxLayout(self.probe_help_Group_select)
        self.horizontalLayout_44.setObjectName(u"horizontalLayout_44")
        self.horizontalLayout_44.setContentsMargins(70, 1, 70, 1)
        self.probe_help_prev = QPushButton(self.probe_help_Group_select)
        self.probe_help_prev.setObjectName(u"probe_help_prev")
        sizePolicy4.setHeightForWidth(self.probe_help_prev.sizePolicy().hasHeightForWidth())
        self.probe_help_prev.setSizePolicy(sizePolicy4)
        self.probe_help_prev.setMinimumSize(QSize(150, 37))
        self.probe_help_prev.setMaximumSize(QSize(150, 37))
        self.probe_help_prev.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_help_prev.setStyleSheet(u"QPushButton{\n"
"    padding-left: 0px;\n"
"    padding-right: 0px;\n"
"}")
        icon43 = QIcon()
        icon43.addFile(u":/images/left_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_help_prev.setIcon(icon43)
        self.probe_help_prev.setIconSize(QSize(16, 16))
        self.probe_help_prev.setCheckable(False)
        self.probe_help_prev.setChecked(False)
        self.probe_help_prev.setAutoExclusive(True)

        self.horizontalLayout_44.addWidget(self.probe_help_prev)

        self.probe_help_next = QPushButton(self.probe_help_Group_select)
        self.probe_help_next.setObjectName(u"probe_help_next")
        sizePolicy4.setHeightForWidth(self.probe_help_next.sizePolicy().hasHeightForWidth())
        self.probe_help_next.setSizePolicy(sizePolicy4)
        self.probe_help_next.setMinimumSize(QSize(150, 37))
        self.probe_help_next.setMaximumSize(QSize(150, 37))
        self.probe_help_next.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.probe_help_next.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.probe_help_next.setStyleSheet(u"QPushButton{\n"
"    padding-left: 0px;\n"
"    padding-right: 0px;\n"
"}")
        icon44 = QIcon()
        icon44.addFile(u":/images/right_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.probe_help_next.setIcon(icon44)
        self.probe_help_next.setIconSize(QSize(16, 16))
        self.probe_help_next.setCheckable(False)
        self.probe_help_next.setAutoExclusive(True)

        self.horizontalLayout_44.addWidget(self.probe_help_next)


        self.verticalLayout_21.addWidget(self.probe_help_Group_select)


        self.horizontalLayout_21.addWidget(self.frame)

        self.probe_tab_widget.addWidget(self.Page8)

        self.verticalLayout_10.addWidget(self.probe_tab_widget)


        self.horizontalLayout_32.addLayout(self.verticalLayout_10)


        self.verticalLayout_45.addWidget(self.widget_11)


        self.horizontalLayout_22.addWidget(self.widget_13)

        self.Tabs.addTab(self.tab_6, "")
        self.tab_5 = QWidget()
        self.tab_5.setObjectName(u"tab_5")
        self.verticalLayout_15 = QVBoxLayout(self.tab_5)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.statuslabel = StatusLabel(self.tab_5)
        self.statuslabel.setObjectName(u"statuslabel")

        self.verticalLayout_15.addWidget(self.statuslabel)

        self.halbutton_2 = HalButton(self.tab_5)
        self.halbutton_2.setObjectName(u"halbutton_2")

        self.verticalLayout_15.addWidget(self.halbutton_2)

        self.Tabs.addTab(self.tab_5, "")
        self.tab_9 = QWidget()
        self.tab_9.setObjectName(u"tab_9")
        self.Tabs.addTab(self.tab_9, "")

        self.verticalLayout.addWidget(self.Tabs)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(-1, 0, -1, -1)
        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_6)

        self.groupBox = QGroupBox(self.centralwidget)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setFont(font)
        self.horizontalLayout_33 = QHBoxLayout(self.groupBox)
        self.horizontalLayout_33.setObjectName(u"horizontalLayout_33")
        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setHorizontalSpacing(20)
        self.gridLayout.setVerticalSpacing(8)
        self.jogxplus_abutton = ActionButton(self.groupBox)
        self.jogxplus_abutton.setObjectName(u"jogxplus_abutton")
        self.jogxplus_abutton.setMinimumSize(QSize(42, 42))
        self.jogxplus_abutton.setMaximumSize(QSize(48, 48))
        self.jogxplus_abutton.setFont(font)
        icon45 = QIcon()
        icon45.addFile(u":/images/x_plus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.jogxplus_abutton.setIcon(icon45)
        self.jogxplus_abutton.setIconSize(QSize(32, 32))

        self.gridLayout.addWidget(self.jogxplus_abutton, 1, 5, 1, 1)

        self.jogxmin_abutton = ActionButton(self.groupBox)
        self.jogxmin_abutton.setObjectName(u"jogxmin_abutton")
        self.jogxmin_abutton.setMinimumSize(QSize(42, 42))
        self.jogxmin_abutton.setMaximumSize(QSize(48, 48))
        self.jogxmin_abutton.setFont(font)
        icon46 = QIcon()
        icon46.addFile(u":/images/x_minus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.jogxmin_abutton.setIcon(icon46)
        self.jogxmin_abutton.setIconSize(QSize(32, 32))

        self.gridLayout.addWidget(self.jogxmin_abutton, 1, 3, 1, 1)

        self.jogyplus_abutton = ActionButton(self.groupBox)
        self.jogyplus_abutton.setObjectName(u"jogyplus_abutton")
        self.jogyplus_abutton.setMinimumSize(QSize(42, 42))
        self.jogyplus_abutton.setMaximumSize(QSize(48, 48))
        self.jogyplus_abutton.setFont(font)
        icon47 = QIcon()
        icon47.addFile(u":/images/y_plus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.jogyplus_abutton.setIcon(icon47)
        self.jogyplus_abutton.setIconSize(QSize(32, 32))

        self.gridLayout.addWidget(self.jogyplus_abutton, 0, 4, 1, 1)

        self.jogzplus_abutton = ActionButton(self.groupBox)
        self.jogzplus_abutton.setObjectName(u"jogzplus_abutton")
        self.jogzplus_abutton.setMinimumSize(QSize(42, 42))
        self.jogzplus_abutton.setMaximumSize(QSize(48, 48))
        self.jogzplus_abutton.setFont(font)
        icon48 = QIcon()
        icon48.addFile(u":/images/z_plus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.jogzplus_abutton.setIcon(icon48)
        self.jogzplus_abutton.setIconSize(QSize(32, 32))

        self.gridLayout.addWidget(self.jogzplus_abutton, 0, 7, 1, 1)

        self.jogzmin_abutton = ActionButton(self.groupBox)
        self.jogzmin_abutton.setObjectName(u"jogzmin_abutton")
        self.jogzmin_abutton.setMinimumSize(QSize(42, 42))
        self.jogzmin_abutton.setMaximumSize(QSize(48, 48))
        self.jogzmin_abutton.setFont(font)
        icon49 = QIcon()
        icon49.addFile(u":/images/z_minus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.jogzmin_abutton.setIcon(icon49)
        self.jogzmin_abutton.setIconSize(QSize(32, 32))

        self.gridLayout.addWidget(self.jogzmin_abutton, 1, 7, 1, 1)

        self.jogymin_abutton = ActionButton(self.groupBox)
        self.jogymin_abutton.setObjectName(u"jogymin_abutton")
        self.jogymin_abutton.setMinimumSize(QSize(42, 42))
        self.jogymin_abutton.setMaximumSize(QSize(48, 48))
        self.jogymin_abutton.setFont(font)
        icon50 = QIcon()
        icon50.addFile(u":/images/y_minus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.jogymin_abutton.setIcon(icon50)
        self.jogymin_abutton.setIconSize(QSize(32, 32))

        self.gridLayout.addWidget(self.jogymin_abutton, 1, 4, 1, 1)


        self.horizontalLayout_33.addLayout(self.gridLayout)


        self.horizontalLayout_4.addWidget(self.groupBox)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_5)

        self.groupBox_2 = QGroupBox(self.centralwidget)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.groupBox_2.setFont(font)
        self.verticalLayout_19 = QVBoxLayout(self.groupBox_2)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.feedover_slabel = StatusLabel(self.groupBox_2)
        self.feedover_slabel.setObjectName(u"feedover_slabel")
        sizePolicy12 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        sizePolicy12.setHorizontalStretch(0)
        sizePolicy12.setVerticalStretch(0)
        sizePolicy12.setHeightForWidth(self.feedover_slabel.sizePolicy().hasHeightForWidth())
        self.feedover_slabel.setSizePolicy(sizePolicy12)
        self.feedover_slabel.setMinimumSize(QSize(180, 30))
        self.feedover_slabel.setMaximumSize(QSize(185, 30))
        self.feedover_slabel.setFont(font1)
        self.feedover_slabel.setTextFormat(Qt.TextFormat.AutoText)
        self.feedover_slabel.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_19.addWidget(self.feedover_slabel)

        self.horizontalLayout_37 = QHBoxLayout()
        self.horizontalLayout_37.setSpacing(10)
        self.horizontalLayout_37.setObjectName(u"horizontalLayout_37")
        self.feed_slider = ActionSlider(self.groupBox_2)
        self.feed_slider.setObjectName(u"feed_slider")
        self.feed_slider.setMinimumSize(QSize(120, 0))
        self.feed_slider.setFont(font6)
        self.feed_slider.setMinimum(10)
        self.feed_slider.setMaximum(100)
        self.feed_slider.setValue(100)
        self.feed_slider.setOrientation(Qt.Orientation.Horizontal)

        self.horizontalLayout_37.addWidget(self.feed_slider)

        self.statuslabel_5 = StatusLabel(self.groupBox_2)
        self.statuslabel_5.setObjectName(u"statuslabel_5")
        sizePolicy4.setHeightForWidth(self.statuslabel_5.sizePolicy().hasHeightForWidth())
        self.statuslabel_5.setSizePolicy(sizePolicy4)
        self.statuslabel_5.setMinimumSize(QSize(50, 34))
        self.statuslabel_5.setMaximumSize(QSize(55, 36))
        self.statuslabel_5.setFont(font)
        self.statuslabel_5.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.statuslabel_5.setMargin(-6)
        self.statuslabel_5.setIndent(0)

        self.horizontalLayout_37.addWidget(self.statuslabel_5)

        self.actionbutton_30 = ActionButton(self.groupBox_2)
        self.actionbutton_30.setObjectName(u"actionbutton_30")
        self.actionbutton_30.setMinimumSize(QSize(60, 42))
        self.actionbutton_30.setMaximumSize(QSize(100, 100))
        self.actionbutton_30.setFont(font)
        self.actionbutton_30.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_30.setStyleSheet(u"")

        self.horizontalLayout_37.addWidget(self.actionbutton_30)


        self.verticalLayout_19.addLayout(self.horizontalLayout_37)

        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setSpacing(0)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.rpm_label_3 = QLabel(self.groupBox_2)
        self.rpm_label_3.setObjectName(u"rpm_label_3")
        sizePolicy13 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy13.setHorizontalStretch(0)
        sizePolicy13.setVerticalStretch(0)
        sizePolicy13.setHeightForWidth(self.rpm_label_3.sizePolicy().hasHeightForWidth())
        self.rpm_label_3.setSizePolicy(sizePolicy13)
        self.rpm_label_3.setMinimumSize(QSize(0, 30))
        self.rpm_label_3.setMaximumSize(QSize(16777215, 30))
        self.rpm_label_3.setFont(font1)
        self.rpm_label_3.setStyleSheet(u"")
        self.rpm_label_3.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.rpm_label_3.setWordWrap(False)
        self.rpm_label_3.setIndent(0)

        self.horizontalLayout_14.addWidget(self.rpm_label_3)

        self.cur_feed = StatusLabel(self.groupBox_2)
        self.cur_feed.setObjectName(u"cur_feed")
        sizePolicy4.setHeightForWidth(self.cur_feed.sizePolicy().hasHeightForWidth())
        self.cur_feed.setSizePolicy(sizePolicy4)
        self.cur_feed.setMinimumSize(QSize(80, 30))
        self.cur_feed.setMaximumSize(QSize(105, 30))
        self.cur_feed.setFont(font1)
        self.cur_feed.setStyleSheet(u"")
        self.cur_feed.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_14.addWidget(self.cur_feed)

        self.cur_units = StatusLabel(self.groupBox_2)
        self.cur_units.setObjectName(u"cur_units")
        sizePolicy13.setHeightForWidth(self.cur_units.sizePolicy().hasHeightForWidth())
        self.cur_units.setSizePolicy(sizePolicy13)
        self.cur_units.setMaximumSize(QSize(16777215, 30))
        self.cur_units.setFont(font1)
        self.cur_units.setStyleSheet(u"")
        self.cur_units.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.cur_units.setIndent(0)

        self.horizontalLayout_14.addWidget(self.cur_units)


        self.verticalLayout_19.addLayout(self.horizontalLayout_14)


        self.horizontalLayout_4.addWidget(self.groupBox_2)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_7)

        self.groupBox_3 = QGroupBox(self.centralwidget)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.groupBox_3.setFont(font)
        self.verticalLayout_3 = QVBoxLayout(self.groupBox_3)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.statuslabel_4 = StatusLabel(self.groupBox_3)
        self.statuslabel_4.setObjectName(u"statuslabel_4")
        sizePolicy14 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        sizePolicy14.setHorizontalStretch(0)
        sizePolicy14.setVerticalStretch(0)
        sizePolicy14.setHeightForWidth(self.statuslabel_4.sizePolicy().hasHeightForWidth())
        self.statuslabel_4.setSizePolicy(sizePolicy14)
        self.statuslabel_4.setMinimumSize(QSize(214, 30))
        self.statuslabel_4.setMaximumSize(QSize(250, 30))
        self.statuslabel_4.setFont(font1)
        self.statuslabel_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.statuslabel_4)

        self.statuslabel_2 = StatusLabel(self.groupBox_3)
        self.statuslabel_2.setObjectName(u"statuslabel_2")
        sizePolicy14.setHeightForWidth(self.statuslabel_2.sizePolicy().hasHeightForWidth())
        self.statuslabel_2.setSizePolicy(sizePolicy14)
        self.statuslabel_2.setMinimumSize(QSize(214, 30))
        self.statuslabel_2.setMaximumSize(QSize(250, 30))
        self.statuslabel_2.setFont(font1)
        self.statuslabel_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_3.addWidget(self.statuslabel_2)


        self.horizontalLayout_4.addWidget(self.groupBox_3)

        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_4)

        self.groupBox_4 = QGroupBox(self.centralwidget)
        self.groupBox_4.setObjectName(u"groupBox_4")
        self.groupBox_4.setFont(font)
        self.verticalLayout_24 = QVBoxLayout(self.groupBox_4)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.spindle_load_indicator = HalBarIndicator(self.groupBox_4)
        self.spindle_load_indicator.setObjectName(u"spindle_load_indicator")
        self.spindle_load_indicator.setMinimumSize(QSize(0, 30))
        self.spindle_load_indicator.setMaximumSize(QSize(16777215, 30))
        self.spindle_load_indicator.setFont(font)
        self.spindle_load_indicator.setStyleSheet(u"")
        self.spindle_load_indicator.setProperty(u"value", 96.500000000000000)
        self.spindle_load_indicator.setProperty(u"maximum", 100.000000000000000)
        self.spindle_load_indicator.setProperty(u"valueAt100Percent", 100.000000000000000)
        self.spindle_load_indicator.setProperty(u"textColor", QColor(53, 53, 53))
        self.spindle_load_indicator.setProperty(u"borderColor", QColor(119, 118, 123))
        self.spindle_load_indicator.setProperty(u"borderRadius", 1)
        self.spindle_load_indicator.setProperty(u"borderWidth", 1)

        self.verticalLayout_24.addWidget(self.spindle_load_indicator)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setSpacing(10)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.actionslider = ActionSlider(self.groupBox_4)
        self.actionslider.setObjectName(u"actionslider")
        self.actionslider.setMinimumSize(QSize(120, 0))
        self.actionslider.setFont(font6)
        self.actionslider.setMinimum(10)
        self.actionslider.setMaximum(100)
        self.actionslider.setValue(100)
        self.actionslider.setOrientation(Qt.Orientation.Horizontal)

        self.horizontalLayout_11.addWidget(self.actionslider)

        self.statuslabel_3 = StatusLabel(self.groupBox_4)
        self.statuslabel_3.setObjectName(u"statuslabel_3")
        sizePolicy4.setHeightForWidth(self.statuslabel_3.sizePolicy().hasHeightForWidth())
        self.statuslabel_3.setSizePolicy(sizePolicy4)
        self.statuslabel_3.setMinimumSize(QSize(50, 34))
        self.statuslabel_3.setMaximumSize(QSize(55, 36))
        self.statuslabel_3.setFont(font)
        self.statuslabel_3.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.statuslabel_3.setMargin(-6)
        self.statuslabel_3.setIndent(0)

        self.horizontalLayout_11.addWidget(self.statuslabel_3)

        self.actionbutton_29 = ActionButton(self.groupBox_4)
        self.actionbutton_29.setObjectName(u"actionbutton_29")
        self.actionbutton_29.setMinimumSize(QSize(60, 42))
        self.actionbutton_29.setMaximumSize(QSize(100, 100))
        self.actionbutton_29.setFont(font)
        self.actionbutton_29.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_29.setStyleSheet(u"")

        self.horizontalLayout_11.addWidget(self.actionbutton_29)


        self.verticalLayout_24.addLayout(self.horizontalLayout_11)

        self.horizontalLayout_36 = QHBoxLayout()
        self.horizontalLayout_36.setSpacing(10)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.spindleon_abutton = ActionButton(self.groupBox_4)
        self.spindleon_abutton.setObjectName(u"spindleon_abutton")
        self.spindleon_abutton.setMinimumSize(QSize(42, 42))
        self.spindleon_abutton.setMaximumSize(QSize(100, 100))
        self.spindleon_abutton.setFont(font)

        self.horizontalLayout_36.addWidget(self.spindleon_abutton)

        self.spindleoff_abutton = ActionButton(self.groupBox_4)
        self.spindleoff_abutton.setObjectName(u"spindleoff_abutton")
        self.spindleoff_abutton.setMinimumSize(QSize(42, 42))
        self.spindleoff_abutton.setMaximumSize(QSize(100, 100))
        self.spindleoff_abutton.setFont(font)

        self.horizontalLayout_36.addWidget(self.spindleoff_abutton)


        self.verticalLayout_24.addLayout(self.horizontalLayout_36)


        self.horizontalLayout_4.addWidget(self.groupBox_4)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_8)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_2.setContentsMargins(-1, 5, -1, 5)
        self.main_gbox = QGroupBox(self.centralwidget)
        self.main_gbox.setObjectName(u"main_gbox")
        font12 = QFont()
        font12.setFamilies([u"3270 Semi-Condensed"])
        font12.setPointSize(10)
        font12.setBold(True)
        self.main_gbox.setFont(font12)
        self.horizontalLayout_6 = QHBoxLayout(self.main_gbox)
        self.horizontalLayout_6.setSpacing(10)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.estop_abutton = ActionButton(self.main_gbox)
        self.estop_abutton.setObjectName(u"estop_abutton")
        sizePolicy13.setHeightForWidth(self.estop_abutton.sizePolicy().hasHeightForWidth())
        self.estop_abutton.setSizePolicy(sizePolicy13)
        self.estop_abutton.setMinimumSize(QSize(68, 48))
        self.estop_abutton.setMaximumSize(QSize(80, 60))
        self.estop_abutton.setFont(font12)
        self.estop_abutton.setCheckable(True)

        self.horizontalLayout_6.addWidget(self.estop_abutton)

        self.power_abutton = ActionButton(self.main_gbox)
        self.power_abutton.setObjectName(u"power_abutton")
        self.power_abutton.setEnabled(False)
        self.power_abutton.setMinimumSize(QSize(68, 48))
        self.power_abutton.setMaximumSize(QSize(80, 60))
        self.power_abutton.setFont(font12)
        self.power_abutton.setCheckable(True)

        self.horizontalLayout_6.addWidget(self.power_abutton)


        self.horizontalLayout_2.addWidget(self.main_gbox)

        self.mode_gbox = QGroupBox(self.centralwidget)
        self.mode_gbox.setObjectName(u"mode_gbox")
        self.mode_gbox.setFont(font12)
        self.horizontalLayout_8 = QHBoxLayout(self.mode_gbox)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.mode_man_button = ActionButton(self.mode_gbox)
        self.modeGroup = QButtonGroup(MainWindow)
        self.modeGroup.setObjectName(u"modeGroup")
        self.modeGroup.addButton(self.mode_man_button)
        self.mode_man_button.setObjectName(u"mode_man_button")
        sizePolicy15 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        sizePolicy15.setHorizontalStretch(0)
        sizePolicy15.setVerticalStretch(0)
        sizePolicy15.setHeightForWidth(self.mode_man_button.sizePolicy().hasHeightForWidth())
        self.mode_man_button.setSizePolicy(sizePolicy15)
        self.mode_man_button.setMinimumSize(QSize(68, 48))
        self.mode_man_button.setMaximumSize(QSize(80, 60))
        self.mode_man_button.setFont(font12)
        self.mode_man_button.setCheckable(True)
        self.mode_man_button.setAutoExclusive(True)

        self.horizontalLayout_8.addWidget(self.mode_man_button)

        self.mod_auto_button = ActionButton(self.mode_gbox)
        self.modeGroup.addButton(self.mod_auto_button)
        self.mod_auto_button.setObjectName(u"mod_auto_button")
        sizePolicy15.setHeightForWidth(self.mod_auto_button.sizePolicy().hasHeightForWidth())
        self.mod_auto_button.setSizePolicy(sizePolicy15)
        self.mod_auto_button.setMinimumSize(QSize(68, 48))
        self.mod_auto_button.setMaximumSize(QSize(80, 60))
        self.mod_auto_button.setFont(font12)
        self.mod_auto_button.setCheckable(True)
        self.mod_auto_button.setAutoExclusive(True)

        self.horizontalLayout_8.addWidget(self.mod_auto_button)

        self.mode_mdi_button = ActionButton(self.mode_gbox)
        self.modeGroup.addButton(self.mode_mdi_button)
        self.mode_mdi_button.setObjectName(u"mode_mdi_button")
        sizePolicy15.setHeightForWidth(self.mode_mdi_button.sizePolicy().hasHeightForWidth())
        self.mode_mdi_button.setSizePolicy(sizePolicy15)
        self.mode_mdi_button.setMinimumSize(QSize(68, 48))
        self.mode_mdi_button.setMaximumSize(QSize(80, 60))
        self.mode_mdi_button.setFont(font12)
        self.mode_mdi_button.setCheckable(True)
        self.mode_mdi_button.setAutoExclusive(True)

        self.horizontalLayout_8.addWidget(self.mode_mdi_button)


        self.horizontalLayout_2.addWidget(self.mode_gbox)

        self.home_gbox = QGroupBox(self.centralwidget)
        self.home_gbox.setObjectName(u"home_gbox")
        self.home_gbox.setFont(font12)
        self.horizontalLayout_3 = QHBoxLayout(self.home_gbox)
        self.horizontalLayout_3.setSpacing(10)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.home_dbutton = DialogButton(self.home_gbox)
        self.home_dbutton.setObjectName(u"home_dbutton")
        self.home_dbutton.setMinimumSize(QSize(68, 48))
        self.home_dbutton.setMaximumSize(QSize(80, 60))
        self.home_dbutton.setFont(font12)
        self.home_dbutton.setCheckable(True)

        self.horizontalLayout_3.addWidget(self.home_dbutton)


        self.horizontalLayout_2.addWidget(self.home_gbox)

        self.part_gbox = QGroupBox(self.centralwidget)
        self.part_gbox.setObjectName(u"part_gbox")
        self.part_gbox.setFont(font12)
        self.horizontalLayout_5 = QHBoxLayout(self.part_gbox)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.zero_dbutton_2 = DialogButton(self.part_gbox)
        self.zero_dbutton_2.setObjectName(u"zero_dbutton_2")
        self.zero_dbutton_2.setMinimumSize(QSize(68, 48))
        self.zero_dbutton_2.setMaximumSize(QSize(80, 60))
        self.zero_dbutton_2.setFont(font12)

        self.horizontalLayout_5.addWidget(self.zero_dbutton_2)

        self.zero_dbutton = DialogButton(self.part_gbox)
        self.zero_dbutton.setObjectName(u"zero_dbutton")
        self.zero_dbutton.setMinimumSize(QSize(68, 48))
        self.zero_dbutton.setMaximumSize(QSize(80, 60))
        self.zero_dbutton.setFont(font12)

        self.horizontalLayout_5.addWidget(self.zero_dbutton)


        self.horizontalLayout_2.addWidget(self.part_gbox)

        self.program_gbox = QGroupBox(self.centralwidget)
        self.program_gbox.setObjectName(u"program_gbox")
        self.program_gbox.setFont(font12)
        self.horizontalLayout_7 = QHBoxLayout(self.program_gbox)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.run_abutton = ActionButton(self.program_gbox)
        self.run_abutton.setObjectName(u"run_abutton")
        self.run_abutton.setMinimumSize(QSize(68, 48))
        self.run_abutton.setMaximumSize(QSize(80, 60))
        self.run_abutton.setFont(font12)
        icon51 = QIcon()
        icon51.addFile(u":/images/forward.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.run_abutton.setIcon(icon51)
        self.run_abutton.setIconSize(QSize(24, 24))

        self.horizontalLayout_7.addWidget(self.run_abutton)

        self.pause_abutton = ActionButton(self.program_gbox)
        self.pause_abutton.setObjectName(u"pause_abutton")
        self.pause_abutton.setMinimumSize(QSize(68, 48))
        self.pause_abutton.setMaximumSize(QSize(80, 60))
        self.pause_abutton.setFont(font12)
        icon52 = QIcon()
        icon52.addFile(u":/images/pause.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pause_abutton.setIcon(icon52)
        self.pause_abutton.setIconSize(QSize(24, 24))

        self.horizontalLayout_7.addWidget(self.pause_abutton)

        self.stop_abutton = ActionButton(self.program_gbox)
        self.stop_abutton.setObjectName(u"stop_abutton")
        self.stop_abutton.setMinimumSize(QSize(68, 48))
        self.stop_abutton.setMaximumSize(QSize(80, 60))
        self.stop_abutton.setFont(font12)
        icon53 = QIcon()
        icon53.addFile(u":/images/stop.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.stop_abutton.setIcon(icon53)
        self.stop_abutton.setIconSize(QSize(24, 24))

        self.horizontalLayout_7.addWidget(self.stop_abutton)


        self.horizontalLayout_2.addWidget(self.program_gbox)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        self.device_delete_item_button.clicked.connect(self.filesystemtable_2.deleteItem)
        self.removabledevicecombobox.currentPathChanged.connect(self.filesystemtable_2.setRootPath)
        self.device_new_file_button.clicked.connect(self.filesystemtable_2.newFile)
        self.main_rename_item_button.clicked.connect(self.filesystemtable.rename)
        self.main_new_file_button.clicked.connect(self.filesystemtable.newFile)
        self.main_new_folder_button.clicked.connect(self.filesystemtable.newFolder)
        self.device_new_folder_button.clicked.connect(self.filesystemtable_2.newFolder)
        self.main_load_gcode_button.clicked.connect(self.filesystemtable.loadSelectedFile)
        self.main_delete_item_button.clicked.connect(self.filesystemtable.deleteItem)
        self.device_folder_up_button.clicked.connect(self.filesystemtable_2.viewParentDirectory)
        self.device_rename_item_button.clicked.connect(self.filesystemtable_2.rename)
        self.main_folder_up_button.clicked.connect(self.filesystemtable.viewParentDirectory)
        self.device_eject_usb_button.clicked.connect(self.removabledevicecombobox.ejectDevice)
        self.pushButton_17.clicked.connect(self.tooltable.deleteSelectedTool)
        self.pushButton_18.clicked.connect(self.tooltable.addTool)
        self.pushButton_15.clicked.connect(self.tooltable.saveToolTable)
        self.pushButton_12.clicked.connect(self.tooltable.loadToolTable)
        self.tooltable.toolSelected.connect(self.toolmodel.toolSelected)
        self.save_tool_properties.clicked.connect(self.toolmodel.saveField)
        self.find_dialog.clicked.connect(self.gcodeEditor.findDialog)
        self.pushButton.clicked.connect(self.gcodeEditor.saveFile)
        self.pushButton_5.clicked.connect(self.gcodeEditor.saveFileAs)
        self.pushButton_3.clicked.connect(self.gcodeEditor.undo)
        self.pushButton_6.clicked.connect(self.gcodeEditor.redo)
        self.pushButton_14.clicked.connect(self.gcodeEditor.selectAll)
        self.pushButton_7.clicked.connect(self.gcodeEditor.zoomIn)
        self.pushButton_13.clicked.connect(self.gcodeEditor.zoomOut)
        self.clear_view.clicked.connect(self.vtk.clearLivePlot)
        self.pan_view.toggled.connect(self.vtk.enable_panning)
        self.machine_view.clicked.connect(self.vtk.setViewMachine)
        self.path_view.clicked.connect(self.vtk.setViewPath)
        self.zoom_out.clicked.connect(self.vtk.zoomOut)
        self.zoom_in.clicked.connect(self.vtk.zoomIn)
        self.plotY.clicked.connect(self.vtk.setViewY)
        self.plotX.clicked.connect(self.vtk.setViewX)
        self.plotP.clicked.connect(self.vtk.setViewP)
        self.plotZ.clicked.connect(self.vtk.setViewZ)
        self.program_view.clicked.connect(self.vtk.setViewProgram)

        self.Tabs.setCurrentIndex(0)
        self.tabWidget.setCurrentIndex(0)
        self.probe_tab_widget.setCurrentIndex(0)
        self.set_wco_offset_Btn.setDefault(False)
        self.probe_help_widget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"TurBoNC", None))
        self.actionExit.setText(QCoreApplication.translate("MainWindow", u"Exit", None))
        self.actionOpen.setText(QCoreApplication.translate("MainWindow", u"&Open ...", None))
#if QT_CONFIG(shortcut)
        self.actionOpen.setShortcut(QCoreApplication.translate("MainWindow", u"O", None))
#endif // QT_CONFIG(shortcut)
        self.actionClose.setText(QCoreApplication.translate("MainWindow", u"Close", None))
        self.actionReload.setText(QCoreApplication.translate("MainWindow", u"&Reload", None))
#if QT_CONFIG(shortcut)
        self.actionReload.setShortcut(QCoreApplication.translate("MainWindow", u"Ctrl+R", None))
#endif // QT_CONFIG(shortcut)
        self.actionSave_As.setText(QCoreApplication.translate("MainWindow", u"Save As ...", None))
        self.actionHome_X.setText(QCoreApplication.translate("MainWindow", u"Home &X", None))
        self.actionHome_Y.setText(QCoreApplication.translate("MainWindow", u"Home &Y", None))
        self.actionHome_Z.setText(QCoreApplication.translate("MainWindow", u"Home &Z", None))
        self.action_EmergencyStop_toggle.setText(QCoreApplication.translate("MainWindow", u"Toggle E-stop", None))
#if QT_CONFIG(shortcut)
        self.action_EmergencyStop_toggle.setShortcut(QCoreApplication.translate("MainWindow", u"F1", None))
#endif // QT_CONFIG(shortcut)
        self.action_EmergencyStop_toggle.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.estop.toggle", None))
        self.action_MachinePower_toggle.setText(QCoreApplication.translate("MainWindow", u"Machine Power", None))
#if QT_CONFIG(shortcut)
        self.action_MachinePower_toggle.setShortcut(QCoreApplication.translate("MainWindow", u"F2", None))
#endif // QT_CONFIG(shortcut)
        self.action_MachinePower_toggle.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.power.toggle", None))
        self.actionHome_All.setText(QCoreApplication.translate("MainWindow", u"Home All", None))
#if QT_CONFIG(shortcut)
        self.actionHome_All.setShortcut(QCoreApplication.translate("MainWindow", u"Home", None))
#endif // QT_CONFIG(shortcut)
        self.actionRun_Program.setText(QCoreApplication.translate("MainWindow", u"Run Program", None))
#if QT_CONFIG(shortcut)
        self.actionRun_Program.setShortcut(QCoreApplication.translate("MainWindow", u"R", None))
#endif // QT_CONFIG(shortcut)
        self.actionRun_Program.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.run", None))
        self.actionFile1.setText(QCoreApplication.translate("MainWindow", u"File1", None))
        self.actionReport_Actual_Position.setText(QCoreApplication.translate("MainWindow", u"Report Actual Position", None))
        self.actionTest.setText(QCoreApplication.translate("MainWindow", u"Test", None))
        self.action_Mist_toggle.setText(QCoreApplication.translate("MainWindow", u"Mist", None))
#if QT_CONFIG(shortcut)
        self.action_Mist_toggle.setShortcut(QCoreApplication.translate("MainWindow", u"F7", None))
#endif // QT_CONFIG(shortcut)
        self.action_Mist_toggle.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"coolant.mist.toggle", None))
        self.action_Flood_toggle.setText(QCoreApplication.translate("MainWindow", u"Flood", None))
#if QT_CONFIG(shortcut)
        self.action_Flood_toggle.setShortcut(QCoreApplication.translate("MainWindow", u"F8", None))
#endif // QT_CONFIG(shortcut)
        self.action_Flood_toggle.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"coolant.flood.toggle", None))
        self.action_program_run.setText(QCoreApplication.translate("MainWindow", u"Run Program", None))
        self.action_coolant_floodToggle.setText(QCoreApplication.translate("MainWindow", u"Flood", None))
        self.actionHalshow.setText(QCoreApplication.translate("MainWindow", u"HAL Show", None))
        self.actionHalshow.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"tool.halshow", None))
        self.actionHalmeter.setText(QCoreApplication.translate("MainWindow", u"HAL Meter", None))
        self.actionHalmeter.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"tool.halmeter", None))
        self.actionHAL_Scope.setText(QCoreApplication.translate("MainWindow", u"HAL Scope", None))
        self.actionHAL_Scope.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"tool.halscope", None))
        self.actionCalibration.setText(QCoreApplication.translate("MainWindow", u"Calibration", None))
        self.actionCalibration.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"tool.calibration", None))
        self.actionOverride_Limits.setText(QCoreApplication.translate("MainWindow", u"Override Limits", None))
        self.actionOverride_Limits.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.override-limits", None))
        self.actionOverride_Limits_2.setText(QCoreApplication.translate("MainWindow", u"Override Limits", None))
        self.actionOverride_Limits_2.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.override-limits", None))
        self.actionRun_From_Line.setText(QCoreApplication.translate("MainWindow", u"Run From Line", None))
        self.actionRun_From_Line.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.run-from-line", None))
        self.actionStep.setText(QCoreApplication.translate("MainWindow", u"Step", None))
#if QT_CONFIG(shortcut)
        self.actionStep.setShortcut(QCoreApplication.translate("MainWindow", u"T", None))
#endif // QT_CONFIG(shortcut)
        self.actionStep.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.step", None))
        self.actionPause.setText(QCoreApplication.translate("MainWindow", u"Pause", None))
#if QT_CONFIG(shortcut)
        self.actionPause.setShortcut(QCoreApplication.translate("MainWindow", u"P", None))
#endif // QT_CONFIG(shortcut)
        self.actionPause.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.pause", None))
        self.actionStop.setText(QCoreApplication.translate("MainWindow", u"Stop", None))
#if QT_CONFIG(shortcut)
        self.actionStop.setShortcut(QCoreApplication.translate("MainWindow", u"Esc", None))
#endif // QT_CONFIG(shortcut)
        self.actionStop.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.abort", None))
        self.actionResume.setText(QCoreApplication.translate("MainWindow", u"Resume", None))
#if QT_CONFIG(shortcut)
        self.actionResume.setShortcut(QCoreApplication.translate("MainWindow", u"S", None))
#endif // QT_CONFIG(shortcut)
        self.actionResume.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.resume", None))
        self.actionPause_at_M1.setText(QCoreApplication.translate("MainWindow", u"Pause at 'M1'", None))
        self.actionPause_at_M1.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.optional-stop.toggle", None))
        self.actionSkip_lines_with.setText(QCoreApplication.translate("MainWindow", u"Skip lines with '/'", None))
        self.actionSkip_lines_with.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.block-delete.toggle", None))
        self.statuslabel_13.setText(QCoreApplication.translate("MainWindow", u"G0 G0 G0 G0 G0 G0 G0 G0 G0 G0 G0 G0 G0 G0 G0 G0", None))
        self.statuslabel_13.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"trigger\": true, \"type\": \"str\", \"url\": \"status:gcodes?text\"}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"Active Codes\"}]", None))
        self.statuslabel_13.setProperty(u"statusItem", "")
        self.statuslabel_14.setText(QCoreApplication.translate("MainWindow", u"M0 M0 M0 M0 M0 M0 M0 M0 M0", None))
        self.statuslabel_14.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"trigger\": true, \"type\": \"str\", \"url\": \"status:mcodes?text\"}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"Active Mcodes\"}]", None))
        self.statuslabel_14.setProperty(u"statusItem", "")
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.drolabel_10.setText(QCoreApplication.translate("MainWindow", u"     0.000", None))
        self.drolabel_10.setProperty(u"inchFormat", QCoreApplication.translate("MainWindow", u"%9.4f", None))
        self.drolabel_10.setProperty(u"millimeterFormat", QCoreApplication.translate("MainWindow", u"%10.3f", None))
        self.drolabel_10.setProperty(u"degreeFormat", QCoreApplication.translate("MainWindow", u"%10.2f", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Y", None))
        self.drolabel_15.setText(QCoreApplication.translate("MainWindow", u"     0.000", None))
        self.drolabel_15.setProperty(u"inchFormat", QCoreApplication.translate("MainWindow", u"%9.4f", None))
        self.drolabel_15.setProperty(u"millimeterFormat", QCoreApplication.translate("MainWindow", u"%10.3f", None))
        self.drolabel_15.setProperty(u"degreeFormat", QCoreApplication.translate("MainWindow", u"%10.2f", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"Z", None))
        self.drolabel_16.setText(QCoreApplication.translate("MainWindow", u"     0.000", None))
        self.drolabel_16.setProperty(u"inchFormat", QCoreApplication.translate("MainWindow", u"%9.4f", None))
        self.drolabel_16.setProperty(u"millimeterFormat", QCoreApplication.translate("MainWindow", u"%10.3f", None))
        self.drolabel_16.setProperty(u"degreeFormat", QCoreApplication.translate("MainWindow", u"%10.2f", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_8), QCoreApplication.translate("MainWindow", u"Relative", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.drolabel_7.setText(QCoreApplication.translate("MainWindow", u"     0.000", None))
        self.drolabel_7.setProperty(u"inchFormat", QCoreApplication.translate("MainWindow", u"%9.4f", None))
        self.drolabel_7.setProperty(u"millimeterFormat", QCoreApplication.translate("MainWindow", u"%10.3f", None))
        self.drolabel_7.setProperty(u"degreeFormat", QCoreApplication.translate("MainWindow", u"%10.2f", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Y", None))
        self.drolabel_8.setText(QCoreApplication.translate("MainWindow", u"     0.000", None))
        self.drolabel_8.setProperty(u"inchFormat", QCoreApplication.translate("MainWindow", u"%9.4f", None))
        self.drolabel_8.setProperty(u"millimeterFormat", QCoreApplication.translate("MainWindow", u"%10.3f", None))
        self.drolabel_8.setProperty(u"degreeFormat", QCoreApplication.translate("MainWindow", u"%10.2f", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Z", None))
        self.drolabel_9.setText(QCoreApplication.translate("MainWindow", u"     0.000", None))
        self.drolabel_9.setProperty(u"inchFormat", QCoreApplication.translate("MainWindow", u"%9.4f", None))
        self.drolabel_9.setProperty(u"millimeterFormat", QCoreApplication.translate("MainWindow", u"%10.3f", None))
        self.drolabel_9.setProperty(u"degreeFormat", QCoreApplication.translate("MainWindow", u"%10.2f", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_7), QCoreApplication.translate("MainWindow", u"Absolute", None))
        self.clear_view.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
        self.pan_view.setText(QCoreApplication.translate("MainWindow", u"Pan", None))
        self.machine_view.setText(QCoreApplication.translate("MainWindow", u"Mach", None))
        self.program_view.setText(QCoreApplication.translate("MainWindow", u"Prgm", None))
        self.path_view.setText(QCoreApplication.translate("MainWindow", u"Path", None))
        self.zoom_out.setText(QCoreApplication.translate("MainWindow", u"-", None))
        self.zoom_in.setText(QCoreApplication.translate("MainWindow", u"+", None))
        self.plotX.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.plotY.setText(QCoreApplication.translate("MainWindow", u"Y", None))
        self.plotZ.setText(QCoreApplication.translate("MainWindow", u"Z", None))
        self.plotP.setText(QCoreApplication.translate("MainWindow", u"P", None))
        self.actioncombobox.setItemText(0, QCoreApplication.translate("MainWindow", u"G54", None))
        self.actioncombobox.setItemText(1, QCoreApplication.translate("MainWindow", u"G55", None))
        self.actioncombobox.setItemText(2, QCoreApplication.translate("MainWindow", u"G56", None))
        self.actioncombobox.setItemText(3, QCoreApplication.translate("MainWindow", u"G57", None))
        self.actioncombobox.setItemText(4, QCoreApplication.translate("MainWindow", u"G58", None))
        self.actioncombobox.setItemText(5, QCoreApplication.translate("MainWindow", u"G59", None))
        self.actioncombobox.setItemText(6, QCoreApplication.translate("MainWindow", u"G59.1", None))
        self.actioncombobox.setItemText(7, QCoreApplication.translate("MainWindow", u"G59.2", None))
        self.actioncombobox.setItemText(8, QCoreApplication.translate("MainWindow", u"G59.3", None))

        self.actioncombobox.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"MDI", None))
        self.Tabs.setTabText(self.Tabs.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"Program", None))
        self.dialogbutton_2.setText(QCoreApplication.translate("MainWindow", u"Open", None))
        self.dialogbutton_2.setProperty(u"dialogName", QCoreApplication.translate("MainWindow", u"open_file", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.pushButton_5.setText(QCoreApplication.translate("MainWindow", u"Save As", None))
        self.pushButton_3.setText(QCoreApplication.translate("MainWindow", u"Undo", None))
        self.pushButton_6.setText(QCoreApplication.translate("MainWindow", u"Redo", None))
        self.pushButton_14.setText(QCoreApplication.translate("MainWindow", u"Select All", None))
        self.pushButton_7.setText(QCoreApplication.translate("MainWindow", u"Zoon +", None))
        self.pushButton_13.setText(QCoreApplication.translate("MainWindow", u"Zoom -", None))
        self.find_dialog.setText(QCoreApplication.translate("MainWindow", u"Find/Replace", None))
        self.Tabs.setTabText(self.Tabs.indexOf(self.tab_4), QCoreApplication.translate("MainWindow", u"Editor", None))
        self.main_folder_up_button.setText(QCoreApplication.translate("MainWindow", u"  FOLDER UP", None))
        self.main_load_gcode_button.setText(QCoreApplication.translate("MainWindow", u"LOAD G-CODE", None))
        self.main_delete_item_button.setText(QCoreApplication.translate("MainWindow", u" DELETE", None))
        self.main_new_file_button.setText(QCoreApplication.translate("MainWindow", u" NEW FILE", None))
        self.main_new_folder_button.setText(QCoreApplication.translate("MainWindow", u" NEW FOLDER", None))
        self.main_rename_item_button.setText(QCoreApplication.translate("MainWindow", u"RENAME", None))
        self.copy_from_usb.setText(QCoreApplication.translate("MainWindow", u"COPY\n"
"FROM\n"
"  USB", None))
        self.copy_to_usb.setText(QCoreApplication.translate("MainWindow", u"COPY\n"
"TO\n"
"USB", None))
        self.device_folder_up_button.setText(QCoreApplication.translate("MainWindow", u"  FOLDER UP", None))
        self.device_eject_usb_button.setText(QCoreApplication.translate("MainWindow", u"EJECT USB", None))
        self.device_delete_item_button.setText(QCoreApplication.translate("MainWindow", u" DELETE", None))
        self.device_new_file_button.setText(QCoreApplication.translate("MainWindow", u" NEW FILE", None))
        self.device_new_folder_button.setText(QCoreApplication.translate("MainWindow", u" NEW FOLDER", None))
        self.device_rename_item_button.setText(QCoreApplication.translate("MainWindow", u"RENAME", None))
        self.Tabs.setTabText(self.Tabs.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Files", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Tool Extra Properties", None))
        self.save_tool_properties.setText(QCoreApplication.translate("MainWindow", u"Save Tool Things", None))
        self.pushButton_17.setText(QCoreApplication.translate("MainWindow", u"DELETE", None))
        self.pushButton_18.setText(QCoreApplication.translate("MainWindow", u"ADD TOOL", None))
        self.pushButton_15.setText(QCoreApplication.translate("MainWindow", u"SAVE TABLE", None))
        self.pushButton_12.setText(QCoreApplication.translate("MainWindow", u"RELOAD TABLE", None))
        self.Tabs.setTabText(self.Tabs.indexOf(self.tab_3), QCoreApplication.translate("MainWindow", u"Tools", None))
        self.label_89.setText(QCoreApplication.translate("MainWindow", u" WORK OFFSETS", None))
        self.actionbutton_31.setText(QCoreApplication.translate("MainWindow", u"G54", None))
        self.actionbutton_31.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G54", None))
        self.actionbutton_32.setText(QCoreApplication.translate("MainWindow", u"G55", None))
        self.actionbutton_32.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G55", None))
        self.actionbutton_33.setText(QCoreApplication.translate("MainWindow", u"G56", None))
        self.actionbutton_33.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G56", None))
        self.actionbutton_34.setText(QCoreApplication.translate("MainWindow", u"G57", None))
        self.actionbutton_34.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G57", None))
        self.actionbutton_35.setText(QCoreApplication.translate("MainWindow", u"G58", None))
        self.actionbutton_35.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G58", None))
        self.actionbutton_36.setText(QCoreApplication.translate("MainWindow", u"G59", None))
        self.actionbutton_36.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G59", None))
        self.actionbutton_37.setText(QCoreApplication.translate("MainWindow", u"G59.1", None))
        self.actionbutton_37.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G59.1", None))
        self.actionbutton_38.setText(QCoreApplication.translate("MainWindow", u"G59.2", None))
        self.actionbutton_38.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G59.2", None))
        self.actionbutton_39.setText(QCoreApplication.translate("MainWindow", u"G59.3", None))
        self.actionbutton_39.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.set-work-coord:G59.3", None))
        self.probe_wco_2.setText(QCoreApplication.translate("MainWindow", u"PROBE WCO", None))
        self.probe_wco_2.setProperty(u"checkedAction", QCoreApplication.translate("MainWindow", u"0", None))
        self.probe_Position_only_2.setText(QCoreApplication.translate("MainWindow", u"PROBE POS'N", None))
        self.probe_Position_only_2.setProperty(u"checkedAction", QCoreApplication.translate("MainWindow", u"1", None))
        self.label_93.setText(QCoreApplication.translate("MainWindow", u" Probing Parameters", None))
        self.ref_coilumn_header_24.setText("")
        self.label_103.setText(QCoreApplication.translate("MainWindow", u"Probe Tool #:", None))
        self.probe_tool_number_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0", None))
        self.probe_tool_number_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.probe-tool-number", None))
        self.probe_tool_number_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.label_104.setText(QCoreApplication.translate("MainWindow", u"Step Off Width:", None))
        self.step_off_width_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.step_off_width_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.step-off-width", None))
        self.step_off_width_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.ref_coilumn_header_25.setText("")
        self.label_105.setText(QCoreApplication.translate("MainWindow", u"PROBE FAST FDRATE:", None))
        self.probe_fast_fr_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0", None))
        self.probe_fast_fr_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.probe-fast-fr", None))
        self.probe_fast_fr_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.label_106.setText(QCoreApplication.translate("MainWindow", u"PROBE SLOW FDRATE:", None))
        self.probe_slow_fr_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0", None))
        self.probe_slow_fr_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.probe-slow-fr", None))
        self.probe_slow_fr_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.ref_coilumn_header_26.setText("")
        self.label_107.setText(QCoreApplication.translate("MainWindow", u"Max X/Y Distance:", None))
        self.max_xy_distance_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.max_xy_distance_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.max-xy-distance", None))
        self.max_xy_distance_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.label_111.setText(QCoreApplication.translate("MainWindow", u"X/Y Clearance:", None))
        self.xy_clearance_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.xy_clearance_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.xy-clearance", None))
        self.xy_clearance_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.ref_coilumn_header_27.setText("")
        self.label_112.setText(QCoreApplication.translate("MainWindow", u"Max Z Distance:", None))
        self.max_z_distance_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.max_z_distance_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.max-z-distance", None))
        self.max_z_distance_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.label_115.setText(QCoreApplication.translate("MainWindow", u"Z Clearance:", None))
        self.z_clearance_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.z_clearance_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.z-clearance", None))
        self.z_clearance_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.ref_coilumn_header_28.setText("")
        self.label_116.setText(QCoreApplication.translate("MainWindow", u"Extra Probe Depth:", None))
        self.extra_probe_depth_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.extra_probe_depth_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.extra-probe-depth", None))
        self.extra_probe_depth_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.label_117.setText(QCoreApplication.translate("MainWindow", u"EDGE WIDTH:", None))
        self.edge_width_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.edge_width_2.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"probe-parameters.edge-width", None))
        self.edge_width_2.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.label_118.setText(QCoreApplication.translate("MainWindow", u" Probe Results", None))
        self.reset_all_data_2.setText(QCoreApplication.translate("MainWindow", u"RESET ALL DATA", None))
        self.reset_all_data_2.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"reset_all_data.ngc", None))
        self.x_data_reset1_2.setText(QCoreApplication.translate("MainWindow", u"X DATA RESET", None))
        self.x_data_reset1_2.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"x_data_reset.ngc", None))
        self.y_data_reset1_2.setText(QCoreApplication.translate("MainWindow", u"Y DATA RESET", None))
        self.y_data_reset1_2.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"y_data_reset.ngc", None))
        self.label_119.setText(QCoreApplication.translate("MainWindow", u"X- PROBED:", None))
        self.x_minus_probed_position_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.x_minus_probed_position_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.x_minus_probed_position_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_120.setText(QCoreApplication.translate("MainWindow", u"X+ PROBED:", None))
        self.x_plus_probed_position_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.x_plus_probed_position_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.x_plus_probed_position_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_121.setText(QCoreApplication.translate("MainWindow", u"X WIDTH:", None))
        self.x_probed_width_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.x_probed_width_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.x_probed_width_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_122.setText(QCoreApplication.translate("MainWindow", u"Y- PROBED:", None))
        self.y_minus_probed_position_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.y_minus_probed_position_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.y_minus_probed_position_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_123.setText(QCoreApplication.translate("MainWindow", u"Y+ PROBED:", None))
        self.y_plus_probed_position_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.y_plus_probed_position_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.y_plus_probed_position_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_124.setText(QCoreApplication.translate("MainWindow", u"Y WIDTH:", None))
        self.y_probed_width_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.y_probed_width_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.y_probed_width_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_125.setText(QCoreApplication.translate("MainWindow", u"Z- PROBED:", None))
        self.z_minus_probed_position_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.z_minus_probed_position_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.z_minus_probed_position_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_126.setText(QCoreApplication.translate("MainWindow", u"DIAM:", None))
        self.averaged_diam_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.averaged_diam_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.averaged_diam_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_127.setText(QCoreApplication.translate("MainWindow", u"X CENTER:", None))
        self.x_center_probed_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.x_center_probed_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.x_center_probed_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_128.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p>EDGE DELTA:</p></body></html>", None))
        self.edge_delta_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.edge_delta_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.edge_delta_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_129.setText(QCoreApplication.translate("MainWindow", u"EDGE ANGLE:", None))
        self.edge_angle_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.edge_angle_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.edge_angle_2.setProperty(u"expression", QCoreApplication.translate("MainWindow", u"val", None))
        self.edge_angle_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_130.setText(QCoreApplication.translate("MainWindow", u"Y CENTER:", None))
        self.y_center_probed_2.setText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.y_center_probed_2.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.4f}", None))
        self.y_center_probed_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.mdi_entry_box_6.setPlaceholderText(QCoreApplication.translate("MainWindow", u"MDI", None))
        self.outside_corners.setText(QCoreApplication.translate("MainWindow", u"OUTSIDE CORNERS", None))
        self.inside_corners.setText(QCoreApplication.translate("MainWindow", u"INSIDE CORNERS", None))
        self.boss_and_pocket.setText(QCoreApplication.translate("MainWindow", u"BOSS AND POCKET", None))
        self.ridge_and_valley.setText(QCoreApplication.translate("MainWindow", u"RIDGE AND VALLEY", None))
        self.rotation_angle.setText(QCoreApplication.translate("MainWindow", u"EDGE ANGLE", None))
        self.rotary_axis_2.setText(QCoreApplication.translate("MainWindow", u"ROTARY AXIS", None))
        self.calibrate.setText(QCoreApplication.translate("MainWindow", u"CALIBRATE", None))
        self.probe_help.setText(QCoreApplication.translate("MainWindow", u"PROBE HELP", None))
        self.label_19.setText("")
        self.probe_led.setProperty(u"pinBaseName", QCoreApplication.translate("MainWindow", u"probe-led", None))
        self.halbutton.setText("")
        self.halbutton.setProperty(u"pinBaseName", QCoreApplication.translate("MainWindow", u"probe-in", None))
        self.probe_back_left_top_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_back_left_top_corner.ngc", None))
        self.probe_back_right_top_corner.setText("")
        self.probe_back_right_top_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_back_right_top_corner.ngc", None))
        self.probe_right_top_side.setText("")
        self.probe_right_top_side.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_right_top_side.ngc", None))
        self.probe_z_minus_wco_edge.setText("")
        self.probe_z_minus_wco_edge.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_z_minus_wco.ngc", None))
        self.probe_front_top_side.setText("")
        self.probe_front_top_side.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_front_top_side.ngc", None))
        self.probe_back_top_side.setText("")
        self.probe_back_top_side.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_back_top_side.ngc", None))
        self.probe_front_left_top_corner.setText("")
        self.probe_front_left_top_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_front_left_top_corner.ngc", None))
        self.probe_front_right_top_corner.setText("")
        self.probe_front_right_top_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_front_right_top_corner.ngc", None))
        self.probe_left_top_side.setText("")
        self.probe_left_top_side.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_left_top_side.ngc", None))
        self.probe_front_right_inside_corner.setText("")
        self.probe_front_right_inside_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_front_right_inside_corner.ngc", None))
        self.probe_y_plus_wco.setText("")
        self.probe_y_plus_wco.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_y_plus_wco.ngc", None))
        self.probe_back_right_inside_corner.setText("")
        self.probe_back_right_inside_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_back_right_inside_corner.ngc", None))
        self.probe_front_left_inside_corner.setText("")
        self.probe_front_left_inside_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_front_left_inside_corner.ngc", None))
        self.probe_z_minus_wco_inside.setText("")
        self.probe_z_minus_wco_inside.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_z_minus_wco.ngc", None))
        self.probe_back_left_inside_corner.setText("")
        self.probe_back_left_inside_corner.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_back_left_inside_corner.ngc", None))
        self.probe_x_minus_wco.setText("")
        self.probe_x_minus_wco.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_x_minus_wco.ngc", None))
        self.probe_x_plus_wco.setText("")
        self.probe_x_plus_wco.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_x_plus_wco.ngc", None))
        self.probe_y_minus_wco.setText("")
        self.probe_y_minus_wco.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_y_minus_wco.ngc", None))
        self.probe_round_boss.setText("")
        self.probe_round_boss.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_round_boss.ngc", None))
        self.probe_round_pocket.setText("")
        self.probe_round_pocket.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_round_pocket.ngc", None))
        self.probe_rect_boss.setText("")
        self.probe_rect_boss.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_rect_boss.ngc", None))
        self.probe_rect_pocket.setText("")
        self.probe_rect_pocket.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_rect_pocket.ngc", None))
        self.hint_label.setText(QCoreApplication.translate("MainWindow", u"HINT", None))
        self.label_70.setText(QCoreApplication.translate("MainWindow", u"DIAM:", None))
        self.diameter_hint.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.label_71.setText(QCoreApplication.translate("MainWindow", u"X :", None))
        self.x_hint_0.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.label_72.setText(QCoreApplication.translate("MainWindow", u"Y :", None))
        self.y_hint_0.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.probe_valley_x.setText("")
        self.probe_valley_x.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_valley_x.ngc", None))
        self.probe_valley_y.setText("")
        self.probe_valley_y.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_valley_y.ngc", None))
        self.probe_ridge_x.setText("")
        self.probe_ridge_x.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_ridge_x.ngc", None))
        self.probe_ridge_y.setText("")
        self.probe_ridge_y.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_ridge_y.ngc", None))
        self.hint_label_2.setText(QCoreApplication.translate("MainWindow", u"HINT", None))
        self.label_74.setText(QCoreApplication.translate("MainWindow", u"X :", None))
        self.x_hint.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.label_75.setText(QCoreApplication.translate("MainWindow", u"Y :", None))
        self.y_hint.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.probe_top_left_edge_angle.setText("")
        self.probe_top_left_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_top_left_edge_angle.ngc", None))
        self.probe_corner_y_plus_edge_angle.setText("")
        self.probe_corner_y_plus_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_corner_y_plus_edge_angle.ngc", None))
        self.probe_corner_x_plus_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_corner_x_plus_edge_angle.ngc", None))
        self.probe_corner_y_minus_edge_angle.setText("")
        self.probe_corner_y_minus_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_corner_y_minus_edge_angle.ngc", None))
        self.probe_z_minus_edge.setText("")
        self.probe_z_minus_edge.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_z_minus_wco.ngc", None))
        self.probe_corner_x_minus_edge_angle.setText("")
        self.probe_corner_x_minus_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_corner_x_minus_edge_angle.ngc", None))
        self.probe_top_right_edge_angle.setText("")
        self.probe_top_right_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_top_right_edge_angle.ngc", None))
        self.probe_top_back_edge_angle.setText("")
        self.probe_top_back_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_top_back_edge_angle.ngc", None))
        self.probe_top_front_edge_angle.setText("")
        self.probe_top_front_edge_angle.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_top_front_edge_angle.ngc", None))
        self.set_wco_offset_Btn.setText(QCoreApplication.translate("MainWindow", u"SET WCO ROTATION FOR ANGLE PROBE OPERATIONS", None))
        self.label_94.setText(QCoreApplication.translate("MainWindow", u"PROBE CALIBRATION OFFSET:", None))
        self.calibration_offset.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.000000", None))
        self.calibration_offset.setProperty(u"settingName", QCoreApplication.translate("MainWindow", u"touch-probe.calibration-offset", None))
        self.calibration_offset.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[]", None))
        self.calibration_offset.setProperty(u"textFormat", QCoreApplication.translate("MainWindow", u"{:4f}", None))
        self.probe_cal_reset.setText(QCoreApplication.translate("MainWindow", u"PROBE CAL RESET", None))
        self.probe_cal_reset.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_cal_reset.ngc", None))
#if QT_CONFIG(statustip)
        self.probe_cal_round_pocket.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.probe_cal_round_pocket.setText("")
        self.probe_cal_round_pocket.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_cal_round_pocket.ngc", None))
#if QT_CONFIG(statustip)
        self.probe_cal_round_boss.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.probe_cal_round_boss.setText("")
        self.probe_cal_round_boss.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_cal_round_boss.ngc", None))
        self.hint_label_4.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p align=\"center\">CALIBRATION</p><p align=\"center\">DIAMETER</p></body></html>", None))
        self.cal_diameter.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.cal_avg_error.setText(QCoreApplication.translate("MainWindow", u"CAL ON AVG XY ERROR", None))
        self.cal_avg_error.setProperty(u"checkedAction", QCoreApplication.translate("MainWindow", u"0", None))
        self.cal_x_error.setText(QCoreApplication.translate("MainWindow", u"CAL ON X ERROR", None))
        self.cal_x_error.setProperty(u"checkedAction", QCoreApplication.translate("MainWindow", u"1", None))
        self.cal_y_error.setText(QCoreApplication.translate("MainWindow", u"CAL ON Y ERROR", None))
        self.cal_y_error.setProperty(u"checkedAction", QCoreApplication.translate("MainWindow", u"2", None))
#if QT_CONFIG(statustip)
        self.probe_cal_square_pocket.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.probe_cal_square_pocket.setText("")
        self.probe_cal_square_pocket.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_cal_square_pocket.ngc", None))
#if QT_CONFIG(statustip)
        self.probe_cal_square_boss.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.probe_cal_square_boss.setText("")
        self.probe_cal_square_boss.setProperty(u"filename", QCoreApplication.translate("MainWindow", u"probe_cal_square_boss.ngc", None))
        self.hint_label_3.setText(QCoreApplication.translate("MainWindow", u"CALIBRATION WIDTH", None))
        self.label_108.setText(QCoreApplication.translate("MainWindow", u"X :", None))
        self.label_109.setText(QCoreApplication.translate("MainWindow", u"Y :", None))
        self.x_cal_width.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.y_cal_width.setPlaceholderText(QCoreApplication.translate("MainWindow", u"0.0000", None))
        self.label_77.setText("")
        self.label_78.setText("")
        self.label_79.setText("")
        self.label_110.setText("")
        self.label_80.setText("")
        self.label_113.setText("")
        self.probe_help_prev.setText(QCoreApplication.translate("MainWindow", u"     PREV PAGE  ", None))
        self.probe_help_next.setText(QCoreApplication.translate("MainWindow", u" NEXT PAGE     ", None))
        self.Tabs.setTabText(self.Tabs.indexOf(self.tab_6), QCoreApplication.translate("MainWindow", u"Probe", None))
        self.statuslabel.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"name\": \"New Rule\", \"property\": \"Text\", \"expression\": \"f\\\"The program has {ch[0]} lines of code\\\"\", \"channels\": [{\"url\": \"gcode_properties:file_lines\", \"trigger\": true}]}]", None))
        self.halbutton_2.setProperty(u"pinBaseName", QCoreApplication.translate("MainWindow", u"halbutton_test", None))
        self.Tabs.setTabText(self.Tabs.indexOf(self.tab_5), QCoreApplication.translate("MainWindow", u"Stats", None))
        self.Tabs.setTabText(self.Tabs.indexOf(self.tab_9), QCoreApplication.translate("MainWindow", u"P\u00e1gina", None))
        self.groupBox.setTitle(QCoreApplication.translate("MainWindow", u"JOG", None))
        self.jogxplus_abutton.setText("")
        self.jogxplus_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.jog.axis:x,pos", None))
        self.jogxmin_abutton.setText("")
        self.jogxmin_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.jog.axis:x,neg", None))
        self.jogyplus_abutton.setText("")
        self.jogyplus_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.jog.axis:y,pos", None))
        self.jogzplus_abutton.setText("")
        self.jogzplus_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.jog.axis:z,pos", None))
        self.jogzmin_abutton.setText("")
        self.jogzmin_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.jog.axis:z,neg", None))
        self.jogymin_abutton.setText("")
        self.jogymin_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.jog.axis:y,neg", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("MainWindow", u"FEED", None))
        self.feedover_slabel.setText(QCoreApplication.translate("MainWindow", u"Feed Override 0%", None))
        self.feedover_slabel.setProperty(u"format", QCoreApplication.translate("MainWindow", u"<b>FEED:</b> {:.0%}", None))
        self.feedover_slabel.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"url\": \"status:feedrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"Feed Override {ch[0]:.0%}\\\"\", \"name\": \"Feed Rate\"}]", None))
        self.feed_slider.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.feed-override.set", None))
        self.statuslabel_5.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"url\": \"status:spindle.0.override\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"{(ch[0]):.0%}\\\"\", \"name\": \"New Rule\"}]", None))
        self.actionbutton_30.setText(QCoreApplication.translate("MainWindow", u"F 100%", None))
        self.actionbutton_30.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"spindle.override.reset", None))
        self.rpm_label_3.setText(QCoreApplication.translate("MainWindow", u"Feed Rate", None))
        self.cur_feed.setText(QCoreApplication.translate("MainWindow", u"0.0", None))
        self.cur_feed.setProperty(u"format", QCoreApplication.translate("MainWindow", u"{:.1f}", None))
        self.cur_feed.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"url\": \"status:current_vel\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"{ch[0] * 60:.1f}\\\"\", \"name\": \"cur vel\"}]", None))
        self.cur_units.setText(QCoreApplication.translate("MainWindow", u"N/A/m", None))
        self.cur_units.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"url\": \"status:program_units?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"{ch[0]}/m\\\"\", \"name\": \"Linear Units\"}]", None))
        self.cur_units.setProperty(u"fromat", "")
        self.groupBox_3.setTitle(QCoreApplication.translate("MainWindow", u"TIME DATE", None))
        self.statuslabel_4.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"url\": \"clock:time\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"{ch[0]:%I:%M:%S}\\\"\", \"name\": \"time\"}]", None))
        self.statuslabel_2.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"url\": \"clock:time\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"{ch[0]:%d/%m/%Y}\\\"\", \"name\": \"date\"}]", None))
        self.groupBox_4.setTitle(QCoreApplication.translate("MainWindow", u"SPINDLE", None))
        self.spindle_load_indicator.setProperty(u"prefix", QCoreApplication.translate("MainWindow", u"LOAD", None))
        self.spindle_load_indicator.setProperty(u"sufix", QCoreApplication.translate("MainWindow", u"%", None))
        self.spindle_load_indicator.setProperty(u"format", QCoreApplication.translate("MainWindow", u".2f", None))
        self.spindle_load_indicator.setProperty(u"barGradient", [
            QCoreApplication.translate("MainWindow", u"0.0, 143, 179, 70", None),
            QCoreApplication.translate("MainWindow", u"0.79, 227, 237, 106", None),
            QCoreApplication.translate("MainWindow", u"0.84, 219, 124, 55", None),
            QCoreApplication.translate("MainWindow", u"1.0, 209, 0, 0", None)])
        self.spindle_load_indicator.setProperty(u"pinBaseName", QCoreApplication.translate("MainWindow", u"spindle-load", None))
        self.actionslider.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"spindle.override", None))
        self.statuslabel_3.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"channels\": [{\"url\": \"status:spindle.0.override\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"{(ch[0]):.0%}\\\"\", \"name\": \"New Rule\"}]", None))
        self.actionbutton_29.setText(QCoreApplication.translate("MainWindow", u"S 100%", None))
        self.actionbutton_29.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"spindle.override.reset", None))
        self.spindleon_abutton.setText(QCoreApplication.translate("MainWindow", u"ON", None))
        self.spindleon_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"spindle.0.forward", None))
        self.spindleoff_abutton.setText(QCoreApplication.translate("MainWindow", u"OFF", None))
        self.spindleoff_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"spindle.0.off", None))
        self.main_gbox.setTitle(QCoreApplication.translate("MainWindow", u"MAIN", None))
        self.estop_abutton.setText(QCoreApplication.translate("MainWindow", u"E-STOP", None))
        self.estop_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.estop.toggle", None))
        self.power_abutton.setText(QCoreApplication.translate("MainWindow", u"POWER", None))
        self.power_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.power.toggle", None))
        self.mode_gbox.setTitle(QCoreApplication.translate("MainWindow", u"MODE", None))
        self.mode_man_button.setText(QCoreApplication.translate("MainWindow", u"MAN", None))
        self.mode_man_button.setProperty(u"styleClass", QCoreApplication.translate("MainWindow", u"option", None))
        self.mode_man_button.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.mode.manual", None))
        self.mode_man_button.setProperty(u"position", QCoreApplication.translate("MainWindow", u"first", None))
        self.mod_auto_button.setText(QCoreApplication.translate("MainWindow", u"AUTO", None))
        self.mod_auto_button.setProperty(u"styleClass", QCoreApplication.translate("MainWindow", u"option", None))
        self.mod_auto_button.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.mode.auto", None))
        self.mode_mdi_button.setText(QCoreApplication.translate("MainWindow", u"MDI", None))
        self.mode_mdi_button.setProperty(u"styleClass", QCoreApplication.translate("MainWindow", u"option", None))
        self.mode_mdi_button.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"machine.mode.mdi", None))
        self.mode_mdi_button.setProperty(u"position", QCoreApplication.translate("MainWindow", u"last", None))
        self.home_gbox.setTitle(QCoreApplication.translate("MainWindow", u"HOME", None))
        self.home_dbutton.setText(QCoreApplication.translate("MainWindow", u"ALL", None))
        self.home_dbutton.setProperty(u"rules", QCoreApplication.translate("MainWindow", u"[{\"name\": \"All Homed\", \"property\": \"Checked\", \"expression\": \"ch[0]\", \"channels\": [{\"url\": \"status:all_axes_homed\", \"trigger\": true}]}]", None))
        self.home_dbutton.setProperty(u"dialogName", QCoreApplication.translate("MainWindow", u"home_all", None))
        self.part_gbox.setTitle(QCoreApplication.translate("MainWindow", u"PART", None))
        self.zero_dbutton_2.setText(QCoreApplication.translate("MainWindow", u"ZERO\n"
"X Y", None))
        self.zero_dbutton_2.setProperty(u"dialogName", QCoreApplication.translate("MainWindow", u"zero_xy", None))
        self.zero_dbutton.setText(QCoreApplication.translate("MainWindow", u"ZERO", None))
        self.zero_dbutton.setProperty(u"dialogName", QCoreApplication.translate("MainWindow", u"set_work_offsets", None))
        self.program_gbox.setTitle(QCoreApplication.translate("MainWindow", u"PROGRAM", None))
        self.run_abutton.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.run_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.run", None))
        self.pause_abutton.setText(QCoreApplication.translate("MainWindow", u"PAUSE", None))
        self.pause_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.pause", None))
        self.stop_abutton.setText(QCoreApplication.translate("MainWindow", u"STOP", None))
        self.stop_abutton.setProperty(u"actionName", QCoreApplication.translate("MainWindow", u"program.abort", None))
    # retranslateUi

