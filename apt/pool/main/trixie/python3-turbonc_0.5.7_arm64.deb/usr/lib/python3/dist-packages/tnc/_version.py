# These version placeholders will be replaced later during substitution.
__version__ = "0.5.6.post3.dev0+57a5303"
__version_tuple__ = (0, 5, 6, "post3", "dev0", "57a5303")
