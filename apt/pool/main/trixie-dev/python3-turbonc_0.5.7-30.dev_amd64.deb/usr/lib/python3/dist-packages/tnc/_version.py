# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post46.dev0+5f31a8c"
__version_tuple__ = (0, 5, 5, "post46", "dev0", "5f31a8c")
