# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post34.dev0+64af9e9"
__version_tuple__ = (0, 5, 5, "post34", "dev0", "64af9e9")
