# These version placeholders will be replaced later during substitution.
__version__ = "0.5.6.post2.dev0+df62f6c"
__version_tuple__ = (0, 5, 6, "post2", "dev0", "df62f6c")
