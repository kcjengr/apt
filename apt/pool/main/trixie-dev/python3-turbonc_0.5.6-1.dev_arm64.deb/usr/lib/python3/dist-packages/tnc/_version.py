# These version placeholders will be replaced later during substitution.
__version__ = "0.5.6.post1.dev0+b0a2090"
__version_tuple__ = (0, 5, 6, "post1", "dev0", "b0a2090")
