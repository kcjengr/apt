# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QAbstractSpinBox, QApplication, QButtonGroup,
    QCheckBox, QComboBox, QDoubleSpinBox, QFrame,
    QGridLayout, QHBoxLayout, QLabel, QLayout,
    QLineEdit, QListView, QListWidget, QListWidgetItem,
    QPushButton, QSizePolicy, QSlider, QSpacerItem,
    QSpinBox, QStackedWidget, QTabWidget, QTextBrowser,
    QVBoxLayout, QWidget)

from gcodeeditor import GCodeEditor
from monokrom.common.widgets.group_box import MkGroupBox
from monokrom.common.widgets.mk_dro.mk_dro import (MonokromDroGroup, MonokromDroWidget)
from monokrom.common.widgets.mk_led import MkLedIndicator
from monokrom.common.widgets.mk_led_hal import MkHalLedIndicator
from monokrom.common.widgets.mk_push_button import MkPushButton
from monokrom.common.widgets.tab_widget import MkTabWidget
from monokrom.plasma.widgets.cyclestart_action_button import CycleStartActionButton
from monokrom.plasma.widgets.plasma_hal_checkbox import PlasmaHalCheckBox
from monokrom.plasma.widgets.plasma_hal_double_spinbox import PlasmaHalDoubleSpinBox
from monokrom.plasma.widgets.plasma_hal_spinbox import PlasmaHalSpinBox
from monokrom.plasma.widgets.plasma_push_button import PlasmaPushButton
from qtpyvcp.widgets.button_widgets.action_button import ActionButton
from qtpyvcp.widgets.button_widgets.dialog_button import DialogButton
from qtpyvcp.widgets.button_widgets.mdi_button import MDIButton
from qtpyvcp.widgets.button_widgets.subcall_button import SubCallButton
from qtpyvcp.widgets.containers.frame import VCPFrame
from qtpyvcp.widgets.containers.stack import VCPStackedWidget
from qtpyvcp.widgets.containers.widget import VCPWidget
from qtpyvcp.widgets.display_widgets.designer_plugins import VTKBackPlot
from qtpyvcp.widgets.display_widgets.notification_widget import NotificationWidget
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel
from qtpyvcp.widgets.display_widgets.status_led import StatusLED
from qtpyvcp.widgets.form_widgets.main_window import VCPMainWindow
from qtpyvcp.widgets.hal_widgets.hal_button import HalButton
from qtpyvcp.widgets.hal_widgets.hal_checkbox import HalCheckBox
from qtpyvcp.widgets.hal_widgets.hal_double_spinbox import HalDoubleSpinBox
from qtpyvcp.widgets.hal_widgets.hal_label import HalLabel
from qtpyvcp.widgets.hal_widgets.hal_led import HalLedIndicator
from qtpyvcp.widgets.hal_widgets.hal_spinbox import HalQSpinBox
from qtpyvcp.widgets.input_widgets.action_slider import ActionSlider
from qtpyvcp.widgets.input_widgets.mdientry_widget import MDIEntry
from qtpyvcp.widgets.input_widgets.mdihistory_widget import MDIHistory
from qtpyvcp.widgets.input_widgets.recent_file_combobox import RecentFileComboBox
from qtpyvcp.widgets.input_widgets.setting_slider import (VCPSettingsCheckBox, VCPSettingsComboBox, VCPSettingsDoubleSpinBox, VCPSettingsLineEdit,
    VCPSettingsSlider)
import monokrom_rc
import common_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1920, 1100)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        Form.setMinimumSize(QSize(1024, 40))
        icon = QIcon()
        icon.addFile(u":/image/common/icons/icon.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        Form.setWindowIcon(icon)
        self.centralwidget = QWidget(Form)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout_26 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.mainTabWidget = MkTabWidget(self.centralwidget)
        self.mainTabWidget.setObjectName(u"mainTabWidget")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.mainTabWidget.sizePolicy().hasHeightForWidth())
        self.mainTabWidget.setSizePolicy(sizePolicy1)
        self.mainTabWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.mainTabWidget.setTabPosition(QTabWidget.TabPosition.South)
        self.tab_main = QWidget()
        self.tab_main.setObjectName(u"tab_main")
        self.horizontalLayout_4 = QHBoxLayout(self.tab_main)
        self.horizontalLayout_4.setSpacing(15)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(10, 0, 10, 10)
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setSpacing(14)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.tabWidget_leftcolumn = MkTabWidget(self.tab_main)
        self.tabWidget_leftcolumn.setObjectName(u"tabWidget_leftcolumn")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.tabWidget_leftcolumn.sizePolicy().hasHeightForWidth())
        self.tabWidget_leftcolumn.setSizePolicy(sizePolicy2)
        self.tabWidget_leftcolumn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tabWidget_leftcolumn.setTabShape(QTabWidget.TabShape.Rounded)
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.gridLayout_5 = QGridLayout(self.tab_4)
        self.gridLayout_5.setSpacing(10)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.gridLayout_5.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        self.gridLayout_5.setContentsMargins(20, 20, 20, 20)
        self.compositedrogroup_2 = MonokromDroGroup(self.tab_4)
        self.compositedrogroup_2.setObjectName(u"compositedrogroup_2")
        self.compositedrogroup_2.setMaximumSize(QSize(10000, 200))
        self.compositedrogroup_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_5.addWidget(self.compositedrogroup_2, 1, 0, 1, 2)

        self.widget_6 = QWidget(self.tab_4)
        self.widget_6.setObjectName(u"widget_6")
        self.widget_6.setMinimumSize(QSize(5, 30))
        self.horizontalLayout_28 = QHBoxLayout(self.widget_6)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.actionbutton_13 = ActionButton(self.widget_6)
        self.actionbutton_13.setObjectName(u"actionbutton_13")
        self.actionbutton_13.setMinimumSize(QSize(34, 44))

        self.horizontalLayout_28.addWidget(self.actionbutton_13)

        self.actionbutton_12 = ActionButton(self.widget_6)
        self.actionbutton_12.setObjectName(u"actionbutton_12")
        self.actionbutton_12.setMinimumSize(QSize(34, 44))

        self.horizontalLayout_28.addWidget(self.actionbutton_12)

        self.actionbutton_11 = ActionButton(self.widget_6)
        self.actionbutton_11.setObjectName(u"actionbutton_11")
        self.actionbutton_11.setMinimumSize(QSize(34, 44))

        self.horizontalLayout_28.addWidget(self.actionbutton_11)

        self.actionbutton_14 = ActionButton(self.widget_6)
        self.actionbutton_14.setObjectName(u"actionbutton_14")
        self.actionbutton_14.setMinimumSize(QSize(34, 44))

        self.horizontalLayout_28.addWidget(self.actionbutton_14)

        self.actionbutton_2 = ActionButton(self.widget_6)
        self.actionbutton_2.setObjectName(u"actionbutton_2")

        self.horizontalLayout_28.addWidget(self.actionbutton_2)

        self.actionbutton_3 = ActionButton(self.widget_6)
        self.actionbutton_3.setObjectName(u"actionbutton_3")

        self.horizontalLayout_28.addWidget(self.actionbutton_3)


        self.gridLayout_5.addWidget(self.widget_6, 0, 0, 1, 4)

        self.widget_19 = QWidget(self.tab_4)
        self.widget_19.setObjectName(u"widget_19")
        self.horizontalLayout_29 = QHBoxLayout(self.widget_19)
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.horizontalLayout_29.setContentsMargins(-1, 0, -1, 0)
        self.actionbutton_15 = ActionButton(self.widget_19)
        self.actionbutton_15.setObjectName(u"actionbutton_15")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.actionbutton_15.sizePolicy().hasHeightForWidth())
        self.actionbutton_15.setSizePolicy(sizePolicy3)
        self.actionbutton_15.setMinimumSize(QSize(34, 44))
        self.actionbutton_15.setMaximumSize(QSize(106, 16777215))
        self.actionbutton_15.setStyleSheet(u"max-width: 102px;")
        icon1 = QIcon()
        icon1.addFile(u":/image/common/icons/homed.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton_15.setIcon(icon1)
        self.actionbutton_15.setIconSize(QSize(20, 20))

        self.horizontalLayout_29.addWidget(self.actionbutton_15)

        self.btn_zero_xy = QPushButton(self.widget_19)
        self.btn_zero_xy.setObjectName(u"btn_zero_xy")
        sizePolicy3.setHeightForWidth(self.btn_zero_xy.sizePolicy().hasHeightForWidth())
        self.btn_zero_xy.setSizePolicy(sizePolicy3)
        self.btn_zero_xy.setMinimumSize(QSize(34, 44))
        self.btn_zero_xy.setMaximumSize(QSize(106, 16777215))
        self.btn_zero_xy.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_zero_xy.setStyleSheet(u"max-width: 102px;")

        self.horizontalLayout_29.addWidget(self.btn_zero_xy)


        self.gridLayout_5.addWidget(self.widget_19, 1, 2, 1, 2)

        icon2 = QIcon()
        icon2.addFile(u":/image/common/icons/crosshairs-solid.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.tabWidget_leftcolumn.addTab(self.tab_4, icon2, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.gridLayout_11 = QGridLayout(self.tab_3)
        self.gridLayout_11.setSpacing(10)
        self.gridLayout_11.setObjectName(u"gridLayout_11")
        self.gridLayout_11.setContentsMargins(20, 20, 20, 20)
        self.widget_17 = QWidget(self.tab_3)
        self.widget_17.setObjectName(u"widget_17")
        self.widget_17.setMaximumSize(QSize(16777215, 200))
        self.gridLayout_9 = QGridLayout(self.widget_17)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.gridLayout_9.setContentsMargins(0, 0, 0, 0)
        self.monokromdrowidget_2 = MonokromDroWidget(self.widget_17)
        self.monokromdrowidget_2.setObjectName(u"monokromdrowidget_2")
        self.monokromdrowidget_2.setProperty(u"axisNumber", 1)
        self.monokromdrowidget_2.setProperty(u"useWorkCoordinates", 0)

        self.gridLayout_9.addWidget(self.monokromdrowidget_2, 1, 1, 1, 1)

        self.monokromdrowidget_3 = MonokromDroWidget(self.widget_17)
        self.monokromdrowidget_3.setObjectName(u"monokromdrowidget_3")
        self.monokromdrowidget_3.setProperty(u"axisNumber", 2)
        self.monokromdrowidget_3.setProperty(u"useWorkCoordinates", 0)

        self.gridLayout_9.addWidget(self.monokromdrowidget_3, 2, 1, 1, 1)

        self.monokromdrowidget = MonokromDroWidget(self.widget_17)
        self.monokromdrowidget.setObjectName(u"monokromdrowidget")
        self.monokromdrowidget.setProperty(u"useWorkCoordinates", 0)

        self.gridLayout_9.addWidget(self.monokromdrowidget, 0, 1, 1, 1)

        self.actionbutton_5 = ActionButton(self.widget_17)
        self.actionbutton_5.setObjectName(u"actionbutton_5")
        self.actionbutton_5.setMinimumSize(QSize(34, 44))
        self.actionbutton_5.setMaximumSize(QSize(44, 44))
        self.actionbutton_5.setStyleSheet(u"background-color: rgb(255, 238, 6)")
        icon3 = QIcon()
        icon3.addFile(u":/image/common/icons/unhomed.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton_5.setIcon(icon3)

        self.gridLayout_9.addWidget(self.actionbutton_5, 0, 0, 1, 1)

        self.actionbutton_6 = ActionButton(self.widget_17)
        self.actionbutton_6.setObjectName(u"actionbutton_6")
        self.actionbutton_6.setMinimumSize(QSize(34, 44))
        self.actionbutton_6.setMaximumSize(QSize(44, 44))
        self.actionbutton_6.setStyleSheet(u"background-color: rgb(255, 238, 6)")
        self.actionbutton_6.setIcon(icon3)

        self.gridLayout_9.addWidget(self.actionbutton_6, 1, 0, 1, 1)

        self.actionbutton_7 = ActionButton(self.widget_17)
        self.actionbutton_7.setObjectName(u"actionbutton_7")
        self.actionbutton_7.setMinimumSize(QSize(34, 44))
        self.actionbutton_7.setMaximumSize(QSize(44, 44))
        self.actionbutton_7.setStyleSheet(u"background-color: rgb(255, 238, 6)")
        self.actionbutton_7.setIcon(icon3)

        self.gridLayout_9.addWidget(self.actionbutton_7, 2, 0, 1, 1)


        self.gridLayout_11.addWidget(self.widget_17, 1, 0, 1, 1)

        self.actionbutton_36 = ActionButton(self.tab_3)
        self.actionbutton_36.setObjectName(u"actionbutton_36")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.actionbutton_36.sizePolicy().hasHeightForWidth())
        self.actionbutton_36.setSizePolicy(sizePolicy4)
        self.actionbutton_36.setMaximumSize(QSize(44, 16777215))
        self.actionbutton_36.setStyleSheet(u"max-width: 40px;")
        self.actionbutton_36.setIcon(icon1)
        self.actionbutton_36.setIconSize(QSize(20, 20))

        self.gridLayout_11.addWidget(self.actionbutton_36, 1, 1, 1, 1)

        self.verticalSpacer_3 = QSpacerItem(20, 29, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.gridLayout_11.addItem(self.verticalSpacer_3, 0, 0, 1, 1)

        self.tabWidget_leftcolumn.addTab(self.tab_3, icon2, "")

        self.verticalLayout_3.addWidget(self.tabWidget_leftcolumn)

        self.widget_27 = QWidget(self.tab_main)
        self.widget_27.setObjectName(u"widget_27")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.widget_27.sizePolicy().hasHeightForWidth())
        self.widget_27.setSizePolicy(sizePolicy5)
        self.widget_27.setMinimumSize(QSize(0, 0))
        self.gridLayout_32 = QGridLayout(self.widget_27)
        self.gridLayout_32.setObjectName(u"gridLayout_32")
        self.mk_feedrate = HalLabel(self.widget_27)
        self.mk_feedrate.setObjectName(u"mk_feedrate")
        self.mk_feedrate.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_32.addWidget(self.mk_feedrate, 0, 2, 1, 1)

        self.label_98 = QLabel(self.widget_27)
        self.label_98.setObjectName(u"label_98")

        self.gridLayout_32.addWidget(self.label_98, 0, 0, 1, 1)

        self.lbl_process_name = QLabel(self.widget_27)
        self.lbl_process_name.setObjectName(u"lbl_process_name")

        self.gridLayout_32.addWidget(self.lbl_process_name, 1, 2, 1, 4)

        self.label_91 = QLabel(self.widget_27)
        self.label_91.setObjectName(u"label_91")

        self.gridLayout_32.addWidget(self.label_91, 1, 0, 1, 1)

        self.label_99 = QLabel(self.widget_27)
        self.label_99.setObjectName(u"label_99")

        self.gridLayout_32.addWidget(self.label_99, 0, 3, 1, 1)

        self.mk_current_velcoity = HalLabel(self.widget_27)
        self.mk_current_velcoity.setObjectName(u"mk_current_velcoity")
        self.mk_current_velcoity.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_32.addWidget(self.mk_current_velcoity, 0, 4, 1, 2)


        self.verticalLayout_3.addWidget(self.widget_27)

        self.widget_16 = QWidget(self.tab_main)
        self.widget_16.setObjectName(u"widget_16")
        self.horizontalLayout_23 = QHBoxLayout(self.widget_16)
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.groupbox_6 = MkGroupBox(self.widget_16)
        self.groupbox_6.setObjectName(u"groupbox_6")
        self.gridLayout = QGridLayout(self.groupbox_6)
        self.gridLayout.setObjectName(u"gridLayout")
        self.sc_park = SubCallButton(self.groupbox_6)
        self.sc_park.setObjectName(u"sc_park")
        self.sc_park.setMaximumSize(QSize(16777215, 44))

        self.gridLayout.addWidget(self.sc_park, 10, 1, 1, 1)

        self.btn_m1_break = ActionButton(self.groupbox_6)
        self.btn_m1_break.setObjectName(u"btn_m1_break")
        self.btn_m1_break.setMaximumSize(QSize(16777215, 44))
        self.btn_m1_break.setCheckable(True)

        self.gridLayout.addWidget(self.btn_m1_break, 3, 0, 1, 1)

        self.btn_g5x_home = MDIButton(self.groupbox_6)
        self.btn_g5x_home.setObjectName(u"btn_g5x_home")
        self.btn_g5x_home.setMaximumSize(QSize(16777215, 44))

        self.gridLayout.addWidget(self.btn_g5x_home, 12, 0, 1, 1)

        self.btn_feed_hold = ActionButton(self.groupbox_6)
        self.btn_feed_hold.setObjectName(u"btn_feed_hold")
        self.btn_feed_hold.setMaximumSize(QSize(16777215, 44))

        self.gridLayout.addWidget(self.btn_feed_hold, 1, 0, 1, 2)

        self.btn_cycle_start = CycleStartActionButton(self.groupbox_6)
        self.btn_cycle_start.setObjectName(u"btn_cycle_start")
        self.btn_cycle_start.setMaximumSize(QSize(16777215, 44))

        self.gridLayout.addWidget(self.btn_cycle_start, 0, 0, 1, 2)

        self.btn_move_home = MDIButton(self.groupbox_6)
        self.btn_move_home.setObjectName(u"btn_move_home")
        self.btn_move_home.setMaximumSize(QSize(16777215, 44))

        self.gridLayout.addWidget(self.btn_move_home, 12, 1, 1, 1)

        self.btn_machine_power_toggle = ActionButton(self.groupbox_6)
        self.btn_machine_power_toggle.setObjectName(u"btn_machine_power_toggle")
        self.btn_machine_power_toggle.setMaximumSize(QSize(16777215, 44))
        self.btn_machine_power_toggle.setCheckable(True)

        self.gridLayout.addWidget(self.btn_machine_power_toggle, 16, 0, 1, 2)

        self.btn_stop_abort = ActionButton(self.groupbox_6)
        self.btn_stop_abort.setObjectName(u"btn_stop_abort")
        self.btn_stop_abort.setMaximumSize(QSize(16777215, 44))

        self.gridLayout.addWidget(self.btn_stop_abort, 2, 0, 1, 2)

        self.btn_frame_job = SubCallButton(self.groupbox_6)
        self.btn_frame_job.setObjectName(u"btn_frame_job")
        self.btn_frame_job.setMaximumSize(QSize(16777215, 44))

        self.gridLayout.addWidget(self.btn_frame_job, 10, 0, 1, 1)

        self.estopbutton = ActionButton(self.groupbox_6)
        self.estopbutton.setObjectName(u"estopbutton")

        self.gridLayout.addWidget(self.estopbutton, 17, 0, 1, 2)

        self.btn_consumable_change = HalButton(self.groupbox_6)
        self.btn_consumable_change.setObjectName(u"btn_consumable_change")
        self.btn_consumable_change.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_consumable_change.setCheckable(True)

        self.gridLayout.addWidget(self.btn_consumable_change, 3, 1, 1, 1)


        self.horizontalLayout_23.addWidget(self.groupbox_6)

        self.layout_overrides = QGridLayout()
        self.layout_overrides.setObjectName(u"layout_overrides")
        self.rapid_slider = ActionSlider(self.widget_16)
        self.rapid_slider.setObjectName(u"rapid_slider")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.rapid_slider.sizePolicy().hasHeightForWidth())
        self.rapid_slider.setSizePolicy(sizePolicy6)
        self.rapid_slider.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.layout_overrides.addWidget(self.rapid_slider, 1, 0, 1, 1)

        self.btn_reset_rapid = QPushButton(self.widget_16)
        self.btn_reset_rapid.setObjectName(u"btn_reset_rapid")
        self.btn_reset_rapid.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.layout_overrides.addWidget(self.btn_reset_rapid, 0, 0, 1, 1)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.statuslabel_4 = StatusLabel(self.widget_16)
        self.statuslabel_4.setObjectName(u"statuslabel_4")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.statuslabel_4.sizePolicy().hasHeightForWidth())
        self.statuslabel_4.setSizePolicy(sizePolicy7)
        self.statuslabel_4.setMinimumSize(QSize(50, 0))
        font = QFont()
        font.setFamilies([u"DSEG7 Classic"])
        font.setPointSize(10)
        font.setBold(True)
        font.setItalic(True)
        self.statuslabel_4.setFont(font)
        self.statuslabel_4.setStyleSheet(u"font: bold italic 10pt \"DSEG7 Classic\";")
        self.statuslabel_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout.addWidget(self.statuslabel_4)

        self.label_8 = QLabel(self.widget_16)
        self.label_8.setObjectName(u"label_8")
        font1 = QFont()
        font1.setFamilies([u"Sans"])
        font1.setBold(True)
        font1.setItalic(False)
        self.label_8.setFont(font1)
        self.label_8.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout.addWidget(self.label_8)


        self.layout_overrides.addLayout(self.verticalLayout, 2, 0, 1, 1)

        self.btn_reset_jog = QPushButton(self.widget_16)
        self.btn_reset_jog.setObjectName(u"btn_reset_jog")
        self.btn_reset_jog.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.layout_overrides.addWidget(self.btn_reset_jog, 0, 2, 1, 1)

        self.btn_reset_feed = QPushButton(self.widget_16)
        self.btn_reset_feed.setObjectName(u"btn_reset_feed")
        self.btn_reset_feed.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.layout_overrides.addWidget(self.btn_reset_feed, 0, 1, 1, 1)

        self.feed_slider = ActionSlider(self.widget_16)
        self.feed_slider.setObjectName(u"feed_slider")
        self.feed_slider.setEnabled(False)
        sizePolicy6.setHeightForWidth(self.feed_slider.sizePolicy().hasHeightForWidth())
        self.feed_slider.setSizePolicy(sizePolicy6)
        self.feed_slider.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.layout_overrides.addWidget(self.feed_slider, 1, 1, 1, 1)

        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.statuslabel_5 = StatusLabel(self.widget_16)
        self.statuslabel_5.setObjectName(u"statuslabel_5")
        sizePolicy7.setHeightForWidth(self.statuslabel_5.sizePolicy().hasHeightForWidth())
        self.statuslabel_5.setSizePolicy(sizePolicy7)
        self.statuslabel_5.setMinimumSize(QSize(50, 0))
        self.statuslabel_5.setFont(font)
        self.statuslabel_5.setStyleSheet(u"font: bold italic 10pt \"DSEG7 Classic\";")
        self.statuslabel_5.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_7.addWidget(self.statuslabel_5)

        self.label_9 = QLabel(self.widget_16)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font1)
        self.label_9.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_7.addWidget(self.label_9)


        self.layout_overrides.addLayout(self.verticalLayout_7, 2, 1, 1, 1)

        self.verticalLayout_9 = QVBoxLayout()
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.statuslabel_6 = StatusLabel(self.widget_16)
        self.statuslabel_6.setObjectName(u"statuslabel_6")
        sizePolicy7.setHeightForWidth(self.statuslabel_6.sizePolicy().hasHeightForWidth())
        self.statuslabel_6.setSizePolicy(sizePolicy7)
        self.statuslabel_6.setMinimumSize(QSize(50, 0))
        self.statuslabel_6.setFont(font)
        self.statuslabel_6.setStyleSheet(u"font: bold italic 10pt \"DSEG7 Classic\";")
        self.statuslabel_6.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_9.addWidget(self.statuslabel_6)

        self.label_10 = QLabel(self.widget_16)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setFont(font1)
        self.label_10.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_9.addWidget(self.label_10)


        self.layout_overrides.addLayout(self.verticalLayout_9, 2, 2, 1, 1)

        self.jog_slider = VCPSettingsSlider(self.widget_16)
        self.jog_slider.setObjectName(u"jog_slider")
        sizePolicy6.setHeightForWidth(self.jog_slider.sizePolicy().hasHeightForWidth())
        self.jog_slider.setSizePolicy(sizePolicy6)
        self.jog_slider.setMaximum(100)
        self.jog_slider.setSliderPosition(30)

        self.layout_overrides.addWidget(self.jog_slider, 1, 2, 1, 1)


        self.horizontalLayout_23.addLayout(self.layout_overrides)


        self.verticalLayout_3.addWidget(self.widget_16)


        self.horizontalLayout_4.addLayout(self.verticalLayout_3)

        self.tabwidget_midcolumn = MkTabWidget(self.tab_main)
        self.tabwidget_midcolumn.setObjectName(u"tabwidget_midcolumn")
        sizePolicy8 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy8.setHorizontalStretch(2)
        sizePolicy8.setVerticalStretch(0)
        sizePolicy8.setHeightForWidth(self.tabwidget_midcolumn.sizePolicy().hasHeightForWidth())
        self.tabwidget_midcolumn.setSizePolicy(sizePolicy8)
        self.tabwidget_midcolumn.setMinimumSize(QSize(0, 0))
        self.tabwidget_midcolumn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tab_run_monitor = QWidget()
        self.tab_run_monitor.setObjectName(u"tab_run_monitor")
        self.gridLayout_4 = QGridLayout(self.tab_run_monitor)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.gridLayout_4.setContentsMargins(6, -1, 6, -1)
        self.user9 = SubCallButton(self.tab_run_monitor)
        self.user9.setObjectName(u"user9")

        self.gridLayout_4.addWidget(self.user9, 19, 3, 1, 1)

        self.btn_load_newest = QPushButton(self.tab_run_monitor)
        self.btn_load_newest.setObjectName(u"btn_load_newest")
        self.btn_load_newest.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_4.addWidget(self.btn_load_newest, 14, 0, 1, 2)

        self.user5 = SubCallButton(self.tab_run_monitor)
        self.user5.setObjectName(u"user5")

        self.gridLayout_4.addWidget(self.user5, 20, 0, 1, 1)

        self.widget_20 = QWidget(self.tab_run_monitor)
        self.widget_20.setObjectName(u"widget_20")
        self.horizontalLayout = QHBoxLayout(self.widget_20)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 4, 0, 4)
        self.label_6 = QLabel(self.widget_20)
        self.label_6.setObjectName(u"label_6")

        self.horizontalLayout.addWidget(self.label_6)

        self.horizontalSpacer_9 = QSpacerItem(9, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_9)

        self.mkhalledindicator_7 = MkHalLedIndicator(self.widget_20)
        self.mkhalledindicator_7.setObjectName(u"mkhalledindicator_7")
        self.mkhalledindicator_7.setProperty(u"diameter", 20)
        self.mkhalledindicator_7.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_7.setProperty(u"state", False)

        self.horizontalLayout.addWidget(self.mkhalledindicator_7)


        self.gridLayout_4.addWidget(self.widget_20, 4, 3, 1, 1)

        self.widget_4 = QWidget(self.tab_run_monitor)
        self.widget_4.setObjectName(u"widget_4")
        self.horizontalLayout_14 = QHBoxLayout(self.widget_4)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.horizontalLayout_14.setContentsMargins(0, 4, 0, 4)
        self.label_16 = QLabel(self.widget_4)
        self.label_16.setObjectName(u"label_16")

        self.horizontalLayout_14.addWidget(self.label_16)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_14.addItem(self.horizontalSpacer_6)

        self.mkhalledindicator_4 = MkHalLedIndicator(self.widget_4)
        self.mkhalledindicator_4.setObjectName(u"mkhalledindicator_4")
        self.mkhalledindicator_4.setProperty(u"diameter", 20)
        self.mkhalledindicator_4.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_4.setProperty(u"state", False)

        self.horizontalLayout_14.addWidget(self.mkhalledindicator_4)


        self.gridLayout_4.addWidget(self.widget_4, 3, 3, 1, 1)

        self.torch_enable = HalButton(self.tab_run_monitor)
        self.dry_run_torch_enable = QButtonGroup(Form)
        self.dry_run_torch_enable.setObjectName(u"dry_run_torch_enable")
        self.dry_run_torch_enable.addButton(self.torch_enable)
        self.torch_enable.setObjectName(u"torch_enable")
        self.torch_enable.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.torch_enable.setCheckable(True)

        self.gridLayout_4.addWidget(self.torch_enable, 8, 0, 1, 1)

        self.widget_2 = QWidget(self.tab_run_monitor)
        self.widget_2.setObjectName(u"widget_2")
        self.horizontalLayout_12 = QHBoxLayout(self.widget_2)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(0, 4, 0, 4)
        self.label_14 = QLabel(self.widget_2)
        self.label_14.setObjectName(u"label_14")

        self.horizontalLayout_12.addWidget(self.label_14)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_12.addItem(self.horizontalSpacer_5)

        self.mkhalledindicator_2 = MkHalLedIndicator(self.widget_2)
        self.mkhalledindicator_2.setObjectName(u"mkhalledindicator_2")
        self.mkhalledindicator_2.setProperty(u"diameter", 20)
        self.mkhalledindicator_2.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_2.setProperty(u"state", False)

        self.horizontalLayout_12.addWidget(self.mkhalledindicator_2)


        self.gridLayout_4.addWidget(self.widget_2, 3, 0, 1, 1)

        self.widget_30 = QWidget(self.tab_run_monitor)
        self.widget_30.setObjectName(u"widget_30")
        self.horizontalLayout_21 = QHBoxLayout(self.widget_30)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.horizontalLayout_21.setContentsMargins(0, 4, 0, 4)
        self.label_97 = QLabel(self.widget_30)
        self.label_97.setObjectName(u"label_97")

        self.horizontalLayout_21.addWidget(self.label_97)

        self.horizontalSpacer_12 = QSpacerItem(15, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_21.addItem(self.horizontalSpacer_12)

        self.mkhalledindicator_10 = MkHalLedIndicator(self.widget_30)
        self.mkhalledindicator_10.setObjectName(u"mkhalledindicator_10")
        self.mkhalledindicator_10.setProperty(u"diameter", 20)
        self.mkhalledindicator_10.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_10.setProperty(u"state", False)

        self.horizontalLayout_21.addWidget(self.mkhalledindicator_10)


        self.gridLayout_4.addWidget(self.widget_30, 5, 3, 1, 1)

        self.user3 = SubCallButton(self.tab_run_monitor)
        self.user3.setObjectName(u"user3")

        self.gridLayout_4.addWidget(self.user3, 18, 0, 1, 1)

        self.widget_3 = QWidget(self.tab_run_monitor)
        self.widget_3.setObjectName(u"widget_3")
        self.horizontalLayout_13 = QHBoxLayout(self.widget_3)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.horizontalLayout_13.setContentsMargins(0, 4, 0, 4)
        self.label_15 = QLabel(self.widget_3)
        self.label_15.setObjectName(u"label_15")

        self.horizontalLayout_13.addWidget(self.label_15)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_3)

        self.mkhalledindicator_3 = MkHalLedIndicator(self.widget_3)
        self.mkhalledindicator_3.setObjectName(u"mkhalledindicator_3")
        self.mkhalledindicator_3.setProperty(u"diameter", 20)
        self.mkhalledindicator_3.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_3.setProperty(u"state", False)

        self.horizontalLayout_13.addWidget(self.mkhalledindicator_3)


        self.gridLayout_4.addWidget(self.widget_3, 2, 0, 1, 1)

        self.widget_29 = QWidget(self.tab_run_monitor)
        self.widget_29.setObjectName(u"widget_29")
        self.horizontalLayout_24 = QHBoxLayout(self.widget_29)
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.horizontalLayout_24.setContentsMargins(0, 4, 0, 4)
        self.label_96 = QLabel(self.widget_29)
        self.label_96.setObjectName(u"label_96")

        self.horizontalLayout_24.addWidget(self.label_96)

        self.horizontalSpacer_11 = QSpacerItem(3, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_24.addItem(self.horizontalSpacer_11)

        self.mkhalledindicator_9 = MkHalLedIndicator(self.widget_29)
        self.mkhalledindicator_9.setObjectName(u"mkhalledindicator_9")
        self.mkhalledindicator_9.setProperty(u"diameter", 20)
        self.mkhalledindicator_9.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_9.setProperty(u"state", False)

        self.horizontalLayout_24.addWidget(self.mkhalledindicator_9)


        self.gridLayout_4.addWidget(self.widget_29, 5, 0, 1, 1)

        self.user2 = SubCallButton(self.tab_run_monitor)
        self.user2.setObjectName(u"user2")

        self.gridLayout_4.addWidget(self.user2, 17, 0, 1, 1)

        self.widget_9 = QWidget(self.tab_run_monitor)
        self.widget_9.setObjectName(u"widget_9")
        self.verticalLayout_18 = QVBoxLayout(self.widget_9)
        self.verticalLayout_18.setSpacing(0)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setContentsMargins(-1, 0, -1, 0)
        self.widget_5 = QWidget(self.widget_9)
        self.widget_5.setObjectName(u"widget_5")
        self.gridLayout_30 = QGridLayout(self.widget_5)
        self.gridLayout_30.setObjectName(u"gridLayout_30")
        self.gridLayout_30.setContentsMargins(-1, 4, -1, 4)
        self.spin_voltage_override = HalDoubleSpinBox(self.widget_5)
        self.spin_voltage_override.setObjectName(u"spin_voltage_override")
        sizePolicy9 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Maximum)
        sizePolicy9.setHorizontalStretch(0)
        sizePolicy9.setVerticalStretch(0)
        sizePolicy9.setHeightForWidth(self.spin_voltage_override.sizePolicy().hasHeightForWidth())
        self.spin_voltage_override.setSizePolicy(sizePolicy9)
        self.spin_voltage_override.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.spin_voltage_override.setStyleSheet(u"")
        self.spin_voltage_override.setFrame(False)
        self.spin_voltage_override.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spin_voltage_override.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spin_voltage_override.setDecimals(0)
        self.spin_voltage_override.setMinimum(-200.000000000000000)
        self.spin_voltage_override.setMaximum(200.000000000000000)

        self.gridLayout_30.addWidget(self.spin_voltage_override, 1, 1, 1, 1)

        self.label_18 = QLabel(self.widget_5)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_30.addWidget(self.label_18, 0, 1, 1, 1)

        self.label_17 = QLabel(self.widget_5)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_30.addWidget(self.label_17, 0, 0, 1, 1)

        self.hallabel = HalLabel(self.widget_5)
        self.hallabel.setObjectName(u"hallabel")
        self.hallabel.setStyleSheet(u"font: bold 14pt;")
        self.hallabel.setTextFormat(Qt.TextFormat.AutoText)
        self.hallabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_30.addWidget(self.hallabel, 1, 0, 1, 1)


        self.verticalLayout_18.addWidget(self.widget_5)


        self.gridLayout_4.addWidget(self.widget_9, 11, 0, 1, 4)

        self.btn_void_sense = QPushButton(self.tab_run_monitor)
        self.btn_void_sense.setObjectName(u"btn_void_sense")
        self.btn_void_sense.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_void_sense.setCheckable(True)

        self.gridLayout_4.addWidget(self.btn_void_sense, 10, 3, 1, 1)

        self.user7 = SubCallButton(self.tab_run_monitor)
        self.user7.setObjectName(u"user7")

        self.gridLayout_4.addWidget(self.user7, 17, 3, 1, 1)

        self.widget_28 = QWidget(self.tab_run_monitor)
        self.widget_28.setObjectName(u"widget_28")
        self.horizontalLayout_18 = QHBoxLayout(self.widget_28)
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.horizontalLayout_18.setContentsMargins(0, 4, 0, 4)
        self.label_12 = QLabel(self.widget_28)
        self.label_12.setObjectName(u"label_12")

        self.horizontalLayout_18.addWidget(self.label_12)

        self.horizontalSpacer_10 = QSpacerItem(3, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_18.addItem(self.horizontalSpacer_10)

        self.mkhalledindicator_8 = MkHalLedIndicator(self.widget_28)
        self.mkhalledindicator_8.setObjectName(u"mkhalledindicator_8")
        self.mkhalledindicator_8.setProperty(u"diameter", 20)
        self.mkhalledindicator_8.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_8.setProperty(u"state", False)

        self.horizontalLayout_18.addWidget(self.mkhalledindicator_8)


        self.gridLayout_4.addWidget(self.widget_28, 4, 0, 1, 1)

        self.user10 = SubCallButton(self.tab_run_monitor)
        self.user10.setObjectName(u"user10")

        self.gridLayout_4.addWidget(self.user10, 20, 3, 1, 1)

        self.user1 = SubCallButton(self.tab_run_monitor)
        self.user1.setObjectName(u"user1")

        self.gridLayout_4.addWidget(self.user1, 16, 0, 1, 1)

        self.btn_vad = QPushButton(self.tab_run_monitor)
        self.btn_vad.setObjectName(u"btn_vad")
        self.btn_vad.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_vad.setCheckable(True)

        self.gridLayout_4.addWidget(self.btn_vad, 10, 0, 1, 1)

        self.btn_thc_enable = QPushButton(self.tab_run_monitor)
        self.btn_thc_enable.setObjectName(u"btn_thc_enable")
        self.btn_thc_enable.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_thc_enable.setCheckable(True)

        self.gridLayout_4.addWidget(self.btn_thc_enable, 8, 3, 1, 1)

        self.widget = QWidget(self.tab_run_monitor)
        self.widget.setObjectName(u"widget")
        self.widget.setMinimumSize(QSize(133, 0))
        self.horizontalLayout_11 = QHBoxLayout(self.widget)
        self.horizontalLayout_11.setSpacing(6)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 4, 0, 4)
        self.label_13 = QLabel(self.widget)
        self.label_13.setObjectName(u"label_13")

        self.horizontalLayout_11.addWidget(self.label_13)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_11.addItem(self.horizontalSpacer)

        self.mkhalledindicator = MkHalLedIndicator(self.widget)
        self.mkhalledindicator.setObjectName(u"mkhalledindicator")
        self.mkhalledindicator.setProperty(u"diameter", 20)
        self.mkhalledindicator.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator.setProperty(u"state", False)

        self.horizontalLayout_11.addWidget(self.mkhalledindicator)


        self.gridLayout_4.addWidget(self.widget, 0, 0, 1, 1)

        self.widget_26 = QWidget(self.tab_run_monitor)
        self.widget_26.setObjectName(u"widget_26")
        self.horizontalLayout_9 = QHBoxLayout(self.widget_26)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(-1, 4, -1, 4)
        self.btnManualState = ActionButton(self.widget_26)
        self.machine_state = QButtonGroup(Form)
        self.machine_state.setObjectName(u"machine_state")
        self.machine_state.addButton(self.btnManualState)
        self.btnManualState.setObjectName(u"btnManualState")
        self.btnManualState.setCheckable(True)
        self.btnManualState.setChecked(False)
        self.btnManualState.setAutoExclusive(True)

        self.horizontalLayout_9.addWidget(self.btnManualState)

        self.btnMdiState = ActionButton(self.widget_26)
        self.machine_state.addButton(self.btnMdiState)
        self.btnMdiState.setObjectName(u"btnMdiState")
        self.btnMdiState.setCheckable(True)
        self.btnMdiState.setAutoExclusive(True)

        self.horizontalLayout_9.addWidget(self.btnMdiState)

        self.btnAutoState = ActionButton(self.widget_26)
        self.machine_state.addButton(self.btnAutoState)
        self.btnAutoState.setObjectName(u"btnAutoState")
        self.btnAutoState.setCheckable(True)
        self.btnAutoState.setAutoExclusive(True)

        self.horizontalLayout_9.addWidget(self.btnAutoState)


        self.gridLayout_4.addWidget(self.widget_26, 12, 0, 1, 4)

        self.user4 = SubCallButton(self.tab_run_monitor)
        self.user4.setObjectName(u"user4")

        self.gridLayout_4.addWidget(self.user4, 19, 0, 1, 1)

        self.widget_32 = QWidget(self.tab_run_monitor)
        self.widget_32.setObjectName(u"widget_32")
        self.horizontalLayout_26 = QHBoxLayout(self.widget_32)
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.horizontalLayout_26.setContentsMargins(0, 4, 0, 4)
        self.label_106 = QLabel(self.widget_32)
        self.label_106.setObjectName(u"label_106")

        self.horizontalLayout_26.addWidget(self.label_106)

        self.horizontalSpacer_15 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_26.addItem(self.horizontalSpacer_15)

        self.mkled_mesh_sense = MkLedIndicator(self.widget_32)
        self.mkled_mesh_sense.setObjectName(u"mkled_mesh_sense")
        self.mkled_mesh_sense.setProperty(u"diameter", 20)
        self.mkled_mesh_sense.setProperty(u"color", QColor(255, 238, 6))
        self.mkled_mesh_sense.setProperty(u"state", False)

        self.horizontalLayout_26.addWidget(self.mkled_mesh_sense)


        self.gridLayout_4.addWidget(self.widget_32, 6, 3, 1, 1)

        self.btn_pierce_only = HalButton(self.tab_run_monitor)
        self.btn_pierce_only.setObjectName(u"btn_pierce_only")
        self.btn_pierce_only.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_pierce_only.setCheckable(True)

        self.gridLayout_4.addWidget(self.btn_pierce_only, 15, 0, 1, 1)

        self.user8 = SubCallButton(self.tab_run_monitor)
        self.user8.setObjectName(u"user8")

        self.gridLayout_4.addWidget(self.user8, 18, 3, 1, 1)

        self.widget_31 = QWidget(self.tab_run_monitor)
        self.widget_31.setObjectName(u"widget_31")
        self.horizontalLayout_25 = QHBoxLayout(self.widget_31)
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.horizontalLayout_25.setContentsMargins(0, 4, 0, 4)
        self.label_105 = QLabel(self.widget_31)
        self.label_105.setObjectName(u"label_105")

        self.horizontalLayout_25.addWidget(self.label_105)

        self.horizontalSpacer_14 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_25.addItem(self.horizontalSpacer_14)

        self.mkled_thc_auto_volts = MkLedIndicator(self.widget_31)
        self.mkled_thc_auto_volts.setObjectName(u"mkled_thc_auto_volts")
        self.mkled_thc_auto_volts.setProperty(u"diameter", 20)
        self.mkled_thc_auto_volts.setProperty(u"color", QColor(255, 238, 6))
        self.mkled_thc_auto_volts.setProperty(u"state", False)

        self.horizontalLayout_25.addWidget(self.mkled_thc_auto_volts)


        self.gridLayout_4.addWidget(self.widget_31, 6, 0, 1, 1)

        self.plasma_torch_pulse = HalButton(self.tab_run_monitor)
        self.plasma_torch_pulse.setObjectName(u"plasma_torch_pulse")
        self.plasma_torch_pulse.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_4.addWidget(self.plasma_torch_pulse, 14, 3, 1, 1)

        self.widget_7 = QWidget(self.tab_run_monitor)
        self.widget_7.setObjectName(u"widget_7")
        self.widget_7.setMinimumSize(QSize(133, 0))
        self.horizontalLayout_15 = QHBoxLayout(self.widget_7)
        self.horizontalLayout_15.setSpacing(6)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.horizontalLayout_15.setContentsMargins(0, 4, 0, 4)
        self.label_19 = QLabel(self.widget_7)
        self.label_19.setObjectName(u"label_19")

        self.horizontalLayout_15.addWidget(self.label_19)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_15.addItem(self.horizontalSpacer_2)

        self.mkhalledindicator_5 = MkHalLedIndicator(self.widget_7)
        self.mkhalledindicator_5.setObjectName(u"mkhalledindicator_5")
        self.mkhalledindicator_5.setProperty(u"diameter", 20)
        self.mkhalledindicator_5.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_5.setProperty(u"state", False)

        self.horizontalLayout_15.addWidget(self.mkhalledindicator_5)

        self.mkhalledindicator_6 = MkHalLedIndicator(self.widget_7)
        self.mkhalledindicator_6.setObjectName(u"mkhalledindicator_6")
        self.mkhalledindicator_6.setProperty(u"diameter", 20)
        self.mkhalledindicator_6.setProperty(u"color", QColor(255, 238, 6))
        self.mkhalledindicator_6.setProperty(u"state", False)

        self.horizontalLayout_15.addWidget(self.mkhalledindicator_6)


        self.gridLayout_4.addWidget(self.widget_7, 0, 3, 1, 1)

        self.user6 = SubCallButton(self.tab_run_monitor)
        self.user6.setObjectName(u"user6")

        self.gridLayout_4.addWidget(self.user6, 16, 3, 1, 1)

        self.dry_run = HalButton(self.tab_run_monitor)
        self.dry_run_torch_enable.addButton(self.dry_run)
        self.dry_run.setObjectName(u"dry_run")
        self.dry_run.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.dry_run.setCheckable(True)
        self.dry_run.setChecked(True)

        self.gridLayout_4.addWidget(self.dry_run, 15, 3, 1, 1)

        self.widget_33 = QWidget(self.tab_run_monitor)
        self.widget_33.setObjectName(u"widget_33")
        self.horizontalLayout_27 = QHBoxLayout(self.widget_33)
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.horizontalLayout_27.setContentsMargins(0, 4, 0, 4)
        self.label_107 = QLabel(self.widget_33)
        self.label_107.setObjectName(u"label_107")

        self.horizontalLayout_27.addWidget(self.label_107)

        self.horizontalSpacer_16 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_27.addItem(self.horizontalSpacer_16)

        self.mkled_ohmic_sense = MkLedIndicator(self.widget_33)
        self.mkled_ohmic_sense.setObjectName(u"mkled_ohmic_sense")
        self.mkled_ohmic_sense.setProperty(u"diameter", 20)
        self.mkled_ohmic_sense.setProperty(u"color", QColor(255, 238, 6))
        self.mkled_ohmic_sense.setProperty(u"state", False)

        self.horizontalLayout_27.addWidget(self.mkled_ohmic_sense)


        self.gridLayout_4.addWidget(self.widget_33, 2, 3, 1, 1)

        self.tabwidget_midcolumn.addTab(self.tab_run_monitor, "")
        self.tab_jog = QWidget()
        self.tab_jog.setObjectName(u"tab_jog")
        self.verticalLayout_15 = QVBoxLayout(self.tab_jog)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.jog_stack = VCPStackedWidget(self.tab_jog)
        self.jog_stack.setObjectName(u"jog_stack")
        self.page_1 = QWidget()
        self.page_1.setObjectName(u"page_1")
        self.verticalLayout_24 = QVBoxLayout(self.page_1)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.verticalLayout_24.setContentsMargins(0, 9, 0, 0)
        self.widget_25 = VCPWidget(self.page_1)
        self.widget_25.setObjectName(u"widget_25")
        self.gridLayout_25 = QGridLayout(self.widget_25)
        self.gridLayout_25.setObjectName(u"gridLayout_25")
        self.actionbutton_4 = ActionButton(self.widget_25)
        self.actionbutton_4.setObjectName(u"actionbutton_4")
        icon4 = QIcon()
        icon4.addFile(u":/image/common/icons/y-down.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton_4.setIcon(icon4)
        self.actionbutton_4.setIconSize(QSize(46, 40))
        self.actionbutton_4.setFlat(True)

        self.gridLayout_25.addWidget(self.actionbutton_4, 2, 1, 1, 1)

        self.actionbutton_21 = ActionButton(self.widget_25)
        self.actionbutton_21.setObjectName(u"actionbutton_21")
        icon5 = QIcon()
        icon5.addFile(u":/image/common/icons/x-left.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton_21.setIcon(icon5)
        self.actionbutton_21.setIconSize(QSize(46, 40))
        self.actionbutton_21.setFlat(True)

        self.gridLayout_25.addWidget(self.actionbutton_21, 1, 0, 1, 1)

        self.actionbutton = ActionButton(self.widget_25)
        self.actionbutton.setObjectName(u"actionbutton")
        icon6 = QIcon()
        icon6.addFile(u":/image/common/icons/y-up.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton.setIcon(icon6)
        self.actionbutton.setIconSize(QSize(46, 40))
        self.actionbutton.setFlat(True)

        self.gridLayout_25.addWidget(self.actionbutton, 0, 1, 1, 1)

        self.widget_15 = QWidget(self.widget_25)
        self.widget_15.setObjectName(u"widget_15")
        self.horizontalLayout_20 = QHBoxLayout(self.widget_15)
        self.horizontalLayout_20.setSpacing(0)
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.horizontalLayout_20.setContentsMargins(40, 0, 0, 0)

        self.gridLayout_25.addWidget(self.widget_15, 2, 2, 1, 1)

        self.actionbutton_22 = ActionButton(self.widget_25)
        self.actionbutton_22.setObjectName(u"actionbutton_22")
        icon7 = QIcon()
        icon7.addFile(u":/image/common/icons/x-right.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton_22.setIcon(icon7)
        self.actionbutton_22.setIconSize(QSize(46, 40))
        self.actionbutton_22.setFlat(True)

        self.gridLayout_25.addWidget(self.actionbutton_22, 1, 2, 1, 1)

        self.widget_14 = QWidget(self.widget_25)
        self.widget_14.setObjectName(u"widget_14")
        self.horizontalLayout_19 = QHBoxLayout(self.widget_14)
        self.horizontalLayout_19.setSpacing(0)
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.horizontalLayout_19.setContentsMargins(40, 0, 0, 0)

        self.gridLayout_25.addWidget(self.widget_14, 0, 2, 1, 1)

        self.horizontalSpacer_13 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_25.addItem(self.horizontalSpacer_13, 1, 3, 1, 1)

        self.actionbutton_25 = ActionButton(self.widget_25)
        self.actionbutton_25.setObjectName(u"actionbutton_25")
        icon8 = QIcon()
        icon8.addFile(u":/image/common/icons/z-down.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton_25.setIcon(icon8)
        self.actionbutton_25.setIconSize(QSize(46, 40))
        self.actionbutton_25.setFlat(True)

        self.gridLayout_25.addWidget(self.actionbutton_25, 2, 3, 1, 1)

        self.actionbutton_24 = ActionButton(self.widget_25)
        self.actionbutton_24.setObjectName(u"actionbutton_24")
        self.actionbutton_24.setMinimumSize(QSize(34, 44))
        icon9 = QIcon()
        icon9.addFile(u":/image/common/icons/z-up.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.actionbutton_24.setIcon(icon9)
        self.actionbutton_24.setIconSize(QSize(46, 40))
        self.actionbutton_24.setFlat(True)

        self.gridLayout_25.addWidget(self.actionbutton_24, 0, 3, 1, 1)


        self.verticalLayout_24.addWidget(self.widget_25)

        self.verticalLayout_25 = QVBoxLayout()
        self.verticalLayout_25.setSpacing(6)
        self.verticalLayout_25.setObjectName(u"verticalLayout_25")
        self.verticalLayout_25.setContentsMargins(-1, 9, -1, 9)
        self.widget_10 = VCPWidget(self.page_1)
        self.widget_10.setObjectName(u"widget_10")
        self.gridLayout_8 = QGridLayout(self.widget_10)
        self.gridLayout_8.setObjectName(u"gridLayout_8")
        self.inc_0_01 = ActionButton(self.widget_10)
        self.jog_inc_values = QButtonGroup(Form)
        self.jog_inc_values.setObjectName(u"jog_inc_values")
        self.jog_inc_values.addButton(self.inc_0_01)
        self.inc_0_01.setObjectName(u"inc_0_01")
        self.inc_0_01.setCheckable(True)
        self.inc_0_01.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.inc_0_01, 3, 1, 1, 1)

        self.inc_1 = ActionButton(self.widget_10)
        self.jog_inc_values.addButton(self.inc_1)
        self.inc_1.setObjectName(u"inc_1")
        self.inc_1.setCheckable(True)
        self.inc_1.setChecked(True)
        self.inc_1.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.inc_1, 1, 1, 1, 1)

        self.inc_5 = ActionButton(self.widget_10)
        self.jog_inc_values.addButton(self.inc_5)
        self.inc_5.setObjectName(u"inc_5")
        self.inc_5.setCheckable(True)
        self.inc_5.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.inc_5, 1, 0, 1, 1)

        self.inc_0_1 = ActionButton(self.widget_10)
        self.jog_inc_values.addButton(self.inc_0_1)
        self.inc_0_1.setObjectName(u"inc_0_1")
        self.inc_0_1.setCheckable(True)
        self.inc_0_1.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.inc_0_1, 3, 0, 1, 1)

        self.btn_inc_jog = ActionButton(self.widget_10)
        self.jog_type = QButtonGroup(Form)
        self.jog_type.setObjectName(u"jog_type")
        self.jog_type.addButton(self.btn_inc_jog)
        self.btn_inc_jog.setObjectName(u"btn_inc_jog")
        sizePolicy10 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy10.setHorizontalStretch(0)
        sizePolicy10.setVerticalStretch(0)
        sizePolicy10.setHeightForWidth(self.btn_inc_jog.sizePolicy().hasHeightForWidth())
        self.btn_inc_jog.setSizePolicy(sizePolicy10)
        self.btn_inc_jog.setCheckable(True)
        self.btn_inc_jog.setAutoExclusive(False)

        self.gridLayout_8.addWidget(self.btn_inc_jog, 1, 2, 1, 1)

        self.btn_cont_jog = ActionButton(self.widget_10)
        self.jog_type.addButton(self.btn_cont_jog)
        self.btn_cont_jog.setObjectName(u"btn_cont_jog")
        sizePolicy10.setHeightForWidth(self.btn_cont_jog.sizePolicy().hasHeightForWidth())
        self.btn_cont_jog.setSizePolicy(sizePolicy10)
        self.btn_cont_jog.setMinimumSize(QSize(34, 44))
        self.btn_cont_jog.setCheckable(True)
        self.btn_cont_jog.setChecked(True)
        self.btn_cont_jog.setAutoExclusive(False)

        self.gridLayout_8.addWidget(self.btn_cont_jog, 3, 2, 1, 1)

        self.label_21 = QLabel(self.widget_10)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_8.addWidget(self.label_21, 0, 0, 1, 3)


        self.verticalLayout_25.addWidget(self.widget_10)

        self.groupbox_13 = MkGroupBox(self.page_1)
        self.groupbox_13.setObjectName(u"groupbox_13")
        self.gridLayout_24 = QGridLayout(self.groupbox_13)
        self.gridLayout_24.setObjectName(u"gridLayout_24")
        self.lbl_align_data = QLabel(self.groupbox_13)
        self.lbl_align_data.setObjectName(u"lbl_align_data")

        self.gridLayout_24.addWidget(self.lbl_align_data, 0, 1, 1, 1)

        self.btn_sheet_align_pt2 = QPushButton(self.groupbox_13)
        self.btn_sheet_align_pt2.setObjectName(u"btn_sheet_align_pt2")
        self.btn_sheet_align_pt2.setEnabled(False)
        self.btn_sheet_align_pt2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_sheet_align_pt2.setCheckable(True)

        self.gridLayout_24.addWidget(self.btn_sheet_align_pt2, 2, 1, 1, 1)

        self.btn_sheet_doalign = QPushButton(self.groupbox_13)
        self.btn_sheet_doalign.setObjectName(u"btn_sheet_doalign")
        self.btn_sheet_doalign.setEnabled(False)
        self.btn_sheet_doalign.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_24.addWidget(self.btn_sheet_doalign, 4, 0, 1, 2)

        self.btn_laser = HalButton(self.groupbox_13)
        self.btn_laser.setObjectName(u"btn_laser")
        self.btn_laser.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_laser.setCheckable(True)

        self.gridLayout_24.addWidget(self.btn_laser, 0, 0, 1, 1)

        self.btn_sheet_align_pt1 = QPushButton(self.groupbox_13)
        self.btn_sheet_align_pt1.setObjectName(u"btn_sheet_align_pt1")
        self.btn_sheet_align_pt1.setEnabled(False)
        self.btn_sheet_align_pt1.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_sheet_align_pt1.setCheckable(True)

        self.gridLayout_24.addWidget(self.btn_sheet_align_pt1, 2, 0, 1, 1)


        self.verticalLayout_25.addWidget(self.groupbox_13)

        self.groupbox_12 = MkGroupBox(self.page_1)
        self.groupbox_12.setObjectName(u"groupbox_12")
        sizePolicy2.setHeightForWidth(self.groupbox_12.sizePolicy().hasHeightForWidth())
        self.groupbox_12.setSizePolicy(sizePolicy2)
        self.gridLayout_33 = QGridLayout(self.groupbox_12)
        self.gridLayout_33.setObjectName(u"gridLayout_33")
        self.gridLayout_33.setVerticalSpacing(9)
        self.single_cut_x = PlasmaHalDoubleSpinBox(self.groupbox_12)
        self.single_cut_x.setObjectName(u"single_cut_x")
        self.single_cut_x.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.single_cut_x.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.single_cut_x.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.single_cut_x.setDecimals(3)

        self.gridLayout_33.addWidget(self.single_cut_x, 0, 2, 1, 1)

        self.single_cut_y = PlasmaHalDoubleSpinBox(self.groupbox_12)
        self.single_cut_y.setObjectName(u"single_cut_y")
        self.single_cut_y.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.single_cut_y.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.single_cut_y.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.single_cut_y.setDecimals(3)

        self.gridLayout_33.addWidget(self.single_cut_y, 2, 2, 1, 1)

        self.label_94 = QLabel(self.groupbox_12)
        self.label_94.setObjectName(u"label_94")
        self.label_94.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_33.addWidget(self.label_94, 0, 0, 1, 1)

        self.btn_single_cut = SubCallButton(self.groupbox_12)
        self.btn_single_cut.setObjectName(u"btn_single_cut")
        self.btn_single_cut.setMinimumSize(QSize(34, 44))
        self.btn_single_cut.setMaximumSize(QSize(16777215, 44))

        self.gridLayout_33.addWidget(self.btn_single_cut, 3, 0, 1, 3)

        self.label_95 = QLabel(self.groupbox_12)
        self.label_95.setObjectName(u"label_95")
        self.label_95.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_33.addWidget(self.label_95, 2, 0, 1, 1)


        self.verticalLayout_25.addWidget(self.groupbox_12)

        self.verticalSpacer_10 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_25.addItem(self.verticalSpacer_10)


        self.verticalLayout_24.addLayout(self.verticalLayout_25)

        self.jog_stack.addWidget(self.page_1)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.verticalLayout_27 = QVBoxLayout(self.page_2)
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.verticalLayout_27.setContentsMargins(0, -1, 0, -1)
        self.groupbox_26 = MkGroupBox(self.page_2)
        self.groupbox_26.setObjectName(u"groupbox_26")
        self.verticalLayout_11 = QVBoxLayout(self.groupbox_26)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(6, -1, 6, -1)
        self.widget_recovery = VCPWidget(self.groupbox_26)
        self.widget_recovery.setObjectName(u"widget_recovery")
        self.widget_recovery.setEnabled(True)
        self.gridLayout_34 = QGridLayout(self.widget_recovery)
        self.gridLayout_34.setObjectName(u"gridLayout_34")
        self.btn_cut_recover_fwd = QPushButton(self.widget_recovery)
        self.btn_cut_recover_fwd.setObjectName(u"btn_cut_recover_fwd")
        self.btn_cut_recover_fwd.setEnabled(True)
        self.btn_cut_recover_fwd.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_34.addWidget(self.btn_cut_recover_fwd, 0, 3, 1, 1)

        self.btn_cut_recover_rev = QPushButton(self.widget_recovery)
        self.btn_cut_recover_rev.setObjectName(u"btn_cut_recover_rev")
        self.btn_cut_recover_rev.setEnabled(True)
        self.btn_cut_recover_rev.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_34.addWidget(self.btn_cut_recover_rev, 0, 0, 1, 1)

        self.verticalSpacer_12 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_34.addItem(self.verticalSpacer_12, 1, 0, 1, 1)

        self.cut_recovery_speed = QSlider(self.widget_recovery)
        self.cut_recovery_speed.setObjectName(u"cut_recovery_speed")
        self.cut_recovery_speed.setEnabled(True)
        self.cut_recovery_speed.setMinimumSize(QSize(30, 300))
        self.cut_recovery_speed.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.cut_recovery_speed.setMaximum(100)
        self.cut_recovery_speed.setValue(50)
        self.cut_recovery_speed.setOrientation(Qt.Orientation.Vertical)
        self.cut_recovery_speed.setInvertedAppearance(False)
        self.cut_recovery_speed.setInvertedControls(False)
        self.cut_recovery_speed.setTickPosition(QSlider.TickPosition.TicksBothSides)
        self.cut_recovery_speed.setTickInterval(10)

        self.gridLayout_34.addWidget(self.cut_recovery_speed, 0, 1, 2, 1)


        self.verticalLayout_11.addWidget(self.widget_recovery)

        self.widget_34 = VCPWidget(self.groupbox_26)
        self.widget_34.setObjectName(u"widget_34")
        self.gridLayout_26 = QGridLayout(self.widget_34)
        self.gridLayout_26.setObjectName(u"gridLayout_26")
        self.btn_recovery_s = PlasmaPushButton(self.widget_34)
        self.btn_recovery_s.setObjectName(u"btn_recovery_s")
        self.btn_recovery_s.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon10 = QIcon()
        icon10.addFile(u":/image/icons/S.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_s.setIcon(icon10)
        self.btn_recovery_s.setIconSize(QSize(46, 46))
        self.btn_recovery_s.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_s, 2, 1, 1, 1)

        self.btn_recovery_sw = PlasmaPushButton(self.widget_34)
        self.btn_recovery_sw.setObjectName(u"btn_recovery_sw")
        self.btn_recovery_sw.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon11 = QIcon()
        icon11.addFile(u":/image/icons/SW.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_sw.setIcon(icon11)
        self.btn_recovery_sw.setIconSize(QSize(40, 40))
        self.btn_recovery_sw.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_sw, 2, 0, 1, 1)

        self.btn_recovery_se = PlasmaPushButton(self.widget_34)
        self.btn_recovery_se.setObjectName(u"btn_recovery_se")
        self.btn_recovery_se.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon12 = QIcon()
        icon12.addFile(u":/image/icons/SE.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_se.setIcon(icon12)
        self.btn_recovery_se.setIconSize(QSize(40, 40))
        self.btn_recovery_se.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_se, 2, 2, 1, 1)

        self.btn_recovery_e = PlasmaPushButton(self.widget_34)
        self.btn_recovery_e.setObjectName(u"btn_recovery_e")
        self.btn_recovery_e.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon13 = QIcon()
        icon13.addFile(u":/image/icons/E.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_e.setIcon(icon13)
        self.btn_recovery_e.setIconSize(QSize(46, 46))
        self.btn_recovery_e.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_e, 1, 2, 1, 1)

        self.btn_recovery_ne = PlasmaPushButton(self.widget_34)
        self.btn_recovery_ne.setObjectName(u"btn_recovery_ne")
        self.btn_recovery_ne.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon14 = QIcon()
        icon14.addFile(u":/image/icons/NE.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_ne.setIcon(icon14)
        self.btn_recovery_ne.setIconSize(QSize(40, 40))
        self.btn_recovery_ne.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_ne, 0, 2, 1, 1)

        self.btn_recovery_w = PlasmaPushButton(self.widget_34)
        self.btn_recovery_w.setObjectName(u"btn_recovery_w")
        self.btn_recovery_w.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon15 = QIcon()
        icon15.addFile(u":/image/icons/W.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_w.setIcon(icon15)
        self.btn_recovery_w.setIconSize(QSize(46, 46))
        self.btn_recovery_w.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_w, 1, 0, 1, 1)

        self.btn_recovery_n = PlasmaPushButton(self.widget_34)
        self.btn_recovery_n.setObjectName(u"btn_recovery_n")
        self.btn_recovery_n.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon16 = QIcon()
        icon16.addFile(u":/image/icons/N.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_n.setIcon(icon16)
        self.btn_recovery_n.setIconSize(QSize(46, 46))
        self.btn_recovery_n.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_n, 0, 1, 1, 1)

        self.btn_recovery_nw = PlasmaPushButton(self.widget_34)
        self.btn_recovery_nw.setObjectName(u"btn_recovery_nw")
        self.btn_recovery_nw.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        icon17 = QIcon()
        icon17.addFile(u":/image/icons/NW.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_recovery_nw.setIcon(icon17)
        self.btn_recovery_nw.setIconSize(QSize(40, 40))
        self.btn_recovery_nw.setFlat(True)

        self.gridLayout_26.addWidget(self.btn_recovery_nw, 0, 0, 1, 1)

        self.label_20 = QLabel(self.widget_34)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_26.addWidget(self.label_20, 1, 1, 1, 1)


        self.verticalLayout_11.addWidget(self.widget_34)

        self.btn_cut_recover_cancel = PlasmaPushButton(self.groupbox_26)
        self.btn_cut_recover_cancel.setObjectName(u"btn_cut_recover_cancel")
        self.btn_cut_recover_cancel.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.verticalLayout_11.addWidget(self.btn_cut_recover_cancel)


        self.verticalLayout_27.addWidget(self.groupbox_26)

        self.verticalSpacer_11 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_27.addItem(self.verticalSpacer_11)

        self.jog_stack.addWidget(self.page_2)

        self.verticalLayout_15.addWidget(self.jog_stack)

        self.tabwidget_midcolumn.addTab(self.tab_jog, "")

        self.horizontalLayout_4.addWidget(self.tabwidget_midcolumn)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setSpacing(14)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.tabs_ctl_run_right = MkTabWidget(self.tab_main)
        self.tabs_ctl_run_right.setObjectName(u"tabs_ctl_run_right")
        self.tabs_ctl_run_right.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tab_7 = QWidget()
        self.tab_7.setObjectName(u"tab_7")
        self.verticalLayout_14 = QVBoxLayout(self.tab_7)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.widget_13 = QWidget(self.tab_7)
        self.widget_13.setObjectName(u"widget_13")
        self.gridLayout_18 = QGridLayout(self.widget_13)
        self.gridLayout_18.setObjectName(u"gridLayout_18")
        self.vtk_minus = QPushButton(self.widget_13)
        self.vtk_minus.setObjectName(u"vtk_minus")
        self.vtk_minus.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_18.addWidget(self.vtk_minus, 0, 1, 1, 1)

        self.vtk_clear = QPushButton(self.widget_13)
        self.vtk_clear.setObjectName(u"vtk_clear")
        self.vtk_clear.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_18.addWidget(self.vtk_clear, 0, 3, 1, 1)

        self.vtk_mach_extent = QPushButton(self.widget_13)
        self.vtk_mach_extent.setObjectName(u"vtk_mach_extent")
        self.vtk_mach_extent.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.vtk_mach_extent.setCheckable(True)

        self.gridLayout_18.addWidget(self.vtk_mach_extent, 0, 6, 1, 1)

        self.vtk_no_lines = QPushButton(self.widget_13)
        self.vtk_no_lines.setObjectName(u"vtk_no_lines")
        self.vtk_no_lines.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.vtk_no_lines.setCheckable(True)
        self.vtk_no_lines.setChecked(True)

        self.gridLayout_18.addWidget(self.vtk_no_lines, 0, 8, 1, 1)

        self.vtk_center = QPushButton(self.widget_13)
        self.vtk_center.setObjectName(u"vtk_center")
        self.vtk_center.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_18.addWidget(self.vtk_center, 0, 2, 1, 1)

        self.vtk_plus = QPushButton(self.widget_13)
        self.vtk_plus.setObjectName(u"vtk_plus")
        self.vtk_plus.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_18.addWidget(self.vtk_plus, 0, 0, 1, 1)

        self.vtk_prog_extent = QPushButton(self.widget_13)
        self.vtk_prog_extent.setObjectName(u"vtk_prog_extent")
        self.vtk_prog_extent.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.vtk_prog_extent.setCheckable(True)

        self.gridLayout_18.addWidget(self.vtk_prog_extent, 0, 4, 1, 1)

        self.btn_transform = QPushButton(self.widget_13)
        self.btn_transform.setObjectName(u"btn_transform")
        self.btn_transform.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_transform.setCheckable(True)

        self.gridLayout_18.addWidget(self.btn_transform, 0, 7, 1, 1)


        self.verticalLayout_14.addWidget(self.widget_13)

        self.transformFrame = VCPFrame(self.tab_7)
        self.transformFrame.setObjectName(u"transformFrame")
        self.gridLayout_35 = QGridLayout(self.transformFrame)
        self.gridLayout_35.setObjectName(u"gridLayout_35")
        self.label_108 = QLabel(self.transformFrame)
        self.label_108.setObjectName(u"label_108")

        self.gridLayout_35.addWidget(self.label_108, 1, 0, 1, 1)

        self.label_113 = QLabel(self.transformFrame)
        self.label_113.setObjectName(u"label_113")
        self.label_113.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_35.addWidget(self.label_113, 2, 7, 1, 1)

        self.row_separation = HalDoubleSpinBox(self.transformFrame)
        self.row_separation.setObjectName(u"row_separation")
        self.row_separation.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.row_separation.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.row_separation.setDecimals(4)
        self.row_separation.setMaximum(1000.000000000000000)

        self.gridLayout_35.addWidget(self.row_separation, 2, 2, 1, 1)

        self.tile_columns = HalQSpinBox(self.transformFrame)
        self.tile_columns.setObjectName(u"tile_columns")
        self.tile_columns.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.tile_columns.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.tile_columns.setMinimum(1)
        self.tile_columns.setMaximum(1000)

        self.gridLayout_35.addWidget(self.tile_columns, 1, 1, 1, 1)

        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_35.addItem(self.horizontalSpacer_4, 0, 9, 1, 1)

        self.label_114 = QLabel(self.transformFrame)
        self.label_114.setObjectName(u"label_114")

        self.gridLayout_35.addWidget(self.label_114, 2, 3, 1, 1)

        self.label_111 = QLabel(self.transformFrame)
        self.label_111.setObjectName(u"label_111")
        self.label_111.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_35.addWidget(self.label_111, 0, 2, 1, 1)

        self.gcode_mirror = HalCheckBox(self.transformFrame)
        self.gcode_mirror.setObjectName(u"gcode_mirror")

        self.gridLayout_35.addWidget(self.gcode_mirror, 2, 8, 1, 1)

        self.tile_rows = HalQSpinBox(self.transformFrame)
        self.tile_rows.setObjectName(u"tile_rows")
        self.tile_rows.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.tile_rows.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.tile_rows.setMinimum(1)
        self.tile_rows.setMaximum(1000)

        self.gridLayout_35.addWidget(self.tile_rows, 2, 1, 1, 1)

        self.btn_transform_apply = QPushButton(self.transformFrame)
        self.btn_transform_apply.setObjectName(u"btn_transform_apply")
        sizePolicy6.setHeightForWidth(self.btn_transform_apply.sizePolicy().hasHeightForWidth())
        self.btn_transform_apply.setSizePolicy(sizePolicy6)
        self.btn_transform_apply.setMinimumSize(QSize(34, 44))
        self.btn_transform_apply.setBaseSize(QSize(0, 0))
        self.btn_transform_apply.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_transform_apply.setFlat(False)

        self.gridLayout_35.addWidget(self.btn_transform_apply, 1, 9, 2, 1)

        self.label_109 = QLabel(self.transformFrame)
        self.label_109.setObjectName(u"label_109")

        self.gridLayout_35.addWidget(self.label_109, 2, 0, 1, 1)

        self.column_separation = HalDoubleSpinBox(self.transformFrame)
        self.column_separation.setObjectName(u"column_separation")
        self.column_separation.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.column_separation.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.column_separation.setDecimals(4)
        self.column_separation.setMaximum(1000.000000000000000)

        self.gridLayout_35.addWidget(self.column_separation, 1, 2, 1, 1)

        self.gcode_rotation = HalDoubleSpinBox(self.transformFrame)
        self.gcode_rotation.setObjectName(u"gcode_rotation")
        self.gcode_rotation.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.gcode_rotation.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.gcode_rotation.setDecimals(2)
        self.gcode_rotation.setMaximum(360.000000000000000)

        self.gridLayout_35.addWidget(self.gcode_rotation, 2, 4, 1, 1)

        self.label_112 = QLabel(self.transformFrame)
        self.label_112.setObjectName(u"label_112")
        self.label_112.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_35.addWidget(self.label_112, 1, 7, 1, 1)

        self.gcode_flip = HalCheckBox(self.transformFrame)
        self.gcode_flip.setObjectName(u"gcode_flip")
        self.gcode_flip.setChecked(False)

        self.gridLayout_35.addWidget(self.gcode_flip, 1, 8, 1, 1)

        self.label_110 = QLabel(self.transformFrame)
        self.label_110.setObjectName(u"label_110")
        self.label_110.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_35.addWidget(self.label_110, 1, 3, 1, 1)

        self.gcode_scale = HalDoubleSpinBox(self.transformFrame)
        self.gcode_scale.setObjectName(u"gcode_scale")
        self.gcode_scale.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.gcode_scale.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.gcode_scale.setDecimals(2)
        self.gcode_scale.setMinimum(0.000000000000000)
        self.gcode_scale.setMaximum(1000.000000000000000)
        self.gcode_scale.setValue(1.000000000000000)

        self.gridLayout_35.addWidget(self.gcode_scale, 1, 4, 1, 1)


        self.verticalLayout_14.addWidget(self.transformFrame)

        self.vtkbackplot = VTKBackPlot(self.tab_7)
        self.vtkbackplot.setObjectName(u"vtkbackplot")

        self.verticalLayout_14.addWidget(self.vtkbackplot)

        self.widget_8 = QWidget(self.tab_7)
        self.widget_8.setObjectName(u"widget_8")
        sizePolicy10.setHeightForWidth(self.widget_8.sizePolicy().hasHeightForWidth())
        self.widget_8.setSizePolicy(sizePolicy10)
        self.widget_8.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_5 = QHBoxLayout(self.widget_8)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(-1, 1, -1, 1)
        self.btn_open_dialog_2 = DialogButton(self.widget_8)
        self.btn_open_dialog_2.setObjectName(u"btn_open_dialog_2")

        self.horizontalLayout_5.addWidget(self.btn_open_dialog_2)

        self.btn_reload_2 = ActionButton(self.widget_8)
        self.btn_reload_2.setObjectName(u"btn_reload_2")
        self.btn_reload_2.setEnabled(False)

        self.horizontalLayout_5.addWidget(self.btn_reload_2)

        self.dialogbutton_3 = DialogButton(self.widget_8)
        self.dialogbutton_3.setObjectName(u"dialogbutton_3")

        self.horizontalLayout_5.addWidget(self.dialogbutton_3)


        self.verticalLayout_14.addWidget(self.widget_8)

        self.mdiFrame = VCPFrame(self.tab_7)
        self.mdiFrame.setObjectName(u"mdiFrame")
        self.mdiFrame.setMinimumSize(QSize(0, 500))
        self.mdiFrame.setFrameShape(QFrame.Shape.WinPanel)
        self.gridLayout_14 = QGridLayout(self.mdiFrame)
        self.gridLayout_14.setObjectName(u"gridLayout_14")
        self.gridLayout_14.setHorizontalSpacing(6)
        self.gridLayout_14.setContentsMargins(6, -1, 6, -1)
        self.pushButton_28 = QPushButton(self.mdiFrame)
        self.btngrpMdi = QButtonGroup(Form)
        self.btngrpMdi.setObjectName(u"btngrpMdi")
        self.btngrpMdi.addButton(self.pushButton_28)
        self.pushButton_28.setObjectName(u"pushButton_28")
        self.pushButton_28.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_28, 8, 9, 1, 1)

        self.pushButton_30 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_30)
        self.pushButton_30.setObjectName(u"pushButton_30")
        self.pushButton_30.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_30, 7, 8, 1, 1)

        self.btnMdiRunSelection = QPushButton(self.mdiFrame)
        self.btnMdiRunSelection.setObjectName(u"btnMdiRunSelection")
        self.btnMdiRunSelection.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiRunSelection, 10, 3, 1, 1)

        self.pushButton_8 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_8)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_8, 8, 7, 1, 1)

        self.pushButton_29 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_29)
        self.pushButton_29.setObjectName(u"pushButton_29")
        self.pushButton_29.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_29, 8, 10, 1, 1)

        self.pushButton_25 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_25)
        self.pushButton_25.setObjectName(u"pushButton_25")
        self.pushButton_25.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_25, 9, 9, 1, 1)

        self.btnMdiDelAll = QPushButton(self.mdiFrame)
        self.btnMdiDelAll.setObjectName(u"btnMdiDelAll")
        self.btnMdiDelAll.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiDelAll, 10, 0, 1, 1)

        self.pushButton_31 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_31)
        self.pushButton_31.setObjectName(u"pushButton_31")
        self.pushButton_31.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_31, 7, 9, 1, 1)

        self.pushButton_34 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_34)
        self.pushButton_34.setObjectName(u"pushButton_34")
        self.pushButton_34.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_34, 6, 9, 1, 1)

        self.btnMdiParams = QPushButton(self.mdiFrame)
        self.btnMdiParams.setObjectName(u"btnMdiParams")
        self.btnMdiParams.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiParams, 10, 8, 1, 1)

        self.pushButton_32 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_32)
        self.pushButton_32.setObjectName(u"pushButton_32")
        self.pushButton_32.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_32, 7, 10, 1, 1)

        self.btnMdiSpace = QPushButton(self.mdiFrame)
        self.btnMdiSpace.setObjectName(u"btnMdiSpace")
        self.btnMdiSpace.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiSpace, 10, 7, 1, 1)

        self.btnMdiDelRow = QPushButton(self.mdiFrame)
        self.btnMdiDelRow.setObjectName(u"btnMdiDelRow")
        self.btnMdiDelRow.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiDelRow, 10, 1, 1, 1)

        self.pushButton_9 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_9)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_9, 7, 7, 1, 1)

        self.pushButton_10 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_10)
        self.pushButton_10.setObjectName(u"pushButton_10")
        self.pushButton_10.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_10, 6, 7, 1, 1)

        self.btnMdiRunFrom = QPushButton(self.mdiFrame)
        self.btnMdiRunFrom.setObjectName(u"btnMdiRunFrom")
        self.btnMdiRunFrom.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiRunFrom, 10, 2, 1, 1)

        self.btnMdiBksp = QPushButton(self.mdiFrame)
        self.btnMdiBksp.setObjectName(u"btnMdiBksp")
        self.btnMdiBksp.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiBksp, 10, 9, 1, 1)

        self.pushButton_27 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_27)
        self.pushButton_27.setObjectName(u"pushButton_27")
        self.pushButton_27.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_27, 8, 8, 1, 1)

        self.pushButton_26 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_26)
        self.pushButton_26.setObjectName(u"pushButton_26")
        self.pushButton_26.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_26, 9, 10, 1, 1)

        self.btnMdiSend = ActionButton(self.mdiFrame)
        self.btnMdiSend.setObjectName(u"btnMdiSend")

        self.gridLayout_14.addWidget(self.btnMdiSend, 10, 10, 1, 1)

        self.btnToEditor = QPushButton(self.mdiFrame)
        self.btnToEditor.setObjectName(u"btnToEditor")
        self.btnToEditor.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnToEditor, 10, 4, 1, 1)

        self.pushButton_24 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_24)
        self.pushButton_24.setObjectName(u"pushButton_24")
        self.pushButton_24.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_24, 9, 8, 1, 1)

        self.pushButton_35 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_35)
        self.pushButton_35.setObjectName(u"pushButton_35")
        self.pushButton_35.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_35, 6, 10, 1, 1)

        self.pushButton_7 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_7)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_7, 9, 7, 1, 1)

        self.pushButton_33 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.pushButton_33)
        self.pushButton_33.setObjectName(u"pushButton_33")
        self.pushButton_33.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.pushButton_33, 6, 8, 1, 1)

        self.btnGcodeP9 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP9)
        self.btnGcodeP9.setObjectName(u"btnGcodeP9")
        self.btnGcodeP9.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP9, 5, 7, 1, 1)

        self.btnGcodeP10 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP10)
        self.btnGcodeP10.setObjectName(u"btnGcodeP10")
        self.btnGcodeP10.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP10, 5, 8, 1, 1)

        self.btnGcodeP5 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP5)
        self.btnGcodeP5.setObjectName(u"btnGcodeP5")
        self.btnGcodeP5.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP5, 4, 7, 1, 1)

        self.btnGcodeP6 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP6)
        self.btnGcodeP6.setObjectName(u"btnGcodeP6")
        self.btnGcodeP6.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP6, 4, 8, 1, 1)

        self.btnGcodeP7 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP7)
        self.btnGcodeP7.setObjectName(u"btnGcodeP7")
        self.btnGcodeP7.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP7, 4, 9, 1, 1)

        self.btnGcodeP8 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP8)
        self.btnGcodeP8.setObjectName(u"btnGcodeP8")
        self.btnGcodeP8.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP8, 4, 10, 1, 1)

        self.btnGcodeP1 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP1)
        self.btnGcodeP1.setObjectName(u"btnGcodeP1")
        self.btnGcodeP1.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP1, 3, 7, 1, 1)

        self.btnGcodeP2 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP2)
        self.btnGcodeP2.setObjectName(u"btnGcodeP2")
        self.btnGcodeP2.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP2, 3, 8, 1, 1)

        self.btnGcodeP3 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP3)
        self.btnGcodeP3.setObjectName(u"btnGcodeP3")
        self.btnGcodeP3.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP3, 3, 9, 1, 1)

        self.btnGcodeP4 = QPushButton(self.mdiFrame)
        self.btngrpMdi.addButton(self.btnGcodeP4)
        self.btnGcodeP4.setObjectName(u"btnGcodeP4")
        self.btnGcodeP4.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnGcodeP4, 3, 10, 1, 1)

        self.mdiEntry = MDIEntry(self.mdiFrame)
        self.mdiEntry.setObjectName(u"mdiEntry")
        self.mdiEntry.setMinimumSize(QSize(0, 29))
        self.mdiEntry.setMaximumSize(QSize(16777215, 42))
        self.mdiEntry.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.mdiEntry.setProperty(u"mdi_history_size", 5)
        self.mdiEntry.setProperty(u"completerEnabled", False)

        self.gridLayout_14.addWidget(self.mdiEntry, 2, 7, 1, 4)

        self.mdihistory = MDIHistory(self.mdiFrame)
        self.mdihistory.setObjectName(u"mdihistory")
        self.mdihistory.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.mdihistory.setAlternatingRowColors(True)
        self.mdihistory.setSelectionMode(QAbstractItemView.SelectionMode.ContiguousSelection)
        self.mdihistory.setProperty(u"mdiListOrderNatural", True)

        self.gridLayout_14.addWidget(self.mdihistory, 2, 0, 8, 5)

        self.btnMdiPauseQ = QPushButton(self.mdiFrame)
        self.btnMdiPauseQ.setObjectName(u"btnMdiPauseQ")
        self.btnMdiPauseQ.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btnMdiPauseQ.setCheckable(True)

        self.gridLayout_14.addWidget(self.btnMdiPauseQ, 3, 6, 1, 1)

        self.btnMdiClearQ = QPushButton(self.mdiFrame)
        self.btnMdiClearQ.setObjectName(u"btnMdiClearQ")
        self.btnMdiClearQ.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiClearQ, 4, 6, 1, 1)

        self.btnMdiRowUp = QPushButton(self.mdiFrame)
        self.btnMdiRowUp.setObjectName(u"btnMdiRowUp")
        self.btnMdiRowUp.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiRowUp, 6, 6, 1, 1)

        self.btnMdiRowDown = QPushButton(self.mdiFrame)
        self.btnMdiRowDown.setObjectName(u"btnMdiRowDown")
        self.btnMdiRowDown.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_14.addWidget(self.btnMdiRowDown, 7, 6, 1, 1)


        self.verticalLayout_14.addWidget(self.mdiFrame)

        self.tabs_ctl_run_right.addTab(self.tab_7, "")
        self.tab_5 = QWidget()
        self.tab_5.setObjectName(u"tab_5")
        self.horizontalLayout_17 = QHBoxLayout(self.tab_5)
        self.horizontalLayout_17.setSpacing(0)
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.horizontalLayout_17.setContentsMargins(0, 9, 0, 0)
        self.file_frame = QFrame(self.tab_5)
        self.file_frame.setObjectName(u"file_frame")
        self.file_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.file_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.file_frame)
        self.verticalLayout_8.setSpacing(2)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(9, 0, 0, 0)
        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setSpacing(0)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_7 = QLabel(self.file_frame)
        self.label_7.setObjectName(u"label_7")
        sizePolicy11 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Preferred)
        sizePolicy11.setHorizontalStretch(0)
        sizePolicy11.setVerticalStretch(0)
        sizePolicy11.setHeightForWidth(self.label_7.sizePolicy().hasHeightForWidth())
        self.label_7.setSizePolicy(sizePolicy11)

        self.horizontalLayout_6.addWidget(self.label_7)

        self.gcode_recentfile = RecentFileComboBox(self.file_frame)
        self.gcode_recentfile.setObjectName(u"gcode_recentfile")
        sizePolicy12 = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed)
        sizePolicy12.setHorizontalStretch(0)
        sizePolicy12.setVerticalStretch(0)
        sizePolicy12.setHeightForWidth(self.gcode_recentfile.sizePolicy().hasHeightForWidth())
        self.gcode_recentfile.setSizePolicy(sizePolicy12)
        self.gcode_recentfile.setMinimumSize(QSize(100, 32))
        self.gcode_recentfile.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.horizontalLayout_6.addWidget(self.gcode_recentfile)


        self.verticalLayout_8.addLayout(self.horizontalLayout_6)

        self.gcode_editor = GCodeEditor(self.file_frame)
        self.gcode_editor.setObjectName(u"gcode_editor")

        self.verticalLayout_8.addWidget(self.gcode_editor)


        self.horizontalLayout_17.addWidget(self.file_frame)

        self.widget_12 = QWidget(self.tab_5)
        self.widget_12.setObjectName(u"widget_12")
        self.widget_12.setMinimumSize(QSize(20, 20))
        self.verticalLayout_20 = QVBoxLayout(self.widget_12)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.verticalLayout_20.setContentsMargins(-1, 0, -1, -1)
        self.btn_syntax_highlight = ActionButton(self.widget_12)
        self.btn_syntax_highlight.setObjectName(u"btn_syntax_highlight")
        self.btn_syntax_highlight.setEnabled(False)
        self.btn_syntax_highlight.setCheckable(True)

        self.verticalLayout_20.addWidget(self.btn_syntax_highlight)

        self.btn_edit = ActionButton(self.widget_12)
        self.btn_edit.setObjectName(u"btn_edit")
        self.btn_edit.setEnabled(False)
        self.btn_edit.setCheckable(True)

        self.verticalLayout_20.addWidget(self.btn_edit)

        self.btn_save = ActionButton(self.widget_12)
        self.btn_save.setObjectName(u"btn_save")
        self.btn_save.setEnabled(False)

        self.verticalLayout_20.addWidget(self.btn_save)

        self.btn_open_dialog = DialogButton(self.widget_12)
        self.btn_open_dialog.setObjectName(u"btn_open_dialog")

        self.verticalLayout_20.addWidget(self.btn_open_dialog)

        self.btn_reload = ActionButton(self.widget_12)
        self.btn_reload.setObjectName(u"btn_reload")
        self.btn_reload.setEnabled(False)

        self.verticalLayout_20.addWidget(self.btn_reload)

        self.dialogbutton_2 = DialogButton(self.widget_12)
        self.dialogbutton_2.setObjectName(u"dialogbutton_2")

        self.verticalLayout_20.addWidget(self.dialogbutton_2)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_20.addItem(self.verticalSpacer)


        self.horizontalLayout_17.addWidget(self.widget_12)

        self.tabs_ctl_run_right.addTab(self.tab_5, "")
        self.tab_13 = QWidget()
        self.tab_13.setObjectName(u"tab_13")
        self.tab_13.setEnabled(True)
        self.groupbox_20 = MkGroupBox(self.tab_13)
        self.groupbox_20.setObjectName(u"groupbox_20")
        self.groupbox_20.setGeometry(QRect(20, 10, 431, 391))
        self.jobs_to_process = QListWidget(self.groupbox_20)
        self.jobs_to_process.setObjectName(u"jobs_to_process")
        self.jobs_to_process.setGeometry(QRect(10, 30, 411, 351))
        self.jobs_to_process.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.groupbox_21 = MkGroupBox(self.tab_13)
        self.groupbox_21.setObjectName(u"groupbox_21")
        self.groupbox_21.setGeometry(QRect(20, 490, 431, 391))
        self.jobs_done = QListView(self.groupbox_21)
        self.jobs_done.setObjectName(u"jobs_done")
        self.jobs_done.setGeometry(QRect(10, 30, 411, 351))
        self.jobs_done.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.groupbox_22 = MkGroupBox(self.tab_13)
        self.groupbox_22.setObjectName(u"groupbox_22")
        self.groupbox_22.setGeometry(QRect(460, 10, 421, 391))
        self.verticalLayout_17 = QVBoxLayout(self.groupbox_22)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.job_instructions = QTextBrowser(self.groupbox_22)
        self.job_instructions.setObjectName(u"job_instructions")
        self.job_instructions.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.verticalLayout_17.addWidget(self.job_instructions)

        self.widget_11 = QWidget(self.tab_13)
        self.widget_11.setObjectName(u"widget_11")
        self.widget_11.setGeometry(QRect(20, 410, 711, 71))
        self.gridLayout_22 = QGridLayout(self.widget_11)
        self.gridLayout_22.setObjectName(u"gridLayout_22")
        self.pushButton_14 = QPushButton(self.widget_11)
        self.pushButton_14.setObjectName(u"pushButton_14")
        self.pushButton_14.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_22.addWidget(self.pushButton_14, 0, 2, 1, 1)

        self.pushButton_12 = QPushButton(self.widget_11)
        self.pushButton_12.setObjectName(u"pushButton_12")
        self.pushButton_12.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_22.addWidget(self.pushButton_12, 0, 0, 1, 1)

        self.pushButton_3 = QPushButton(self.widget_11)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_22.addWidget(self.pushButton_3, 0, 1, 1, 1)

        self.groupbox_25 = MkGroupBox(self.tab_13)
        self.groupbox_25.setObjectName(u"groupbox_25")
        self.groupbox_25.setGeometry(QRect(460, 490, 421, 391))
        self.verticalLayout_21 = QVBoxLayout(self.groupbox_25)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.listWidget = QListWidget(self.groupbox_25)
        self.listWidget.setObjectName(u"listWidget")
        self.listWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.verticalLayout_21.addWidget(self.listWidget)

        self.tabs_ctl_run_right.addTab(self.tab_13, "")

        self.verticalLayout_4.addWidget(self.tabs_ctl_run_right)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setSpacing(14)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")

        self.verticalLayout_4.addLayout(self.horizontalLayout_3)


        self.horizontalLayout_4.addLayout(self.verticalLayout_4)

        self.horizontalLayout_4.setStretch(0, 4)
        self.horizontalLayout_4.setStretch(2, 6)
        self.mainTabWidget.addTab(self.tab_main, "")
        self.tab_parameters = QWidget()
        self.tab_parameters.setObjectName(u"tab_parameters")
        self.horizontalLayout_2 = QHBoxLayout(self.tab_parameters)
        self.horizontalLayout_2.setSpacing(15)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(10, 0, 10, 10)
        self.tabWidget = MkTabWidget(self.tab_parameters)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tab_8 = QWidget()
        self.tab_8.setObjectName(u"tab_8")
        self.horizontalLayout_8 = QHBoxLayout(self.tab_8)
        self.horizontalLayout_8.setSpacing(6)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(6, 12, 6, 6)
        self.gridLayout_7 = QGridLayout()
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.gridLayout_7.setHorizontalSpacing(6)
        self.gridLayout_7.setContentsMargins(-1, 4, -1, 0)
        self.groupbox_15 = MkGroupBox(self.tab_8)
        self.groupbox_15.setObjectName(u"groupbox_15")
        sizePolicy13 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy13.setHorizontalStretch(0)
        sizePolicy13.setVerticalStretch(0)
        sizePolicy13.setHeightForWidth(self.groupbox_15.sizePolicy().hasHeightForWidth())
        self.groupbox_15.setSizePolicy(sizePolicy13)
        self.groupbox_15.setMinimumSize(QSize(400, 0))
        self.groupbox_15.setMaximumSize(QSize(450, 16777215))
        self.gridLayout_19 = QGridLayout(self.groupbox_15)
        self.gridLayout_19.setObjectName(u"gridLayout_19")
        self.gridLayout_19.setVerticalSpacing(18)
        self.label_63 = QLabel(self.groupbox_15)
        self.label_63.setObjectName(u"label_63")

        self.gridLayout_19.addWidget(self.label_63, 3, 0, 1, 1)

        self.filter_operation = QComboBox(self.groupbox_15)
        self.filter_operation.setObjectName(u"filter_operation")

        self.gridLayout_19.addWidget(self.filter_operation, 4, 1, 1, 1)

        self.filter_gas = QComboBox(self.groupbox_15)
        self.filter_gas.setObjectName(u"filter_gas")

        self.gridLayout_19.addWidget(self.filter_gas, 5, 1, 1, 1)

        self.filter_material = QComboBox(self.groupbox_15)
        self.filter_material.setObjectName(u"filter_material")

        self.gridLayout_19.addWidget(self.filter_material, 1, 1, 1, 1)

        self.filter_quality = QComboBox(self.groupbox_15)
        self.filter_quality.setObjectName(u"filter_quality")

        self.gridLayout_19.addWidget(self.filter_quality, 6, 1, 1, 1)

        self.filter_consumable = QComboBox(self.groupbox_15)
        self.filter_consumable.setObjectName(u"filter_consumable")

        self.gridLayout_19.addWidget(self.filter_consumable, 3, 1, 1, 1)

        self.label_65 = QLabel(self.groupbox_15)
        self.label_65.setObjectName(u"label_65")

        self.gridLayout_19.addWidget(self.label_65, 2, 0, 1, 1)

        self.label_68 = QLabel(self.groupbox_15)
        self.label_68.setObjectName(u"label_68")

        self.gridLayout_19.addWidget(self.label_68, 6, 0, 1, 1)

        self.label_64 = QLabel(self.groupbox_15)
        self.label_64.setObjectName(u"label_64")

        self.gridLayout_19.addWidget(self.label_64, 1, 0, 1, 1)

        self.label_67 = QLabel(self.groupbox_15)
        self.label_67.setObjectName(u"label_67")

        self.gridLayout_19.addWidget(self.label_67, 5, 0, 1, 1)

        self.label_66 = QLabel(self.groupbox_15)
        self.label_66.setObjectName(u"label_66")

        self.gridLayout_19.addWidget(self.label_66, 4, 0, 1, 1)

        self.filter_thickness = QComboBox(self.groupbox_15)
        self.filter_thickness.setObjectName(u"filter_thickness")

        self.gridLayout_19.addWidget(self.filter_thickness, 2, 1, 1, 1)


        self.gridLayout_7.addWidget(self.groupbox_15, 0, 0, 1, 1)

        self.groupbox_9 = MkGroupBox(self.tab_8)
        self.groupbox_9.setObjectName(u"groupbox_9")
        self.gridLayout_17 = QGridLayout(self.groupbox_9)
        self.gridLayout_17.setObjectName(u"gridLayout_17")
        self.gridLayout_17.setVerticalSpacing(12)
        self.btn_save_run_process = MkPushButton(self.groupbox_9)
        self.btn_save_run_process.setObjectName(u"btn_save_run_process")
        sizePolicy14 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy14.setHorizontalStretch(1)
        sizePolicy14.setVerticalStretch(0)
        sizePolicy14.setHeightForWidth(self.btn_save_run_process.sizePolicy().hasHeightForWidth())
        self.btn_save_run_process.setSizePolicy(sizePolicy14)

        self.gridLayout_17.addWidget(self.btn_save_run_process, 0, 0, 1, 1)

        self.btn_del_run_process = MkPushButton(self.groupbox_9)
        self.btn_del_run_process.setObjectName(u"btn_del_run_process")
        sizePolicy14.setHeightForWidth(self.btn_del_run_process.sizePolicy().hasHeightForWidth())
        self.btn_del_run_process.setSizePolicy(sizePolicy14)

        self.gridLayout_17.addWidget(self.btn_del_run_process, 0, 2, 1, 1)

        self.btn_new_run_process = DialogButton(self.groupbox_9)
        self.btn_new_run_process.setObjectName(u"btn_new_run_process")
        sizePolicy14.setHeightForWidth(self.btn_new_run_process.sizePolicy().hasHeightForWidth())
        self.btn_new_run_process.setSizePolicy(sizePolicy14)

        self.gridLayout_17.addWidget(self.btn_new_run_process, 0, 3, 1, 1)

        self.btn_run_reload = QPushButton(self.groupbox_9)
        self.btn_run_reload.setObjectName(u"btn_run_reload")
        sizePolicy14.setHeightForWidth(self.btn_run_reload.sizePolicy().hasHeightForWidth())
        self.btn_run_reload.setSizePolicy(sizePolicy14)
        self.btn_run_reload.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_17.addWidget(self.btn_run_reload, 0, 1, 1, 1)


        self.gridLayout_7.addWidget(self.groupbox_9, 1, 0, 1, 1)

        self.grp_filter_sub_list = MkGroupBox(self.tab_8)
        self.grp_filter_sub_list.setObjectName(u"grp_filter_sub_list")
        sizePolicy15 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy15.setHorizontalStretch(0)
        sizePolicy15.setVerticalStretch(1)
        sizePolicy15.setHeightForWidth(self.grp_filter_sub_list.sizePolicy().hasHeightForWidth())
        self.grp_filter_sub_list.setSizePolicy(sizePolicy15)
        self.verticalLayout_16 = QVBoxLayout(self.grp_filter_sub_list)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.verticalLayout_16.setContentsMargins(0, 6, 0, 6)
        self.filter_sub_list = QListWidget(self.grp_filter_sub_list)
        QListWidgetItem(self.filter_sub_list)
        QListWidgetItem(self.filter_sub_list)
        self.filter_sub_list.setObjectName(u"filter_sub_list")
        sizePolicy.setHeightForWidth(self.filter_sub_list.sizePolicy().hasHeightForWidth())
        self.filter_sub_list.setSizePolicy(sizePolicy)
        self.filter_sub_list.setMinimumSize(QSize(0, 0))
        self.filter_sub_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.filter_sub_list.setStyleSheet(u"QListView::item {\n"
"min-height: 42px; \n"
"}\n"
"\n"
"QListView {\n"
"font-weight: bold;\n"
"}\n"
"\n"
"QListView::item:selected {\n"
"    border: 1px solid rgb(255, 238, 6);\n"
"}\n"
"")
        self.filter_sub_list.setDefaultDropAction(Qt.DropAction.IgnoreAction)
        self.filter_sub_list.setMovement(QListView.Movement.Static)
        self.filter_sub_list.setProperty(u"isWrapping", True)
        self.filter_sub_list.setSpacing(0)
        self.filter_sub_list.setUniformItemSizes(False)
        self.filter_sub_list.setWordWrap(True)

        self.verticalLayout_16.addWidget(self.filter_sub_list)


        self.gridLayout_7.addWidget(self.grp_filter_sub_list, 2, 0, 1, 1)

        self.verticalSpacer_4 = QSpacerItem(20, 0, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.MinimumExpanding)

        self.gridLayout_7.addItem(self.verticalSpacer_4, 3, 0, 1, 1)

        self.groupbox_16 = MkGroupBox(self.tab_8)
        self.groupbox_16.setObjectName(u"groupbox_16")
        sizePolicy13.setHeightForWidth(self.groupbox_16.sizePolicy().hasHeightForWidth())
        self.groupbox_16.setSizePolicy(sizePolicy13)
        self.groupbox_16.setMinimumSize(QSize(350, 0))
        self.groupbox_16.setMaximumSize(QSize(450, 16777215))
        self.gridLayout_20 = QGridLayout(self.groupbox_16)
        self.gridLayout_20.setObjectName(u"gridLayout_20")
        self.gridLayout_20.setVerticalSpacing(18)
        self.paramKirfWidthLabel = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel.setObjectName(u"paramKirfWidthLabel")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel, 2, 0, 1, 1)

        self.param_puddlejumpdelay = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_puddlejumpdelay.setObjectName(u"param_puddlejumpdelay")
        self.param_puddlejumpdelay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_puddlejumpdelay.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)

        self.gridLayout_20.addWidget(self.param_puddlejumpdelay, 11, 1, 1, 1)

        self.paramKirfWidthLabel_3 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_3.setObjectName(u"paramKirfWidthLabel_3")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_3, 5, 0, 1, 1)

        self.label_69 = QLabel(self.groupbox_16)
        self.label_69.setObjectName(u"label_69")

        self.gridLayout_20.addWidget(self.label_69, 0, 0, 1, 1)

        self.param_pierceheight = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_pierceheight.setObjectName(u"param_pierceheight")
        self.param_pierceheight.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_pierceheight.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_pierceheight.setMaximum(20.000000000000000)
        self.param_pierceheight.setSingleStep(0.500000000000000)

        self.gridLayout_20.addWidget(self.param_pierceheight, 3, 1, 1, 1)

        self.param_plungefeedrate = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_plungefeedrate.setObjectName(u"param_plungefeedrate")
        self.param_plungefeedrate.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_plungefeedrate.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_plungefeedrate.setMaximum(10000.000000000000000)

        self.gridLayout_20.addWidget(self.param_plungefeedrate, 7, 1, 1, 1)

        self.paramKirfWidthLabel_7 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_7.setObjectName(u"paramKirfWidthLabel_7")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_7, 9, 0, 1, 1)

        self.param_process_id = QLabel(self.groupbox_16)
        self.param_process_id.setObjectName(u"param_process_id")
        self.param_process_id.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_20.addWidget(self.param_process_id, 1, 1, 1, 1)

        self.param_name = QLabel(self.groupbox_16)
        self.param_name.setObjectName(u"param_name")
        self.param_name.setWordWrap(True)

        self.gridLayout_20.addWidget(self.param_name, 0, 1, 1, 1)

        self.label_90 = QLabel(self.groupbox_16)
        self.label_90.setObjectName(u"label_90")

        self.gridLayout_20.addWidget(self.label_90, 1, 0, 1, 1)

        self.label_5 = QLabel(self.groupbox_16)
        self.label_5.setObjectName(u"label_5")

        self.gridLayout_20.addWidget(self.label_5, 7, 0, 1, 1)

        self.paramKirfWidthLabel_5 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_5.setObjectName(u"paramKirfWidthLabel_5")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_5, 6, 0, 1, 1)

        self.param_pauseatend = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_pauseatend.setObjectName(u"param_pauseatend")
        self.param_pauseatend.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_pauseatend.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_pauseatend.setMaximum(10.000000000000000)

        self.gridLayout_20.addWidget(self.param_pauseatend, 12, 1, 1, 1)

        self.param_puddlejumpheight = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_puddlejumpheight.setObjectName(u"param_puddlejumpheight")
        self.param_puddlejumpheight.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_puddlejumpheight.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_puddlejumpheight.setProperty(u"showGroupSeparator", False)
        self.param_puddlejumpheight.setMaximum(100.000000000000000)

        self.gridLayout_20.addWidget(self.param_puddlejumpheight, 10, 1, 1, 1)

        self.paramKirfWidthLabel_4 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_4.setObjectName(u"paramKirfWidthLabel_4")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_4, 4, 0, 1, 1)

        self.paramKirfWidthLabel_6 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_6.setObjectName(u"paramKirfWidthLabel_6")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_6, 8, 0, 1, 1)

        self.paramKirfWidthLabel_9 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_9.setObjectName(u"paramKirfWidthLabel_9")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_9, 11, 0, 1, 1)

        self.param_cutfeedrate = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_cutfeedrate.setObjectName(u"param_cutfeedrate")
        self.param_cutfeedrate.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_cutfeedrate.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_cutfeedrate.setDecimals(0)
        self.param_cutfeedrate.setMaximum(30000.000000000000000)

        self.gridLayout_20.addWidget(self.param_cutfeedrate, 6, 1, 1, 1)

        self.param_cutheight = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_cutheight.setObjectName(u"param_cutheight")
        self.param_cutheight.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_cutheight.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_cutheight.setMaximum(10.000000000000000)

        self.gridLayout_20.addWidget(self.param_cutheight, 5, 1, 1, 1)

        self.param_cutamps = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_cutamps.setObjectName(u"param_cutamps")
        self.param_cutamps.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_cutamps.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_cutamps.setDecimals(0)
        self.param_cutamps.setMaximum(400.000000000000000)

        self.gridLayout_20.addWidget(self.param_cutamps, 8, 1, 1, 1)

        self.paramKirfWidthLabel_8 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_8.setObjectName(u"paramKirfWidthLabel_8")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_8, 10, 0, 1, 1)

        self.param_cutvolts = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_cutvolts.setObjectName(u"param_cutvolts")
        self.param_cutvolts.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_cutvolts.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_cutvolts.setDecimals(0)
        self.param_cutvolts.setMaximum(200.000000000000000)
        self.param_cutvolts.setSingleStep(5.000000000000000)

        self.gridLayout_20.addWidget(self.param_cutvolts, 9, 1, 1, 1)

        self.param_kerfwidth = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_kerfwidth.setObjectName(u"param_kerfwidth")
        self.param_kerfwidth.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_kerfwidth.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_kerfwidth.setDecimals(3)
        self.param_kerfwidth.setMaximum(5.000000000000000)
        self.param_kerfwidth.setSingleStep(0.100000000000000)

        self.gridLayout_20.addWidget(self.param_kerfwidth, 2, 1, 1, 1)

        self.paramKirfWidthLabel_2 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_2.setObjectName(u"paramKirfWidthLabel_2")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_2, 3, 0, 1, 1)

        self.paramKirfWidthLabel_10 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_10.setObjectName(u"paramKirfWidthLabel_10")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_10, 12, 0, 1, 1)

        self.paramKirfWidthLabel_11 = QLabel(self.groupbox_16)
        self.paramKirfWidthLabel_11.setObjectName(u"paramKirfWidthLabel_11")

        self.gridLayout_20.addWidget(self.paramKirfWidthLabel_11, 13, 0, 1, 1)

        self.param_piercedelay = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_piercedelay.setObjectName(u"param_piercedelay")
        self.param_piercedelay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_piercedelay.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)

        self.gridLayout_20.addWidget(self.param_piercedelay, 4, 1, 1, 1)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_20.addItem(self.verticalSpacer_5, 25, 1, 1, 1)

        self.param_gaspressure = PlasmaHalDoubleSpinBox(self.groupbox_16)
        self.param_gaspressure.setObjectName(u"param_gaspressure")
        self.param_gaspressure.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.param_gaspressure.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.param_gaspressure.setMaximum(200.000000000000000)

        self.gridLayout_20.addWidget(self.param_gaspressure, 13, 1, 1, 1)


        self.gridLayout_7.addWidget(self.groupbox_16, 0, 1, 3, 1)


        self.horizontalLayout_8.addLayout(self.gridLayout_7)

        self.widget_18 = QWidget(self.tab_8)
        self.widget_18.setObjectName(u"widget_18")
        sizePolicy16 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy16.setHorizontalStretch(1)
        sizePolicy16.setVerticalStretch(0)
        sizePolicy16.setHeightForWidth(self.widget_18.sizePolicy().hasHeightForWidth())
        self.widget_18.setSizePolicy(sizePolicy16)
        self.verticalLayout_10 = QVBoxLayout(self.widget_18)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.tab_holes_and_slots = MkTabWidget(self.widget_18)
        self.tab_holes_and_slots.setObjectName(u"tab_holes_and_slots")
        self.tab_holes_and_slots.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tab_holes = QWidget()
        self.tab_holes.setObjectName(u"tab_holes")
        sizePolicy17 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.MinimumExpanding)
        sizePolicy17.setHorizontalStretch(0)
        sizePolicy17.setVerticalStretch(0)
        sizePolicy17.setHeightForWidth(self.tab_holes.sizePolicy().hasHeightForWidth())
        self.tab_holes.setSizePolicy(sizePolicy17)
        self.tab_holes.setMinimumSize(QSize(0, 850))
        self.verticalLayout_19 = QVBoxLayout(self.tab_holes)
        self.verticalLayout_19.setSpacing(5)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(-1, 5, -1, 5)
        self.widget_22 = QWidget(self.tab_holes)
        self.widget_22.setObjectName(u"widget_22")
        self.gridLayout_28 = QGridLayout(self.widget_22)
        self.gridLayout_28.setObjectName(u"gridLayout_28")
        self.spn_hole_thickness_ratio = PlasmaHalSpinBox(self.widget_22)
        self.spn_hole_thickness_ratio.setObjectName(u"spn_hole_thickness_ratio")
        self.spn_hole_thickness_ratio.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_hole_thickness_ratio.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)

        self.gridLayout_28.addWidget(self.spn_hole_thickness_ratio, 1, 0, 1, 1)

        self.spn_small_hole_threshold = PlasmaHalDoubleSpinBox(self.widget_22)
        self.spn_small_hole_threshold.setObjectName(u"spn_small_hole_threshold")
        self.spn_small_hole_threshold.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_small_hole_threshold.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_small_hole_threshold.setDecimals(4)

        self.gridLayout_28.addWidget(self.spn_small_hole_threshold, 4, 0, 1, 1)

        self.label_79 = QLabel(self.widget_22)
        self.label_79.setObjectName(u"label_79")
        self.label_79.setWordWrap(True)

        self.gridLayout_28.addWidget(self.label_79, 3, 1, 1, 2)

        self.chkb_hole_detect_enable = PlasmaHalCheckBox(self.widget_22)
        self.chkb_hole_detect_enable.setObjectName(u"chkb_hole_detect_enable")
        self.chkb_hole_detect_enable.setMinimumSize(QSize(0, 42))
        self.chkb_hole_detect_enable.setMaximumSize(QSize(16777215, 42))
        font2 = QFont()
        font2.setFamilies([u"Sans"])
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setItalic(False)
        self.chkb_hole_detect_enable.setFont(font2)
        self.chkb_hole_detect_enable.setStyleSheet(u"font: bold 12pt;")

        self.gridLayout_28.addWidget(self.chkb_hole_detect_enable, 0, 0, 1, 1)

        self.spn_max_hole_size = PlasmaHalDoubleSpinBox(self.widget_22)
        self.spn_max_hole_size.setObjectName(u"spn_max_hole_size")
        self.spn_max_hole_size.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_max_hole_size.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_max_hole_size.setDecimals(4)
        self.spn_max_hole_size.setMaximum(200.000000000000000)

        self.gridLayout_28.addWidget(self.spn_max_hole_size, 2, 0, 1, 1)

        self.spn_hole_kerf = PlasmaHalDoubleSpinBox(self.widget_22)
        self.spn_hole_kerf.setObjectName(u"spn_hole_kerf")
        self.spn_hole_kerf.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_hole_kerf.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_hole_kerf.setDecimals(4)
        self.spn_hole_kerf.setMinimum(-10.000000000000000)
        self.spn_hole_kerf.setMaximum(10.000000000000000)
        self.spn_hole_kerf.setSingleStep(0.100000000000000)

        self.gridLayout_28.addWidget(self.spn_hole_kerf, 4, 3, 1, 1)

        self.chkb_small_hole_detect = PlasmaHalCheckBox(self.widget_22)
        self.chkb_small_hole_detect.setObjectName(u"chkb_small_hole_detect")
        self.chkb_small_hole_detect.setStyleSheet(u"font: bold 12pt;")

        self.gridLayout_28.addWidget(self.chkb_small_hole_detect, 0, 1, 1, 1)

        self.label_11 = QLabel(self.widget_22)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setWordWrap(True)

        self.gridLayout_28.addWidget(self.label_11, 1, 1, 1, 2)

        self.label_73 = QLabel(self.widget_22)
        self.label_73.setObjectName(u"label_73")

        self.gridLayout_28.addWidget(self.label_73, 4, 1, 1, 1)

        self.spn_leadin_radius = PlasmaHalDoubleSpinBox(self.widget_22)
        self.spn_leadin_radius.setObjectName(u"spn_leadin_radius")
        self.spn_leadin_radius.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_leadin_radius.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_leadin_radius.setDecimals(4)

        self.gridLayout_28.addWidget(self.spn_leadin_radius, 3, 0, 1, 1)

        self.label_194 = QLabel(self.widget_22)
        self.label_194.setObjectName(u"label_194")

        self.gridLayout_28.addWidget(self.label_194, 4, 2, 1, 1)

        self.label_70 = QLabel(self.widget_22)
        self.label_70.setObjectName(u"label_70")

        self.gridLayout_28.addWidget(self.label_70, 2, 1, 1, 2)

        self.chkb_force_straight_leadin = PlasmaHalCheckBox(self.widget_22)
        self.chkb_force_straight_leadin.setObjectName(u"chkb_force_straight_leadin")
        self.chkb_force_straight_leadin.setStyleSheet(u"font: bold 12pt;")

        self.gridLayout_28.addWidget(self.chkb_force_straight_leadin, 0, 2, 1, 1)

        self.chkb_is_kerf_compensated = PlasmaHalCheckBox(self.widget_22)
        self.chkb_is_kerf_compensated.setObjectName(u"chkb_is_kerf_compensated")
        self.chkb_is_kerf_compensated.setFont(font2)
        self.chkb_is_kerf_compensated.setStyleSheet(u"font: bold 12pt;")

        self.gridLayout_28.addWidget(self.chkb_is_kerf_compensated, 0, 3, 1, 1)

        self.chkb_use_hidef = PlasmaHalCheckBox(self.widget_22)
        self.chkb_use_hidef.setObjectName(u"chkb_use_hidef")
        self.chkb_use_hidef.setStyleSheet(u"font: bold 12pt;")

        self.gridLayout_28.addWidget(self.chkb_use_hidef, 1, 3, 1, 1)


        self.verticalLayout_19.addWidget(self.widget_22)

        self.widget_21 = QWidget(self.tab_holes)
        self.widget_21.setObjectName(u"widget_21")
        sizePolicy5.setHeightForWidth(self.widget_21.sizePolicy().hasHeightForWidth())
        self.widget_21.setSizePolicy(sizePolicy5)
        self.widget_21.setSizeIncrement(QSize(0, 0))
        self.widget_21.setBaseSize(QSize(0, 0))
        self.gridLayout_29 = QGridLayout(self.widget_21)
        self.gridLayout_29.setObjectName(u"gridLayout_29")
        self.gridLayout_29.setHorizontalSpacing(18)
        self.gridLayout_29.setVerticalSpacing(9)
        self.gridLayout_29.setContentsMargins(-1, 0, -1, 0)
        self.spn_overburn_percent_2 = PlasmaHalDoubleSpinBox(self.widget_21)
        self.spn_overburn_percent_2.setObjectName(u"spn_overburn_percent_2")
        self.spn_overburn_percent_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_overburn_percent_2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_overburn_percent_2.setDecimals(1)
        self.spn_overburn_percent_2.setMaximum(200.000000000000000)

        self.gridLayout_29.addWidget(self.spn_overburn_percent_2, 5, 1, 1, 1)

        self.label_85 = QLabel(self.widget_21)
        self.label_85.setObjectName(u"label_85")
        self.label_85.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_29.addWidget(self.label_85, 0, 2, 1, 1)

        self.label_200 = QLabel(self.widget_21)
        self.label_200.setObjectName(u"label_200")

        self.gridLayout_29.addWidget(self.label_200, 4, 0, 1, 1)

        self.spn_arc3_percent_3 = PlasmaHalDoubleSpinBox(self.widget_21)
        self.spn_arc3_percent_3.setObjectName(u"spn_arc3_percent_3")
        self.spn_arc3_percent_3.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_arc3_percent_3.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_arc3_percent_3.setDecimals(1)

        self.gridLayout_29.addWidget(self.spn_arc3_percent_3, 4, 1, 1, 1)

        self.spn_leadin_percent_2 = PlasmaHalDoubleSpinBox(self.widget_21)
        self.spn_leadin_percent_2.setObjectName(u"spn_leadin_percent_2")
        self.spn_leadin_percent_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_leadin_percent_2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_leadin_percent_2.setDecimals(1)

        self.gridLayout_29.addWidget(self.spn_leadin_percent_2, 1, 1, 1, 1)

        self.spn_overburn_distance_2 = PlasmaHalDoubleSpinBox(self.widget_21)
        self.spn_overburn_distance_2.setObjectName(u"spn_overburn_distance_2")
        self.spn_overburn_distance_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_overburn_distance_2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_overburn_distance_2.setDecimals(4)
        self.spn_overburn_distance_2.setMinimum(-100.000000000000000)
        self.spn_overburn_distance_2.setMaximum(10.000000000000000)

        self.gridLayout_29.addWidget(self.spn_overburn_distance_2, 5, 2, 1, 1)

        self.label_80 = QLabel(self.widget_21)
        self.label_80.setObjectName(u"label_80")

        self.gridLayout_29.addWidget(self.label_80, 2, 0, 1, 1)

        self.spn_arc2_percent_2 = PlasmaHalDoubleSpinBox(self.widget_21)
        self.spn_arc2_percent_2.setObjectName(u"spn_arc2_percent_2")
        self.spn_arc2_percent_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_arc2_percent_2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_arc2_percent_2.setDecimals(1)

        self.gridLayout_29.addWidget(self.spn_arc2_percent_2, 3, 1, 1, 1)

        self.label_84 = QLabel(self.widget_21)
        self.label_84.setObjectName(u"label_84")

        self.gridLayout_29.addWidget(self.label_84, 3, 0, 1, 1)

        self.label_83 = QLabel(self.widget_21)
        self.label_83.setObjectName(u"label_83")
        self.label_83.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_29.addWidget(self.label_83, 0, 1, 1, 1)

        self.spn_arc1_percent_2 = PlasmaHalDoubleSpinBox(self.widget_21)
        self.spn_arc1_percent_2.setObjectName(u"spn_arc1_percent_2")
        self.spn_arc1_percent_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spn_arc1_percent_2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spn_arc1_percent_2.setDecimals(1)

        self.gridLayout_29.addWidget(self.spn_arc1_percent_2, 2, 1, 1, 1)

        self.label_82 = QLabel(self.widget_21)
        self.label_82.setObjectName(u"label_82")

        self.gridLayout_29.addWidget(self.label_82, 1, 0, 1, 1)

        self.label_81 = QLabel(self.widget_21)
        self.label_81.setObjectName(u"label_81")

        self.gridLayout_29.addWidget(self.label_81, 5, 0, 1, 1)


        self.verticalLayout_19.addWidget(self.widget_21)

        self.widget_23 = QWidget(self.tab_holes)
        self.widget_23.setObjectName(u"widget_23")
        self.horizontalLayout_7 = QHBoxLayout(self.widget_23)
        self.horizontalLayout_7.setSpacing(0)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_7.addItem(self.horizontalSpacer_7)

        self.label_76 = QLabel(self.widget_23)
        self.label_76.setObjectName(u"label_76")
        sizePolicy7.setHeightForWidth(self.label_76.sizePolicy().hasHeightForWidth())
        self.label_76.setSizePolicy(sizePolicy7)
        self.label_76.setMinimumSize(QSize(250, 289))
        self.label_76.setMaximumSize(QSize(250, 289))
        self.label_76.setPixmap(QPixmap(u":/image/icons/hole-ui-graphic_v3.png"))
        self.label_76.setScaledContents(True)
        self.label_76.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_7.addWidget(self.label_76)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_7.addItem(self.horizontalSpacer_8)

        self.widget_24 = QWidget(self.widget_23)
        self.widget_24.setObjectName(u"widget_24")
        sizePolicy13.setHeightForWidth(self.widget_24.sizePolicy().hasHeightForWidth())
        self.widget_24.setSizePolicy(sizePolicy13)
        self.widget_24.setMinimumSize(QSize(50, 0))
        self.verticalLayout_23 = QVBoxLayout(self.widget_24)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.label_71 = QLabel(self.widget_24)
        self.label_71.setObjectName(u"label_71")
        self.label_71.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.label_71.setWordWrap(True)

        self.verticalLayout_23.addWidget(self.label_71)

        self.label_74 = QLabel(self.widget_24)
        self.label_74.setObjectName(u"label_74")
        self.label_74.setWordWrap(True)

        self.verticalLayout_23.addWidget(self.label_74)


        self.horizontalLayout_7.addWidget(self.widget_24)


        self.verticalLayout_19.addWidget(self.widget_23)

        self.tab_holes_and_slots.addTab(self.tab_holes, "")
        self.tab_slots = QWidget()
        self.tab_slots.setObjectName(u"tab_slots")
        self.verticalLayout_22 = QVBoxLayout(self.tab_slots)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.verticalLayout_22.setContentsMargins(-1, 20, -1, -1)
        self.groupbox_19 = MkGroupBox(self.tab_slots)
        self.groupbox_19.setObjectName(u"groupbox_19")
        self.gridLayout_27 = QGridLayout(self.groupbox_19)
        self.gridLayout_27.setObjectName(u"gridLayout_27")
        self.verticalSpacer_7 = QSpacerItem(20, 411, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_27.addItem(self.verticalSpacer_7, 1, 1, 1, 1)

        self.chkb_slot_detect_enable = QCheckBox(self.groupbox_19)
        self.chkb_slot_detect_enable.setObjectName(u"chkb_slot_detect_enable")
        self.chkb_slot_detect_enable.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_27.addWidget(self.chkb_slot_detect_enable, 0, 0, 1, 1)


        self.verticalLayout_22.addWidget(self.groupbox_19)

        self.tab_holes_and_slots.addTab(self.tab_slots, "")
        self.tab_hole_insructions = QWidget()
        self.tab_hole_insructions.setObjectName(u"tab_hole_insructions")
        self.label_196 = QLabel(self.tab_hole_insructions)
        self.label_196.setObjectName(u"label_196")
        self.label_196.setGeometry(QRect(30, 40, 671, 701))
        self.label_196.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.label_196.setWordWrap(True)
        self.tab_holes_and_slots.addTab(self.tab_hole_insructions, "")

        self.verticalLayout_10.addWidget(self.tab_holes_and_slots)


        self.horizontalLayout_8.addWidget(self.widget_18)

        self.verticalLayout_13 = QVBoxLayout()
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(-1, 4, -1, -1)
        self.groupbox_14 = MkGroupBox(self.tab_8)
        self.groupbox_14.setObjectName(u"groupbox_14")
        sizePolicy5.setHeightForWidth(self.groupbox_14.sizePolicy().hasHeightForWidth())
        self.groupbox_14.setSizePolicy(sizePolicy5)
        self.verticalLayout_6 = QVBoxLayout(self.groupbox_14)
        self.verticalLayout_6.setSpacing(12)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.thc_enabled = PlasmaHalCheckBox(self.groupbox_14)
        self.thc_enabled.setObjectName(u"thc_enabled")
        self.thc_enabled.setStyleSheet(u"font: bold 12pt;")

        self.verticalLayout_6.addWidget(self.thc_enabled)

        self.chkb_auto_volts = PlasmaHalCheckBox(self.groupbox_14)
        self.chkb_auto_volts.setObjectName(u"chkb_auto_volts")
        self.chkb_auto_volts.setStyleSheet(u"font: bold 12pt;")

        self.verticalLayout_6.addWidget(self.chkb_auto_volts)

        self.chkb_vad = PlasmaHalCheckBox(self.groupbox_14)
        self.chkb_vad.setObjectName(u"chkb_vad")
        self.chkb_vad.setStyleSheet(u"font: bold 12pt;")

        self.verticalLayout_6.addWidget(self.chkb_vad)

        self.chkb_void_sense = PlasmaHalCheckBox(self.groupbox_14)
        self.chkb_void_sense.setObjectName(u"chkb_void_sense")
        self.chkb_void_sense.setStyleSheet(u"font: bold 12pt;")

        self.verticalLayout_6.addWidget(self.chkb_void_sense)

        self.chkb_mesh_sense = PlasmaHalCheckBox(self.groupbox_14)
        self.chkb_mesh_sense.setObjectName(u"chkb_mesh_sense")
        self.chkb_mesh_sense.setStyleSheet(u"font: bold 12pt;")

        self.verticalLayout_6.addWidget(self.chkb_mesh_sense)

        self.chkb_ohmic_sense = PlasmaHalCheckBox(self.groupbox_14)
        self.chkb_ohmic_sense.setObjectName(u"chkb_ohmic_sense")
        self.chkb_ohmic_sense.setStyleSheet(u"font: bold 12pt;")

        self.verticalLayout_6.addWidget(self.chkb_ohmic_sense)


        self.verticalLayout_13.addWidget(self.groupbox_14)

        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_13.addItem(self.verticalSpacer_6)


        self.horizontalLayout_8.addLayout(self.verticalLayout_13)

        self.tabWidget.addTab(self.tab_8, "")
        self.tab_10 = QWidget()
        self.tab_10.setObjectName(u"tab_10")
        self.tabWidget.addTab(self.tab_10, "")
        self.tab_12 = QWidget()
        self.tab_12.setObjectName(u"tab_12")
        self.groupbox_10 = MkGroupBox(self.tab_12)
        self.groupbox_10.setObjectName(u"groupbox_10")
        self.groupbox_10.setGeometry(QRect(20, 20, 711, 751))
        self.gridLayout_6 = QGridLayout(self.groupbox_10)
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.label_58 = QLabel(self.groupbox_10)
        self.label_58.setObjectName(u"label_58")

        self.gridLayout_6.addWidget(self.label_58, 6, 1, 1, 1)

        self.label_50 = QLabel(self.groupbox_10)
        self.label_50.setObjectName(u"label_50")

        self.gridLayout_6.addWidget(self.label_50, 0, 2, 1, 1)

        self.label_56 = QLabel(self.groupbox_10)
        self.label_56.setObjectName(u"label_56")

        self.gridLayout_6.addWidget(self.label_56, 4, 1, 1, 1)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_2, 8, 0, 1, 1)

        self.label_52 = QLabel(self.groupbox_10)
        self.label_52.setObjectName(u"label_52")

        self.gridLayout_6.addWidget(self.label_52, 0, 4, 1, 1)

        self.label_57 = QLabel(self.groupbox_10)
        self.label_57.setObjectName(u"label_57")

        self.gridLayout_6.addWidget(self.label_57, 5, 1, 1, 1)

        self.label_54 = QLabel(self.groupbox_10)
        self.label_54.setObjectName(u"label_54")

        self.gridLayout_6.addWidget(self.label_54, 2, 1, 1, 1)

        self.label_53 = QLabel(self.groupbox_10)
        self.label_53.setObjectName(u"label_53")

        self.gridLayout_6.addWidget(self.label_53, 1, 1, 1, 1)

        self.label_51 = QLabel(self.groupbox_10)
        self.label_51.setObjectName(u"label_51")

        self.gridLayout_6.addWidget(self.label_51, 0, 1, 1, 1)

        self.label_55 = QLabel(self.groupbox_10)
        self.label_55.setObjectName(u"label_55")

        self.gridLayout_6.addWidget(self.label_55, 3, 1, 1, 1)

        self.label_59 = QLabel(self.groupbox_10)
        self.label_59.setObjectName(u"label_59")

        self.gridLayout_6.addWidget(self.label_59, 7, 1, 1, 1)

        self.pushButton_11 = QPushButton(self.groupbox_10)
        self.pushButton_11.setObjectName(u"pushButton_11")
        sizePolicy5.setHeightForWidth(self.pushButton_11.sizePolicy().hasHeightForWidth())
        self.pushButton_11.setSizePolicy(sizePolicy5)
        self.pushButton_11.setMinimumSize(QSize(34, 44))
        self.pushButton_11.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_6.addWidget(self.pushButton_11, 1, 0, 1, 1)

        self.hallabel_2 = HalLabel(self.groupbox_10)
        self.hallabel_2.setObjectName(u"hallabel_2")

        self.gridLayout_6.addWidget(self.hallabel_2, 2, 2, 1, 1)

        self.hallabel_3 = HalLabel(self.groupbox_10)
        self.hallabel_3.setObjectName(u"hallabel_3")

        self.gridLayout_6.addWidget(self.hallabel_3, 3, 2, 1, 1)

        self.tabWidget.addTab(self.tab_12, "")

        self.horizontalLayout_2.addWidget(self.tabWidget)

        self.mainTabWidget.addTab(self.tab_parameters, "")
        self.tab_conversational = QWidget()
        self.tab_conversational.setObjectName(u"tab_conversational")
        self.tab_conversational.setEnabled(True)
        self.frame = QFrame(self.tab_conversational)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(10, 0, 291, 985))
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_36 = QGridLayout(self.frame)
        self.gridLayout_36.setObjectName(u"gridLayout_36")
        self.btn_7 = QPushButton(self.frame)
        self.grp_shape_btns = QButtonGroup(Form)
        self.grp_shape_btns.setObjectName(u"grp_shape_btns")
        self.grp_shape_btns.addButton(self.btn_7)
        self.btn_7.setObjectName(u"btn_7")
        icon18 = QIcon()
        icon18.addFile(u":/image/icons/pipesaddle.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_7.setIcon(icon18)
        self.btn_7.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_7, 3, 1, 1, 1)

        self.btn_13 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_13)
        self.btn_13.setObjectName(u"btn_13")
        icon19 = QIcon()
        icon19.addFile(u":/image/icons/webstiffener.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_13.setIcon(icon19)
        self.btn_13.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_13, 6, 1, 1, 1)

        self.btn_12 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_12)
        self.btn_12.setObjectName(u"btn_12")
        icon20 = QIcon()
        icon20.addFile(u":/image/icons/truss_support.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_12.setIcon(icon20)
        self.btn_12.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_12, 6, 0, 1, 1)

        self.btn_2 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_2)
        self.btn_2.setObjectName(u"btn_2")
        icon21 = QIcon()
        icon21.addFile(u":/image/icons/donut.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_2.setIcon(icon21)
        self.btn_2.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_2, 1, 0, 1, 1)

        self.btn_6 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_6)
        self.btn_6.setObjectName(u"btn_6")
        icon22 = QIcon()
        icon22.addFile(u":/image/icons/pipeflange.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_6.setIcon(icon22)
        self.btn_6.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_6, 3, 0, 1, 1)

        self.btn_9 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_9)
        self.btn_9.setObjectName(u"btn_9")
        icon23 = QIcon()
        icon23.addFile(u":/image/icons/n_holerectangle.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_9.setIcon(icon23)
        self.btn_9.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_9, 4, 1, 1, 1)

        self.btn_4 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_4)
        self.btn_4.setObjectName(u"btn_4")
        icon24 = QIcon()
        icon24.addFile(u":/image/icons/liftlug.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_4.setIcon(icon24)
        self.btn_4.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_4, 2, 0, 1, 1)

        self.btn_5 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_5)
        self.btn_5.setObjectName(u"btn_5")
        icon25 = QIcon()
        icon25.addFile(u":/image/icons/ulug.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_5.setIcon(icon25)
        self.btn_5.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_5, 2, 1, 1, 1)

        self.btn_3 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_3)
        self.btn_3.setObjectName(u"btn_3")
        icon26 = QIcon()
        icon26.addFile(u":/image/icons/convexrect.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_3.setIcon(icon26)
        self.btn_3.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_3, 1, 1, 1, 1)

        self.btn_11 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_11)
        self.btn_11.setObjectName(u"btn_11")
        icon27 = QIcon()
        icon27.addFile(u":/image/icons/anglegusset.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_11.setIcon(icon27)
        self.btn_11.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_11, 5, 1, 1, 1)

        self.btn_8 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_8)
        self.btn_8.setObjectName(u"btn_8")
        icon28 = QIcon()
        icon28.addFile(u":/image/icons/exhaust.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_8.setIcon(icon28)
        self.btn_8.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_8, 4, 0, 1, 1)

        self.btn_1 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_1)
        self.btn_1.setObjectName(u"btn_1")
        icon29 = QIcon()
        icon29.addFile(u":/image/icons/rectangle.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_1.setIcon(icon29)
        self.btn_1.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_1, 0, 1, 1, 1)

        self.btn_0 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_0)
        self.btn_0.setObjectName(u"btn_0")
        icon30 = QIcon()
        icon30.addFile(u":/image/icons/circle.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_0.setIcon(icon30)
        self.btn_0.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_0, 0, 0, 1, 1)

        self.btn_10 = QPushButton(self.frame)
        self.grp_shape_btns.addButton(self.btn_10)
        self.btn_10.setObjectName(u"btn_10")
        icon31 = QIcon()
        icon31.addFile(u":/image/icons/Lgusset.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_10.setIcon(icon31)
        self.btn_10.setIconSize(QSize(100, 100))

        self.gridLayout_36.addWidget(self.btn_10, 5, 0, 1, 1)

        self.verticalSpacer_14 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_36.addItem(self.verticalSpacer_14, 7, 0, 1, 1)

        self.frame_2 = QFrame(self.tab_conversational)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setGeometry(QRect(310, 0, 1580, 985))
        self.frame_2.setMinimumSize(QSize(1580, 985))
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.details_pages = QStackedWidget(self.frame_2)
        self.details_pages.setObjectName(u"details_pages")
        self.details_pages.setGeometry(QRect(10, 10, 620, 880))
        self.details_pages.setMinimumSize(QSize(620, 0))
        self.details_pages.setFrameShape(QFrame.Shape.NoFrame)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.widget_35 = QWidget(self.page_4)
        self.widget_35.setObjectName(u"widget_35")
        self.widget_35.setGeometry(QRect(10, 30, 331, 71))
        self.gridLayout_37 = QGridLayout(self.widget_35)
        self.gridLayout_37.setObjectName(u"gridLayout_37")
        self.label_49 = QLabel(self.widget_35)
        self.label_49.setObjectName(u"label_49")

        self.gridLayout_37.addWidget(self.label_49, 0, 0, 1, 1)

        self.id0_dbl_diam = QDoubleSpinBox(self.widget_35)
        self.id0_dbl_diam.setObjectName(u"id0_dbl_diam")
        self.id0_dbl_diam.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id0_dbl_diam.setDecimals(4)
        self.id0_dbl_diam.setMaximum(10000.000000000000000)
        self.id0_dbl_diam.setValue(100.000000000000000)

        self.gridLayout_37.addWidget(self.id0_dbl_diam, 0, 1, 1, 1)

        self.label_179 = QLabel(self.page_4)
        self.label_179.setObjectName(u"label_179")
        self.label_179.setGeometry(QRect(190, 120, 421, 411))
        self.label_179.setAutoFillBackground(False)
        self.label_179.setPixmap(QPixmap(u":/image/icons/circle_dimensions.png"))
        self.label_179.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_4)
        self.page_5 = QWidget()
        self.page_5.setObjectName(u"page_5")
        self.widget_36 = QWidget(self.page_5)
        self.widget_36.setObjectName(u"widget_36")
        self.widget_36.setGeometry(QRect(10, 30, 281, 81))
        self.gridLayout_38 = QGridLayout(self.widget_36)
        self.gridLayout_38.setObjectName(u"gridLayout_38")
        self.label_75 = QLabel(self.widget_36)
        self.label_75.setObjectName(u"label_75")

        self.gridLayout_38.addWidget(self.label_75, 0, 0, 1, 1)

        self.id1_dbl_width = QDoubleSpinBox(self.widget_36)
        self.id1_dbl_width.setObjectName(u"id1_dbl_width")
        self.id1_dbl_width.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id1_dbl_width.setDecimals(4)
        self.id1_dbl_width.setMaximum(10000.000000000000000)
        self.id1_dbl_width.setValue(50.000000000000000)

        self.gridLayout_38.addWidget(self.id1_dbl_width, 0, 1, 1, 1)

        self.label_77 = QLabel(self.widget_36)
        self.label_77.setObjectName(u"label_77")

        self.gridLayout_38.addWidget(self.label_77, 1, 0, 1, 1)

        self.id1_dbl_height = QDoubleSpinBox(self.widget_36)
        self.id1_dbl_height.setObjectName(u"id1_dbl_height")
        self.id1_dbl_height.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id1_dbl_height.setDecimals(4)
        self.id1_dbl_height.setMaximum(10000.000000000000000)
        self.id1_dbl_height.setValue(100.000000000000000)

        self.gridLayout_38.addWidget(self.id1_dbl_height, 1, 1, 1, 1)

        self.label_180 = QLabel(self.page_5)
        self.label_180.setObjectName(u"label_180")
        self.label_180.setGeometry(QRect(230, 130, 371, 521))
        self.label_180.setPixmap(QPixmap(u":/image/icons/rectangle_dimensions.png"))
        self.label_180.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_5)
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.widget_37 = QWidget(self.page)
        self.widget_37.setObjectName(u"widget_37")
        self.widget_37.setGeometry(QRect(0, 20, 391, 81))
        self.gridLayout_39 = QGridLayout(self.widget_37)
        self.gridLayout_39.setObjectName(u"gridLayout_39")
        self.label_115 = QLabel(self.widget_37)
        self.label_115.setObjectName(u"label_115")

        self.gridLayout_39.addWidget(self.label_115, 0, 0, 1, 1)

        self.id2_dbl_outer_diam = QDoubleSpinBox(self.widget_37)
        self.id2_dbl_outer_diam.setObjectName(u"id2_dbl_outer_diam")
        self.id2_dbl_outer_diam.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id2_dbl_outer_diam.setDecimals(4)
        self.id2_dbl_outer_diam.setMaximum(10000.000000000000000)
        self.id2_dbl_outer_diam.setValue(150.000000000000000)

        self.gridLayout_39.addWidget(self.id2_dbl_outer_diam, 0, 1, 1, 1)

        self.label_116 = QLabel(self.widget_37)
        self.label_116.setObjectName(u"label_116")

        self.gridLayout_39.addWidget(self.label_116, 1, 0, 1, 1)

        self.id2_dbl_inner_diam = QDoubleSpinBox(self.widget_37)
        self.id2_dbl_inner_diam.setObjectName(u"id2_dbl_inner_diam")
        self.id2_dbl_inner_diam.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id2_dbl_inner_diam.setDecimals(4)
        self.id2_dbl_inner_diam.setMaximum(10000.000000000000000)
        self.id2_dbl_inner_diam.setValue(100.000000000000000)

        self.gridLayout_39.addWidget(self.id2_dbl_inner_diam, 1, 1, 1, 1)

        self.label_181 = QLabel(self.page)
        self.label_181.setObjectName(u"label_181")
        self.label_181.setGeometry(QRect(160, 150, 441, 421))
        self.label_181.setPixmap(QPixmap(u":/image/icons/donut_dimensions.png"))
        self.label_181.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page)
        self.page_6 = QWidget()
        self.page_6.setObjectName(u"page_6")
        self.widget_38 = QWidget(self.page_6)
        self.widget_38.setObjectName(u"widget_38")
        self.widget_38.setGeometry(QRect(0, 20, 301, 81))
        self.gridLayout_40 = QGridLayout(self.widget_38)
        self.gridLayout_40.setObjectName(u"gridLayout_40")
        self.label_117 = QLabel(self.widget_38)
        self.label_117.setObjectName(u"label_117")

        self.gridLayout_40.addWidget(self.label_117, 0, 0, 1, 1)

        self.id3_dbl_width = QDoubleSpinBox(self.widget_38)
        self.id3_dbl_width.setObjectName(u"id3_dbl_width")
        self.id3_dbl_width.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id3_dbl_width.setDecimals(4)
        self.id3_dbl_width.setMaximum(10000.000000000000000)
        self.id3_dbl_width.setValue(50.000000000000000)

        self.gridLayout_40.addWidget(self.id3_dbl_width, 0, 1, 1, 1)

        self.label_118 = QLabel(self.widget_38)
        self.label_118.setObjectName(u"label_118")

        self.gridLayout_40.addWidget(self.label_118, 1, 0, 1, 1)

        self.id3_dbl_height = QDoubleSpinBox(self.widget_38)
        self.id3_dbl_height.setObjectName(u"id3_dbl_height")
        self.id3_dbl_height.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id3_dbl_height.setDecimals(4)
        self.id3_dbl_height.setMaximum(10000.000000000000000)
        self.id3_dbl_height.setValue(125.000000000000000)

        self.gridLayout_40.addWidget(self.id3_dbl_height, 1, 1, 1, 1)

        self.label_182 = QLabel(self.page_6)
        self.label_182.setObjectName(u"label_182")
        self.label_182.setGeometry(QRect(200, 110, 401, 511))
        self.label_182.setPixmap(QPixmap(u":/image/icons/convexrect_dimensions.png"))
        self.label_182.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_6)
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.label_119 = QLabel(self.page_3)
        self.label_119.setObjectName(u"label_119")
        self.label_119.setGeometry(QRect(320, 320, 261, 20))
        self.id4_error_text = QLabel(self.page_3)
        self.id4_error_text.setObjectName(u"id4_error_text")
        self.id4_error_text.setGeometry(QRect(0, 570, 191, 91))
        self.id4_error_text.setWordWrap(True)
        self.label_120 = QLabel(self.page_3)
        self.label_120.setObjectName(u"label_120")
        self.label_120.setGeometry(QRect(0, 370, 191, 191))
        self.label_120.setWordWrap(True)
        self.widget_39 = QWidget(self.page_3)
        self.widget_39.setObjectName(u"widget_39")
        self.widget_39.setGeometry(QRect(0, 0, 311, 361))
        self.gridLayout_41 = QGridLayout(self.widget_39)
        self.gridLayout_41.setObjectName(u"gridLayout_41")
        self.id4_dbl_h1 = QDoubleSpinBox(self.widget_39)
        self.id4_dbl_h1.setObjectName(u"id4_dbl_h1")
        self.id4_dbl_h1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id4_dbl_h1.setDecimals(4)
        self.id4_dbl_h1.setMaximum(10000.000000000000000)
        self.id4_dbl_h1.setValue(150.000000000000000)

        self.gridLayout_41.addWidget(self.id4_dbl_h1, 1, 1, 1, 1)

        self.id4_dbl_d2 = QDoubleSpinBox(self.widget_39)
        self.id4_dbl_d2.setObjectName(u"id4_dbl_d2")
        self.id4_dbl_d2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id4_dbl_d2.setDecimals(4)
        self.id4_dbl_d2.setMaximum(10000.000000000000000)
        self.id4_dbl_d2.setValue(57.000000000000000)

        self.gridLayout_41.addWidget(self.id4_dbl_d2, 6, 1, 1, 1)

        self.label_121 = QLabel(self.widget_39)
        self.label_121.setObjectName(u"label_121")

        self.gridLayout_41.addWidget(self.label_121, 2, 0, 1, 1)

        self.id4_dbl_rb = QDoubleSpinBox(self.widget_39)
        self.id4_dbl_rb.setObjectName(u"id4_dbl_rb")
        self.id4_dbl_rb.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id4_dbl_rb.setDecimals(4)
        self.id4_dbl_rb.setMinimum(0.000000000000000)
        self.id4_dbl_rb.setMaximum(10000.000000000000000)

        self.gridLayout_41.addWidget(self.id4_dbl_rb, 7, 1, 1, 1)

        self.label_122 = QLabel(self.widget_39)
        self.label_122.setObjectName(u"label_122")

        self.gridLayout_41.addWidget(self.label_122, 9, 0, 1, 1)

        self.id4_dbl_separation = QDoubleSpinBox(self.widget_39)
        self.id4_dbl_separation.setObjectName(u"id4_dbl_separation")
        self.id4_dbl_separation.setEnabled(False)
        self.id4_dbl_separation.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.UpDownArrows)
        self.id4_dbl_separation.setDecimals(4)
        self.id4_dbl_separation.setMinimum(-10000.000000000000000)
        self.id4_dbl_separation.setMaximum(10000.000000000000000)

        self.gridLayout_41.addWidget(self.id4_dbl_separation, 9, 1, 1, 1)

        self.label_123 = QLabel(self.widget_39)
        self.label_123.setObjectName(u"label_123")

        self.gridLayout_41.addWidget(self.label_123, 6, 0, 1, 1)

        self.id4_dbl_w1 = QDoubleSpinBox(self.widget_39)
        self.id4_dbl_w1.setObjectName(u"id4_dbl_w1")
        self.id4_dbl_w1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id4_dbl_w1.setDecimals(4)
        self.id4_dbl_w1.setMaximum(10000.000000000000000)
        self.id4_dbl_w1.setValue(150.000000000000000)

        self.gridLayout_41.addWidget(self.id4_dbl_w1, 0, 1, 1, 1)

        self.label_124 = QLabel(self.widget_39)
        self.label_124.setObjectName(u"label_124")

        self.gridLayout_41.addWidget(self.label_124, 7, 0, 1, 1)

        self.id4_chk_pair = QCheckBox(self.widget_39)
        self.id4_chk_pair.setObjectName(u"id4_chk_pair")
        self.id4_chk_pair.setLayoutDirection(Qt.LayoutDirection.LeftToRight)

        self.gridLayout_41.addWidget(self.id4_chk_pair, 8, 0, 1, 2)

        self.label_125 = QLabel(self.widget_39)
        self.label_125.setObjectName(u"label_125")

        self.gridLayout_41.addWidget(self.label_125, 0, 0, 1, 1)

        self.label_126 = QLabel(self.widget_39)
        self.label_126.setObjectName(u"label_126")

        self.gridLayout_41.addWidget(self.label_126, 1, 0, 1, 1)

        self.id4_dbl_h2 = QDoubleSpinBox(self.widget_39)
        self.id4_dbl_h2.setObjectName(u"id4_dbl_h2")
        self.id4_dbl_h2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id4_dbl_h2.setDecimals(4)
        self.id4_dbl_h2.setMaximum(10000.000000000000000)
        self.id4_dbl_h2.setValue(12.000000000000000)

        self.gridLayout_41.addWidget(self.id4_dbl_h2, 2, 1, 1, 1)

        self.id4_dbl_d1 = QDoubleSpinBox(self.widget_39)
        self.id4_dbl_d1.setObjectName(u"id4_dbl_d1")
        self.id4_dbl_d1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id4_dbl_d1.setDecimals(4)
        self.id4_dbl_d1.setMaximum(10000.000000000000000)
        self.id4_dbl_d1.setValue(100.000000000000000)

        self.gridLayout_41.addWidget(self.id4_dbl_d1, 3, 1, 1, 1)

        self.label_127 = QLabel(self.widget_39)
        self.label_127.setObjectName(u"label_127")

        self.gridLayout_41.addWidget(self.label_127, 3, 0, 1, 1)

        self.label_183 = QLabel(self.page_3)
        self.label_183.setObjectName(u"label_183")
        self.label_183.setGeometry(QRect(60, 320, 550, 550))
        self.label_183.setPixmap(QPixmap(u":/image/icons/liftlug_dimensions.png"))
        self.label_183.setScaledContents(True)
        self.label_183.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_3)
        self.label_183.raise_()
        self.label_119.raise_()
        self.widget_39.raise_()
        self.id4_error_text.raise_()
        self.label_120.raise_()
        self.page_7 = QWidget()
        self.page_7.setObjectName(u"page_7")
        self.widget_40 = QWidget(self.page_7)
        self.widget_40.setObjectName(u"widget_40")
        self.widget_40.setGeometry(QRect(0, 0, 261, 164))
        self.gridLayout_42 = QGridLayout(self.widget_40)
        self.gridLayout_42.setObjectName(u"gridLayout_42")
        self.label_128 = QLabel(self.widget_40)
        self.label_128.setObjectName(u"label_128")

        self.gridLayout_42.addWidget(self.label_128, 0, 0, 1, 1)

        self.id5_dbl_w1 = QDoubleSpinBox(self.widget_40)
        self.id5_dbl_w1.setObjectName(u"id5_dbl_w1")
        self.id5_dbl_w1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id5_dbl_w1.setDecimals(4)
        self.id5_dbl_w1.setMaximum(10000.000000000000000)
        self.id5_dbl_w1.setValue(100.000000000000000)

        self.gridLayout_42.addWidget(self.id5_dbl_w1, 0, 1, 1, 1)

        self.label_129 = QLabel(self.widget_40)
        self.label_129.setObjectName(u"label_129")

        self.gridLayout_42.addWidget(self.label_129, 1, 0, 1, 1)

        self.id5_dbl_w2 = QDoubleSpinBox(self.widget_40)
        self.id5_dbl_w2.setObjectName(u"id5_dbl_w2")
        self.id5_dbl_w2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id5_dbl_w2.setDecimals(4)
        self.id5_dbl_w2.setMaximum(10000.000000000000000)
        self.id5_dbl_w2.setValue(25.000000000000000)

        self.gridLayout_42.addWidget(self.id5_dbl_w2, 1, 1, 1, 1)

        self.label_130 = QLabel(self.widget_40)
        self.label_130.setObjectName(u"label_130")

        self.gridLayout_42.addWidget(self.label_130, 2, 0, 1, 1)

        self.id5_dbl_h = QDoubleSpinBox(self.widget_40)
        self.id5_dbl_h.setObjectName(u"id5_dbl_h")
        self.id5_dbl_h.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id5_dbl_h.setDecimals(4)
        self.id5_dbl_h.setMaximum(10000.000000000000000)
        self.id5_dbl_h.setValue(150.000000000000000)

        self.gridLayout_42.addWidget(self.id5_dbl_h, 2, 1, 1, 1)

        self.verticalSpacer_15 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_42.addItem(self.verticalSpacer_15, 3, 0, 1, 1)

        self.label_184 = QLabel(self.page_7)
        self.label_184.setObjectName(u"label_184")
        self.label_184.setGeometry(QRect(210, 160, 401, 481))
        self.label_184.setPixmap(QPixmap(u":/image/icons/ulug_dimensions.png"))
        self.label_184.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_7)
        self.page_8 = QWidget()
        self.page_8.setObjectName(u"page_8")
        self.widget_41 = QWidget(self.page_8)
        self.widget_41.setObjectName(u"widget_41")
        self.widget_41.setGeometry(QRect(0, 10, 291, 311))
        self.gridLayout_43 = QGridLayout(self.widget_41)
        self.gridLayout_43.setObjectName(u"gridLayout_43")
        self.id6_dbl_pcd = QDoubleSpinBox(self.widget_41)
        self.id6_dbl_pcd.setObjectName(u"id6_dbl_pcd")
        self.id6_dbl_pcd.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id6_dbl_pcd.setDecimals(4)
        self.id6_dbl_pcd.setMaximum(10000.000000000000000)
        self.id6_dbl_pcd.setValue(76.000000000000000)

        self.gridLayout_43.addWidget(self.id6_dbl_pcd, 1, 2, 1, 1)

        self.label_136 = QLabel(self.widget_41)
        self.label_136.setObjectName(u"label_136")

        self.gridLayout_43.addWidget(self.label_136, 6, 0, 1, 1)

        self.label_132 = QLabel(self.widget_41)
        self.label_132.setObjectName(u"label_132")

        self.gridLayout_43.addWidget(self.label_132, 1, 0, 1, 1)

        self.label_131 = QLabel(self.widget_41)
        self.label_131.setObjectName(u"label_131")

        self.gridLayout_43.addWidget(self.label_131, 0, 0, 1, 1)

        self.id6_combo_hole = QComboBox(self.widget_41)
        self.id6_combo_hole.addItem("")
        self.id6_combo_hole.addItem("")
        self.id6_combo_hole.addItem("")
        self.id6_combo_hole.setObjectName(u"id6_combo_hole")
        font3 = QFont()
        font3.setFamilies([u"Sans"])
        font3.setPointSize(16)
        font3.setBold(True)
        font3.setItalic(False)
        self.id6_combo_hole.setFont(font3)

        self.gridLayout_43.addWidget(self.id6_combo_hole, 4, 2, 1, 1)

        self.id6_dbl_od = QDoubleSpinBox(self.widget_41)
        self.id6_dbl_od.setObjectName(u"id6_dbl_od")
        self.id6_dbl_od.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id6_dbl_od.setDecimals(4)
        self.id6_dbl_od.setMaximum(10000.000000000000000)
        self.id6_dbl_od.setValue(100.000000000000000)

        self.gridLayout_43.addWidget(self.id6_dbl_od, 0, 2, 1, 1)

        self.label_134 = QLabel(self.widget_41)
        self.label_134.setObjectName(u"label_134")

        self.gridLayout_43.addWidget(self.label_134, 3, 0, 1, 1)

        self.verticalSpacer_16 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_43.addItem(self.verticalSpacer_16, 7, 0, 1, 2)

        self.label_135 = QLabel(self.widget_41)
        self.label_135.setObjectName(u"label_135")

        self.gridLayout_43.addWidget(self.label_135, 4, 0, 1, 1)

        self.id6_int_holes = QSpinBox(self.widget_41)
        self.id6_int_holes.setObjectName(u"id6_int_holes")
        self.id6_int_holes.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id6_int_holes.setValue(4)

        self.gridLayout_43.addWidget(self.id6_int_holes, 2, 2, 1, 1)

        self.label_133 = QLabel(self.widget_41)
        self.label_133.setObjectName(u"label_133")

        self.gridLayout_43.addWidget(self.label_133, 2, 0, 1, 1)

        self.id6_dbl_hd = QDoubleSpinBox(self.widget_41)
        self.id6_dbl_hd.setObjectName(u"id6_dbl_hd")
        self.id6_dbl_hd.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id6_dbl_hd.setDecimals(4)
        self.id6_dbl_hd.setMaximum(10000.000000000000000)
        self.id6_dbl_hd.setValue(12.000000000000000)

        self.gridLayout_43.addWidget(self.id6_dbl_hd, 3, 2, 1, 1)

        self.id6_dbl_id = QDoubleSpinBox(self.widget_41)
        self.id6_dbl_id.setObjectName(u"id6_dbl_id")
        self.id6_dbl_id.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id6_dbl_id.setDecimals(4)
        self.id6_dbl_id.setMaximum(10000.000000000000000)
        self.id6_dbl_id.setValue(45.000000000000000)

        self.gridLayout_43.addWidget(self.id6_dbl_id, 6, 2, 1, 1)

        self.label_185 = QLabel(self.page_8)
        self.label_185.setObjectName(u"label_185")
        self.label_185.setGeometry(QRect(170, 330, 441, 511))
        self.label_185.setPixmap(QPixmap(u":/image/icons/pipeflange_dimensions.png"))
        self.label_185.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_8)
        self.page_9 = QWidget()
        self.page_9.setObjectName(u"page_9")
        self.widget_42 = QWidget(self.page_9)
        self.widget_42.setObjectName(u"widget_42")
        self.widget_42.setGeometry(QRect(0, 0, 241, 197))
        self.gridLayout_44 = QGridLayout(self.widget_42)
        self.gridLayout_44.setObjectName(u"gridLayout_44")
        self.label_137 = QLabel(self.widget_42)
        self.label_137.setObjectName(u"label_137")

        self.gridLayout_44.addWidget(self.label_137, 0, 0, 1, 1)

        self.id7_dbl_w = QDoubleSpinBox(self.widget_42)
        self.id7_dbl_w.setObjectName(u"id7_dbl_w")
        self.id7_dbl_w.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id7_dbl_w.setDecimals(4)
        self.id7_dbl_w.setMinimum(0.000000000000000)
        self.id7_dbl_w.setMaximum(10000.000000000000000)
        self.id7_dbl_w.setValue(100.000000000000000)

        self.gridLayout_44.addWidget(self.id7_dbl_w, 0, 1, 1, 1)

        self.label_138 = QLabel(self.widget_42)
        self.label_138.setObjectName(u"label_138")

        self.gridLayout_44.addWidget(self.label_138, 1, 0, 1, 1)

        self.id7_dbl_h = QDoubleSpinBox(self.widget_42)
        self.id7_dbl_h.setObjectName(u"id7_dbl_h")
        self.id7_dbl_h.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id7_dbl_h.setDecimals(4)
        self.id7_dbl_h.setMinimum(0.000000000000000)
        self.id7_dbl_h.setMaximum(10000.000000000000000)
        self.id7_dbl_h.setValue(150.000000000000000)

        self.gridLayout_44.addWidget(self.id7_dbl_h, 1, 1, 1, 1)

        self.label_139 = QLabel(self.widget_42)
        self.label_139.setObjectName(u"label_139")

        self.gridLayout_44.addWidget(self.label_139, 2, 0, 1, 1)

        self.id7_dbl_pd = QDoubleSpinBox(self.widget_42)
        self.id7_dbl_pd.setObjectName(u"id7_dbl_pd")
        self.id7_dbl_pd.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id7_dbl_pd.setDecimals(4)
        self.id7_dbl_pd.setMinimum(0.000000000000000)
        self.id7_dbl_pd.setMaximum(10000.000000000000000)
        self.id7_dbl_pd.setValue(51.000000000000000)

        self.gridLayout_44.addWidget(self.id7_dbl_pd, 2, 1, 1, 1)

        self.label_140 = QLabel(self.widget_42)
        self.label_140.setObjectName(u"label_140")

        self.gridLayout_44.addWidget(self.label_140, 3, 0, 1, 1)

        self.id7_dbl_o = QDoubleSpinBox(self.widget_42)
        self.id7_dbl_o.setObjectName(u"id7_dbl_o")
        self.id7_dbl_o.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id7_dbl_o.setDecimals(4)
        self.id7_dbl_o.setMaximum(10000.000000000000000)
        self.id7_dbl_o.setValue(0.000000000000000)

        self.gridLayout_44.addWidget(self.id7_dbl_o, 3, 1, 1, 1)

        self.verticalSpacer_17 = QSpacerItem(20, 48, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_44.addItem(self.verticalSpacer_17, 4, 0, 1, 1)

        self.label_186 = QLabel(self.page_9)
        self.label_186.setObjectName(u"label_186")
        self.label_186.setGeometry(QRect(220, 210, 391, 491))
        self.label_186.setPixmap(QPixmap(u":/image/icons/pipesaddle_dimensions.png"))
        self.label_186.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_9)
        self.page_10 = QWidget()
        self.page_10.setObjectName(u"page_10")
        self.widget_43 = QWidget(self.page_10)
        self.widget_43.setObjectName(u"widget_43")
        self.widget_43.setGeometry(QRect(0, 0, 351, 263))
        self.gridLayout_45 = QGridLayout(self.widget_43)
        self.gridLayout_45.setObjectName(u"gridLayout_45")
        self.label_143 = QLabel(self.widget_43)
        self.label_143.setObjectName(u"label_143")

        self.gridLayout_45.addWidget(self.label_143, 2, 0, 1, 1)

        self.label_146 = QLabel(self.widget_43)
        self.label_146.setObjectName(u"label_146")

        self.gridLayout_45.addWidget(self.label_146, 6, 0, 1, 1)

        self.id8_dbl_bd = QDoubleSpinBox(self.widget_43)
        self.id8_dbl_bd.setObjectName(u"id8_dbl_bd")
        self.id8_dbl_bd.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id8_dbl_bd.setDecimals(4)
        self.id8_dbl_bd.setMaximum(10000.000000000000000)
        self.id8_dbl_bd.setValue(8.000000000000000)

        self.gridLayout_45.addWidget(self.id8_dbl_bd, 3, 1, 1, 2)

        self.id8_dbl_wt = QDoubleSpinBox(self.widget_43)
        self.id8_dbl_wt.setObjectName(u"id8_dbl_wt")
        self.id8_dbl_wt.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id8_dbl_wt.setDecimals(4)
        self.id8_dbl_wt.setMaximum(10000.000000000000000)
        self.id8_dbl_wt.setValue(8.000000000000000)

        self.gridLayout_45.addWidget(self.id8_dbl_wt, 1, 1, 1, 2)

        self.label_144 = QLabel(self.widget_43)
        self.label_144.setObjectName(u"label_144")

        self.gridLayout_45.addWidget(self.label_144, 3, 0, 1, 1)

        self.id8_dbl_id = QDoubleSpinBox(self.widget_43)
        self.id8_dbl_id.setObjectName(u"id8_dbl_id")
        self.id8_dbl_id.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id8_dbl_id.setDecimals(4)
        self.id8_dbl_id.setMaximum(10000.000000000000000)
        self.id8_dbl_id.setValue(50.000000000000000)

        self.gridLayout_45.addWidget(self.id8_dbl_id, 0, 1, 1, 2)

        self.id8_dbl_pcd = QDoubleSpinBox(self.widget_43)
        self.id8_dbl_pcd.setObjectName(u"id8_dbl_pcd")
        self.id8_dbl_pcd.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id8_dbl_pcd.setDecimals(4)
        self.id8_dbl_pcd.setMaximum(10000.000000000000000)
        self.id8_dbl_pcd.setValue(80.000000000000000)

        self.gridLayout_45.addWidget(self.id8_dbl_pcd, 2, 1, 1, 2)

        self.label_141 = QLabel(self.widget_43)
        self.label_141.setObjectName(u"label_141")

        self.gridLayout_45.addWidget(self.label_141, 0, 0, 1, 1)

        self.label_145 = QLabel(self.widget_43)
        self.label_145.setObjectName(u"label_145")

        self.gridLayout_45.addWidget(self.label_145, 4, 0, 1, 1)

        self.verticalSpacer_18 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_45.addItem(self.verticalSpacer_18, 7, 0, 1, 2)

        self.label_142 = QLabel(self.widget_43)
        self.label_142.setObjectName(u"label_142")

        self.gridLayout_45.addWidget(self.label_142, 1, 0, 1, 1)

        self.id8_dbl_sw = QDoubleSpinBox(self.widget_43)
        self.id8_dbl_sw.setObjectName(u"id8_dbl_sw")
        self.id8_dbl_sw.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id8_dbl_sw.setDecimals(4)
        self.id8_dbl_sw.setMaximum(10000.000000000000000)
        self.id8_dbl_sw.setValue(12.000000000000000)

        self.gridLayout_45.addWidget(self.id8_dbl_sw, 4, 1, 1, 2)

        self.id8_int_nb = QSpinBox(self.widget_43)
        self.id8_int_nb.setObjectName(u"id8_int_nb")
        self.id8_int_nb.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id8_int_nb.setMinimum(2)
        self.id8_int_nb.setMaximum(3)

        self.gridLayout_45.addWidget(self.id8_int_nb, 6, 1, 1, 2)

        self.label_187 = QLabel(self.page_10)
        self.label_187.setObjectName(u"label_187")
        self.label_187.setGeometry(QRect(130, 260, 481, 391))
        self.label_187.setPixmap(QPixmap(u":/image/icons/exhaust._dimensions.png"))
        self.label_187.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_10)
        self.page_11 = QWidget()
        self.page_11.setObjectName(u"page_11")
        self.widget_44 = QWidget(self.page_11)
        self.widget_44.setObjectName(u"widget_44")
        self.widget_44.setGeometry(QRect(0, 0, 601, 401))
        self.gridLayout_46 = QGridLayout(self.widget_44)
        self.gridLayout_46.setObjectName(u"gridLayout_46")
        self.label_152 = QLabel(self.widget_44)
        self.label_152.setObjectName(u"label_152")

        self.gridLayout_46.addWidget(self.label_152, 5, 0, 1, 1)

        self.id9_dbl_vs = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_vs.setObjectName(u"id9_dbl_vs")
        self.id9_dbl_vs.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_vs.setDecimals(4)
        self.id9_dbl_vs.setMaximum(10000.000000000000000)
        self.id9_dbl_vs.setValue(25.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_vs, 5, 1, 1, 1)

        self.label_150 = QLabel(self.widget_44)
        self.label_150.setObjectName(u"label_150")

        self.gridLayout_46.addWidget(self.label_150, 3, 0, 1, 1)

        self.id9_int_hhn = QSpinBox(self.widget_44)
        self.id9_int_hhn.setObjectName(u"id9_int_hhn")
        self.id9_int_hhn.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_int_hhn.setValue(4)

        self.gridLayout_46.addWidget(self.id9_int_hhn, 2, 1, 1, 1)

        self.label_149 = QLabel(self.widget_44)
        self.label_149.setObjectName(u"label_149")

        self.gridLayout_46.addWidget(self.label_149, 2, 0, 1, 1)

        self.verticalSpacer_19 = QSpacerItem(20, 96, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_46.addItem(self.verticalSpacer_19, 16, 0, 1, 1)

        self.id9_dbl_w = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_w.setObjectName(u"id9_dbl_w")
        self.id9_dbl_w.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_w.setDecimals(4)
        self.id9_dbl_w.setMaximum(10000.000000000000000)
        self.id9_dbl_w.setValue(100.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_w, 0, 1, 1, 1)

        self.label_151 = QLabel(self.widget_44)
        self.label_151.setObjectName(u"label_151")

        self.gridLayout_46.addWidget(self.label_151, 4, 0, 1, 1)

        self.label_155 = QLabel(self.widget_44)
        self.label_155.setObjectName(u"label_155")

        self.gridLayout_46.addWidget(self.label_155, 0, 2, 1, 1)

        self.id9_int_vhn = QSpinBox(self.widget_44)
        self.id9_int_vhn.setObjectName(u"id9_int_vhn")
        self.id9_int_vhn.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_int_vhn.setValue(4)

        self.gridLayout_46.addWidget(self.id9_int_vhn, 4, 1, 1, 1)

        self.id9_dbl_hs = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_hs.setObjectName(u"id9_dbl_hs")
        self.id9_dbl_hs.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_hs.setDecimals(4)
        self.id9_dbl_hs.setMaximum(10000.000000000000000)
        self.id9_dbl_hs.setValue(25.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_hs, 3, 1, 1, 1)

        self.label_147 = QLabel(self.widget_44)
        self.label_147.setObjectName(u"label_147")

        self.gridLayout_46.addWidget(self.label_147, 0, 0, 1, 1)

        self.id9_dbl_hd = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_hd.setObjectName(u"id9_dbl_hd")
        self.id9_dbl_hd.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_hd.setDecimals(4)
        self.id9_dbl_hd.setMaximum(10000.000000000000000)
        self.id9_dbl_hd.setValue(12.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_hd, 6, 1, 1, 1)

        self.label_148 = QLabel(self.widget_44)
        self.label_148.setObjectName(u"label_148")

        self.gridLayout_46.addWidget(self.label_148, 1, 0, 1, 1)

        self.label_153 = QLabel(self.widget_44)
        self.label_153.setObjectName(u"label_153")

        self.gridLayout_46.addWidget(self.label_153, 6, 0, 1, 1)

        self.id9_dbl_fr = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_fr.setObjectName(u"id9_dbl_fr")
        self.id9_dbl_fr.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_fr.setDecimals(4)
        self.id9_dbl_fr.setMaximum(10000.000000000000000)
        self.id9_dbl_fr.setValue(12.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_fr, 7, 1, 1, 1)

        self.id9_dbl_h = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_h.setObjectName(u"id9_dbl_h")
        self.id9_dbl_h.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_h.setDecimals(4)
        self.id9_dbl_h.setMaximum(10000.000000000000000)
        self.id9_dbl_h.setValue(100.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_h, 1, 1, 1, 1)

        self.label_154 = QLabel(self.widget_44)
        self.label_154.setObjectName(u"label_154")

        self.gridLayout_46.addWidget(self.label_154, 7, 0, 1, 1)

        self.id9_combo_ch = QComboBox(self.widget_44)
        self.id9_combo_ch.addItem("")
        self.id9_combo_ch.addItem("")
        self.id9_combo_ch.addItem("")
        self.id9_combo_ch.setObjectName(u"id9_combo_ch")
        self.id9_combo_ch.setFont(font3)

        self.gridLayout_46.addWidget(self.id9_combo_ch, 0, 3, 1, 1)

        self.label_156 = QLabel(self.widget_44)
        self.label_156.setObjectName(u"label_156")

        self.gridLayout_46.addWidget(self.label_156, 1, 2, 1, 1)

        self.id9_dbl_chs = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_chs.setObjectName(u"id9_dbl_chs")
        self.id9_dbl_chs.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_chs.setDecimals(4)
        self.id9_dbl_chs.setMaximum(10000.000000000000000)
        self.id9_dbl_chs.setValue(24.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_chs, 1, 3, 1, 1)

        self.label_157 = QLabel(self.widget_44)
        self.label_157.setObjectName(u"label_157")

        self.gridLayout_46.addWidget(self.label_157, 2, 2, 1, 1)

        self.id9_dbl_chw = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_chw.setObjectName(u"id9_dbl_chw")
        self.id9_dbl_chw.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_chw.setDecimals(4)
        self.id9_dbl_chw.setMaximum(10000.000000000000000)
        self.id9_dbl_chw.setValue(12.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_chw, 2, 3, 1, 1)

        self.label_158 = QLabel(self.widget_44)
        self.label_158.setObjectName(u"label_158")

        self.gridLayout_46.addWidget(self.label_158, 3, 2, 1, 1)

        self.id9_dbl_chh = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_chh.setObjectName(u"id9_dbl_chh")
        self.id9_dbl_chh.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_chh.setDecimals(4)
        self.id9_dbl_chh.setMaximum(10000.000000000000000)
        self.id9_dbl_chh.setValue(25.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_chh, 3, 3, 1, 1)

        self.label_159 = QLabel(self.widget_44)
        self.label_159.setObjectName(u"label_159")

        self.gridLayout_46.addWidget(self.label_159, 4, 2, 1, 1)

        self.id9_dbl_chfr = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_chfr.setObjectName(u"id9_dbl_chfr")
        self.id9_dbl_chfr.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_chfr.setDecimals(4)
        self.id9_dbl_chfr.setMaximum(10000.000000000000000)
        self.id9_dbl_chfr.setValue(3.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_chfr, 4, 3, 1, 1)

        self.id9_dbl_cha = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_cha.setObjectName(u"id9_dbl_cha")
        self.id9_dbl_cha.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_cha.setMinimum(-90.000000000000000)
        self.id9_dbl_cha.setMaximum(90.000000000000000)
        self.id9_dbl_cha.setValue(0.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_cha, 5, 3, 1, 1)

        self.label_160 = QLabel(self.widget_44)
        self.label_160.setObjectName(u"label_160")

        self.gridLayout_46.addWidget(self.label_160, 5, 2, 1, 1)

        self.id9_dbl_chxo = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_chxo.setObjectName(u"id9_dbl_chxo")
        self.id9_dbl_chxo.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_chxo.setDecimals(4)
        self.id9_dbl_chxo.setMinimum(-10000.000000000000000)
        self.id9_dbl_chxo.setMaximum(10000.000000000000000)
        self.id9_dbl_chxo.setValue(0.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_chxo, 6, 3, 1, 1)

        self.id9_dbl_chyo = QDoubleSpinBox(self.widget_44)
        self.id9_dbl_chyo.setObjectName(u"id9_dbl_chyo")
        self.id9_dbl_chyo.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id9_dbl_chyo.setDecimals(4)
        self.id9_dbl_chyo.setMinimum(-10000.000000000000000)
        self.id9_dbl_chyo.setMaximum(10000.000000000000000)
        self.id9_dbl_chyo.setValue(0.000000000000000)

        self.gridLayout_46.addWidget(self.id9_dbl_chyo, 7, 3, 1, 1)

        self.label_161 = QLabel(self.widget_44)
        self.label_161.setObjectName(u"label_161")

        self.gridLayout_46.addWidget(self.label_161, 6, 2, 1, 1)

        self.label_162 = QLabel(self.widget_44)
        self.label_162.setObjectName(u"label_162")

        self.gridLayout_46.addWidget(self.label_162, 7, 2, 1, 1)

        self.label_188 = QLabel(self.page_11)
        self.label_188.setObjectName(u"label_188")
        self.label_188.setGeometry(QRect(70, 390, 480, 480))
        self.label_188.setPixmap(QPixmap(u":/image/icons/n_holerectangle_dimensions.png"))
        self.label_188.setScaledContents(True)
        self.label_188.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_11)
        self.page_12 = QWidget()
        self.page_12.setObjectName(u"page_12")
        self.widget_45 = QWidget(self.page_12)
        self.widget_45.setObjectName(u"widget_45")
        self.widget_45.setGeometry(QRect(0, 0, 229, 229))
        self.gridLayout_47 = QGridLayout(self.widget_45)
        self.gridLayout_47.setObjectName(u"gridLayout_47")
        self.label_163 = QLabel(self.widget_45)
        self.label_163.setObjectName(u"label_163")

        self.gridLayout_47.addWidget(self.label_163, 0, 0, 1, 1)

        self.id10_dbl_w = QDoubleSpinBox(self.widget_45)
        self.id10_dbl_w.setObjectName(u"id10_dbl_w")
        self.id10_dbl_w.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id10_dbl_w.setDecimals(4)
        self.id10_dbl_w.setMaximum(10000.000000000000000)
        self.id10_dbl_w.setValue(50.000000000000000)

        self.gridLayout_47.addWidget(self.id10_dbl_w, 0, 1, 1, 1)

        self.label_164 = QLabel(self.widget_45)
        self.label_164.setObjectName(u"label_164")

        self.gridLayout_47.addWidget(self.label_164, 1, 0, 1, 1)

        self.id10_dbl_h = QDoubleSpinBox(self.widget_45)
        self.id10_dbl_h.setObjectName(u"id10_dbl_h")
        self.id10_dbl_h.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id10_dbl_h.setDecimals(4)
        self.id10_dbl_h.setMaximum(10000.000000000000000)
        self.id10_dbl_h.setValue(100.000000000000000)

        self.gridLayout_47.addWidget(self.id10_dbl_h, 1, 1, 1, 1)

        self.label_165 = QLabel(self.widget_45)
        self.label_165.setObjectName(u"label_165")

        self.gridLayout_47.addWidget(self.label_165, 2, 0, 1, 1)

        self.id10_dbl_w1 = QDoubleSpinBox(self.widget_45)
        self.id10_dbl_w1.setObjectName(u"id10_dbl_w1")
        self.id10_dbl_w1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id10_dbl_w1.setDecimals(4)
        self.id10_dbl_w1.setMaximum(10000.000000000000000)
        self.id10_dbl_w1.setValue(25.000000000000000)

        self.gridLayout_47.addWidget(self.id10_dbl_w1, 2, 1, 1, 1)

        self.label_166 = QLabel(self.widget_45)
        self.label_166.setObjectName(u"label_166")

        self.gridLayout_47.addWidget(self.label_166, 3, 0, 1, 1)

        self.id10_dbl_h1 = QDoubleSpinBox(self.widget_45)
        self.id10_dbl_h1.setObjectName(u"id10_dbl_h1")
        self.id10_dbl_h1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id10_dbl_h1.setDecimals(4)
        self.id10_dbl_h1.setMaximum(10000.000000000000000)
        self.id10_dbl_h1.setValue(50.000000000000000)

        self.gridLayout_47.addWidget(self.id10_dbl_h1, 3, 1, 1, 1)

        self.verticalSpacer_20 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_47.addItem(self.verticalSpacer_20, 4, 0, 1, 1)

        self.label_189 = QLabel(self.page_12)
        self.label_189.setObjectName(u"label_189")
        self.label_189.setGeometry(QRect(130, 220, 471, 511))
        self.label_189.setPixmap(QPixmap(u":/image/icons/Lgusset_dimensions.png"))
        self.label_189.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_12)
        self.page_13 = QWidget()
        self.page_13.setObjectName(u"page_13")
        self.widget_46 = QWidget(self.page_13)
        self.widget_46.setObjectName(u"widget_46")
        self.widget_46.setGeometry(QRect(10, 10, 581, 321))
        self.gridLayout_48 = QGridLayout(self.widget_46)
        self.gridLayout_48.setObjectName(u"gridLayout_48")
        self.id11_dbl_w = QDoubleSpinBox(self.widget_46)
        self.id11_dbl_w.setObjectName(u"id11_dbl_w")
        self.id11_dbl_w.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id11_dbl_w.setDecimals(4)
        self.id11_dbl_w.setMaximum(10000.000000000000000)
        self.id11_dbl_w.setValue(100.000000000000000)

        self.gridLayout_48.addWidget(self.id11_dbl_w, 0, 1, 1, 1)

        self.label_167 = QLabel(self.widget_46)
        self.label_167.setObjectName(u"label_167")

        self.gridLayout_48.addWidget(self.label_167, 0, 0, 1, 1)

        self.id11_dbl_h = QDoubleSpinBox(self.widget_46)
        self.id11_dbl_h.setObjectName(u"id11_dbl_h")
        self.id11_dbl_h.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id11_dbl_h.setDecimals(4)
        self.id11_dbl_h.setMaximum(10000.000000000000000)
        self.id11_dbl_h.setValue(100.000000000000000)

        self.gridLayout_48.addWidget(self.id11_dbl_h, 1, 1, 1, 1)

        self.label_170 = QLabel(self.widget_46)
        self.label_170.setObjectName(u"label_170")

        self.gridLayout_48.addWidget(self.label_170, 3, 0, 1, 1)

        self.id11_dbl_a = QDoubleSpinBox(self.widget_46)
        self.id11_dbl_a.setObjectName(u"id11_dbl_a")
        self.id11_dbl_a.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id11_dbl_a.setDecimals(2)
        self.id11_dbl_a.setMaximum(180.000000000000000)
        self.id11_dbl_a.setValue(90.000000000000000)

        self.gridLayout_48.addWidget(self.id11_dbl_a, 3, 1, 1, 1)

        self.verticalSpacer_21 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_48.addItem(self.verticalSpacer_21, 7, 0, 1, 1)

        self.label_169 = QLabel(self.widget_46)
        self.label_169.setObjectName(u"label_169")

        self.gridLayout_48.addWidget(self.label_169, 2, 0, 1, 1)

        self.label_168 = QLabel(self.widget_46)
        self.label_168.setObjectName(u"label_168")

        self.gridLayout_48.addWidget(self.label_168, 1, 0, 1, 1)

        self.id11_dbl_c1 = QDoubleSpinBox(self.widget_46)
        self.id11_dbl_c1.setObjectName(u"id11_dbl_c1")
        self.id11_dbl_c1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id11_dbl_c1.setDecimals(4)
        self.id11_dbl_c1.setMaximum(10000.000000000000000)
        self.id11_dbl_c1.setValue(12.000000000000000)

        self.gridLayout_48.addWidget(self.id11_dbl_c1, 4, 1, 1, 1)

        self.id11_dbl_c2 = QDoubleSpinBox(self.widget_46)
        self.id11_dbl_c2.setObjectName(u"id11_dbl_c2")
        self.id11_dbl_c2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id11_dbl_c2.setDecimals(4)
        self.id11_dbl_c2.setMaximum(10000.000000000000000)
        self.id11_dbl_c2.setValue(12.000000000000000)

        self.gridLayout_48.addWidget(self.id11_dbl_c2, 2, 1, 1, 1)

        self.label_171 = QLabel(self.widget_46)
        self.label_171.setObjectName(u"label_171")

        self.gridLayout_48.addWidget(self.label_171, 4, 0, 1, 1)

        self.id11_chk_pair = QCheckBox(self.widget_46)
        self.id11_chk_pair.setObjectName(u"id11_chk_pair")
        self.id11_chk_pair.setLayoutDirection(Qt.LayoutDirection.LeftToRight)

        self.gridLayout_48.addWidget(self.id11_chk_pair, 0, 2, 1, 2)

        self.label_195 = QLabel(self.widget_46)
        self.label_195.setObjectName(u"label_195")

        self.gridLayout_48.addWidget(self.label_195, 1, 2, 1, 1)

        self.label_193 = QLabel(self.widget_46)
        self.label_193.setObjectName(u"label_193")

        self.gridLayout_48.addWidget(self.label_193, 2, 2, 1, 1)

        self.id11_dbl_xoffset = QDoubleSpinBox(self.widget_46)
        self.id11_dbl_xoffset.setObjectName(u"id11_dbl_xoffset")
        self.id11_dbl_xoffset.setEnabled(False)
        self.id11_dbl_xoffset.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id11_dbl_xoffset.setDecimals(4)
        self.id11_dbl_xoffset.setMinimum(-10000.000000000000000)
        self.id11_dbl_xoffset.setMaximum(10000.000000000000000)

        self.gridLayout_48.addWidget(self.id11_dbl_xoffset, 1, 3, 1, 1)

        self.id11_dbl_yoffset = QDoubleSpinBox(self.widget_46)
        self.id11_dbl_yoffset.setObjectName(u"id11_dbl_yoffset")
        self.id11_dbl_yoffset.setEnabled(False)
        self.id11_dbl_yoffset.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id11_dbl_yoffset.setDecimals(4)
        self.id11_dbl_yoffset.setMinimum(-10000.000000000000000)
        self.id11_dbl_yoffset.setMaximum(10000.000000000000000)

        self.gridLayout_48.addWidget(self.id11_dbl_yoffset, 2, 3, 1, 1)

        self.label_190 = QLabel(self.page_13)
        self.label_190.setObjectName(u"label_190")
        self.label_190.setGeometry(QRect(70, 350, 531, 511))
        self.label_190.setPixmap(QPixmap(u":/image/icons/anglegusset_dimensions.png"))
        self.label_190.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_13)
        self.page_14 = QWidget()
        self.page_14.setObjectName(u"page_14")
        self.widget_47 = QWidget(self.page_14)
        self.widget_47.setObjectName(u"widget_47")
        self.widget_47.setGeometry(QRect(10, 0, 241, 201))
        self.gridLayout_49 = QGridLayout(self.widget_47)
        self.gridLayout_49.setObjectName(u"gridLayout_49")
        self.label_172 = QLabel(self.widget_47)
        self.label_172.setObjectName(u"label_172")

        self.gridLayout_49.addWidget(self.label_172, 0, 0, 1, 1)

        self.label_173 = QLabel(self.widget_47)
        self.label_173.setObjectName(u"label_173")

        self.gridLayout_49.addWidget(self.label_173, 1, 0, 1, 1)

        self.id12_dbl_h = QDoubleSpinBox(self.widget_47)
        self.id12_dbl_h.setObjectName(u"id12_dbl_h")
        self.id12_dbl_h.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id12_dbl_h.setDecimals(4)
        self.id12_dbl_h.setMaximum(10000.000000000000000)
        self.id12_dbl_h.setValue(50.000000000000000)

        self.gridLayout_49.addWidget(self.id12_dbl_h, 1, 1, 1, 1)

        self.id12_dbl_w = QDoubleSpinBox(self.widget_47)
        self.id12_dbl_w.setObjectName(u"id12_dbl_w")
        self.id12_dbl_w.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id12_dbl_w.setDecimals(4)
        self.id12_dbl_w.setMaximum(10000.000000000000000)
        self.id12_dbl_w.setValue(100.000000000000000)

        self.gridLayout_49.addWidget(self.id12_dbl_w, 0, 1, 1, 1)

        self.id12_dbl_h1 = QDoubleSpinBox(self.widget_47)
        self.id12_dbl_h1.setObjectName(u"id12_dbl_h1")
        self.id12_dbl_h1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id12_dbl_h1.setDecimals(4)
        self.id12_dbl_h1.setMaximum(10000.000000000000000)
        self.id12_dbl_h1.setValue(12.000000000000000)

        self.gridLayout_49.addWidget(self.id12_dbl_h1, 3, 1, 1, 1)

        self.id12_dbl_w1 = QDoubleSpinBox(self.widget_47)
        self.id12_dbl_w1.setObjectName(u"id12_dbl_w1")
        self.id12_dbl_w1.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id12_dbl_w1.setDecimals(4)
        self.id12_dbl_w1.setMaximum(10000.000000000000000)
        self.id12_dbl_w1.setValue(25.000000000000000)

        self.gridLayout_49.addWidget(self.id12_dbl_w1, 2, 1, 1, 1)

        self.label_174 = QLabel(self.widget_47)
        self.label_174.setObjectName(u"label_174")

        self.gridLayout_49.addWidget(self.label_174, 3, 0, 1, 1)

        self.label_175 = QLabel(self.widget_47)
        self.label_175.setObjectName(u"label_175")

        self.gridLayout_49.addWidget(self.label_175, 2, 0, 1, 1)

        self.verticalSpacer_22 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_49.addItem(self.verticalSpacer_22, 4, 1, 1, 1)

        self.label_191 = QLabel(self.page_14)
        self.label_191.setObjectName(u"label_191")
        self.label_191.setGeometry(QRect(110, 220, 501, 411))
        self.label_191.setPixmap(QPixmap(u":/image/icons/truss_support_dimensions.png"))
        self.label_191.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_14)
        self.page_15 = QWidget()
        self.page_15.setObjectName(u"page_15")
        self.widget_48 = QWidget(self.page_15)
        self.widget_48.setObjectName(u"widget_48")
        self.widget_48.setGeometry(QRect(0, 0, 201, 201))
        self.gridLayout_50 = QGridLayout(self.widget_48)
        self.gridLayout_50.setObjectName(u"gridLayout_50")
        self.id13_dbl_w = QDoubleSpinBox(self.widget_48)
        self.id13_dbl_w.setObjectName(u"id13_dbl_w")
        self.id13_dbl_w.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id13_dbl_w.setDecimals(4)
        self.id13_dbl_w.setMaximum(10000.000000000000000)
        self.id13_dbl_w.setValue(50.000000000000000)

        self.gridLayout_50.addWidget(self.id13_dbl_w, 0, 1, 1, 1)

        self.id13_dbl_c = QDoubleSpinBox(self.widget_48)
        self.id13_dbl_c.setObjectName(u"id13_dbl_c")
        self.id13_dbl_c.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id13_dbl_c.setDecimals(4)
        self.id13_dbl_c.setMaximum(10000.000000000000000)
        self.id13_dbl_c.setValue(12.000000000000000)

        self.gridLayout_50.addWidget(self.id13_dbl_c, 2, 1, 1, 1)

        self.id13_dbl_h = QDoubleSpinBox(self.widget_48)
        self.id13_dbl_h.setObjectName(u"id13_dbl_h")
        self.id13_dbl_h.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.id13_dbl_h.setDecimals(4)
        self.id13_dbl_h.setMaximum(10000.000000000000000)
        self.id13_dbl_h.setValue(100.000000000000000)

        self.gridLayout_50.addWidget(self.id13_dbl_h, 1, 1, 1, 1)

        self.label_176 = QLabel(self.widget_48)
        self.label_176.setObjectName(u"label_176")

        self.gridLayout_50.addWidget(self.label_176, 1, 0, 1, 1)

        self.label_177 = QLabel(self.widget_48)
        self.label_177.setObjectName(u"label_177")

        self.gridLayout_50.addWidget(self.label_177, 0, 0, 1, 1)

        self.label_178 = QLabel(self.widget_48)
        self.label_178.setObjectName(u"label_178")

        self.gridLayout_50.addWidget(self.label_178, 2, 0, 1, 1)

        self.verticalSpacer_23 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_50.addItem(self.verticalSpacer_23, 3, 1, 1, 1)

        self.label_192 = QLabel(self.page_15)
        self.label_192.setObjectName(u"label_192")
        self.label_192.setGeometry(QRect(220, 130, 371, 491))
        self.label_192.setPixmap(QPixmap(u":/image/icons/webstiffener_dimensions.png"))
        self.label_192.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.details_pages.addWidget(self.page_15)
        self.widget_49 = QWidget(self.frame_2)
        self.widget_49.setObjectName(u"widget_49")
        self.widget_49.setGeometry(QRect(630, 10, 941, 961))
        sizePolicy.setHeightForWidth(self.widget_49.sizePolicy().hasHeightForWidth())
        self.widget_49.setSizePolicy(sizePolicy)
        self.widget_49.setMinimumSize(QSize(900, 940))
        self.gridLayout_51 = QGridLayout(self.widget_49)
        self.gridLayout_51.setObjectName(u"gridLayout_51")
        self.widget_50 = QWidget(self.widget_49)
        self.widget_50.setObjectName(u"widget_50")
        self.gridLayout_52 = QGridLayout(self.widget_50)
        self.gridLayout_52.setObjectName(u"gridLayout_52")
        self.smart_hole_indicator = MkLedIndicator(self.widget_50)
        self.smart_hole_indicator.setObjectName(u"smart_hole_indicator")
        self.smart_hole_indicator.setProperty(u"diameter", 20)
        self.smart_hole_indicator.setProperty(u"color", QColor(255, 238, 6))
        self.smart_hole_indicator.setProperty(u"state", False)

        self.gridLayout_52.addWidget(self.smart_hole_indicator, 0, 1, 1, 1)

        self.label_198 = QLabel(self.widget_50)
        self.label_198.setObjectName(u"label_198")

        self.gridLayout_52.addWidget(self.label_198, 0, 0, 1, 1)

        self.horizontalSpacer_18 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_52.addItem(self.horizontalSpacer_18, 1, 3, 1, 1)

        self.label_197 = QLabel(self.widget_50)
        self.label_197.setObjectName(u"label_197")

        self.gridLayout_52.addWidget(self.label_197, 1, 0, 1, 1)

        self.quickshape_internal_kerf = VCPSettingsDoubleSpinBox(self.widget_50)
        self.quickshape_internal_kerf.setObjectName(u"quickshape_internal_kerf")
        self.quickshape_internal_kerf.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.quickshape_internal_kerf.setDecimals(4)
        self.quickshape_internal_kerf.setMaximum(10.000000000000000)

        self.gridLayout_52.addWidget(self.quickshape_internal_kerf, 1, 1, 1, 1)

        self.label_199 = QLabel(self.widget_50)
        self.label_199.setObjectName(u"label_199")

        self.gridLayout_52.addWidget(self.label_199, 2, 0, 1, 4)


        self.gridLayout_51.addWidget(self.widget_50, 2, 0, 1, 1)

        self.horizontalSpacer_17 = QSpacerItem(914, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_51.addItem(self.horizontalSpacer_17, 1, 0, 1, 1)

        self.vtk_qs = VTKBackPlot(self.widget_49)
        self.vtk_qs.setObjectName(u"vtk_qs")
        self.vtk_qs.setMinimumSize(QSize(400, 800))

        self.gridLayout_51.addWidget(self.vtk_qs, 0, 0, 1, 1)

        self.btn_qs_refresh = QPushButton(self.frame_2)
        self.btn_qs_refresh.setObjectName(u"btn_qs_refresh")
        self.btn_qs_refresh.setGeometry(QRect(150, 900, 301, 61))
        sizePolicy18 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy18.setHorizontalStretch(0)
        sizePolicy18.setVerticalStretch(0)
        sizePolicy18.setHeightForWidth(self.btn_qs_refresh.sizePolicy().hasHeightForWidth())
        self.btn_qs_refresh.setSizePolicy(sizePolicy18)
        self.btn_qs_refresh.setMinimumSize(QSize(34, 44))
        self.btn_qs_refresh.setFlat(False)
        self.mainTabWidget.addTab(self.tab_conversational, "")
        self.tab_settings = QWidget()
        self.tab_settings.setObjectName(u"tab_settings")
        self.horizontalLayout_10 = QHBoxLayout(self.tab_settings)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.tabwidget_3 = MkTabWidget(self.tab_settings)
        self.tabwidget_3.setObjectName(u"tabwidget_3")
        self.tabwidget_3.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tab_settings_thcarc = QWidget()
        self.tab_settings_thcarc.setObjectName(u"tab_settings_thcarc")
        self.gridLayout_12 = QGridLayout(self.tab_settings_thcarc)
        self.gridLayout_12.setObjectName(u"gridLayout_12")
        self.groupbox = MkGroupBox(self.tab_settings_thcarc)
        self.groupbox.setObjectName(u"groupbox")
        self.gridLayout_2 = QGridLayout(self.groupbox)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setVerticalSpacing(12)
        self.gridLayout_2.setContentsMargins(-1, 9, -1, -1)
        self.label_31 = QLabel(self.groupbox)
        self.label_31.setObjectName(u"label_31")

        self.gridLayout_2.addWidget(self.label_31, 1, 0, 1, 1)

        self.arc_voltage_scale = PlasmaHalDoubleSpinBox(self.groupbox)
        self.arc_voltage_scale.setObjectName(u"arc_voltage_scale")
        self.arc_voltage_scale.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_voltage_scale.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.arc_voltage_scale.setDecimals(6)

        self.gridLayout_2.addWidget(self.arc_voltage_scale, 3, 2, 1, 1)

        self.label_32 = QLabel(self.groupbox)
        self.label_32.setObjectName(u"label_32")

        self.gridLayout_2.addWidget(self.label_32, 2, 0, 1, 1)

        self.arc_retry_delay = PlasmaHalDoubleSpinBox(self.groupbox)
        self.arc_retry_delay.setObjectName(u"arc_retry_delay")
        self.arc_retry_delay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_retry_delay.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.arc_retry_delay.setDecimals(0)

        self.gridLayout_2.addWidget(self.arc_retry_delay, 2, 2, 1, 1)

        self.arc_voltage_offset = PlasmaHalDoubleSpinBox(self.groupbox)
        self.arc_voltage_offset.setObjectName(u"arc_voltage_offset")
        self.arc_voltage_offset.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_voltage_offset.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.arc_voltage_offset.setDecimals(3)
        self.arc_voltage_offset.setMaximum(1000000.000000000000000)

        self.gridLayout_2.addWidget(self.arc_voltage_offset, 4, 2, 1, 1)

        self.label_37 = QLabel(self.groupbox)
        self.label_37.setObjectName(u"label_37")

        self.gridLayout_2.addWidget(self.label_37, 2, 3, 1, 1)

        self.label_34 = QLabel(self.groupbox)
        self.label_34.setObjectName(u"label_34")

        self.gridLayout_2.addWidget(self.label_34, 4, 0, 1, 1)

        self.label_35 = QLabel(self.groupbox)
        self.label_35.setObjectName(u"label_35")

        self.gridLayout_2.addWidget(self.label_35, 0, 3, 1, 1)

        self.label_36 = QLabel(self.groupbox)
        self.label_36.setObjectName(u"label_36")

        self.gridLayout_2.addWidget(self.label_36, 1, 3, 1, 1)

        self.label_33 = QLabel(self.groupbox)
        self.label_33.setObjectName(u"label_33")

        self.gridLayout_2.addWidget(self.label_33, 3, 0, 1, 1)

        self.label_30 = QLabel(self.groupbox)
        self.label_30.setObjectName(u"label_30")

        self.gridLayout_2.addWidget(self.label_30, 0, 0, 1, 1)

        self.arc_max_starts = PlasmaHalSpinBox(self.groupbox)
        self.arc_max_starts.setObjectName(u"arc_max_starts")
        self.arc_max_starts.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_max_starts.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)

        self.gridLayout_2.addWidget(self.arc_max_starts, 1, 2, 1, 1)

        self.arc_fail_timeout = PlasmaHalDoubleSpinBox(self.groupbox)
        self.arc_fail_timeout.setObjectName(u"arc_fail_timeout")
        self.arc_fail_timeout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_fail_timeout.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)

        self.gridLayout_2.addWidget(self.arc_fail_timeout, 0, 2, 1, 1)

        self.arc_height_per_volt = PlasmaHalDoubleSpinBox(self.groupbox)
        self.arc_height_per_volt.setObjectName(u"arc_height_per_volt")
        self.arc_height_per_volt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_height_per_volt.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.arc_height_per_volt.setDecimals(3)
        self.arc_height_per_volt.setMaximum(10.000000000000000)

        self.gridLayout_2.addWidget(self.arc_height_per_volt, 0, 4, 1, 1)

        self.arc_ok_high_volts = PlasmaHalDoubleSpinBox(self.groupbox)
        self.arc_ok_high_volts.setObjectName(u"arc_ok_high_volts")
        self.arc_ok_high_volts.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_ok_high_volts.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.arc_ok_high_volts.setMaximum(9999.000000000000000)

        self.gridLayout_2.addWidget(self.arc_ok_high_volts, 1, 4, 1, 1)

        self.arc_ok_low_volts = PlasmaHalDoubleSpinBox(self.groupbox)
        self.arc_ok_low_volts.setObjectName(u"arc_ok_low_volts")
        self.arc_ok_low_volts.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arc_ok_low_volts.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.arc_ok_low_volts.setMaximum(60.000000000000000)

        self.gridLayout_2.addWidget(self.arc_ok_low_volts, 2, 4, 1, 1)


        self.gridLayout_12.addWidget(self.groupbox, 0, 1, 1, 1)

        self.groupbox_2 = MkGroupBox(self.tab_settings_thcarc)
        self.groupbox_2.setObjectName(u"groupbox_2")
        self.gridLayout_3 = QGridLayout(self.groupbox_2)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setVerticalSpacing(12)
        self.thc_pid_d_gain = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_pid_d_gain.setObjectName(u"thc_pid_d_gain")
        self.thc_pid_d_gain.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_pid_d_gain.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.thc_pid_d_gain.setDecimals(0)
        self.thc_pid_d_gain.setMaximum(1000.000000000000000)

        self.gridLayout_3.addWidget(self.thc_pid_d_gain, 4, 2, 1, 1)

        self.thc_threshold = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_threshold.setObjectName(u"thc_threshold")
        self.thc_threshold.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_threshold.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.thc_threshold.setMaximum(200.000000000000000)

        self.gridLayout_3.addWidget(self.thc_threshold, 1, 2, 1, 1)

        self.label_27 = QLabel(self.groupbox_2)
        self.label_27.setObjectName(u"label_27")

        self.gridLayout_3.addWidget(self.label_27, 3, 0, 1, 1)

        self.label_24 = QLabel(self.groupbox_2)
        self.label_24.setObjectName(u"label_24")

        self.gridLayout_3.addWidget(self.label_24, 2, 0, 1, 1)

        self.label_23 = QLabel(self.groupbox_2)
        self.label_23.setObjectName(u"label_23")

        self.gridLayout_3.addWidget(self.label_23, 1, 0, 1, 1)

        self.thc_delay = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_delay.setObjectName(u"thc_delay")
        self.thc_delay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_delay.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)

        self.gridLayout_3.addWidget(self.thc_delay, 0, 2, 1, 1)

        self.label_28 = QLabel(self.groupbox_2)
        self.label_28.setObjectName(u"label_28")

        self.gridLayout_3.addWidget(self.label_28, 4, 0, 1, 1)

        self.label_22 = QLabel(self.groupbox_2)
        self.label_22.setObjectName(u"label_22")

        self.gridLayout_3.addWidget(self.label_22, 0, 0, 1, 1)

        self.thc_pid_p_gain = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_pid_p_gain.setObjectName(u"thc_pid_p_gain")
        self.thc_pid_p_gain.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_pid_p_gain.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.thc_pid_p_gain.setDecimals(0)
        self.thc_pid_p_gain.setMaximum(1000.000000000000000)

        self.gridLayout_3.addWidget(self.thc_pid_p_gain, 2, 2, 1, 1)

        self.thc_pid_i_gain = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_pid_i_gain.setObjectName(u"thc_pid_i_gain")
        self.thc_pid_i_gain.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_pid_i_gain.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.thc_pid_i_gain.setDecimals(0)
        self.thc_pid_i_gain.setMaximum(1000.000000000000000)

        self.gridLayout_3.addWidget(self.thc_pid_i_gain, 3, 2, 1, 1)

        self.label_25 = QLabel(self.groupbox_2)
        self.label_25.setObjectName(u"label_25")

        self.gridLayout_3.addWidget(self.label_25, 0, 3, 1, 1)

        self.thc_vad_threshold = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_vad_threshold.setObjectName(u"thc_vad_threshold")
        self.thc_vad_threshold.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_vad_threshold.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.thc_vad_threshold.setDecimals(0)

        self.gridLayout_3.addWidget(self.thc_vad_threshold, 0, 4, 1, 1)

        self.label_26 = QLabel(self.groupbox_2)
        self.label_26.setObjectName(u"label_26")

        self.gridLayout_3.addWidget(self.label_26, 1, 3, 1, 1)

        self.label_29 = QLabel(self.groupbox_2)
        self.label_29.setObjectName(u"label_29")

        self.gridLayout_3.addWidget(self.label_29, 2, 3, 1, 1)

        self.label_93 = QLabel(self.groupbox_2)
        self.label_93.setObjectName(u"label_93")

        self.gridLayout_3.addWidget(self.label_93, 3, 3, 1, 1)

        self.thc_safe_height = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_safe_height.setObjectName(u"thc_safe_height")
        self.thc_safe_height.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_safe_height.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.thc_safe_height.setDecimals(0)
        self.thc_safe_height.setMaximum(200.000000000000000)

        self.gridLayout_3.addWidget(self.thc_safe_height, 2, 4, 1, 1)

        self.thc_void_override = PlasmaHalDoubleSpinBox(self.groupbox_2)
        self.thc_void_override.setObjectName(u"thc_void_override")
        self.thc_void_override.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thc_void_override.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.thc_void_override.setDecimals(0)

        self.gridLayout_3.addWidget(self.thc_void_override, 1, 4, 1, 1)

        self.thc_feed_rate = QLabel(self.groupbox_2)
        self.thc_feed_rate.setObjectName(u"thc_feed_rate")
        font4 = QFont()
        font4.setFamilies([u"Sans"])
        font4.setPointSize(14)
        font4.setBold(True)
        font4.setItalic(False)
        self.thc_feed_rate.setFont(font4)
        self.thc_feed_rate.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_3.addWidget(self.thc_feed_rate, 3, 4, 1, 1)


        self.gridLayout_12.addWidget(self.groupbox_2, 0, 0, 1, 1)

        self.groupbox_4 = MkGroupBox(self.tab_settings_thcarc)
        self.groupbox_4.setObjectName(u"groupbox_4")
        self.gridLayout_13 = QGridLayout(self.groupbox_4)
        self.gridLayout_13.setObjectName(u"gridLayout_13")
        self.gridLayout_13.setVerticalSpacing(12)
        self.scribe_arm_delay = PlasmaHalDoubleSpinBox(self.groupbox_4)
        self.scribe_arm_delay.setObjectName(u"scribe_arm_delay")
        self.scribe_arm_delay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scribe_arm_delay.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.scribe_arm_delay.setDecimals(1)

        self.gridLayout_13.addWidget(self.scribe_arm_delay, 0, 2, 1, 1)

        self.scribe_on_delay = PlasmaHalDoubleSpinBox(self.groupbox_4)
        self.scribe_on_delay.setObjectName(u"scribe_on_delay")
        self.scribe_on_delay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scribe_on_delay.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.scribe_on_delay.setDecimals(1)
        self.scribe_on_delay.setMaximum(10.000000000000000)

        self.gridLayout_13.addWidget(self.scribe_on_delay, 1, 2, 1, 1)

        self.label_46 = QLabel(self.groupbox_4)
        self.label_46.setObjectName(u"label_46")

        self.gridLayout_13.addWidget(self.label_46, 1, 0, 1, 1)

        self.label_48 = QLabel(self.groupbox_4)
        self.label_48.setObjectName(u"label_48")

        self.gridLayout_13.addWidget(self.label_48, 1, 3, 1, 1)

        self.label_45 = QLabel(self.groupbox_4)
        self.label_45.setObjectName(u"label_45")

        self.gridLayout_13.addWidget(self.label_45, 0, 0, 1, 1)

        self.label_47 = QLabel(self.groupbox_4)
        self.label_47.setObjectName(u"label_47")

        self.gridLayout_13.addWidget(self.label_47, 0, 3, 1, 1)

        self.spot_threshold = PlasmaHalDoubleSpinBox(self.groupbox_4)
        self.spot_threshold.setObjectName(u"spot_threshold")
        self.spot_threshold.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spot_threshold.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spot_threshold.setDecimals(0)
        self.spot_threshold.setMaximum(200.000000000000000)

        self.gridLayout_13.addWidget(self.spot_threshold, 0, 4, 1, 1)

        self.spot_delay = PlasmaHalDoubleSpinBox(self.groupbox_4)
        self.spot_delay.setObjectName(u"spot_delay")
        self.spot_delay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spot_delay.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.spot_delay.setDecimals(0)
        self.spot_delay.setMaximum(3000.000000000000000)

        self.gridLayout_13.addWidget(self.spot_delay, 1, 4, 1, 1)


        self.gridLayout_12.addWidget(self.groupbox_4, 1, 1, 1, 1)

        self.groupbox_3 = MkGroupBox(self.tab_settings_thcarc)
        self.groupbox_3.setObjectName(u"groupbox_3")
        self.gridLayout_10 = QGridLayout(self.groupbox_3)
        self.gridLayout_10.setObjectName(u"gridLayout_10")
        self.gridLayout_10.setVerticalSpacing(12)
        self.label_38 = QLabel(self.groupbox_3)
        self.label_38.setObjectName(u"label_38")

        self.gridLayout_10.addWidget(self.label_38, 4, 0, 1, 1)

        self.probe_height = PlasmaHalDoubleSpinBox(self.groupbox_3)
        self.probe_height.setObjectName(u"probe_height")
        self.probe_height.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.probe_height.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.probe_height.setMaximum(999.000000000000000)

        self.gridLayout_10.addWidget(self.probe_height, 6, 2, 1, 1)

        self.probe_float_travel = PlasmaHalDoubleSpinBox(self.groupbox_3)
        self.probe_float_travel.setObjectName(u"probe_float_travel")
        self.probe_float_travel.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.probe_float_travel.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.probe_float_travel.setMaximum(999.000000000000000)

        self.gridLayout_10.addWidget(self.probe_float_travel, 4, 2, 1, 1)

        self.label_43 = QLabel(self.groupbox_3)
        self.label_43.setObjectName(u"label_43")

        self.gridLayout_10.addWidget(self.label_43, 5, 3, 1, 1)

        self.label_44 = QLabel(self.groupbox_3)
        self.label_44.setObjectName(u"label_44")

        self.gridLayout_10.addWidget(self.label_44, 6, 3, 1, 1)

        self.label_40 = QLabel(self.groupbox_3)
        self.label_40.setObjectName(u"label_40")

        self.gridLayout_10.addWidget(self.label_40, 6, 0, 1, 1)

        self.probe_ohmic_retries = PlasmaHalSpinBox(self.groupbox_3)
        self.probe_ohmic_retries.setObjectName(u"probe_ohmic_retries")
        self.probe_ohmic_retries.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.probe_ohmic_retries.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)

        self.gridLayout_10.addWidget(self.probe_ohmic_retries, 4, 4, 1, 1)

        self.label_41 = QLabel(self.groupbox_3)
        self.label_41.setObjectName(u"label_41")

        self.gridLayout_10.addWidget(self.label_41, 8, 0, 1, 1)

        self.label_42 = QLabel(self.groupbox_3)
        self.label_42.setObjectName(u"label_42")

        self.gridLayout_10.addWidget(self.label_42, 4, 3, 1, 1)

        self.probe_skip_ihs = PlasmaHalDoubleSpinBox(self.groupbox_3)
        self.probe_skip_ihs.setObjectName(u"probe_skip_ihs")
        self.probe_skip_ihs.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.probe_skip_ihs.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.probe_skip_ihs.setDecimals(0)
        self.probe_skip_ihs.setMaximum(999.000000000000000)

        self.gridLayout_10.addWidget(self.probe_skip_ihs, 5, 4, 1, 1)

        self.label_39 = QLabel(self.groupbox_3)
        self.label_39.setObjectName(u"label_39")

        self.gridLayout_10.addWidget(self.label_39, 5, 0, 1, 1)

        self.probe_offset = PlasmaHalDoubleSpinBox(self.groupbox_3)
        self.probe_offset.setObjectName(u"probe_offset")
        self.probe_offset.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.probe_offset.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.probe_offset.setDecimals(3)
        self.probe_offset.setMinimum(-400.000000000000000)
        self.probe_offset.setMaximum(400.000000000000000)

        self.gridLayout_10.addWidget(self.probe_offset, 8, 2, 1, 1)

        self.probe_setup_speed = PlasmaHalDoubleSpinBox(self.groupbox_3)
        self.probe_setup_speed.setObjectName(u"probe_setup_speed")
        self.probe_setup_speed.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.probe_setup_speed.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.probe_setup_speed.setDecimals(0)
        self.probe_setup_speed.setMaximum(30000.000000000000000)

        self.gridLayout_10.addWidget(self.probe_setup_speed, 6, 4, 1, 1)

        self.btn_probe_test = MkPushButton(self.groupbox_3)
        self.btn_probe_test.setObjectName(u"btn_probe_test")
        self.btn_probe_test.setCheckable(True)

        self.gridLayout_10.addWidget(self.btn_probe_test, 9, 4, 1, 1)

        self.probe_speed = PlasmaHalDoubleSpinBox(self.groupbox_3)
        self.probe_speed.setObjectName(u"probe_speed")
        self.probe_speed.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.probe_speed.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.probe_speed.setDecimals(0)
        self.probe_speed.setMaximum(10000.000000000000000)

        self.gridLayout_10.addWidget(self.probe_speed, 5, 2, 1, 1)


        self.gridLayout_12.addWidget(self.groupbox_3, 1, 0, 2, 1)

        self.verticalSpacer_8 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_8, 3, 0, 1, 1)

        self.tabwidget_3.addTab(self.tab_settings_thcarc, "")
        self.tab_settings_machine = QWidget()
        self.tab_settings_machine.setObjectName(u"tab_settings_machine")
        self.groupbox_18 = MkGroupBox(self.tab_settings_machine)
        self.groupbox_18.setObjectName(u"groupbox_18")
        self.groupbox_18.setGeometry(QRect(1240, 20, 591, 811))
        self.pushButton = QPushButton(self.groupbox_18)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(30, 430, 111, 44))
        self.pushButton.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.pushButton_2 = QPushButton(self.groupbox_18)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(210, 430, 88, 44))
        self.pushButton_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.groupbox_17 = MkGroupBox(self.tab_settings_machine)
        self.groupbox_17.setObjectName(u"groupbox_17")
        self.groupbox_17.setGeometry(QRect(380, 240, 481, 461))
        self.gridLayout_21 = QGridLayout(self.groupbox_17)
        self.gridLayout_21.setObjectName(u"gridLayout_21")
        self.gridLayout_21.setVerticalSpacing(12)
        self.label_62 = QLabel(self.groupbox_17)
        self.label_62.setObjectName(u"label_62")

        self.gridLayout_21.addWidget(self.label_62, 2, 0, 1, 1)

        self.label_101 = QLabel(self.groupbox_17)
        self.label_101.setObjectName(u"label_101")

        self.gridLayout_21.addWidget(self.label_101, 5, 0, 1, 1)

        self.label_60 = QLabel(self.groupbox_17)
        self.label_60.setObjectName(u"label_60")

        self.gridLayout_21.addWidget(self.label_60, 0, 0, 1, 1)

        self.filter_distance_system = QComboBox(self.groupbox_17)
        self.filter_distance_system.addItem("")
        self.filter_distance_system.addItem("")
        self.filter_distance_system.setObjectName(u"filter_distance_system")
        self.filter_distance_system.setEnabled(False)
        self.filter_distance_system.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_21.addWidget(self.filter_distance_system, 0, 1, 1, 1)

        self.plasma_torch_pulse_sec = PlasmaHalDoubleSpinBox(self.groupbox_17)
        self.plasma_torch_pulse_sec.setObjectName(u"plasma_torch_pulse_sec")
        self.plasma_torch_pulse_sec.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.plasma_torch_pulse_sec.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.plasma_torch_pulse_sec.setDecimals(3)
        self.plasma_torch_pulse_sec.setMaximum(5.000000000000000)
        self.plasma_torch_pulse_sec.setSingleStep(0.100000000000000)

        self.gridLayout_21.addWidget(self.plasma_torch_pulse_sec, 3, 1, 1, 1)

        self.label_92 = QLabel(self.groupbox_17)
        self.label_92.setObjectName(u"label_92")

        self.gridLayout_21.addWidget(self.label_92, 3, 0, 1, 1)

        self.filter_pressure_system = QComboBox(self.groupbox_17)
        self.filter_pressure_system.addItem("")
        self.filter_pressure_system.setObjectName(u"filter_pressure_system")
        self.filter_pressure_system.setEnabled(False)
        self.filter_pressure_system.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_21.addWidget(self.filter_pressure_system, 1, 1, 1, 1)

        self.label_100 = QLabel(self.groupbox_17)
        self.label_100.setObjectName(u"label_100")

        self.gridLayout_21.addWidget(self.label_100, 7, 0, 1, 1)

        self.verticalSpacer_9 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_21.addItem(self.verticalSpacer_9, 8, 0, 1, 1)

        self.label_61 = QLabel(self.groupbox_17)
        self.label_61.setObjectName(u"label_61")

        self.gridLayout_21.addWidget(self.label_61, 1, 0, 1, 1)

        self.label_102 = QLabel(self.groupbox_17)
        self.label_102.setObjectName(u"label_102")
        self.label_102.setWordWrap(True)

        self.gridLayout_21.addWidget(self.label_102, 4, 0, 1, 1)

        self.filter_machine = QComboBox(self.groupbox_17)
        self.filter_machine.addItem("")
        self.filter_machine.addItem("")
        self.filter_machine.addItem("")
        self.filter_machine.setObjectName(u"filter_machine")
        self.filter_machine.setEnabled(False)
        self.filter_machine.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout_21.addWidget(self.filter_machine, 2, 1, 1, 1)

        self.consumable_xy_feed_rate = PlasmaHalDoubleSpinBox(self.groupbox_17)
        self.consumable_xy_feed_rate.setObjectName(u"consumable_xy_feed_rate")
        self.consumable_xy_feed_rate.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.consumable_xy_feed_rate.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.consumable_xy_feed_rate.setMaximum(20000.000000000000000)

        self.gridLayout_21.addWidget(self.consumable_xy_feed_rate, 4, 1, 1, 1)

        self.framing_feed_rate = VCPSettingsDoubleSpinBox(self.groupbox_17)
        self.framing_feed_rate.setObjectName(u"framing_feed_rate")
        self.framing_feed_rate.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.framing_feed_rate.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.framing_feed_rate.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.framing_feed_rate.setMaximum(20000.000000000000000)

        self.gridLayout_21.addWidget(self.framing_feed_rate, 7, 1, 1, 1)

        self.label_103 = QLabel(self.groupbox_17)
        self.label_103.setObjectName(u"label_103")

        self.gridLayout_21.addWidget(self.label_103, 6, 0, 1, 1)

        self.consumable_offset_x = PlasmaHalDoubleSpinBox(self.groupbox_17)
        self.consumable_offset_x.setObjectName(u"consumable_offset_x")
        self.consumable_offset_x.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.consumable_offset_x.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.consumable_offset_x.setDecimals(5)
        self.consumable_offset_x.setMaximum(20000.000000000000000)

        self.gridLayout_21.addWidget(self.consumable_offset_x, 5, 1, 1, 1)

        self.consumable_offset_y = PlasmaHalDoubleSpinBox(self.groupbox_17)
        self.consumable_offset_y.setObjectName(u"consumable_offset_y")
        self.consumable_offset_y.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.consumable_offset_y.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.consumable_offset_y.setDecimals(5)
        self.consumable_offset_y.setMaximum(20000.000000000000000)

        self.gridLayout_21.addWidget(self.consumable_offset_y, 6, 1, 1, 1)

        self.groupbox_27 = MkGroupBox(self.tab_settings_machine)
        self.groupbox_27.setObjectName(u"groupbox_27")
        self.groupbox_27.setGeometry(QRect(380, 10, 481, 221))
        self.gridLayout_31 = QGridLayout(self.groupbox_27)
        self.gridLayout_31.setObjectName(u"gridLayout_31")
        self.camera_offset_x = VCPSettingsDoubleSpinBox(self.groupbox_27)
        self.camera_offset_x.setObjectName(u"camera_offset_x")
        self.camera_offset_x.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.camera_offset_x.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.camera_offset_x.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.camera_offset_x.setDecimals(5)
        self.camera_offset_x.setMinimum(-200.000000000000000)
        self.camera_offset_x.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.camera_offset_x, 2, 1, 1, 1)

        self.label_87 = QLabel(self.groupbox_27)
        self.label_87.setObjectName(u"label_87")
        self.label_87.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_31.addWidget(self.label_87, 0, 2, 1, 1)

        self.scribe_offset_x = PlasmaHalDoubleSpinBox(self.groupbox_27)
        self.scribe_offset_x.setObjectName(u"scribe_offset_x")
        self.scribe_offset_x.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scribe_offset_x.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.scribe_offset_x.setDecimals(5)
        self.scribe_offset_x.setMinimum(-200.000000000000000)
        self.scribe_offset_x.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.scribe_offset_x, 3, 1, 1, 1)

        self.laser_offset_y = VCPSettingsDoubleSpinBox(self.groupbox_27)
        self.laser_offset_y.setObjectName(u"laser_offset_y")
        self.laser_offset_y.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.laser_offset_y.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.laser_offset_y.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.laser_offset_y.setDecimals(5)
        self.laser_offset_y.setMinimum(-200.000000000000000)
        self.laser_offset_y.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.laser_offset_y, 1, 2, 1, 1)

        self.label_88 = QLabel(self.groupbox_27)
        self.label_88.setObjectName(u"label_88")

        self.gridLayout_31.addWidget(self.label_88, 3, 0, 1, 1)

        self.laser_offset_x = VCPSettingsDoubleSpinBox(self.groupbox_27)
        self.laser_offset_x.setObjectName(u"laser_offset_x")
        self.laser_offset_x.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.laser_offset_x.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.laser_offset_x.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.laser_offset_x.setDecimals(5)
        self.laser_offset_x.setMinimum(-200.000000000000000)
        self.laser_offset_x.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.laser_offset_x, 1, 1, 1, 1)

        self.label_89 = QLabel(self.groupbox_27)
        self.label_89.setObjectName(u"label_89")

        self.gridLayout_31.addWidget(self.label_89, 2, 0, 1, 1)

        self.label_78 = QLabel(self.groupbox_27)
        self.label_78.setObjectName(u"label_78")

        self.gridLayout_31.addWidget(self.label_78, 1, 0, 1, 1)

        self.scribe_offset_y = PlasmaHalDoubleSpinBox(self.groupbox_27)
        self.scribe_offset_y.setObjectName(u"scribe_offset_y")
        self.scribe_offset_y.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scribe_offset_y.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.scribe_offset_y.setDecimals(5)
        self.scribe_offset_y.setMinimum(-200.000000000000000)
        self.scribe_offset_y.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.scribe_offset_y, 3, 2, 1, 1)

        self.camera_offset_y = VCPSettingsDoubleSpinBox(self.groupbox_27)
        self.camera_offset_y.setObjectName(u"camera_offset_y")
        self.camera_offset_y.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.camera_offset_y.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.camera_offset_y.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.camera_offset_y.setDecimals(5)
        self.camera_offset_y.setMinimum(-200.000000000000000)
        self.camera_offset_y.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.camera_offset_y, 2, 2, 1, 1)

        self.label_86 = QLabel(self.groupbox_27)
        self.label_86.setObjectName(u"label_86")
        self.label_86.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.gridLayout_31.addWidget(self.label_86, 0, 1, 1, 1)

        self.label_104 = QLabel(self.groupbox_27)
        self.label_104.setObjectName(u"label_104")

        self.gridLayout_31.addWidget(self.label_104, 4, 0, 1, 1)

        self.plasmahaldoublespinbox = PlasmaHalDoubleSpinBox(self.groupbox_27)
        self.plasmahaldoublespinbox.setObjectName(u"plasmahaldoublespinbox")
        self.plasmahaldoublespinbox.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.plasmahaldoublespinbox.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.plasmahaldoublespinbox.setDecimals(5)
        self.plasmahaldoublespinbox.setMinimum(-200.000000000000000)
        self.plasmahaldoublespinbox.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.plasmahaldoublespinbox, 4, 1, 1, 1)

        self.plasmahaldoublespinbox_2 = PlasmaHalDoubleSpinBox(self.groupbox_27)
        self.plasmahaldoublespinbox_2.setObjectName(u"plasmahaldoublespinbox_2")
        self.plasmahaldoublespinbox_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.plasmahaldoublespinbox_2.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.PlusMinus)
        self.plasmahaldoublespinbox_2.setDecimals(5)
        self.plasmahaldoublespinbox_2.setMinimum(-200.000000000000000)
        self.plasmahaldoublespinbox_2.setMaximum(200.000000000000000)

        self.gridLayout_31.addWidget(self.plasmahaldoublespinbox_2, 4, 2, 1, 1)

        self.groupbox_24 = MkGroupBox(self.tab_settings_machine)
        self.groupbox_24.setObjectName(u"groupbox_24")
        self.groupbox_24.setGeometry(QRect(10, 710, 622, 211))
        self.gridLayout_23 = QGridLayout(self.groupbox_24)
        self.gridLayout_23.setObjectName(u"gridLayout_23")
        self.lne_seed_source = QLineEdit(self.groupbox_24)
        self.lne_seed_source.setObjectName(u"lne_seed_source")
        sizePolicy7.setHeightForWidth(self.lne_seed_source.sizePolicy().hasHeightForWidth())
        self.lne_seed_source.setSizePolicy(sizePolicy7)
        self.lne_seed_source.setMinimumSize(QSize(600, 29))
        self.lne_seed_source.setMaximumSize(QSize(600, 16777215))
        self.lne_seed_source.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self.gridLayout_23.addWidget(self.lne_seed_source, 1, 0, 1, 1)

        self.btn_seed_db = ActionButton(self.groupbox_24)
        self.btn_seed_db.setObjectName(u"btn_seed_db")
        sizePolicy7.setHeightForWidth(self.btn_seed_db.sizePolicy().hasHeightForWidth())
        self.btn_seed_db.setSizePolicy(sizePolicy7)
        self.btn_seed_db.setMinimumSize(QSize(34, 44))
        self.btn_seed_db.setMaximumSize(QSize(150, 16777215))

        self.gridLayout_23.addWidget(self.btn_seed_db, 0, 0, 1, 1)

        self.lbl_seed_status = QLabel(self.groupbox_24)
        self.lbl_seed_status.setObjectName(u"lbl_seed_status")

        self.gridLayout_23.addWidget(self.lbl_seed_status, 2, 0, 1, 1)

        self.groupbox_23 = MkGroupBox(self.tab_settings_machine)
        self.groupbox_23.setObjectName(u"groupbox_23")
        self.groupbox_23.setGeometry(QRect(10, 330, 351, 131))
        self.verticalLayout_12 = QVBoxLayout(self.groupbox_23)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.ask_on_run_save = VCPSettingsCheckBox(self.groupbox_23)
        self.ask_on_run_save.setObjectName(u"ask_on_run_save")

        self.verticalLayout_12.addWidget(self.ask_on_run_save)

        self.ask_on_run_delete = VCPSettingsCheckBox(self.groupbox_23)
        self.ask_on_run_delete.setObjectName(u"ask_on_run_delete")

        self.verticalLayout_12.addWidget(self.ask_on_run_delete)

        self.groupbox_7 = MkGroupBox(self.tab_settings_machine)
        self.groupbox_7.setObjectName(u"groupbox_7")
        self.groupbox_7.setGeometry(QRect(10, 100, 358, 216))
        self.gridLayout_15 = QGridLayout(self.groupbox_7)
        self.gridLayout_15.setObjectName(u"gridLayout_15")
        self.settings_lineedit_2 = VCPSettingsLineEdit(self.groupbox_7)
        self.settings_lineedit_2.setObjectName(u"settings_lineedit_2")

        self.gridLayout_15.addWidget(self.settings_lineedit_2, 1, 1, 1, 1)

        self.settings_lineedit = VCPSettingsLineEdit(self.groupbox_7)
        self.settings_lineedit.setObjectName(u"settings_lineedit")

        self.gridLayout_15.addWidget(self.settings_lineedit, 0, 1, 1, 1)

        self.settings_lineedit_3 = VCPSettingsLineEdit(self.groupbox_7)
        self.settings_lineedit_3.setObjectName(u"settings_lineedit_3")

        self.gridLayout_15.addWidget(self.settings_lineedit_3, 2, 1, 1, 1)

        self.label_4 = QLabel(self.groupbox_7)
        self.label_4.setObjectName(u"label_4")

        self.gridLayout_15.addWidget(self.label_4, 3, 0, 1, 1)

        self.label_3 = QLabel(self.groupbox_7)
        self.label_3.setObjectName(u"label_3")

        self.gridLayout_15.addWidget(self.label_3, 2, 0, 1, 1)

        self.settingscombobox = VCPSettingsComboBox(self.groupbox_7)
        self.settingscombobox.setObjectName(u"settingscombobox")

        self.gridLayout_15.addWidget(self.settingscombobox, 3, 1, 1, 1)

        self.label_2 = QLabel(self.groupbox_7)
        self.label_2.setObjectName(u"label_2")

        self.gridLayout_15.addWidget(self.label_2, 1, 0, 1, 1)

        self.label = QLabel(self.groupbox_7)
        self.label.setObjectName(u"label")

        self.gridLayout_15.addWidget(self.label, 0, 0, 1, 1)

        self.groupbox_8 = MkGroupBox(self.tab_settings_machine)
        self.groupbox_8.setObjectName(u"groupbox_8")
        self.groupbox_8.setGeometry(QRect(10, 10, 361, 81))
        self.gridLayout_16 = QGridLayout(self.groupbox_8)
        self.gridLayout_16.setObjectName(u"gridLayout_16")
        self.settings_checkbox = VCPSettingsCheckBox(self.groupbox_8)
        self.settings_checkbox.setObjectName(u"settings_checkbox")

        self.gridLayout_16.addWidget(self.settings_checkbox, 0, 0, 1, 1)

        self.tabwidget_3.addTab(self.tab_settings_machine, "")

        self.horizontalLayout_10.addWidget(self.tabwidget_3)

        self.mainTabWidget.addTab(self.tab_settings, "")
        self.tab_diagnostics = QWidget()
        self.tab_diagnostics.setObjectName(u"tab_diagnostics")
        self.groupbox_11 = MkGroupBox(self.tab_diagnostics)
        self.groupbox_11.setObjectName(u"groupbox_11")
        self.groupbox_11.setGeometry(QRect(10, 0, 711, 971))
        self.verticalLayout_5 = QVBoxLayout(self.groupbox_11)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.notificationwidget = NotificationWidget(self.groupbox_11)
        self.notificationwidget.setObjectName(u"notificationwidget")

        self.verticalLayout_5.addWidget(self.notificationwidget)

        self.groupbox_5 = MkGroupBox(self.tab_diagnostics)
        self.groupbox_5.setObjectName(u"groupbox_5")
        self.groupbox_5.setGeometry(QRect(730, 0, 490, 171))
        self.groupbox_5.setMinimumSize(QSize(490, 0))
        self.verticalLayout_2 = QVBoxLayout(self.groupbox_5)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.statuslabel = StatusLabel(self.groupbox_5)
        self.statuslabel.setObjectName(u"statuslabel")
        self.statuslabel.setWordWrap(True)

        self.verticalLayout_2.addWidget(self.statuslabel)

        self.statuslabel_2 = StatusLabel(self.groupbox_5)
        self.statuslabel_2.setObjectName(u"statuslabel_2")
        self.statuslabel_2.setWordWrap(True)

        self.verticalLayout_2.addWidget(self.statuslabel_2)

        self.groupbox_28 = MkGroupBox(self.tab_diagnostics)
        self.groupbox_28.setObjectName(u"groupbox_28")
        self.groupbox_28.setGeometry(QRect(1580, 0, 291, 831))
        self.verticalLayout_28 = QVBoxLayout(self.groupbox_28)
        self.verticalLayout_28.setObjectName(u"verticalLayout_28")
        self.hal_meter = ActionButton(self.groupbox_28)
        self.hal_meter.setObjectName(u"hal_meter")

        self.verticalLayout_28.addWidget(self.hal_meter)

        self.hal_scope = ActionButton(self.groupbox_28)
        self.hal_scope.setObjectName(u"hal_scope")

        self.verticalLayout_28.addWidget(self.hal_scope)

        self.hal_show = ActionButton(self.groupbox_28)
        self.hal_show.setObjectName(u"hal_show")

        self.verticalLayout_28.addWidget(self.hal_show)

        self.lcnc_status = ActionButton(self.groupbox_28)
        self.lcnc_status.setObjectName(u"lcnc_status")

        self.verticalLayout_28.addWidget(self.lcnc_status)

        self.calibration = ActionButton(self.groupbox_28)
        self.calibration.setObjectName(u"calibration")

        self.verticalLayout_28.addWidget(self.calibration)

        self.classic_ladder_plc = ActionButton(self.groupbox_28)
        self.classic_ladder_plc.setObjectName(u"classic_ladder_plc")

        self.verticalLayout_28.addWidget(self.classic_ladder_plc)

        self.verticalSpacer_13 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_28.addItem(self.verticalSpacer_13)

        self.exitAppBtn = QPushButton(self.groupbox_28)
        self.exitAppBtn.setObjectName(u"exitAppBtn")
        self.exitAppBtn.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.verticalLayout_28.addWidget(self.exitAppBtn)

        self.mainTabWidget.addTab(self.tab_diagnostics, "")

        self.verticalLayout_26.addWidget(self.mainTabWidget)

        Form.setCentralWidget(self.centralwidget)
        QWidget.setTabOrder(self.tile_columns, self.column_separation)
        QWidget.setTabOrder(self.column_separation, self.tile_rows)
        QWidget.setTabOrder(self.tile_rows, self.row_separation)
        QWidget.setTabOrder(self.row_separation, self.gcode_scale)
        QWidget.setTabOrder(self.gcode_scale, self.gcode_rotation)
        QWidget.setTabOrder(self.gcode_rotation, self.filter_material)
        QWidget.setTabOrder(self.filter_material, self.filter_thickness)
        QWidget.setTabOrder(self.filter_thickness, self.filter_consumable)
        QWidget.setTabOrder(self.filter_consumable, self.filter_operation)
        QWidget.setTabOrder(self.filter_operation, self.filter_gas)
        QWidget.setTabOrder(self.filter_gas, self.filter_quality)
        QWidget.setTabOrder(self.filter_quality, self.param_kerfwidth)
        QWidget.setTabOrder(self.param_kerfwidth, self.param_pierceheight)
        QWidget.setTabOrder(self.param_pierceheight, self.param_piercedelay)
        QWidget.setTabOrder(self.param_piercedelay, self.param_cutheight)
        QWidget.setTabOrder(self.param_cutheight, self.param_cutfeedrate)
        QWidget.setTabOrder(self.param_cutfeedrate, self.param_plungefeedrate)
        QWidget.setTabOrder(self.param_plungefeedrate, self.param_cutamps)
        QWidget.setTabOrder(self.param_cutamps, self.param_cutvolts)
        QWidget.setTabOrder(self.param_cutvolts, self.param_puddlejumpheight)
        QWidget.setTabOrder(self.param_puddlejumpheight, self.param_puddlejumpdelay)
        QWidget.setTabOrder(self.param_puddlejumpdelay, self.param_pauseatend)
        QWidget.setTabOrder(self.param_pauseatend, self.param_gaspressure)
        QWidget.setTabOrder(self.param_gaspressure, self.spn_hole_thickness_ratio)
        QWidget.setTabOrder(self.spn_hole_thickness_ratio, self.spn_max_hole_size)
        QWidget.setTabOrder(self.spn_max_hole_size, self.spn_leadin_radius)
        QWidget.setTabOrder(self.spn_leadin_radius, self.spn_small_hole_threshold)
        QWidget.setTabOrder(self.spn_small_hole_threshold, self.spn_hole_kerf)
        QWidget.setTabOrder(self.spn_hole_kerf, self.spn_leadin_percent_2)
        QWidget.setTabOrder(self.spn_leadin_percent_2, self.spn_arc1_percent_2)
        QWidget.setTabOrder(self.spn_arc1_percent_2, self.spn_arc2_percent_2)
        QWidget.setTabOrder(self.spn_arc2_percent_2, self.spn_arc3_percent_3)
        QWidget.setTabOrder(self.spn_arc3_percent_3, self.spn_overburn_percent_2)
        QWidget.setTabOrder(self.spn_overburn_percent_2, self.spn_overburn_distance_2)
        QWidget.setTabOrder(self.spn_overburn_distance_2, self.btn_0)
        QWidget.setTabOrder(self.btn_0, self.btn_1)
        QWidget.setTabOrder(self.btn_1, self.btn_2)
        QWidget.setTabOrder(self.btn_2, self.btn_3)
        QWidget.setTabOrder(self.btn_3, self.btn_4)
        QWidget.setTabOrder(self.btn_4, self.btn_5)
        QWidget.setTabOrder(self.btn_5, self.btn_6)
        QWidget.setTabOrder(self.btn_6, self.btn_7)
        QWidget.setTabOrder(self.btn_7, self.btn_8)
        QWidget.setTabOrder(self.btn_8, self.btn_9)
        QWidget.setTabOrder(self.btn_9, self.btn_10)
        QWidget.setTabOrder(self.btn_10, self.btn_11)
        QWidget.setTabOrder(self.btn_11, self.btn_12)
        QWidget.setTabOrder(self.btn_12, self.btn_13)
        QWidget.setTabOrder(self.btn_13, self.id0_dbl_diam)
        QWidget.setTabOrder(self.id0_dbl_diam, self.id1_dbl_width)
        QWidget.setTabOrder(self.id1_dbl_width, self.id1_dbl_height)
        QWidget.setTabOrder(self.id1_dbl_height, self.id2_dbl_outer_diam)
        QWidget.setTabOrder(self.id2_dbl_outer_diam, self.id2_dbl_inner_diam)
        QWidget.setTabOrder(self.id2_dbl_inner_diam, self.id3_dbl_width)
        QWidget.setTabOrder(self.id3_dbl_width, self.id3_dbl_height)
        QWidget.setTabOrder(self.id3_dbl_height, self.id4_dbl_h1)
        QWidget.setTabOrder(self.id4_dbl_h1, self.id4_dbl_d2)
        QWidget.setTabOrder(self.id4_dbl_d2, self.id4_dbl_rb)
        QWidget.setTabOrder(self.id4_dbl_rb, self.id4_dbl_separation)
        QWidget.setTabOrder(self.id4_dbl_separation, self.id4_dbl_w1)
        QWidget.setTabOrder(self.id4_dbl_w1, self.id4_chk_pair)
        QWidget.setTabOrder(self.id4_chk_pair, self.id4_dbl_h2)
        QWidget.setTabOrder(self.id4_dbl_h2, self.id4_dbl_d1)
        QWidget.setTabOrder(self.id4_dbl_d1, self.id5_dbl_w1)
        QWidget.setTabOrder(self.id5_dbl_w1, self.id5_dbl_w2)
        QWidget.setTabOrder(self.id5_dbl_w2, self.id5_dbl_h)
        QWidget.setTabOrder(self.id5_dbl_h, self.id6_dbl_pcd)
        QWidget.setTabOrder(self.id6_dbl_pcd, self.id6_combo_hole)
        QWidget.setTabOrder(self.id6_combo_hole, self.id6_dbl_od)
        QWidget.setTabOrder(self.id6_dbl_od, self.id6_int_holes)
        QWidget.setTabOrder(self.id6_int_holes, self.id6_dbl_hd)
        QWidget.setTabOrder(self.id6_dbl_hd, self.id6_dbl_id)
        QWidget.setTabOrder(self.id6_dbl_id, self.id7_dbl_w)
        QWidget.setTabOrder(self.id7_dbl_w, self.id7_dbl_h)
        QWidget.setTabOrder(self.id7_dbl_h, self.id7_dbl_pd)
        QWidget.setTabOrder(self.id7_dbl_pd, self.id7_dbl_o)
        QWidget.setTabOrder(self.id7_dbl_o, self.id8_dbl_bd)
        QWidget.setTabOrder(self.id8_dbl_bd, self.id8_dbl_wt)
        QWidget.setTabOrder(self.id8_dbl_wt, self.id8_dbl_id)
        QWidget.setTabOrder(self.id8_dbl_id, self.id8_dbl_pcd)
        QWidget.setTabOrder(self.id8_dbl_pcd, self.id8_dbl_sw)
        QWidget.setTabOrder(self.id8_dbl_sw, self.id8_int_nb)
        QWidget.setTabOrder(self.id8_int_nb, self.id9_dbl_vs)
        QWidget.setTabOrder(self.id9_dbl_vs, self.id9_int_hhn)
        QWidget.setTabOrder(self.id9_int_hhn, self.id9_dbl_w)
        QWidget.setTabOrder(self.id9_dbl_w, self.id9_int_vhn)
        QWidget.setTabOrder(self.id9_int_vhn, self.id9_dbl_hs)
        QWidget.setTabOrder(self.id9_dbl_hs, self.id9_dbl_hd)
        QWidget.setTabOrder(self.id9_dbl_hd, self.id9_dbl_fr)
        QWidget.setTabOrder(self.id9_dbl_fr, self.id9_dbl_h)
        QWidget.setTabOrder(self.id9_dbl_h, self.id9_combo_ch)
        QWidget.setTabOrder(self.id9_combo_ch, self.id9_dbl_chs)
        QWidget.setTabOrder(self.id9_dbl_chs, self.id9_dbl_chw)
        QWidget.setTabOrder(self.id9_dbl_chw, self.id9_dbl_chh)
        QWidget.setTabOrder(self.id9_dbl_chh, self.id9_dbl_chfr)
        QWidget.setTabOrder(self.id9_dbl_chfr, self.id9_dbl_cha)
        QWidget.setTabOrder(self.id9_dbl_cha, self.id9_dbl_chxo)
        QWidget.setTabOrder(self.id9_dbl_chxo, self.id9_dbl_chyo)
        QWidget.setTabOrder(self.id9_dbl_chyo, self.id10_dbl_w)
        QWidget.setTabOrder(self.id10_dbl_w, self.id10_dbl_h)
        QWidget.setTabOrder(self.id10_dbl_h, self.id10_dbl_w1)
        QWidget.setTabOrder(self.id10_dbl_w1, self.id10_dbl_h1)
        QWidget.setTabOrder(self.id10_dbl_h1, self.id11_dbl_w)
        QWidget.setTabOrder(self.id11_dbl_w, self.id11_dbl_h)
        QWidget.setTabOrder(self.id11_dbl_h, self.id11_dbl_c2)
        QWidget.setTabOrder(self.id11_dbl_c2, self.id11_dbl_a)
        QWidget.setTabOrder(self.id11_dbl_a, self.id11_dbl_c1)
        QWidget.setTabOrder(self.id11_dbl_c1, self.id12_dbl_h)
        QWidget.setTabOrder(self.id12_dbl_h, self.id12_dbl_w)
        QWidget.setTabOrder(self.id12_dbl_w, self.id12_dbl_h1)
        QWidget.setTabOrder(self.id12_dbl_h1, self.id12_dbl_w1)
        QWidget.setTabOrder(self.id12_dbl_w1, self.id13_dbl_w)
        QWidget.setTabOrder(self.id13_dbl_w, self.id13_dbl_c)
        QWidget.setTabOrder(self.id13_dbl_c, self.id13_dbl_h)
        QWidget.setTabOrder(self.id13_dbl_h, self.btn_qs_refresh)
        QWidget.setTabOrder(self.btn_qs_refresh, self.thc_delay)
        QWidget.setTabOrder(self.thc_delay, self.thc_threshold)
        QWidget.setTabOrder(self.thc_threshold, self.thc_pid_p_gain)
        QWidget.setTabOrder(self.thc_pid_p_gain, self.thc_pid_i_gain)
        QWidget.setTabOrder(self.thc_pid_i_gain, self.thc_pid_d_gain)
        QWidget.setTabOrder(self.thc_pid_d_gain, self.thc_vad_threshold)
        QWidget.setTabOrder(self.thc_vad_threshold, self.thc_void_override)
        QWidget.setTabOrder(self.thc_void_override, self.thc_safe_height)
        QWidget.setTabOrder(self.thc_safe_height, self.probe_float_travel)
        QWidget.setTabOrder(self.probe_float_travel, self.probe_speed)
        QWidget.setTabOrder(self.probe_speed, self.probe_height)
        QWidget.setTabOrder(self.probe_height, self.probe_offset)
        QWidget.setTabOrder(self.probe_offset, self.probe_ohmic_retries)
        QWidget.setTabOrder(self.probe_ohmic_retries, self.probe_skip_ihs)
        QWidget.setTabOrder(self.probe_skip_ihs, self.probe_setup_speed)
        QWidget.setTabOrder(self.probe_setup_speed, self.arc_fail_timeout)
        QWidget.setTabOrder(self.arc_fail_timeout, self.arc_max_starts)
        QWidget.setTabOrder(self.arc_max_starts, self.arc_retry_delay)
        QWidget.setTabOrder(self.arc_retry_delay, self.arc_voltage_scale)
        QWidget.setTabOrder(self.arc_voltage_scale, self.arc_voltage_offset)
        QWidget.setTabOrder(self.arc_voltage_offset, self.arc_height_per_volt)
        QWidget.setTabOrder(self.arc_height_per_volt, self.arc_ok_high_volts)
        QWidget.setTabOrder(self.arc_ok_high_volts, self.arc_ok_low_volts)
        QWidget.setTabOrder(self.arc_ok_low_volts, self.scribe_arm_delay)
        QWidget.setTabOrder(self.scribe_arm_delay, self.scribe_on_delay)
        QWidget.setTabOrder(self.scribe_on_delay, self.spot_threshold)
        QWidget.setTabOrder(self.spot_threshold, self.spot_delay)
        QWidget.setTabOrder(self.spot_delay, self.laser_offset_x)
        QWidget.setTabOrder(self.laser_offset_x, self.laser_offset_y)
        QWidget.setTabOrder(self.laser_offset_y, self.camera_offset_x)
        QWidget.setTabOrder(self.camera_offset_x, self.camera_offset_y)
        QWidget.setTabOrder(self.camera_offset_y, self.scribe_offset_x)
        QWidget.setTabOrder(self.scribe_offset_x, self.scribe_offset_y)
        QWidget.setTabOrder(self.scribe_offset_y, self.plasmahaldoublespinbox)
        QWidget.setTabOrder(self.plasmahaldoublespinbox, self.plasmahaldoublespinbox_2)
        QWidget.setTabOrder(self.plasmahaldoublespinbox_2, self.plasma_torch_pulse_sec)
        QWidget.setTabOrder(self.plasma_torch_pulse_sec, self.consumable_xy_feed_rate)
        QWidget.setTabOrder(self.consumable_xy_feed_rate, self.consumable_offset_x)
        QWidget.setTabOrder(self.consumable_offset_x, self.consumable_offset_y)
        QWidget.setTabOrder(self.consumable_offset_y, self.framing_feed_rate)
        QWidget.setTabOrder(self.framing_feed_rate, self.id11_chk_pair)
        QWidget.setTabOrder(self.id11_chk_pair, self.id11_dbl_xoffset)
        QWidget.setTabOrder(self.id11_dbl_xoffset, self.id11_dbl_yoffset)

        self.retranslateUi(Form)
        self.btnMdiSend.clicked.connect(self.mdihistory.submit)
        self.btnMdiRowUp.clicked.connect(self.mdihistory.moveRowItemUp)
        self.btnMdiRowDown.clicked.connect(self.mdihistory.moveRowItemDown)
        self.btnMdiDelAll.clicked.connect(self.mdihistory.removeAll)
        self.btnMdiDelRow.clicked.connect(self.mdihistory.removeSelectedItem)
        self.btnMdiRunFrom.clicked.connect(self.mdihistory.runFromSelection)
        self.btnMdiRunSelection.clicked.connect(self.mdihistory.runSelection)
        self.btnMdiClearQ.clicked.connect(self.mdihistory.clearQueue)
        self.btnMdiPauseQ.toggled.connect(self.mdihistory.toggleQueue)
        self.btnManualState.clicked.connect(self.mdiFrame.hide)
        self.btnMdiState.clicked.connect(self.mdiFrame.show)
        self.btnAutoState.clicked.connect(self.mdiFrame.hide)
        self.btnToEditor.clicked.connect(self.mdihistory.copySelectionToGcodeEditor)
        self.btn_thc_enable.toggled.connect(self.thc_enabled.setChecked)
        self.btn_vad.toggled.connect(self.chkb_vad.setChecked)
        self.btn_void_sense.toggled.connect(self.chkb_void_sense.setChecked)
        self.thc_enabled.toggled.connect(self.btn_thc_enable.setChecked)
        self.chkb_vad.toggled.connect(self.btn_vad.setChecked)
        self.chkb_void_sense.toggled.connect(self.btn_void_sense.setChecked)
        self.chkb_auto_volts.toggled.connect(self.mkled_thc_auto_volts.setState)
        self.chkb_mesh_sense.toggled.connect(self.mkled_mesh_sense.setState)
        self.chkb_ohmic_sense.toggled.connect(self.mkled_ohmic_sense.setState)
        self.btn_transform.toggled.connect(self.transformFrame.setVisible)
        self.id4_chk_pair.toggled.connect(self.id4_dbl_separation.setEnabled)
        self.id11_chk_pair.toggled.connect(self.id11_dbl_xoffset.setEnabled)
        self.id11_chk_pair.toggled.connect(self.id11_dbl_yoffset.setEnabled)
        self.btn_edit.toggled.connect(self.btn_save.setEnabled)
        self.chkb_hole_detect_enable.toggled.connect(self.smart_hole_indicator.setState)
        self.vtk_plus.clicked.connect(self.vtkbackplot.zoomIn)
        self.vtk_minus.clicked.connect(self.vtkbackplot.zoomOut)
        self.vtk_clear.clicked.connect(self.vtkbackplot.clearLivePlot)

        self.mainTabWidget.setCurrentIndex(0)
        self.tabWidget_leftcolumn.setCurrentIndex(0)
        self.tabwidget_midcolumn.setCurrentIndex(0)
        self.jog_stack.setCurrentIndex(0)
        self.tabs_ctl_run_right.setCurrentIndex(0)
        self.tabWidget.setCurrentIndex(0)
        self.tab_holes_and_slots.setCurrentIndex(0)
        self.details_pages.setCurrentIndex(0)
        self.id9_combo_ch.setCurrentIndex(0)
        self.tabwidget_3.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.actionbutton_13.setText(QCoreApplication.translate("Form", u"G54", None))
        self.actionbutton_13.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G54", None))
        self.actionbutton_12.setText(QCoreApplication.translate("Form", u"G55", None))
        self.actionbutton_12.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G55", None))
        self.actionbutton_11.setText(QCoreApplication.translate("Form", u"G56", None))
        self.actionbutton_11.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G56", None))
        self.actionbutton_14.setText(QCoreApplication.translate("Form", u"G57", None))
        self.actionbutton_14.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G57", None))
        self.actionbutton_2.setText(QCoreApplication.translate("Form", u"G58", None))
        self.actionbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G58", None))
        self.actionbutton_3.setText(QCoreApplication.translate("Form", u"G59", None))
        self.actionbutton_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59", None))
        self.actionbutton_15.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.home.all", None))
        self.btn_zero_xy.setText(QCoreApplication.translate("Form", u"ZERO XY\n"
"in G5x", None))
        self.tabWidget_leftcolumn.setTabText(self.tabWidget_leftcolumn.indexOf(self.tab_4), QCoreApplication.translate("Form", u"WORK", None))
        self.actionbutton_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.unhome.axis:x", None))
        self.actionbutton_6.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.unhome.axis:y", None))
        self.actionbutton_7.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.unhome.axis:z", None))
        self.actionbutton_36.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.home.all", None))
        self.tabWidget_leftcolumn.setTabText(self.tabWidget_leftcolumn.indexOf(self.tab_3), QCoreApplication.translate("Form", u"MACHINE", None))
        self.label_98.setText(QCoreApplication.translate("Form", u"FEED RATE", None))
        self.lbl_process_name.setText(QCoreApplication.translate("Form", u"None", None))
        self.label_91.setText(QCoreApplication.translate("Form", u"ACTIVE CUT PROCESS:", None))
        self.label_99.setText(QCoreApplication.translate("Form", u"CURRENT VELOCITY", None))
        self.groupbox_6.setTitle(QCoreApplication.translate("Form", u"CONTROL", None))
        self.sc_park.setText(QCoreApplication.translate("Form", u"PARK", None))
        self.sc_park.setProperty(u"filename", QCoreApplication.translate("Form", u"park.ngc", None))
        self.btn_m1_break.setText(QCoreApplication.translate("Form", u"M1\n"
"BREAK", None))
        self.btn_m1_break.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.optional-stop.toggle", None))
        self.btn_g5x_home.setText(QCoreApplication.translate("Form", u"GOTO\n"
" WORK ZERO", None))
        self.btn_g5x_home.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G0X0Y0", None))
        self.btn_feed_hold.setText(QCoreApplication.translate("Form", u"FEED\n"
"HOLD", None))
        self.btn_feed_hold.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.pause", None))
        self.btn_cycle_start.setText(QCoreApplication.translate("Form", u"CYCLE START", None))
        self.btn_cycle_start.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"cycle-start", None))
        self.btn_move_home.setText(QCoreApplication.translate("Form", u"GOTO\n"
"HOME", None))
        self.btn_move_home.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G53 G0Z0X0Y0", None))
        self.btn_machine_power_toggle.setText(QCoreApplication.translate("Form", u"MACHINE\n"
"POWER", None))
        self.btn_machine_power_toggle.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.power.toggle", None))
        self.btn_stop_abort.setText(QCoreApplication.translate("Form", u"STOP\n"
"ABORT", None))
        self.btn_stop_abort.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.abort", None))
        self.btn_frame_job.setText(QCoreApplication.translate("Form", u"FRAME\n"
"JOB", None))
        self.estopbutton.setText(QCoreApplication.translate("Form", u"ESTOP", None))
        self.estopbutton.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"estop\", \"property\": \"Style Class\", \"expression\": \"'estop_triggered' if ch[0] else 'estop_armed'\", \"channels\": [{\"url\": \"status:estop\", \"trigger\": true}]}]", None))
        self.estopbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.estop.toggle", None))
        self.btn_consumable_change.setText(QCoreApplication.translate("Form", u"CONSUMABLE\n"
"CHANGE", None))
        self.btn_consumable_change.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"mk-consumable-change", None))
        self.rapid_slider.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.rapid-override.set", None))
        self.btn_reset_rapid.setText(QCoreApplication.translate("Form", u"RESET", None))
        self.statuslabel_4.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:rapidrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:.0%}\\\".format(ch[0])\", \"name\": \"New Rule\"}]", None))
        self.label_8.setText(QCoreApplication.translate("Form", u"RAPID", None))
        self.btn_reset_jog.setText(QCoreApplication.translate("Form", u"RESET", None))
        self.btn_reset_feed.setText(QCoreApplication.translate("Form", u"RESET", None))
        self.feed_slider.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.feed-override.set", None))
        self.statuslabel_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:feedrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:.0%}\\\".format(ch[0])\", \"name\": \"New Rule\"}]", None))
        self.label_9.setText(QCoreApplication.translate("Form", u"FEED", None))
        self.statuslabel_6.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"settings:machine.jog.linear-speed-percentage\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:.0f}%\\\".format(ch[0])\", \"name\": \"New Rule\"}]", None))
        self.label_10.setText(QCoreApplication.translate("Form", u"JOG", None))
        self.jog_slider.setProperty(u"settingName", QCoreApplication.translate("Form", u"machine.jog.linear-speed-percentage", None))
        self.btn_load_newest.setText(QCoreApplication.translate("Form", u"LOAD NEWEST\n"
"FILE", None))
        self.label_6.setText(QCoreApplication.translate("Form", u"CRNR LOCK", None))
        self.mkhalledindicator_7.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-corner-lock", None))
        self.label_16.setText(QCoreApplication.translate("Form", u"TORCH", None))
        self.mkhalledindicator_4.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-torch-on", None))
        self.torch_enable.setText(QCoreApplication.translate("Form", u"TORCH\n"
"ENABLE", None))
        self.label_14.setText(QCoreApplication.translate("Form", u"ARC-OK", None))
        self.mkhalledindicator_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-arc-ok", None))
        self.label_97.setText(QCoreApplication.translate("Form", u"CHG CON", None))
        self.mkhalledindicator_10.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-change-consumable", None))
        self.label_15.setText(QCoreApplication.translate("Form", u"FLOAT", None))
        self.mkhalledindicator_3.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-float", None))
        self.label_96.setText(QCoreApplication.translate("Form", u"THC ACTIVE", None))
        self.mkhalledindicator_9.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-thc-active", None))
        self.spin_voltage_override.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.spin_voltage_override.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"voltage-override", None))
        self.label_18.setText(QCoreApplication.translate("Form", u"OVERRIDE", None))
        self.label_17.setText(QCoreApplication.translate("Form", u"ARC Voltage", None))
        self.hallabel.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"mk-arc-voltage", None))
        self.btn_void_sense.setText(QCoreApplication.translate("Form", u"VOID\n"
"ANTI DIVE", None))
        self.label_12.setText(QCoreApplication.translate("Form", u"KERF CROSS", None))
        self.mkhalledindicator_8.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-kerf-cross", None))
        self.btn_vad.setText(QCoreApplication.translate("Form", u"VELOCITY\n"
"ANTI DIVE", None))
        self.btn_thc_enable.setText(QCoreApplication.translate("Form", u"THC ENABLE", None))
        self.label_13.setText(QCoreApplication.translate("Form", u"PROBE", None))
        self.mkhalledindicator.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-probe", None))
        self.btnManualState.setText(QCoreApplication.translate("Form", u"MANUAL", None))
        self.btnManualState.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.mode.manual", None))
        self.btnMdiState.setText(QCoreApplication.translate("Form", u"MDI", None))
        self.btnMdiState.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.mode.mdi", None))
        self.btnAutoState.setText(QCoreApplication.translate("Form", u"AUTO", None))
        self.btnAutoState.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.mode.auto", None))
        self.label_106.setText(QCoreApplication.translate("Form", u"MESH", None))
        self.btn_pierce_only.setText(QCoreApplication.translate("Form", u"PIERCE\n"
"ONLY", None))
        self.btn_pierce_only.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-pierce-only-enable", None))
        self.label_105.setText(QCoreApplication.translate("Form", u"THC AUTO Vs", None))
        self.plasma_torch_pulse.setText(QCoreApplication.translate("Form", u"PULSE\n"
"TORCH", None))
        self.label_19.setText(QCoreApplication.translate("Form", u"UP/DOWN", None))
        self.mkhalledindicator_5.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-thc-up", None))
        self.mkhalledindicator_6.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"led-thc-down", None))
        self.dry_run.setText(QCoreApplication.translate("Form", u"DRY RUN", None))
        self.label_107.setText(QCoreApplication.translate("Form", u"OHMIC", None))
        self.tabwidget_midcolumn.setTabText(self.tabwidget_midcolumn.indexOf(self.tab_run_monitor), QCoreApplication.translate("Form", u"RUN && MONITOR", None))
        self.actionbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:y,neg", None))
        self.actionbutton_21.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,neg", None))
        self.actionbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:y,pos", None))
        self.actionbutton_22.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,pos", None))
        self.actionbutton_25.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,neg", None))
        self.actionbutton_24.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,pos", None))
        self.inc_0_01.setText(QCoreApplication.translate("Form", u"0.0004", None))
        self.inc_0_01.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"New Rule\", \"property\": \"Text\", \"expression\": \"\\\".01\\\" if ch[0] == 1 else \\\"0.0004\\\"\", \"channels\": [{\"url\": \"status:linear_units\", \"trigger\": true}]}]", None))
        self.inc_0_01.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.set-increment:0.01", None))
        self.inc_1.setText(QCoreApplication.translate("Form", u"0.039", None))
        self.inc_1.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"measure\", \"property\": \"Text\", \"expression\": \"\\\"1\\\" if ch[0] == 1 else \\\"0.039\\\"\", \"channels\": [{\"url\": \"status:linear_units\", \"trigger\": true}]}]", None))
        self.inc_1.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.set-increment:1", None))
        self.inc_5.setText(QCoreApplication.translate("Form", u"0.1968", None))
        self.inc_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"New Rule\", \"property\": \"Text\", \"expression\": \"\\\"5\\\" if ch[0] == 1 else \\\"0.1968\\\"\", \"channels\": [{\"url\": \"status:linear_units\", \"trigger\": true}]}]", None))
        self.inc_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.set-increment:5", None))
        self.inc_0_1.setText(QCoreApplication.translate("Form", u"0.0039", None))
        self.inc_0_1.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"New Rule\", \"property\": \"Text\", \"expression\": \"\\\"0.1\\\" if ch[0] == 1 else \\\"0.0039\\\"\", \"channels\": [{\"url\": \"status:linear_units\", \"trigger\": true}]}]", None))
        self.inc_0_1.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.set-increment:0.1", None))
        self.btn_inc_jog.setText(QCoreApplication.translate("Form", u"INC", None))
        self.btn_inc_jog.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog-mode.incremental", None))
        self.btn_cont_jog.setText(QCoreApplication.translate("Form", u"CONT", None))
        self.btn_cont_jog.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog-mode.continuous", None))
        self.label_21.setText(QCoreApplication.translate("Form", u"STEP SIZE", None))
        self.groupbox_13.setTitle(QCoreApplication.translate("Form", u"SHEET ALIGNMENT", None))
        self.lbl_align_data.setText(QCoreApplication.translate("Form", u"REF1:...\n"
"REF2:..", None))
        self.btn_sheet_align_pt2.setText(QCoreApplication.translate("Form", u"WCS 0,0 POINT", None))
        self.btn_sheet_doalign.setText(QCoreApplication.translate("Form", u"SHEET ALIGNMENT", None))
        self.btn_laser.setText(QCoreApplication.translate("Form", u"LASER", None))
        self.btn_laser.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"laser", None))
        self.btn_sheet_align_pt1.setText(QCoreApplication.translate("Form", u"REF ON EDGE", None))
        self.groupbox_12.setTitle(QCoreApplication.translate("Form", u"SINGLE CUT", None))
        self.label_94.setText(QCoreApplication.translate("Form", u"X-LENGTH", None))
        self.btn_single_cut.setText(QCoreApplication.translate("Form", u"SINGLE\n"
"CUT", None))
        self.btn_single_cut.setProperty(u"filename", QCoreApplication.translate("Form", u"single_cut.ngc", None))
        self.label_95.setText(QCoreApplication.translate("Form", u"Y-LENGTH", None))
        self.groupbox_26.setTitle(QCoreApplication.translate("Form", u"CUT RECOVERY", None))
        self.widget_recovery.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.btn_cut_recover_fwd.setText(QCoreApplication.translate("Form", u"FORWARD", None))
        self.btn_cut_recover_rev.setText(QCoreApplication.translate("Form", u"REVERSE", None))
        self.btn_recovery_s.setText("")
        self.btn_recovery_sw.setText("")
        self.btn_recovery_se.setText("")
        self.btn_recovery_e.setText("")
        self.btn_recovery_ne.setText("")
        self.btn_recovery_w.setText("")
        self.btn_recovery_n.setText("")
        self.btn_recovery_nw.setText("")
        self.label_20.setText(QCoreApplication.translate("Form", u"kerf", None))
        self.btn_cut_recover_cancel.setText(QCoreApplication.translate("Form", u"Cancel Movement", None))
        self.tabwidget_midcolumn.setTabText(self.tabwidget_midcolumn.indexOf(self.tab_jog), QCoreApplication.translate("Form", u"JOG", None))
        self.vtk_minus.setText(QCoreApplication.translate("Form", u"-", None))
        self.vtk_clear.setText(QCoreApplication.translate("Form", u"CLEAR", None))
        self.vtk_mach_extent.setText(QCoreApplication.translate("Form", u"MACH\n"
"EXTENT", None))
        self.vtk_no_lines.setText(QCoreApplication.translate("Form", u"SHOW\n"
"TRAILS", None))
        self.vtk_center.setText(QCoreApplication.translate("Form", u"CENTER\n"
"PLOT", None))
        self.vtk_plus.setText(QCoreApplication.translate("Form", u"+", None))
        self.vtk_prog_extent.setText(QCoreApplication.translate("Form", u"PROG\n"
"EXTENT", None))
        self.btn_transform.setText(QCoreApplication.translate("Form", u"TRANSFORM", None))
        self.label_108.setText(QCoreApplication.translate("Form", u"COLS", None))
        self.label_113.setText(QCoreApplication.translate("Form", u"MIRROR", None))
        self.label_114.setText(QCoreApplication.translate("Form", u"ROT", None))
        self.label_111.setText(QCoreApplication.translate("Form", u"SEPARATION", None))
        self.btn_transform_apply.setText(QCoreApplication.translate("Form", u"APPLY", None))
        self.label_109.setText(QCoreApplication.translate("Form", u"ROWS", None))
        self.gcode_rotation.setSuffix(QCoreApplication.translate("Form", u"DEG", None))
        self.label_112.setText(QCoreApplication.translate("Form", u"FLIP", None))
        self.gcode_flip.setText("")
        self.label_110.setText(QCoreApplication.translate("Form", u"SCALE", None))
        self.btn_open_dialog_2.setText(QCoreApplication.translate("Form", u"OPEN", None))
        self.btn_open_dialog_2.setProperty(u"dialogName", QCoreApplication.translate("Form", u"open_file", None))
        self.btn_reload_2.setText(QCoreApplication.translate("Form", u"RELOAD", None))
        self.btn_reload_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"New Rule\", \"property\": \"Enable\", \"expression\": \"True if ch[0] != 'No file loaded' else False\", \"channels\": [{\"url\": \"status:file\", \"trigger\": true}]}]", None))
        self.dialogbutton_3.setText(QCoreApplication.translate("Form", u"RECENT", None))
        self.dialogbutton_3.setProperty(u"dialogName", QCoreApplication.translate("Form", u"recent_files", None))
        self.mdiFrame.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.pushButton_28.setText(QCoreApplication.translate("Form", u"2", None))
        self.pushButton_30.setText(QCoreApplication.translate("Form", u"4", None))
        self.btnMdiRunSelection.setText(QCoreApplication.translate("Form", u"RUN\n"
"SINGLE", None))
        self.pushButton_8.setText(QCoreApplication.translate("Form", u"M", None))
        self.pushButton_29.setText(QCoreApplication.translate("Form", u"3", None))
        self.pushButton_25.setText(QCoreApplication.translate("Form", u".", None))
        self.btnMdiDelAll.setText(QCoreApplication.translate("Form", u"DEL\n"
"ALL", None))
        self.pushButton_31.setText(QCoreApplication.translate("Form", u"5", None))
        self.pushButton_34.setText(QCoreApplication.translate("Form", u"8", None))
        self.btnMdiParams.setText(QCoreApplication.translate("Form", u"PARAMS", None))
        self.pushButton_32.setText(QCoreApplication.translate("Form", u"6", None))
        self.btnMdiSpace.setText(QCoreApplication.translate("Form", u"SPACE", None))
        self.btnMdiDelRow.setText(QCoreApplication.translate("Form", u"DEL\n"
"ROW", None))
        self.pushButton_9.setText(QCoreApplication.translate("Form", u"T", None))
        self.pushButton_10.setText(QCoreApplication.translate("Form", u"F", None))
        self.btnMdiRunFrom.setText(QCoreApplication.translate("Form", u"RUN\n"
"FROM", None))
        self.btnMdiBksp.setText(QCoreApplication.translate("Form", u"BKSP", None))
        self.pushButton_27.setText(QCoreApplication.translate("Form", u"1", None))
        self.pushButton_26.setText(QCoreApplication.translate("Form", u"-", None))
        self.btnMdiSend.setText(QCoreApplication.translate("Form", u"SEND", None))
        self.btnToEditor.setText(QCoreApplication.translate("Form", u"TO\n"
"EDITOR", None))
        self.pushButton_24.setText(QCoreApplication.translate("Form", u"0", None))
        self.pushButton_35.setText(QCoreApplication.translate("Form", u"9", None))
        self.pushButton_7.setText(QCoreApplication.translate("Form", u"G", None))
        self.pushButton_33.setText(QCoreApplication.translate("Form", u"7", None))
        self.btnGcodeP9.setText("")
        self.btnGcodeP10.setText("")
        self.btnGcodeP5.setText("")
        self.btnGcodeP6.setText("")
        self.btnGcodeP7.setText("")
        self.btnGcodeP8.setText("")
        self.btnGcodeP1.setText("")
        self.btnGcodeP2.setText("")
        self.btnGcodeP3.setText("")
        self.btnGcodeP4.setText("")
        self.mdiEntry.setPlaceholderText(QCoreApplication.translate("Form", u"MDI:", None))
        self.mdihistory.setProperty(u"mdiEntrylineName", QCoreApplication.translate("Form", u"mdiEntry", None))
        self.btnMdiPauseQ.setText(QCoreApplication.translate("Form", u"PAUSE\n"
"QUEUE", None))
        self.btnMdiClearQ.setText(QCoreApplication.translate("Form", u"CLEAR\n"
"QUEUE", None))
        self.btnMdiRowUp.setText(QCoreApplication.translate("Form", u"ROW\n"
"UP", None))
        self.btnMdiRowDown.setText(QCoreApplication.translate("Form", u"ROW\n"
"DOWN", None))
        self.tabs_ctl_run_right.setTabText(self.tabs_ctl_run_right.indexOf(self.tab_7), QCoreApplication.translate("Form", u"TOOL PATH", None))
        self.file_frame.setProperty(u"styleClass", QCoreApplication.translate("Form", u"comboFrame", None))
        self.label_7.setText(QCoreApplication.translate("Form", u"OPEN:", None))
        self.label_7.setProperty(u"styleClass", QCoreApplication.translate("Form", u"comboFrame", None))
        self.btn_syntax_highlight.setText(QCoreApplication.translate("Form", u"COLORISE", None))
        self.btn_edit.setText(QCoreApplication.translate("Form", u"EDIT", None))
        self.btn_edit.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"New Rule\", \"property\": \"Enable\", \"expression\": \"True if ch[0] != 'No file loaded' else False\", \"channels\": [{\"url\": \"status:file\", \"trigger\": true}]}]", None))
        self.btn_save.setText(QCoreApplication.translate("Form", u"SAVE", None))
        self.btn_open_dialog.setText(QCoreApplication.translate("Form", u"OPEN", None))
        self.btn_open_dialog.setProperty(u"dialogName", QCoreApplication.translate("Form", u"open_file", None))
        self.btn_reload.setText(QCoreApplication.translate("Form", u"RELOAD", None))
        self.btn_reload.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"New Rule\", \"property\": \"Enable\", \"expression\": \"True if ch[0] != 'No file loaded' else False\", \"channels\": [{\"url\": \"status:file\", \"trigger\": true}]}]", None))
        self.dialogbutton_2.setText(QCoreApplication.translate("Form", u"RECENT", None))
        self.dialogbutton_2.setProperty(u"dialogName", QCoreApplication.translate("Form", u"recent_files", None))
        self.tabs_ctl_run_right.setTabText(self.tabs_ctl_run_right.indexOf(self.tab_5), QCoreApplication.translate("Form", u"GCODE", None))
        self.groupbox_20.setTitle(QCoreApplication.translate("Form", u"TO DO", None))
        self.groupbox_21.setTitle(QCoreApplication.translate("Form", u"DONE", None))
        self.groupbox_22.setTitle(QCoreApplication.translate("Form", u"JOB DESCRIPTION/INSTRUCTIONS", None))
        self.pushButton_14.setText(QCoreApplication.translate("Form", u"RESTART JOB SEQUENCE", None))
        self.pushButton_12.setText(QCoreApplication.translate("Form", u"LOAD NEXT", None))
        self.pushButton_3.setText(QCoreApplication.translate("Form", u"REPEAT SAME", None))
        self.groupbox_25.setTitle(QCoreApplication.translate("Form", u"JOB BUNDLE", None))
        self.tabs_ctl_run_right.setTabText(self.tabs_ctl_run_right.indexOf(self.tab_13), QCoreApplication.translate("Form", u"JOB CARD LIST", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_main), QCoreApplication.translate("Form", u"CONTROL && RUN", None))
        self.groupbox_15.setTitle(QCoreApplication.translate("Form", u"PROCESS FILTERS", None))
        self.label_63.setText(QCoreApplication.translate("Form", u"CONSUMABLE", None))
        self.label_65.setText(QCoreApplication.translate("Form", u"THICKNESS", None))
        self.label_68.setText(QCoreApplication.translate("Form", u"QUALITY", None))
        self.label_64.setText(QCoreApplication.translate("Form", u"MATERIAL", None))
        self.label_67.setText(QCoreApplication.translate("Form", u"GAS", None))
        self.label_66.setText(QCoreApplication.translate("Form", u"OPERATION", None))
        self.groupbox_9.setTitle(QCoreApplication.translate("Form", u"RUN SETTINGS", None))
        self.btn_save_run_process.setText(QCoreApplication.translate("Form", u"SAVE", None))
        self.btn_del_run_process.setText(QCoreApplication.translate("Form", u"DELETE", None))
        self.btn_new_run_process.setText(QCoreApplication.translate("Form", u"NEW", None))
        self.btn_new_run_process.setProperty(u"dialogName", QCoreApplication.translate("Form", u"new_process", None))
        self.btn_run_reload.setText(QCoreApplication.translate("Form", u"RELOAD", None))
        self.grp_filter_sub_list.setTitle(QCoreApplication.translate("Form", u"CUT LIST CHOICE", None))

        __sortingEnabled = self.filter_sub_list.isSortingEnabled()
        self.filter_sub_list.setSortingEnabled(False)
        ___qlistwidgetitem = self.filter_sub_list.item(0)
        ___qlistwidgetitem.setText(QCoreApplication.translate("Form", u"Test item 1", None));
        ___qlistwidgetitem1 = self.filter_sub_list.item(1)
        ___qlistwidgetitem1.setText(QCoreApplication.translate("Form", u"Test item 2", None));
        self.filter_sub_list.setSortingEnabled(__sortingEnabled)

        self.groupbox_16.setTitle(QCoreApplication.translate("Form", u"PROCESS PARAMETERS", None))
        self.paramKirfWidthLabel.setText(QCoreApplication.translate("Form", u"KERF WIDTH", None))
        self.param_puddlejumpdelay.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.paramKirfWidthLabel_3.setText(QCoreApplication.translate("Form", u"CUT HEIGHT", None))
        self.label_69.setText(QCoreApplication.translate("Form", u"PROCESS NAME", None))
        self.paramKirfWidthLabel_7.setText(QCoreApplication.translate("Form", u"CUT VOLTS", None))
        self.param_process_id.setText("")
        self.param_name.setText("")
        self.label_90.setText(QCoreApplication.translate("Form", u"PROCESS / CUTCHART  \n"
"/ TOOL ID", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"SETUP FEED RATE", None))
        self.paramKirfWidthLabel_5.setText(QCoreApplication.translate("Form", u"CUT FEED RATE", None))
        self.param_pauseatend.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.param_puddlejumpheight.setSuffix(QCoreApplication.translate("Form", u" %", None))
        self.paramKirfWidthLabel_4.setText(QCoreApplication.translate("Form", u"PIERCE DELAY", None))
        self.paramKirfWidthLabel_6.setText(QCoreApplication.translate("Form", u"CUT AMPS", None))
        self.paramKirfWidthLabel_9.setText(QCoreApplication.translate("Form", u"P-JUMP DELAY", None))
        self.param_cutamps.setSuffix(QCoreApplication.translate("Form", u" A", None))
        self.paramKirfWidthLabel_8.setText(QCoreApplication.translate("Form", u"P-JUMP HEIGHT", None))
        self.param_cutvolts.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.paramKirfWidthLabel_2.setText(QCoreApplication.translate("Form", u"PIERCE HEIGHT", None))
        self.paramKirfWidthLabel_10.setText(QCoreApplication.translate("Form", u"PAUSE AT END", None))
        self.paramKirfWidthLabel_11.setText(QCoreApplication.translate("Form", u"GAS PRESURE", None))
        self.param_piercedelay.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.spn_hole_thickness_ratio.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-hole-thickness-ratio", None))
        self.spn_hole_thickness_ratio.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_hole_thickness_ratio", None))
        self.spn_small_hole_threshold.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-small-hole-threshold", None))
        self.spn_small_hole_threshold.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_small_hole_threshold", None))
        self.label_79.setText(QCoreApplication.translate("Form", u"Leadin Arc Radius\n"
"0 = Auto calculate leadin.", None))
        self.chkb_hole_detect_enable.setText(QCoreApplication.translate("Form", u"ENABLE", None))
        self.chkb_hole_detect_enable.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-hole-detect-enable", None))
        self.chkb_hole_detect_enable.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_hole_detect_enable", None))
        self.spn_max_hole_size.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-max-hole-size", None))
        self.spn_max_hole_size.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_max_hole_size", None))
        self.spn_hole_kerf.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-hole-kerf", None))
        self.spn_hole_kerf.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_hole_kerf", None))
        self.chkb_small_hole_detect.setText(QCoreApplication.translate("Form", u"SMALL HOLE\n"
"MARKING", None))
        self.chkb_small_hole_detect.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-small-hole-detect", None))
        self.chkb_small_hole_detect.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_small_hole_detect", None))
        self.label_11.setText(QCoreApplication.translate("Form", u"Hole Size ratio relative to Material Thickness (x:1) *", None))
        self.label_73.setText(QCoreApplication.translate("Form", u"Small hole threshold", None))
        self.spn_leadin_radius.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-leadin-radius", None))
        self.spn_leadin_radius.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_leadin_radius", None))
        self.label_194.setText(QCoreApplication.translate("Form", u"Hole Kerf Width\n"
"0 = Use process kerf", None))
        self.label_70.setText(QCoreApplication.translate("Form", u"Maximum hole size to process *", None))
        self.chkb_force_straight_leadin.setText(QCoreApplication.translate("Form", u"STRAIGHT\n"
"LEADINS", None))
        self.chkb_force_straight_leadin.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-force-straight-leadin", None))
        self.chkb_force_straight_leadin.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_force_straight_leadin", None))
        self.chkb_is_kerf_compensated.setText(QCoreApplication.translate("Form", u"KERF\n"
"ADJUSTED", None))
        self.chkb_is_kerf_compensated.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-is-kerf-compensated", None))
        self.chkb_use_hidef.setText(QCoreApplication.translate("Form", u"USE HIDEF\n"
"IF AVILABLE", None))
        self.chkb_use_hidef.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-use-hidef", None))
        self.chkb_use_hidef.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_use_hidef", None))
        self.spn_overburn_percent_2.setSuffix(QCoreApplication.translate("Form", u" %", None))
        self.spn_overburn_percent_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-overburn-percent", None))
        self.spn_overburn_percent_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_overburn_percent", None))
        self.label_85.setText(QCoreApplication.translate("Form", u"Adjustment", None))
        self.label_200.setText(QCoreApplication.translate("Form", u"ARC 3", None))
        self.spn_arc3_percent_3.setSuffix(QCoreApplication.translate("Form", u"%", None))
        self.spn_arc3_percent_3.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-arc3-percent", None))
        self.spn_arc3_percent_3.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_arc3_percent", None))
        self.spn_leadin_percent_2.setSuffix(QCoreApplication.translate("Form", u" %", None))
        self.spn_leadin_percent_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-leadin-percent", None))
        self.spn_leadin_percent_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_leadin_percent", None))
        self.spn_overburn_distance_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-overburn-adjustment", None))
        self.spn_overburn_distance_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_overburn_adjustment", None))
        self.label_80.setText(QCoreApplication.translate("Form", u"ARC 1", None))
        self.spn_arc2_percent_2.setSuffix(QCoreApplication.translate("Form", u" %", None))
        self.spn_arc2_percent_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-arc2-percent", None))
        self.spn_arc2_percent_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_arc2_percent", None))
        self.label_84.setText(QCoreApplication.translate("Form", u"ARC 2", None))
        self.label_83.setText(QCoreApplication.translate("Form", u"% OF FEED", None))
        self.spn_arc1_percent_2.setSuffix(QCoreApplication.translate("Form", u" %", None))
        self.spn_arc1_percent_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-arc1-percent", None))
        self.spn_arc1_percent_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_arc1_percent", None))
        self.label_82.setText(QCoreApplication.translate("Form", u"LEAD-IN", None))
        self.label_81.setText(QCoreApplication.translate("Form", u"OVERBURN", None))
        self.label_76.setText("")
        self.label_71.setText(QCoreApplication.translate("Form", u"* The value used is the larger of the two supplied once calculated and processing commences.", None))
        self.label_74.setText(QCoreApplication.translate("Form", u"<html><head/><body><p>Overburn can push torch-off past 12 oclock position. </p><p>Torch-off is at kerf size BEFORE 12 oclock. Overburn Adjustment shifts that position left for a positive value and right for a negative value.</p></body></html>", None))
        self.tab_holes_and_slots.setTabText(self.tab_holes_and_slots.indexOf(self.tab_holes), QCoreApplication.translate("Form", u"HOLES", None))
        self.groupbox_19.setTitle(QCoreApplication.translate("Form", u"SLOT DETECTION (PLACE HOLDER)", None))
        self.chkb_slot_detect_enable.setText(QCoreApplication.translate("Form", u"Enable", None))
        self.tab_holes_and_slots.setTabText(self.tab_holes_and_slots.indexOf(self.tab_slots), QCoreApplication.translate("Form", u"SLOTS", None))
        self.label_196.setText(QCoreApplication.translate("Form", u"<html><head/><body><p>Hole process expects the incoming gcode to have no inherent offset for kerf. i.e. the code tracks the same line as was defined by the source dxf file used for gcode production.</p><p>Put another way, there is no offset processing of the hole during gcode generation.</p><p>The hole processing code identifies holes then generates the new circle/arc code using the paramters supplied. If the plasma machine creates undersized holes when using the normal mnaterial kerf width there is the ability to set a hole specific kerf width. This allows fine tuning of hole generation based on the characteristics of a specific plasma torch/machine combination.</p></body></html>", None))
        self.tab_holes_and_slots.setTabText(self.tab_holes_and_slots.indexOf(self.tab_hole_insructions), QCoreApplication.translate("Form", u"Hole Processing Instructions", None))
        self.groupbox_14.setTitle(QCoreApplication.translate("Form", u"THC, TORCH && OHMIC", None))
        self.thc_enabled.setText(QCoreApplication.translate("Form", u"THC ENABLED", None))
        self.thc_enabled.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_enabled", None))
        self.chkb_auto_volts.setText(QCoreApplication.translate("Form", u"THC AUTO VOLTS", None))
        self.chkb_auto_volts.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-auto-volts", None))
        self.chkb_auto_volts.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_auto_volts", None))
        self.chkb_vad.setText(QCoreApplication.translate("Form", u"THC (VELOCITY)\n"
"ANTI-DIVE", None))
        self.chkb_vad.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-vad", None))
        self.chkb_vad.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_vad", None))
        self.chkb_void_sense.setText(QCoreApplication.translate("Form", u"VOID ANTI DIVE", None))
        self.chkb_void_sense.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-void-sense", None))
        self.chkb_void_sense.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_void_sense", None))
        self.chkb_mesh_sense.setText(QCoreApplication.translate("Form", u"MESH SENSE", None))
        self.chkb_mesh_sense.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"plasma-mesh-sense", None))
        self.chkb_mesh_sense.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_mesh_sense", None))
        self.chkb_ohmic_sense.setText(QCoreApplication.translate("Form", u"OHMIC SENSE", None))
        self.chkb_ohmic_sense.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"ohmic-sensing-enabled", None))
        self.chkb_ohmic_sense.setProperty(u"settingName", QCoreApplication.translate("Form", u"ohmic_sensing_enabled", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_8), QCoreApplication.translate("Form", u"CUT && PROCESS", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_10), QCoreApplication.translate("Form", u"PROCESS EDITOR", None))
        self.groupbox_10.setTitle(QCoreApplication.translate("Form", u"JOB && TOTAL", None))
        self.label_58.setText(QCoreApplication.translate("Form", u"RAPID TIME", None))
        self.label_50.setText(QCoreApplication.translate("Form", u"JOB", None))
        self.label_56.setText(QCoreApplication.translate("Form", u"TORCH ON TIME", None))
        self.label_52.setText(QCoreApplication.translate("Form", u"TOTAL", None))
        self.label_57.setText(QCoreApplication.translate("Form", u"PROG RUN TIME", None))
        self.label_54.setText(QCoreApplication.translate("Form", u"CUT LENGTH", None))
        self.label_53.setText(QCoreApplication.translate("Form", u"PIERCE COUNT", None))
        self.label_51.setText(QCoreApplication.translate("Form", u"ITEM", None))
        self.label_55.setText(QCoreApplication.translate("Form", u"CUT TIME", None))
        self.label_59.setText(QCoreApplication.translate("Form", u"PROBE TIME", None))
        self.pushButton_11.setText(QCoreApplication.translate("Form", u"RESET", None))
        self.hallabel_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"stats-cut-length", None))
        self.hallabel_3.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"stats-cut-time", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_12), QCoreApplication.translate("Form", u"STATISTICS", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_parameters), QCoreApplication.translate("Form", u"CUT && MATERIAL", None))
        self.btn_7.setText("")
        self.btn_13.setText("")
#if QT_CONFIG(shortcut)
        self.btn_13.setShortcut(QCoreApplication.translate("Form", u"Ctrl+S", None))
#endif // QT_CONFIG(shortcut)
        self.btn_12.setText("")
        self.btn_2.setText("")
        self.btn_6.setText("")
        self.btn_9.setText("")
        self.btn_4.setText("")
        self.btn_5.setText("")
        self.btn_3.setText("")
        self.btn_11.setText("")
        self.btn_8.setText("")
        self.btn_1.setText("")
        self.btn_0.setText("")
        self.label_49.setText(QCoreApplication.translate("Form", u"Circle Diameter", None))
        self.label_179.setText("")
        self.label_75.setText(QCoreApplication.translate("Form", u"Width", None))
        self.label_77.setText(QCoreApplication.translate("Form", u"Height", None))
        self.label_180.setText("")
        self.label_115.setText(QCoreApplication.translate("Form", u"Outer Diamter", None))
        self.label_116.setText(QCoreApplication.translate("Form", u"Inner Diameter", None))
        self.label_181.setText("")
        self.label_117.setText(QCoreApplication.translate("Form", u"Width", None))
        self.label_118.setText(QCoreApplication.translate("Form", u"Height", None))
        self.label_182.setText("")
        self.label_119.setText(QCoreApplication.translate("Form", u"Use negative vlaues to bring closer", None))
        self.id4_error_text.setText("")
        self.label_120.setText(QCoreApplication.translate("Form", u"<html><head/><body><p>If &quot;rb&quot; is set to 0 then the base of the lifting lug will be flat. If a curved base is desired then set the required arc radius in setting &quot;rb&quot;.</p><p>NOTE: rb is the radius of the curve. rb*2 MUST be &gt;= to w1 </p></body></html>", None))
        self.label_121.setText(QCoreApplication.translate("Form", u"h2", None))
        self.label_122.setText(QCoreApplication.translate("Form", u"Pair Separation", None))
        self.label_123.setText(QCoreApplication.translate("Form", u"d2", None))
        self.label_124.setText(QCoreApplication.translate("Form", u"rb", None))
        self.id4_chk_pair.setText(QCoreApplication.translate("Form", u"Generate Cutting Pair", None))
        self.label_125.setText(QCoreApplication.translate("Form", u"w1", None))
        self.label_126.setText(QCoreApplication.translate("Form", u"h1", None))
        self.label_127.setText(QCoreApplication.translate("Form", u"d1", None))
        self.label_183.setText("")
        self.label_128.setText(QCoreApplication.translate("Form", u"w1", None))
        self.label_129.setText(QCoreApplication.translate("Form", u"w2", None))
        self.label_130.setText(QCoreApplication.translate("Form", u"h", None))
        self.label_184.setText("")
        self.label_136.setText(QCoreApplication.translate("Form", u"ID", None))
        self.label_132.setText(QCoreApplication.translate("Form", u"PCD", None))
        self.label_131.setText(QCoreApplication.translate("Form", u"OD", None))
        self.id6_combo_hole.setItemText(0, QCoreApplication.translate("Form", u"Round", None))
        self.id6_combo_hole.setItemText(1, QCoreApplication.translate("Form", u"Square", None))
        self.id6_combo_hole.setItemText(2, QCoreApplication.translate("Form", u"None", None))

        self.label_134.setText(QCoreApplication.translate("Form", u"hd", None))
        self.label_135.setText(QCoreApplication.translate("Form", u"Hole style", None))
        self.label_133.setText(QCoreApplication.translate("Form", u"Num Holes", None))
        self.label_185.setText("")
        self.label_137.setText(QCoreApplication.translate("Form", u"w", None))
        self.label_138.setText(QCoreApplication.translate("Form", u"h", None))
        self.label_139.setText(QCoreApplication.translate("Form", u"pd", None))
        self.label_140.setText(QCoreApplication.translate("Form", u"o", None))
        self.label_186.setText("")
        self.label_143.setText(QCoreApplication.translate("Form", u"PCD", None))
        self.label_146.setText(QCoreApplication.translate("Form", u"Num of bolts", None))
        self.label_144.setText(QCoreApplication.translate("Form", u"Bolt Diameter", None))
        self.label_141.setText(QCoreApplication.translate("Form", u"ID", None))
        self.label_145.setText(QCoreApplication.translate("Form", u"sw", None))
        self.label_142.setText(QCoreApplication.translate("Form", u"wt", None))
        self.label_187.setText("")
        self.label_152.setText(QCoreApplication.translate("Form", u"vs", None))
        self.label_150.setText(QCoreApplication.translate("Form", u"hs", None))
        self.label_149.setText(QCoreApplication.translate("Form", u"Horizontal holes", None))
        self.label_151.setText(QCoreApplication.translate("Form", u"Verticle holes", None))
        self.label_155.setText(QCoreApplication.translate("Form", u"Central Hole", None))
        self.label_147.setText(QCoreApplication.translate("Form", u"w", None))
        self.label_148.setText(QCoreApplication.translate("Form", u"h", None))
        self.label_153.setText(QCoreApplication.translate("Form", u"Hole Diam", None))
        self.label_154.setText(QCoreApplication.translate("Form", u"Fillet radius", None))
        self.id9_combo_ch.setItemText(0, QCoreApplication.translate("Form", u"None", None))
        self.id9_combo_ch.setItemText(1, QCoreApplication.translate("Form", u"Round", None))
        self.id9_combo_ch.setItemText(2, QCoreApplication.translate("Form", u"Rectangle", None))

        self.label_156.setText(QCoreApplication.translate("Form", u"Central hole size", None))
        self.label_157.setText(QCoreApplication.translate("Form", u"Center hole Width", None))
        self.label_158.setText(QCoreApplication.translate("Form", u"Center Hole Height", None))
        self.label_159.setText(QCoreApplication.translate("Form", u"Center Fillet Radius", None))
        self.id9_dbl_cha.setSuffix(QCoreApplication.translate("Form", u" deg", None))
        self.label_160.setText(QCoreApplication.translate("Form", u"Center Hole Angle", None))
        self.label_161.setText(QCoreApplication.translate("Form", u"Center Hole X Offset", None))
        self.label_162.setText(QCoreApplication.translate("Form", u"Center Hole Y Offset", None))
        self.label_188.setText("")
        self.label_163.setText(QCoreApplication.translate("Form", u"w", None))
        self.label_164.setText(QCoreApplication.translate("Form", u"h", None))
        self.label_165.setText(QCoreApplication.translate("Form", u"w1", None))
        self.label_166.setText(QCoreApplication.translate("Form", u"h1", None))
        self.label_189.setText("")
        self.label_167.setText(QCoreApplication.translate("Form", u"w", None))
        self.label_170.setText(QCoreApplication.translate("Form", u"a", None))
        self.id11_dbl_a.setSuffix(QCoreApplication.translate("Form", u" deg", None))
        self.label_169.setText(QCoreApplication.translate("Form", u"c2", None))
        self.label_168.setText(QCoreApplication.translate("Form", u"h", None))
        self.label_171.setText(QCoreApplication.translate("Form", u"c1", None))
        self.id11_chk_pair.setText(QCoreApplication.translate("Form", u"Generate Cutting Pair", None))
        self.label_195.setText(QCoreApplication.translate("Form", u"X offset", None))
        self.label_193.setText(QCoreApplication.translate("Form", u"Y offset", None))
        self.label_190.setText("")
        self.label_172.setText(QCoreApplication.translate("Form", u"w", None))
        self.label_173.setText(QCoreApplication.translate("Form", u"h", None))
        self.label_174.setText(QCoreApplication.translate("Form", u"h1", None))
        self.label_175.setText(QCoreApplication.translate("Form", u"w1", None))
        self.label_191.setText("")
        self.label_176.setText(QCoreApplication.translate("Form", u"h", None))
        self.label_177.setText(QCoreApplication.translate("Form", u"w", None))
        self.label_178.setText(QCoreApplication.translate("Form", u"c", None))
        self.label_192.setText("")
        self.label_198.setText(QCoreApplication.translate("Form", u"Smart Hole Processing Active", None))
        self.label_197.setText(QCoreApplication.translate("Form", u"Internal Kerf", None))
        self.label_199.setText(QCoreApplication.translate("Form", u"Internal Kerf = 0 will default to using material kerf from Cur Process.", None))
        self.btn_qs_refresh.setText(QCoreApplication.translate("Form", u"Refresh", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_conversational), QCoreApplication.translate("Form", u"QUICKSHAPES", None))
        self.groupbox.setTitle(QCoreApplication.translate("Form", u"ARC", None))
        self.label_31.setText(QCoreApplication.translate("Form", u"MAX. STARTS", None))
        self.arc_voltage_scale.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.arc_voltage_scale.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_voltage_scale", None))
        self.label_32.setText(QCoreApplication.translate("Form", u"RETRY DELAY", None))
        self.arc_retry_delay.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.arc_retry_delay.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_retry_delay", None))
        self.arc_voltage_offset.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.arc_voltage_offset.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_voltage_offset", None))
        self.label_37.setText(QCoreApplication.translate("Form", u"OK LOW VOLTS", None))
        self.label_34.setText(QCoreApplication.translate("Form", u"VOLTAGE OFFSET", None))
        self.label_35.setText(QCoreApplication.translate("Form", u"HEIGHT PER VOLT", None))
        self.label_36.setText(QCoreApplication.translate("Form", u"OK HIGH VOLTS", None))
        self.label_33.setText(QCoreApplication.translate("Form", u"VOLTAGE SCALE", None))
        self.label_30.setText(QCoreApplication.translate("Form", u"FAIL TIMEOUT", None))
        self.arc_max_starts.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_max_starts", None))
        self.arc_fail_timeout.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.arc_fail_timeout.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_fail_timeout", None))
        self.arc_height_per_volt.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_height_per_volt", None))
        self.arc_ok_high_volts.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.arc_ok_high_volts.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_ok_high_volts", None))
        self.arc_ok_low_volts.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.arc_ok_low_volts.setProperty(u"settingName", QCoreApplication.translate("Form", u"arc_ok_low_volts", None))
        self.groupbox_2.setTitle(QCoreApplication.translate("Form", u"THC", None))
        self.thc_pid_d_gain.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_pid_d_gain", None))
        self.thc_threshold.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.thc_threshold.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_threshold", None))
        self.label_27.setText(QCoreApplication.translate("Form", u"PID I GAIN", None))
        self.label_24.setText(QCoreApplication.translate("Form", u"PID P GAIN (SPEED)", None))
        self.label_23.setText(QCoreApplication.translate("Form", u"THRESHOLD", None))
        self.thc_delay.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.thc_delay.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_delay", None))
        self.label_28.setText(QCoreApplication.translate("Form", u"PID D GAIN", None))
        self.label_22.setText(QCoreApplication.translate("Form", u"DELAY", None))
        self.thc_pid_p_gain.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_pid_p_gain", None))
        self.thc_pid_i_gain.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_pid_i_gain", None))
        self.label_25.setText(QCoreApplication.translate("Form", u"VAD THRESHOLD", None))
        self.thc_vad_threshold.setSuffix(QCoreApplication.translate("Form", u" %", None))
        self.thc_vad_threshold.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_vad_threshold", None))
        self.label_26.setText(QCoreApplication.translate("Form", u"VOID OVERRIDE", None))
        self.label_29.setText(QCoreApplication.translate("Form", u"SAFE HEIGHT", None))
        self.label_93.setText(QCoreApplication.translate("Form", u"MAX THC FEED RATE", None))
        self.thc_safe_height.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_safe_height", None))
        self.thc_void_override.setSuffix(QCoreApplication.translate("Form", u" %", None))
        self.thc_void_override.setProperty(u"settingName", QCoreApplication.translate("Form", u"thc_void_override", None))
        self.thc_feed_rate.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.groupbox_4.setTitle(QCoreApplication.translate("Form", u"SCRIBE && SPOT", None))
        self.scribe_arm_delay.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.scribe_arm_delay.setProperty(u"settingName", QCoreApplication.translate("Form", u"scribe_arm_delay", None))
        self.scribe_on_delay.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.scribe_on_delay.setProperty(u"settingName", QCoreApplication.translate("Form", u"scribe_on_delay", None))
        self.label_46.setText(QCoreApplication.translate("Form", u"SCRIBE ON DELAY", None))
        self.label_48.setText(QCoreApplication.translate("Form", u"SPOT DELAY", None))
        self.label_45.setText(QCoreApplication.translate("Form", u"SCRIBE ARM DELAY", None))
        self.label_47.setText(QCoreApplication.translate("Form", u"SPOT THRESHOLD", None))
        self.spot_threshold.setSuffix(QCoreApplication.translate("Form", u" V", None))
        self.spot_threshold.setProperty(u"settingName", QCoreApplication.translate("Form", u"spot_threshold", None))
        self.spot_delay.setSuffix(QCoreApplication.translate("Form", u" ms", None))
        self.spot_delay.setProperty(u"settingName", QCoreApplication.translate("Form", u"spot_delay", None))
        self.groupbox_3.setTitle(QCoreApplication.translate("Form", u"PROBING && MOTION", None))
        self.label_38.setText(QCoreApplication.translate("Form", u"FLOAT TRAVEL", None))
        self.probe_height.setProperty(u"settingName", QCoreApplication.translate("Form", u"probe_height", None))
        self.probe_float_travel.setProperty(u"settingName", QCoreApplication.translate("Form", u"probe_float_travel", None))
        self.label_43.setText(QCoreApplication.translate("Form", u"SKIP IHS", None))
        self.label_44.setText(QCoreApplication.translate("Form", u"<html><head/><body><p>SETUP SPEED (units per min)</p></body></html>", None))
        self.label_40.setText(QCoreApplication.translate("Form", u"PROBE HEIGHT", None))
        self.probe_ohmic_retries.setProperty(u"settingName", QCoreApplication.translate("Form", u"probe_ohmic_retries", None))
        self.label_41.setText(QCoreApplication.translate("Form", u"OHMIC PROBE OFFSET", None))
        self.label_42.setText(QCoreApplication.translate("Form", u"OHMIC RETRIES", None))
        self.probe_skip_ihs.setProperty(u"settingName", QCoreApplication.translate("Form", u"probe_skip_ihs", None))
        self.label_39.setText(QCoreApplication.translate("Form", u"PROBE SPEED", None))
        self.probe_offset.setProperty(u"settingName", QCoreApplication.translate("Form", u"probe_offset", None))
        self.probe_setup_speed.setProperty(u"settingName", QCoreApplication.translate("Form", u"probe_setup_speed", None))
        self.btn_probe_test.setText(QCoreApplication.translate("Form", u"PROBE TEST", None))
        self.probe_speed.setProperty(u"settingName", QCoreApplication.translate("Form", u"probe_speed", None))
        self.tabwidget_3.setTabText(self.tabwidget_3.indexOf(self.tab_settings_thcarc), QCoreApplication.translate("Form", u"THC / ARC / PROBE && MARKING", None))
        self.groupbox_18.setTitle(QCoreApplication.translate("Form", u"JOB FAVORITES", None))
        self.pushButton.setText(QCoreApplication.translate("Form", u"ADD", None))
        self.pushButton_2.setText(QCoreApplication.translate("Form", u"NEW", None))
        self.groupbox_17.setTitle(QCoreApplication.translate("Form", u"MACHINE && TABLE SETTINGS", None))
        self.label_62.setText(QCoreApplication.translate("Form", u"MACHINE", None))
        self.label_101.setText(QCoreApplication.translate("Form", u"CONSUMABLE X OFFSET", None))
        self.label_60.setText(QCoreApplication.translate("Form", u"DISTANCE SYSTEM", None))
        self.filter_distance_system.setItemText(0, QCoreApplication.translate("Form", u"mm", None))
        self.filter_distance_system.setItemText(1, QCoreApplication.translate("Form", u"inch", None))

        self.plasma_torch_pulse_sec.setSuffix(QCoreApplication.translate("Form", u" S", None))
        self.plasma_torch_pulse_sec.setProperty(u"settingName", QCoreApplication.translate("Form", u"plasma_torch_pulse_sec", None))
        self.label_92.setText(QCoreApplication.translate("Form", u"TORCH PULSE DURATION", None))
        self.filter_pressure_system.setItemText(0, QCoreApplication.translate("Form", u"psi", None))

        self.label_100.setText(QCoreApplication.translate("Form", u"FRAMING FEED", None))
        self.label_61.setText(QCoreApplication.translate("Form", u"PRESSURE SYSTEM", None))
        self.label_102.setText(QCoreApplication.translate("Form", u"CONSUMABLE XY FEEDRATE", None))
        self.filter_machine.setItemText(0, QCoreApplication.translate("Form", u"Cutskill 60", None))
        self.filter_machine.setItemText(1, QCoreApplication.translate("Form", u"Hypertherm 45", None))
        self.filter_machine.setItemText(2, QCoreApplication.translate("Form", u"Thermal Dynamics A120", None))

        self.consumable_xy_feed_rate.setProperty(u"settingName", QCoreApplication.translate("Form", u"consumable_xy_feed_rate", None))
        self.framing_feed_rate.setProperty(u"settingName", QCoreApplication.translate("Form", u"framing_feed_rate", None))
        self.label_103.setText(QCoreApplication.translate("Form", u"CONSUMABLE Y OFFSET", None))
        self.consumable_offset_x.setProperty(u"settingName", QCoreApplication.translate("Form", u"consumable_offset_x", None))
        self.consumable_offset_y.setProperty(u"settingName", QCoreApplication.translate("Form", u"consumable_offset_y", None))
        self.groupbox_27.setTitle(QCoreApplication.translate("Form", u"LASER, CAMERA && SCRIBE OFFSETS", None))
        self.camera_offset_x.setProperty(u"settingName", QCoreApplication.translate("Form", u"camera_offset_x", None))
        self.label_87.setText(QCoreApplication.translate("Form", u"Y", None))
        self.scribe_offset_x.setProperty(u"settingName", QCoreApplication.translate("Form", u"scribe_offset_x", None))
        self.laser_offset_y.setProperty(u"settingName", QCoreApplication.translate("Form", u"laser_offset_y", None))
        self.label_88.setText(QCoreApplication.translate("Form", u"SCRIBE", None))
        self.laser_offset_x.setProperty(u"settingName", QCoreApplication.translate("Form", u"laser_offset_x", None))
        self.label_89.setText(QCoreApplication.translate("Form", u"CAMERA", None))
        self.label_78.setText(QCoreApplication.translate("Form", u"LASER", None))
        self.scribe_offset_y.setProperty(u"settingName", QCoreApplication.translate("Form", u"scribe_offset_y", None))
        self.camera_offset_y.setProperty(u"settingName", QCoreApplication.translate("Form", u"camera_offset_y", None))
        self.label_86.setText(QCoreApplication.translate("Form", u"X", None))
        self.label_104.setText(QCoreApplication.translate("Form", u"OHMIC", None))
        self.plasmahaldoublespinbox.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"ohmic-offset-x", None))
        self.plasmahaldoublespinbox.setProperty(u"settingName", QCoreApplication.translate("Form", u"ohmic_offset_x", None))
        self.plasmahaldoublespinbox_2.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"ohmic-offset-y", None))
        self.plasmahaldoublespinbox_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"ohmic_offset_y", None))
        self.groupbox_24.setTitle(QCoreApplication.translate("Form", u"DB SEEDING", None))
        self.lne_seed_source.setText(QCoreApplication.translate("Form", u"~/linuxcnc/configs/sim.monokrom/plasmac/master-seed-source.csv", None))
        self.btn_seed_db.setText(QCoreApplication.translate("Form", u"Seed DB from file", None))
        self.lbl_seed_status.setText("")
        self.groupbox_23.setTitle(QCoreApplication.translate("Form", u"PROCESS RUN SAVE/DELETE CONFIRMS", None))
        self.ask_on_run_save.setText(QCoreApplication.translate("Form", u"Ask before Process Run save", None))
        self.ask_on_run_save.setProperty(u"settingName", QCoreApplication.translate("Form", u"run_save_confirm", None))
        self.ask_on_run_delete.setText(QCoreApplication.translate("Form", u"Ask before Process Run delete", None))
        self.ask_on_run_delete.setProperty(u"settingName", QCoreApplication.translate("Form", u"run_delete_confirm", None))
        self.groupbox_7.setTitle(QCoreApplication.translate("Form", u"DRO FORMAT", None))
        self.settings_lineedit_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.millimeter-format", None))
        self.settings_lineedit.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.inch-format", None))
        self.settings_lineedit_3.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.degree-format", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"Display Units", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"Degree Format", None))
        self.settingscombobox.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.display-units", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"Millimeter Format", None))
        self.label.setText(QCoreApplication.translate("Form", u"Inch Format", None))
        self.groupbox_8.setTitle(QCoreApplication.translate("Form", u"USER INPUT", None))
        self.settings_checkbox.setText(QCoreApplication.translate("Form", u"On-Screen Keyboard ", None))
        self.settings_checkbox.setProperty(u"settingName", QCoreApplication.translate("Form", u"virtual-input.enable", None))
        self.tabwidget_3.setTabText(self.tabwidget_3.indexOf(self.tab_settings_machine), QCoreApplication.translate("Form", u"MACHINE", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_settings), QCoreApplication.translate("Form", u"SETTINGS", None))
        self.groupbox_11.setTitle(QCoreApplication.translate("Form", u"LOG", None))
        self.groupbox_5.setTitle(QCoreApplication.translate("Form", u"ACTIVE G-CODES && M-CODES", None))
        self.statuslabel.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"gcodes\", \"property\": \"Text\", \"expression\": \"ch[0]\", \"channels\": [{\"url\": \"status:gcodes?string\", \"trigger\": true}]}]", None))
        self.statuslabel_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"mcodes\", \"property\": \"Text\", \"expression\": \"ch[0]\", \"channels\": [{\"url\": \"status:mcodes?string\", \"trigger\": true}]}]", None))
        self.groupbox_28.setTitle(QCoreApplication.translate("Form", u"TOOLS", None))
        self.hal_meter.setText(QCoreApplication.translate("Form", u"HAL Meter", None))
        self.hal_meter.setProperty(u"actionName", QCoreApplication.translate("Form", u"tool.halmeter", None))
        self.hal_scope.setText(QCoreApplication.translate("Form", u"HAL Scope", None))
        self.hal_scope.setProperty(u"actionName", QCoreApplication.translate("Form", u"tool.halscope", None))
        self.hal_show.setText(QCoreApplication.translate("Form", u"HAL Show", None))
        self.hal_show.setProperty(u"actionName", QCoreApplication.translate("Form", u"tool.halshow", None))
        self.lcnc_status.setText(QCoreApplication.translate("Form", u"LinuxCNC Status", None))
        self.lcnc_status.setProperty(u"actionName", QCoreApplication.translate("Form", u"tool.status", None))
        self.calibration.setText(QCoreApplication.translate("Form", u"Calibration", None))
        self.calibration.setProperty(u"actionName", QCoreApplication.translate("Form", u"tool.calibration", None))
        self.classic_ladder_plc.setText(QCoreApplication.translate("Form", u"Classic Ladder PLC", None))
        self.classic_ladder_plc.setProperty(u"actionName", QCoreApplication.translate("Form", u"tool.classicladder", None))
        self.exitAppBtn.setText(QCoreApplication.translate("Form", u"EXIT MONOKROM", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_diagnostics), QCoreApplication.translate("Form", u"DIAGNOSTICS", None))
    # retranslateUi

