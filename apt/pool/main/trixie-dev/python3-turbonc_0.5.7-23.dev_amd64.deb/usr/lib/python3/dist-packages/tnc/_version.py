# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post39.dev0+5d3b0c0"
__version_tuple__ = (0, 5, 5, "post39", "dev0", "5d3b0c0")
