# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'probe_basic_lathe.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QAbstractScrollArea, QApplication, QButtonGroup,
    QComboBox, QFrame, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QLayout, QListView,
    QListWidgetItem, QMenu, QMenuBar, QPushButton,
    QSizePolicy, QSplitter, QStackedWidget, QStatusBar,
    QTabWidget, QVBoxLayout, QWidget)

from gcodeeditor import GCodeEditor
from qtpyvcp.widgets.button_widgets.action_button import ActionButton
from qtpyvcp.widgets.button_widgets.mdi_button import MDIButton
from qtpyvcp.widgets.button_widgets.subcall_button import SubCallButton
from qtpyvcp.widgets.button_widgets.vcpvar_button import VCPVarPushButton
from qtpyvcp.widgets.containers.stack import VCPStackedWidget
from qtpyvcp.widgets.display_widgets.designer_plugins import VTKBackPlot
from qtpyvcp.widgets.display_widgets.notification_widget import NotificationWidget
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel
from qtpyvcp.widgets.form_widgets.main_window import VCPMainWindow
from qtpyvcp.widgets.hal_widgets.hal_bar_indicator import HalBarIndicator
from qtpyvcp.widgets.hal_widgets.hal_label import HalLabel
from qtpyvcp.widgets.input_widgets.action_slider import ActionSlider
from qtpyvcp.widgets.input_widgets.dro_line_edit import DROLineEdit
from qtpyvcp.widgets.input_widgets.file_system import (FileSystemTable, RemovableDeviceComboBox)
from qtpyvcp.widgets.input_widgets.jog_increment import JogIncrementWidget
from qtpyvcp.widgets.input_widgets.lathe_tool_table import LatheToolTable
from qtpyvcp.widgets.input_widgets.line_edit import VCPLineEdit
from qtpyvcp.widgets.input_widgets.mdientry_widget import MDIEntry
from qtpyvcp.widgets.input_widgets.mdihistory_widget import MDIHistory
from qtpyvcp.widgets.input_widgets.offset_table import OffsetTable
from qtpyvcp.widgets.input_widgets.recent_file_combobox import RecentFileComboBox
from qtpyvcp.widgets.input_widgets.setting_slider import (VCPSettingsLineEdit, VCPSettingsPushButton, VCPSettingsSlider)
from qtpyvcp.widgets.input_widgets.var_line_edit import VCPVarLineEdit
from widgets import LatheToolTouchOff
import probe_basic_lathe_rc
import probe_basic_lathe_rc
import probe_basic_lathe_rc
import probe_basic_lathe_rc
import probe_basic_rc
import probe_basic_lathe_rc
import probe_basic_lathe_rc
import probe_basic_lathe_rc
import probe_basic_lathe_rc
import lathe_conv_rc
import probe_basic_lathe_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.setEnabled(True)
        Form.resize(1927, 1089)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        font = QFont()
        font.setFamilies([u"Probe Basic Bebas Mono"])
        font.setPointSize(11)
        Form.setFont(font)
        icon = QIcon()
        icon.addFile(u"../../../../../../../../../../../../icons/probe_basic_icon_lathe.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        Form.setWindowIcon(icon)
        Form.setToolTipDuration(-1)
        Form.setDocumentMode(False)
        Form.setProperty(u"promptAtExit", False)
        Form.setProperty(u"promot_on_exit", False)
        self.actionExit = QAction(Form)
        self.actionExit.setObjectName(u"actionExit")
        self.actionOpen = QAction(Form)
        self.actionOpen.setObjectName(u"actionOpen")
        self.actionClose = QAction(Form)
        self.actionClose.setObjectName(u"actionClose")
        self.actionReload = QAction(Form)
        self.actionReload.setObjectName(u"actionReload")
        self.actionSave_As = QAction(Form)
        self.actionSave_As.setObjectName(u"actionSave_As")
        self.actionHome_X = QAction(Form)
        self.actionHome_X.setObjectName(u"actionHome_X")
        self.actionHome_Y = QAction(Form)
        self.actionHome_Y.setObjectName(u"actionHome_Y")
        self.actionHome_Z = QAction(Form)
        self.actionHome_Z.setObjectName(u"actionHome_Z")
        self.action_EmergencyStop_toggle = QAction(Form)
        self.action_EmergencyStop_toggle.setObjectName(u"action_EmergencyStop_toggle")
        self.action_MachinePower_toggle = QAction(Form)
        self.action_MachinePower_toggle.setObjectName(u"action_MachinePower_toggle")
        self.action_MachinePower_toggle.setProperty(u"_axis", 2)
        self.actionHome_All = QAction(Form)
        self.actionHome_All.setObjectName(u"actionHome_All")
        self.actionRun_Program = QAction(Form)
        self.actionRun_Program.setObjectName(u"actionRun_Program")
        self.actionFile1 = QAction(Form)
        self.actionFile1.setObjectName(u"actionFile1")
        self.actionReport_Actual_Position = QAction(Form)
        self.actionReport_Actual_Position.setObjectName(u"actionReport_Actual_Position")
        self.actionReport_Actual_Position.setCheckable(True)
        self.actionTest = QAction(Form)
        self.actionTest.setObjectName(u"actionTest")
        self.action_Mist_toggle = QAction(Form)
        self.action_Mist_toggle.setObjectName(u"action_Mist_toggle")
        self.action_Mist_toggle.setCheckable(True)
        self.action_Flood_toggle = QAction(Form)
        self.action_Flood_toggle.setObjectName(u"action_Flood_toggle")
        self.action_Flood_toggle.setCheckable(True)
        self.centralwidget = QWidget(Form)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout_31 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_31.setObjectName(u"verticalLayout_31")
        self.verticalLayout_31.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_101 = QHBoxLayout()
        self.horizontalLayout_101.setSpacing(0)
        self.horizontalLayout_101.setObjectName(u"horizontalLayout_101")
        self.verticalLayout_30 = QVBoxLayout()
        self.verticalLayout_30.setSpacing(0)
        self.verticalLayout_30.setObjectName(u"verticalLayout_30")
        self.verticalLayout_30.setContentsMargins(0, -1, 0, 0)
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        sizePolicy.setHeightForWidth(self.tabWidget.sizePolicy().hasHeightForWidth())
        self.tabWidget.setSizePolicy(sizePolicy)
        self.tabWidget.setMaximumSize(QSize(16777215, 690))
        palette = QPalette()
        brush = QBrush(QColor(129, 133, 132, 255))
        brush.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Active, QPalette.Button, brush)
        palette.setBrush(QPalette.Active, QPalette.Base, brush)
        palette.setBrush(QPalette.Active, QPalette.Window, brush)
        brush1 = QBrush(QColor(85, 255, 127, 255))
        brush1.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Active, QPalette.Highlight, brush1)
        palette.setBrush(QPalette.Inactive, QPalette.Button, brush)
        palette.setBrush(QPalette.Inactive, QPalette.Base, brush)
        palette.setBrush(QPalette.Inactive, QPalette.Window, brush)
        palette.setBrush(QPalette.Inactive, QPalette.Highlight, brush1)
        palette.setBrush(QPalette.Disabled, QPalette.Button, brush)
        palette.setBrush(QPalette.Disabled, QPalette.Base, brush)
        palette.setBrush(QPalette.Disabled, QPalette.Window, brush)
        brush2 = QBrush(QColor(145, 141, 126, 255))
        brush2.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Disabled, QPalette.Highlight, brush2)
        self.tabWidget.setPalette(palette)
        font1 = QFont()
        font1.setFamilies([u"Probe Basic Bebas Mono"])
        font1.setPointSize(15)
        self.tabWidget.setFont(font1)
        self.tabWidget.setCursor(QCursor(Qt.CursorShape.ArrowCursor))
        self.tabWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tabWidget.setStyleSheet(u"QTabWidget QTabBar::tab {\n"
"    margin-bottom: 2px;\n"
"    min-width: 150px;\n"
"    min-height:30px;\n"
"    font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.tabWidget.setTabPosition(QTabWidget.TabPosition.South)
        self.main_tab = QWidget()
        self.main_tab.setObjectName(u"main_tab")
        self.main_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout = QHBoxLayout(self.main_tab)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(9, 9, 9, -1)
        self.widget_49 = QWidget(self.main_tab)
        self.widget_49.setObjectName(u"widget_49")
        sizePolicy.setHeightForWidth(self.widget_49.sizePolicy().hasHeightForWidth())
        self.widget_49.setSizePolicy(sizePolicy)
        self.verticalLayout_66 = QVBoxLayout(self.widget_49)
        self.verticalLayout_66.setSpacing(12)
        self.verticalLayout_66.setObjectName(u"verticalLayout_66")
        self.verticalLayout_66.setContentsMargins(0, 0, 6, 0)
        self.splitter_2 = QSplitter(self.widget_49)
        self.splitter_2.setObjectName(u"splitter_2")
        self.splitter_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.splitter_2.setLineWidth(2)
        self.splitter_2.setOrientation(Qt.Orientation.Horizontal)
        self.splitter_2.setHandleWidth(10)
        self.gcode_mdi = QStackedWidget(self.splitter_2)
        self.gcode_mdi.setObjectName(u"gcode_mdi")
        self.Page1_gcodeedit = QWidget()
        self.Page1_gcodeedit.setObjectName(u"Page1_gcodeedit")
        self.verticalLayout_4 = QVBoxLayout(self.Page1_gcodeedit)
        self.verticalLayout_4.setSpacing(6)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        self.verticalLayout_4.setContentsMargins(1, 0, 1, 0)
        self.widget_42 = QWidget(self.Page1_gcodeedit)
        self.widget_42.setObjectName(u"widget_42")
        self.widget_42.setMinimumSize(QSize(0, 40))
        self.widget_42.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_45 = QHBoxLayout(self.widget_42)
        self.horizontalLayout_45.setObjectName(u"horizontalLayout_45")
        self.horizontalLayout_45.setContentsMargins(0, 1, 0, 1)
        self.recentfilecombobox = RecentFileComboBox(self.widget_42)
        self.recentfilecombobox.setObjectName(u"recentfilecombobox")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.recentfilecombobox.sizePolicy().hasHeightForWidth())
        self.recentfilecombobox.setSizePolicy(sizePolicy1)
        self.recentfilecombobox.setMinimumSize(QSize(0, 32))
        self.recentfilecombobox.setMaximumSize(QSize(16777215, 32))
        self.recentfilecombobox.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.recentfilecombobox.setStyleSheet(u"")

        self.horizontalLayout_45.addWidget(self.recentfilecombobox)

        self.widget_41 = QWidget(self.widget_42)
        self.widget_41.setObjectName(u"widget_41")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.widget_41.sizePolicy().hasHeightForWidth())
        self.widget_41.setSizePolicy(sizePolicy2)
        self.horizontalLayout_34 = QHBoxLayout(self.widget_41)
        self.horizontalLayout_34.setSpacing(0)
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.horizontalLayout_34.setContentsMargins(1, 1, 1, 1)
        self.find_m6_button = QPushButton(self.widget_41)
        self.find_m6_button.setObjectName(u"find_m6_button")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.find_m6_button.sizePolicy().hasHeightForWidth())
        self.find_m6_button.setSizePolicy(sizePolicy3)
        self.find_m6_button.setMinimumSize(QSize(80, 32))
        self.find_m6_button.setMaximumSize(QSize(80, 32))
        self.find_m6_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.find_m6_button.setStyleSheet(u"QPushButton {\n"
"	border: 1px solid black;\n"
"    border-top-left-radius: 3px;\n"
"    border-bottom-left-radius: 3px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"	color: white;\n"
"    font: 13pt \"Probe Basic Bebas Mono\";\n"
"	background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_34.addWidget(self.find_m6_button)

        self.run_from_line_Num = VCPLineEdit(self.widget_41)
        self.run_from_line_Num.setObjectName(u"run_from_line_Num")
        sizePolicy3.setHeightForWidth(self.run_from_line_Num.sizePolicy().hasHeightForWidth())
        self.run_from_line_Num.setSizePolicy(sizePolicy3)
        self.run_from_line_Num.setMinimumSize(QSize(80, 32))
        self.run_from_line_Num.setMaximumSize(QSize(80, 32))
        self.run_from_line_Num.setMouseTracking(False)
        self.run_from_line_Num.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.run_from_line_Num.setStyleSheet(u"color: white;\n"
"border-radius: 0px;\n"
"border-top: 1px solid black;\n"
"border-bottom: 1px solid black;\n"
"font: 13pt \"Probe Basic Bebas Mono\";\n"
"background-color: transparent;")
        self.run_from_line_Num.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.run_from_line_Num.setReadOnly(True)

        self.horizontalLayout_34.addWidget(self.run_from_line_Num)

        self.run_from_line_Btn = QPushButton(self.widget_41)
        self.run_from_line_Btn.setObjectName(u"run_from_line_Btn")
        self.run_from_line_Btn.setMinimumSize(QSize(80, 32))
        self.run_from_line_Btn.setMaximumSize(QSize(80, 32))
        self.run_from_line_Btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.run_from_line_Btn.setStyleSheet(u"QPushButton {\n"
"	border: 1px solid black;\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-top-right-radius: 3px;\n"
"    border-bottom-right-radius: 3px;\n"
"    color: white;\n"
"    font: 13pt \"Probe Basic Bebas Mono\";\n"
"	background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:"
                        "pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.18 rgba(123, 123, 232, 255), stop:0.39 rgba(85, 85, 238, 255), stop:0.61 rgba(85, 85, 238, 255), stop:0.82 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.run_from_line_Btn.setCheckable(True)

        self.horizontalLayout_34.addWidget(self.run_from_line_Btn)


        self.horizontalLayout_45.addWidget(self.widget_41)


        self.verticalLayout_4.addWidget(self.widget_42)

        self.gcodeEditor = GCodeEditor(self.Page1_gcodeedit)
        self.gcodeEditor.setObjectName(u"gcodeEditor")
        self.gcodeEditor.setLineWidth(1)
        self.gcodeEditor.setCenterOnScroll(True)

        self.verticalLayout_4.addWidget(self.gcodeEditor)

        self.gcode_mdi.addWidget(self.Page1_gcodeedit)
        self.Page2_mdiedit = QWidget()
        self.Page2_mdiedit.setObjectName(u"Page2_mdiedit")
        self.horizontalLayout_35 = QHBoxLayout(self.Page2_mdiedit)
        self.horizontalLayout_35.setSpacing(30)
        self.horizontalLayout_35.setObjectName(u"horizontalLayout_35")
        self.horizontalLayout_35.setContentsMargins(6, 6, 12, 3)
        self.verticalWidget = QWidget(self.Page2_mdiedit)
        self.verticalWidget.setObjectName(u"verticalWidget")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.verticalWidget.sizePolicy().hasHeightForWidth())
        self.verticalWidget.setSizePolicy(sizePolicy4)
        self.verticalWidget.setStyleSheet(u"")
        self.verticalLayout_60 = QVBoxLayout(self.verticalWidget)
        self.verticalLayout_60.setSpacing(9)
        self.verticalLayout_60.setObjectName(u"verticalLayout_60")
        self.verticalLayout_60.setContentsMargins(0, 0, 0, 0)
        self.mdihistory = MDIHistory(self.verticalWidget)
        self.mdihistory.setObjectName(u"mdihistory")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy5.setHorizontalStretch(1)
        sizePolicy5.setVerticalStretch(1)
        sizePolicy5.setHeightForWidth(self.mdihistory.sizePolicy().hasHeightForWidth())
        self.mdihistory.setSizePolicy(sizePolicy5)
        self.mdihistory.setMinimumSize(QSize(360, 0))
        self.mdihistory.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.mdihistory.setAlternatingRowColors(False)
        self.mdihistory.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.mdihistory.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self.mdihistory.setViewMode(QListView.ViewMode.ListMode)
        self.mdihistory.setProperty(u"mdiListOrderNatural", True)

        self.verticalLayout_60.addWidget(self.mdihistory)

        self.widget_37 = QWidget(self.verticalWidget)
        self.widget_37.setObjectName(u"widget_37")
        sizePolicy4.setHeightForWidth(self.widget_37.sizePolicy().hasHeightForWidth())
        self.widget_37.setSizePolicy(sizePolicy4)
        self.widget_37.setMinimumSize(QSize(0, 40))
        self.horizontalLayout_147 = QHBoxLayout(self.widget_37)
        self.horizontalLayout_147.setSpacing(12)
        self.horizontalLayout_147.setObjectName(u"horizontalLayout_147")
        self.horizontalLayout_147.setContentsMargins(0, 1, 0, 1)
        self.btn_del_history_row_mdi = QPushButton(self.widget_37)
        self.btn_del_history_row_mdi.setObjectName(u"btn_del_history_row_mdi")
        sizePolicy1.setHeightForWidth(self.btn_del_history_row_mdi.sizePolicy().hasHeightForWidth())
        self.btn_del_history_row_mdi.setSizePolicy(sizePolicy1)
        self.btn_del_history_row_mdi.setMinimumSize(QSize(58, 50))
        self.btn_del_history_row_mdi.setMaximumSize(QSize(16777215, 50))
        font2 = QFont()
        font2.setFamilies([u"Probe Basic Bebas Mono"])
        font2.setPointSize(14)
        font2.setBold(False)
        font2.setItalic(False)
        self.btn_del_history_row_mdi.setFont(font2)
        self.btn_del_history_row_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_del_history_row_mdi.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_147.addWidget(self.btn_del_history_row_mdi)

        self.btn_del_all_mdi = QPushButton(self.widget_37)
        self.btn_del_all_mdi.setObjectName(u"btn_del_all_mdi")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.btn_del_all_mdi.sizePolicy().hasHeightForWidth())
        self.btn_del_all_mdi.setSizePolicy(sizePolicy6)
        self.btn_del_all_mdi.setMinimumSize(QSize(58, 50))
        self.btn_del_all_mdi.setMaximumSize(QSize(16777215, 50))
        self.btn_del_all_mdi.setFont(font2)
        self.btn_del_all_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_del_all_mdi.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_147.addWidget(self.btn_del_all_mdi)

        self.btn_clear_queue_mdi = QPushButton(self.widget_37)
        self.btn_clear_queue_mdi.setObjectName(u"btn_clear_queue_mdi")
        sizePolicy1.setHeightForWidth(self.btn_clear_queue_mdi.sizePolicy().hasHeightForWidth())
        self.btn_clear_queue_mdi.setSizePolicy(sizePolicy1)
        self.btn_clear_queue_mdi.setMinimumSize(QSize(58, 50))
        self.btn_clear_queue_mdi.setMaximumSize(QSize(16777215, 50))
        self.btn_clear_queue_mdi.setFont(font2)
        self.btn_clear_queue_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_clear_queue_mdi.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_147.addWidget(self.btn_clear_queue_mdi)

        self.btn_pause_mdi = QPushButton(self.widget_37)
        self.btn_pause_mdi.setObjectName(u"btn_pause_mdi")
        sizePolicy1.setHeightForWidth(self.btn_pause_mdi.sizePolicy().hasHeightForWidth())
        self.btn_pause_mdi.setSizePolicy(sizePolicy1)
        self.btn_pause_mdi.setMinimumSize(QSize(58, 50))
        self.btn_pause_mdi.setMaximumSize(QSize(16777215, 50))
        self.btn_pause_mdi.setFont(font2)
        self.btn_pause_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_pause_mdi.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")
        self.btn_pause_mdi.setCheckable(True)

        self.horizontalLayout_147.addWidget(self.btn_pause_mdi)

        self.btn_row_up_mdi = QPushButton(self.widget_37)
        self.btn_row_up_mdi.setObjectName(u"btn_row_up_mdi")
        sizePolicy6.setHeightForWidth(self.btn_row_up_mdi.sizePolicy().hasHeightForWidth())
        self.btn_row_up_mdi.setSizePolicy(sizePolicy6)
        self.btn_row_up_mdi.setMinimumSize(QSize(62, 50))
        self.btn_row_up_mdi.setMaximumSize(QSize(62, 50))
        self.btn_row_up_mdi.setFont(font1)
        self.btn_row_up_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_row_up_mdi.setStyleSheet(u"")
        icon1 = QIcon()
        icon1.addFile(u":/images/up_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_row_up_mdi.setIcon(icon1)
        self.btn_row_up_mdi.setIconSize(QSize(25, 25))

        self.horizontalLayout_147.addWidget(self.btn_row_up_mdi)


        self.verticalLayout_60.addWidget(self.widget_37)

        self.widget_39 = QWidget(self.verticalWidget)
        self.widget_39.setObjectName(u"widget_39")
        sizePolicy4.setHeightForWidth(self.widget_39.sizePolicy().hasHeightForWidth())
        self.widget_39.setSizePolicy(sizePolicy4)
        self.widget_39.setMinimumSize(QSize(0, 40))
        self.horizontalLayout_161 = QHBoxLayout(self.widget_39)
        self.horizontalLayout_161.setSpacing(12)
        self.horizontalLayout_161.setObjectName(u"horizontalLayout_161")
        self.horizontalLayout_161.setContentsMargins(0, 1, 0, 1)
        self.btn_run_from_line_mdi = QPushButton(self.widget_39)
        self.btn_run_from_line_mdi.setObjectName(u"btn_run_from_line_mdi")
        sizePolicy6.setHeightForWidth(self.btn_run_from_line_mdi.sizePolicy().hasHeightForWidth())
        self.btn_run_from_line_mdi.setSizePolicy(sizePolicy6)
        self.btn_run_from_line_mdi.setMinimumSize(QSize(58, 50))
        self.btn_run_from_line_mdi.setFont(font2)
        self.btn_run_from_line_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_run_from_line_mdi.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_161.addWidget(self.btn_run_from_line_mdi)

        self.btn_run_selection_mdi = QPushButton(self.widget_39)
        self.btn_run_selection_mdi.setObjectName(u"btn_run_selection_mdi")
        sizePolicy6.setHeightForWidth(self.btn_run_selection_mdi.sizePolicy().hasHeightForWidth())
        self.btn_run_selection_mdi.setSizePolicy(sizePolicy6)
        self.btn_run_selection_mdi.setMinimumSize(QSize(58, 50))
        self.btn_run_selection_mdi.setFont(font2)
        self.btn_run_selection_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_run_selection_mdi.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_161.addWidget(self.btn_run_selection_mdi)

        self.btn_copy_to_editor_mdi = QPushButton(self.widget_39)
        self.btn_copy_to_editor_mdi.setObjectName(u"btn_copy_to_editor_mdi")
        sizePolicy6.setHeightForWidth(self.btn_copy_to_editor_mdi.sizePolicy().hasHeightForWidth())
        self.btn_copy_to_editor_mdi.setSizePolicy(sizePolicy6)
        self.btn_copy_to_editor_mdi.setMinimumSize(QSize(58, 50))
        self.btn_copy_to_editor_mdi.setFont(font2)
        self.btn_copy_to_editor_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_copy_to_editor_mdi.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_161.addWidget(self.btn_copy_to_editor_mdi)

        self.btn_row_down_mdi = QPushButton(self.widget_39)
        self.btn_row_down_mdi.setObjectName(u"btn_row_down_mdi")
        sizePolicy3.setHeightForWidth(self.btn_row_down_mdi.sizePolicy().hasHeightForWidth())
        self.btn_row_down_mdi.setSizePolicy(sizePolicy3)
        self.btn_row_down_mdi.setMinimumSize(QSize(62, 50))
        self.btn_row_down_mdi.setMaximumSize(QSize(62, 50))
        self.btn_row_down_mdi.setFont(font1)
        self.btn_row_down_mdi.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_row_down_mdi.setStyleSheet(u"")
        icon2 = QIcon()
        icon2.addFile(u":/images/down_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_row_down_mdi.setIcon(icon2)
        self.btn_row_down_mdi.setIconSize(QSize(25, 25))

        self.horizontalLayout_161.addWidget(self.btn_row_down_mdi)


        self.verticalLayout_60.addWidget(self.widget_39)


        self.horizontalLayout_35.addWidget(self.verticalWidget)

        self.mdi_button_container_widget = QWidget(self.Page2_mdiedit)
        self.mdi_button_container_widget.setObjectName(u"mdi_button_container_widget")
        self.mdi_button_container_widget.setStyleSheet(u"")
        self.gridLayout_4 = QGridLayout(self.mdi_button_container_widget)
        self.gridLayout_4.setSpacing(12)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.gridLayout_4.setContentsMargins(0, 3, 0, 0)
        self.btnMdiBksp = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi = QButtonGroup(Form)
        self.btngrpMdi.setObjectName(u"btngrpMdi")
        self.btngrpMdi.addButton(self.btnMdiBksp)
        self.btnMdiBksp.setObjectName(u"btnMdiBksp")
        sizePolicy.setHeightForWidth(self.btnMdiBksp.sizePolicy().hasHeightForWidth())
        self.btnMdiBksp.setSizePolicy(sizePolicy)
        self.btnMdiBksp.setMinimumSize(QSize(60, 58))
        self.btnMdiBksp.setMaximumSize(QSize(60, 58))
        self.btnMdiBksp.setFont(font1)
        self.btnMdiBksp.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btnMdiBksp.setStyleSheet(u"")
        icon3 = QIcon()
        icon3.addFile(u":/images/backspace.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btnMdiBksp.setIcon(icon3)
        self.btnMdiBksp.setIconSize(QSize(40, 40))

        self.gridLayout_4.addWidget(self.btnMdiBksp, 10, 6, 1, 1)

        self.L = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.L)
        self.L.setObjectName(u"L")
        sizePolicy.setHeightForWidth(self.L.sizePolicy().hasHeightForWidth())
        self.L.setSizePolicy(sizePolicy)
        self.L.setMinimumSize(QSize(60, 58))
        self.L.setMaximumSize(QSize(60, 58))
        font3 = QFont()
        font3.setFamilies([u"Probe Basic Bebas Mono"])
        font3.setPointSize(21)
        self.L.setFont(font3)
        self.L.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.L.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon4 = QIcon()
        icon4.addFile(u"../../../../../../../../../../../../../../../../../../../../Desktop/images/left_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.L.setIcon(icon4)
        self.L.setIconSize(QSize(35, 35))

        self.gridLayout_4.addWidget(self.L, 10, 5, 1, 1)

        self.subtract = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.subtract)
        self.subtract.setObjectName(u"subtract")
        sizePolicy.setHeightForWidth(self.subtract.sizePolicy().hasHeightForWidth())
        self.subtract.setSizePolicy(sizePolicy)
        self.subtract.setMinimumSize(QSize(60, 58))
        self.subtract.setMaximumSize(QSize(60, 58))
        font4 = QFont()
        font4.setFamilies([u"Probe Basic Bebas Mono"])
        font4.setPointSize(24)
        font4.setBold(False)
        font4.setItalic(False)
        self.subtract.setFont(font4)
        self.subtract.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.subtract.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(236, 49, 74, 255), stop:0.328042 rgba(236, 49, 74, 255), stop:0.492063 rgba(240, 53, 78, 255), stop:0.703704 rgba(236, 49, 74, 255), stop:0.86 rgba(236, 49, 74, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 24pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(252, 163, 178, 255), stop: 1.0 rgba(255, 173, 188, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 23"
                        "9, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.subtract, 9, 6, 1, 1)

        self.NP2 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP2)
        self.NP2.setObjectName(u"NP2")
        sizePolicy.setHeightForWidth(self.NP2.sizePolicy().hasHeightForWidth())
        self.NP2.setSizePolicy(sizePolicy)
        self.NP2.setMinimumSize(QSize(60, 58))
        self.NP2.setMaximumSize(QSize(60, 58))
        font5 = QFont()
        font5.setFamilies([u"Probe Basic Bebas Mono"])
        font5.setPointSize(21)
        font5.setBold(False)
        font5.setItalic(False)
        self.NP2.setFont(font5)
        self.NP2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP2.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP2, 6, 8, 1, 1)

        self.btnMdiSpace = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.btnMdiSpace)
        self.btnMdiSpace.setObjectName(u"btnMdiSpace")
        sizePolicy.setHeightForWidth(self.btnMdiSpace.sizePolicy().hasHeightForWidth())
        self.btnMdiSpace.setSizePolicy(sizePolicy)
        self.btnMdiSpace.setMinimumSize(QSize(0, 58))
        self.btnMdiSpace.setMaximumSize(QSize(16777215, 58))
        font6 = QFont()
        font6.setFamilies([u"Probe Basic Bebas Mono"])
        font6.setPointSize(18)
        font6.setBold(False)
        font6.setItalic(False)
        self.btnMdiSpace.setFont(font6)
        self.btnMdiSpace.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btnMdiSpace.setStyleSheet(u"font: 18pt \"Probe Basic Bebas Mono\";")

        self.gridLayout_4.addWidget(self.btnMdiSpace, 10, 8, 1, 2)

        self.K = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.K)
        self.K.setObjectName(u"K")
        sizePolicy.setHeightForWidth(self.K.sizePolicy().hasHeightForWidth())
        self.K.setSizePolicy(sizePolicy)
        self.K.setMinimumSize(QSize(60, 58))
        self.K.setMaximumSize(QSize(60, 58))
        self.K.setFont(font3)
        self.K.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.K.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.K, 0, 8, 1, 1)

        self.X = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.X)
        self.X.setObjectName(u"X")
        sizePolicy.setHeightForWidth(self.X.sizePolicy().hasHeightForWidth())
        self.X.setSizePolicy(sizePolicy)
        self.X.setMinimumSize(QSize(60, 58))
        self.X.setMaximumSize(QSize(60, 58))
        self.X.setFont(font3)
        self.X.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.X.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.X, 1, 5, 1, 1)

        self.T = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.T)
        self.T.setObjectName(u"T")
        sizePolicy.setHeightForWidth(self.T.sizePolicy().hasHeightForWidth())
        self.T.setSizePolicy(sizePolicy)
        self.T.setMinimumSize(QSize(60, 58))
        self.T.setMaximumSize(QSize(60, 58))
        self.T.setFont(font3)
        self.T.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.T.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.T, 6, 5, 1, 1)

        self.R = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.R)
        self.R.setObjectName(u"R")
        sizePolicy.setHeightForWidth(self.R.sizePolicy().hasHeightForWidth())
        self.R.setSizePolicy(sizePolicy)
        self.R.setMinimumSize(QSize(60, 58))
        self.R.setMaximumSize(QSize(60, 58))
        self.R.setFont(font3)
        self.R.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.R.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.R, 0, 10, 1, 1)

        self.P = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.P)
        self.P.setObjectName(u"P")
        sizePolicy.setHeightForWidth(self.P.sizePolicy().hasHeightForWidth())
        self.P.setSizePolicy(sizePolicy)
        self.P.setMinimumSize(QSize(60, 58))
        self.P.setMaximumSize(QSize(60, 58))
        self.P.setFont(font3)
        self.P.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.P.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.P, 9, 10, 1, 1)

        self.D = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.D)
        self.D.setObjectName(u"D")
        sizePolicy.setHeightForWidth(self.D.sizePolicy().hasHeightForWidth())
        self.D.setSizePolicy(sizePolicy)
        self.D.setMinimumSize(QSize(60, 58))
        self.D.setMaximumSize(QSize(60, 58))
        self.D.setFont(font3)
        self.D.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.D.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.D, 0, 9, 1, 1)

        self.NP9 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP9)
        self.NP9.setObjectName(u"NP9")
        sizePolicy.setHeightForWidth(self.NP9.sizePolicy().hasHeightForWidth())
        self.NP9.setSizePolicy(sizePolicy)
        self.NP9.setMinimumSize(QSize(60, 58))
        self.NP9.setMaximumSize(QSize(60, 58))
        self.NP9.setFont(font5)
        self.NP9.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP9.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP9, 2, 9, 1, 1)

        self.NP8 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP8)
        self.NP8.setObjectName(u"NP8")
        sizePolicy.setHeightForWidth(self.NP8.sizePolicy().hasHeightForWidth())
        self.NP8.setSizePolicy(sizePolicy)
        self.NP8.setMinimumSize(QSize(60, 58))
        self.NP8.setMaximumSize(QSize(60, 58))
        self.NP8.setFont(font5)
        self.NP8.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP8.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP8, 2, 8, 1, 1)

        self.decimal = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.decimal)
        self.decimal.setObjectName(u"decimal")
        sizePolicy.setHeightForWidth(self.decimal.sizePolicy().hasHeightForWidth())
        self.decimal.setSizePolicy(sizePolicy)
        self.decimal.setMinimumSize(QSize(60, 58))
        self.decimal.setMaximumSize(QSize(60, 58))
        self.decimal.setFont(font5)
        self.decimal.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.decimal.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.decimal, 9, 9, 1, 1)

        self.NP0 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP0)
        self.NP0.setObjectName(u"NP0")
        sizePolicy.setHeightForWidth(self.NP0.sizePolicy().hasHeightForWidth())
        self.NP0.setSizePolicy(sizePolicy)
        self.NP0.setMinimumSize(QSize(60, 58))
        self.NP0.setMaximumSize(QSize(60, 58))
        self.NP0.setFont(font5)
        self.NP0.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP0.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP0, 9, 8, 1, 1)

        self.J = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.J)
        self.J.setObjectName(u"J")
        sizePolicy.setHeightForWidth(self.J.sizePolicy().hasHeightForWidth())
        self.J.setSizePolicy(sizePolicy)
        self.J.setMinimumSize(QSize(60, 58))
        self.J.setMaximumSize(QSize(60, 58))
        self.J.setFont(font3)
        self.J.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.J.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.J, 0, 6, 1, 1)

        self.H = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.H)
        self.H.setObjectName(u"H")
        sizePolicy.setHeightForWidth(self.H.sizePolicy().hasHeightForWidth())
        self.H.setSizePolicy(sizePolicy)
        self.H.setMinimumSize(QSize(60, 58))
        self.H.setMaximumSize(QSize(60, 58))
        self.H.setFont(font3)
        self.H.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.H.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.H, 6, 10, 1, 1)

        self.A = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.A)
        self.A.setObjectName(u"A")
        sizePolicy.setHeightForWidth(self.A.sizePolicy().hasHeightForWidth())
        self.A.setSizePolicy(sizePolicy)
        self.A.setMinimumSize(QSize(60, 58))
        self.A.setMaximumSize(QSize(60, 58))
        self.A.setFont(font3)
        self.A.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.A.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.A, 1, 9, 1, 1)

        self.G = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.G)
        self.G.setObjectName(u"G")
        sizePolicy.setHeightForWidth(self.G.sizePolicy().hasHeightForWidth())
        self.G.setSizePolicy(sizePolicy)
        self.G.setMinimumSize(QSize(60, 58))
        self.G.setMaximumSize(QSize(60, 58))
        self.G.setFont(font3)
        self.G.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.G.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.G, 2, 5, 1, 1)

        self.NP3 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP3)
        self.NP3.setObjectName(u"NP3")
        sizePolicy.setHeightForWidth(self.NP3.sizePolicy().hasHeightForWidth())
        self.NP3.setSizePolicy(sizePolicy)
        self.NP3.setMinimumSize(QSize(60, 58))
        self.NP3.setMaximumSize(QSize(60, 58))
        self.NP3.setFont(font5)
        self.NP3.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP3.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP3, 6, 9, 1, 1)

        self.Z = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.Z)
        self.Z.setObjectName(u"Z")
        sizePolicy.setHeightForWidth(self.Z.sizePolicy().hasHeightForWidth())
        self.Z.setSizePolicy(sizePolicy)
        self.Z.setMinimumSize(QSize(60, 58))
        self.Z.setMaximumSize(QSize(60, 58))
        self.Z.setFont(font3)
        self.Z.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.Z.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.Z, 1, 8, 1, 1)

        self.F = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.F)
        self.F.setObjectName(u"F")
        sizePolicy.setHeightForWidth(self.F.sizePolicy().hasHeightForWidth())
        self.F.setSizePolicy(sizePolicy)
        self.F.setMinimumSize(QSize(60, 58))
        self.F.setMaximumSize(QSize(60, 58))
        self.F.setFont(font3)
        self.F.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.F.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.F, 2, 10, 1, 1)

        self.enter = QPushButton(self.mdi_button_container_widget)
        self.enter.setObjectName(u"enter")
        sizePolicy.setHeightForWidth(self.enter.sizePolicy().hasHeightForWidth())
        self.enter.setSizePolicy(sizePolicy)
        self.enter.setMinimumSize(QSize(0, 58))
        self.enter.setMaximumSize(QSize(16777215, 58))
        self.enter.setFont(font6)
        self.enter.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.enter.setStyleSheet(u"font: 18pt \"Probe Basic Bebas Mono\";")

        self.gridLayout_4.addWidget(self.enter, 12, 8, 1, 3)

        self.M = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.M)
        self.M.setObjectName(u"M")
        sizePolicy.setHeightForWidth(self.M.sizePolicy().hasHeightForWidth())
        self.M.setSizePolicy(sizePolicy)
        self.M.setMinimumSize(QSize(60, 58))
        self.M.setMaximumSize(QSize(60, 58))
        self.M.setFont(font3)
        self.M.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.M.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.M, 4, 5, 1, 1)

        self.Q = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.Q)
        self.Q.setObjectName(u"Q")
        sizePolicy.setHeightForWidth(self.Q.sizePolicy().hasHeightForWidth())
        self.Q.setSizePolicy(sizePolicy)
        self.Q.setMinimumSize(QSize(60, 58))
        self.Q.setMaximumSize(QSize(60, 58))
        self.Q.setFont(font3)
        self.Q.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.Q.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.Q, 10, 10, 1, 1)

        self.NP4 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP4)
        self.NP4.setObjectName(u"NP4")
        sizePolicy.setHeightForWidth(self.NP4.sizePolicy().hasHeightForWidth())
        self.NP4.setSizePolicy(sizePolicy)
        self.NP4.setMinimumSize(QSize(60, 58))
        self.NP4.setMaximumSize(QSize(60, 58))
        self.NP4.setFont(font5)
        self.NP4.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP4.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP4, 4, 6, 1, 1)

        self.NP5 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP5)
        self.NP5.setObjectName(u"NP5")
        sizePolicy.setHeightForWidth(self.NP5.sizePolicy().hasHeightForWidth())
        self.NP5.setSizePolicy(sizePolicy)
        self.NP5.setMinimumSize(QSize(60, 58))
        self.NP5.setMaximumSize(QSize(60, 58))
        self.NP5.setFont(font5)
        self.NP5.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP5.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP5, 4, 8, 1, 1)

        self.NP6 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP6)
        self.NP6.setObjectName(u"NP6")
        sizePolicy.setHeightForWidth(self.NP6.sizePolicy().hasHeightForWidth())
        self.NP6.setSizePolicy(sizePolicy)
        self.NP6.setMinimumSize(QSize(60, 58))
        self.NP6.setMaximumSize(QSize(60, 58))
        self.NP6.setFont(font5)
        self.NP6.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP6.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP6, 4, 9, 1, 1)

        self.Y = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.Y)
        self.Y.setObjectName(u"Y")
        sizePolicy.setHeightForWidth(self.Y.sizePolicy().hasHeightForWidth())
        self.Y.setSizePolicy(sizePolicy)
        self.Y.setMinimumSize(QSize(60, 58))
        self.Y.setMaximumSize(QSize(60, 58))
        self.Y.setFont(font3)
        self.Y.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.Y.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.Y, 1, 6, 1, 1)

        self.O = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.O)
        self.O.setObjectName(u"O")
        sizePolicy.setHeightForWidth(self.O.sizePolicy().hasHeightForWidth())
        self.O.setSizePolicy(sizePolicy)
        self.O.setMinimumSize(QSize(60, 58))
        self.O.setMaximumSize(QSize(60, 58))
        self.O.setFont(font5)
        self.O.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.O.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.O, 9, 5, 1, 1)

        self.S = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.S)
        self.S.setObjectName(u"S")
        sizePolicy.setHeightForWidth(self.S.sizePolicy().hasHeightForWidth())
        self.S.setSizePolicy(sizePolicy)
        self.S.setMinimumSize(QSize(60, 58))
        self.S.setMaximumSize(QSize(60, 58))
        self.S.setFont(font3)
        self.S.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.S.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.S, 4, 10, 1, 1)

        self.I = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.I)
        self.I.setObjectName(u"I")
        sizePolicy.setHeightForWidth(self.I.sizePolicy().hasHeightForWidth())
        self.I.setSizePolicy(sizePolicy)
        self.I.setMinimumSize(QSize(60, 58))
        self.I.setMaximumSize(QSize(60, 58))
        self.I.setFont(font3)
        self.I.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.I.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.I, 0, 5, 1, 1)

        self.B = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.B)
        self.B.setObjectName(u"B")
        sizePolicy.setHeightForWidth(self.B.sizePolicy().hasHeightForWidth())
        self.B.setSizePolicy(sizePolicy)
        self.B.setMinimumSize(QSize(60, 58))
        self.B.setMaximumSize(QSize(60, 58))
        self.B.setFont(font3)
        self.B.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.B.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.15 rgba(60, 121, 212, 255), stop:0.3 rgba(60, 121, 212, 255), stop:0.5 rgba(63, 124, 215, 255), stop:0.7 rgba(60, 121, 212, 255), stop:0.85 rgba(60, 121, 212, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(136, 177, 238, 255), stop: 1.0 rgba(146, 177, 238, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:"
                        "1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")

        self.gridLayout_4.addWidget(self.B, 1, 10, 1, 1)

        self.NP1 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP1)
        self.NP1.setObjectName(u"NP1")
        sizePolicy.setHeightForWidth(self.NP1.sizePolicy().hasHeightForWidth())
        self.NP1.setSizePolicy(sizePolicy)
        self.NP1.setMinimumSize(QSize(60, 58))
        self.NP1.setMaximumSize(QSize(60, 58))
        self.NP1.setFont(font5)
        self.NP1.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP1.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP1, 6, 6, 1, 1)

        self.NP7 = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.NP7)
        self.NP7.setObjectName(u"NP7")
        sizePolicy.setHeightForWidth(self.NP7.sizePolicy().hasHeightForWidth())
        self.NP7.setSizePolicy(sizePolicy)
        self.NP7.setMinimumSize(QSize(60, 58))
        self.NP7.setMaximumSize(QSize(60, 58))
        self.NP7.setFont(font5)
        self.NP7.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.NP7.setStyleSheet(u"QPushButton {\n"
"    color: black;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(255, 255, 255, 255), stop:0.18 rgba(213, 213, 223, 255), stop:0.3 rgba(213, 213, 223, 255), stop:0.5 rgba(213, 213, 223, 255), stop:0.7 rgba(213, 213, 223, 255), stop:0.82 rgba(213, 213, 213, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 21pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 rgba(255, 255, 255, 255), stop: 1.0 rgba(235, 235, 235, 255));\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), "
                        "stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.gridLayout_4.addWidget(self.NP7, 2, 6, 1, 1)

        self.btnMdiRight_arrow = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.btnMdiRight_arrow)
        self.btnMdiRight_arrow.setObjectName(u"btnMdiRight_arrow")
        sizePolicy.setHeightForWidth(self.btnMdiRight_arrow.sizePolicy().hasHeightForWidth())
        self.btnMdiRight_arrow.setSizePolicy(sizePolicy)
        self.btnMdiRight_arrow.setMinimumSize(QSize(60, 58))
        self.btnMdiRight_arrow.setMaximumSize(QSize(60, 58))
        self.btnMdiRight_arrow.setFont(font1)
        self.btnMdiRight_arrow.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btnMdiRight_arrow.setStyleSheet(u"")
        icon5 = QIcon()
        icon5.addFile(u":/images/right_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btnMdiRight_arrow.setIcon(icon5)
        self.btnMdiRight_arrow.setIconSize(QSize(25, 25))

        self.gridLayout_4.addWidget(self.btnMdiRight_arrow, 12, 6, 1, 1)

        self.btnMdiLeft_arrow = QPushButton(self.mdi_button_container_widget)
        self.btngrpMdi.addButton(self.btnMdiLeft_arrow)
        self.btnMdiLeft_arrow.setObjectName(u"btnMdiLeft_arrow")
        sizePolicy.setHeightForWidth(self.btnMdiLeft_arrow.sizePolicy().hasHeightForWidth())
        self.btnMdiLeft_arrow.setSizePolicy(sizePolicy)
        self.btnMdiLeft_arrow.setMinimumSize(QSize(60, 58))
        self.btnMdiLeft_arrow.setMaximumSize(QSize(60, 58))
        self.btnMdiLeft_arrow.setFont(font1)
        self.btnMdiLeft_arrow.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btnMdiLeft_arrow.setStyleSheet(u"")
        icon6 = QIcon()
        icon6.addFile(u":/images/left_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btnMdiLeft_arrow.setIcon(icon6)
        self.btnMdiLeft_arrow.setIconSize(QSize(25, 25))

        self.gridLayout_4.addWidget(self.btnMdiLeft_arrow, 12, 5, 1, 1)


        self.horizontalLayout_35.addWidget(self.mdi_button_container_widget)

        self.gcode_mdi.addWidget(self.Page2_mdiedit)
        self.splitter_2.addWidget(self.gcode_mdi)

        self.verticalLayout_66.addWidget(self.splitter_2)

        self.widget_52 = QWidget(self.widget_49)
        self.widget_52.setObjectName(u"widget_52")
        self.widget_52.setMinimumSize(QSize(0, 42))
        self.widget_52.setMaximumSize(QSize(16777215, 42))
        self.horizontalLayout_11 = QHBoxLayout(self.widget_52)
        self.horizontalLayout_11.setSpacing(15)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(3, 0, 3, 0)
        self.mdiEntry = MDIEntry(self.widget_52)
        self.mdiEntry.setObjectName(u"mdiEntry")
        sizePolicy1.setHeightForWidth(self.mdiEntry.sizePolicy().hasHeightForWidth())
        self.mdiEntry.setSizePolicy(sizePolicy1)
        self.mdiEntry.setMinimumSize(QSize(0, 42))
        self.mdiEntry.setMaximumSize(QSize(16777215, 42))
        font7 = QFont()
        font7.setFamilies([u"Probe Basic Bebas Mono"])
        font7.setPointSize(15)
        font7.setBold(False)
        font7.setItalic(False)
        self.mdiEntry.setFont(font7)
        self.mdiEntry.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.mdiEntry.setProperty(u"mdi_history_size", 0)

        self.horizontalLayout_11.addWidget(self.mdiEntry)

        self.widget_74 = QWidget(self.widget_52)
        self.widget_74.setObjectName(u"widget_74")
        self.horizontalLayout_136 = QHBoxLayout(self.widget_74)
        self.horizontalLayout_136.setSpacing(0)
        self.horizontalLayout_136.setObjectName(u"horizontalLayout_136")
        self.horizontalLayout_136.setContentsMargins(0, 0, 0, 0)
        self.gcode_page = QPushButton(self.widget_74)
        self.gcodemdibtnGroup = QButtonGroup(Form)
        self.gcodemdibtnGroup.setObjectName(u"gcodemdibtnGroup")
        self.gcodemdibtnGroup.addButton(self.gcode_page)
        self.gcode_page.setObjectName(u"gcode_page")
        self.gcode_page.setMinimumSize(QSize(90, 42))
        self.gcode_page.setMaximumSize(QSize(90, 42))
        self.gcode_page.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.gcode_page.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 2px;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 4px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 4px;\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 255), stop:0.3 rgba(85, 85, 238, 255), stop:0.69473"
                        "7 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.gcode_page.setCheckable(True)
        self.gcode_page.setChecked(True)
        self.gcode_page.setAutoExclusive(True)
        self.gcode_page.setProperty(u"page", 0)

        self.horizontalLayout_136.addWidget(self.gcode_page)

        self.mdi_page = QPushButton(self.widget_74)
        self.gcodemdibtnGroup.addButton(self.mdi_page)
        self.mdi_page.setObjectName(u"mdi_page")
        sizePolicy3.setHeightForWidth(self.mdi_page.sizePolicy().hasHeightForWidth())
        self.mdi_page.setSizePolicy(sizePolicy3)
        self.mdi_page.setMinimumSize(QSize(90, 42))
        self.mdi_page.setMaximumSize(QSize(90, 42))
        self.mdi_page.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.mdi_page.setStyleSheet(u"QPushButton {\n"
"    margin-top: 2px;\n"
"    margin-bottom: 2px;\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 2px;\n"
"    border-left-width: 1px;\n"
"    padding: 2px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 4px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 4px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 255), stop:0.3 rgba(85, 85, 238, 255), stop:0.69473"
                        "7 rgba(85, 85, 238, 255), stop:0.915789 rgba(123, 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.mdi_page.setCheckable(True)
        self.mdi_page.setAutoExclusive(True)
        self.mdi_page.setProperty(u"page", 1)

        self.horizontalLayout_136.addWidget(self.mdi_page)


        self.horizontalLayout_11.addWidget(self.widget_74)


        self.verticalLayout_66.addWidget(self.widget_52)


        self.horizontalLayout.addWidget(self.widget_49)

        self.widget_2 = QWidget(self.main_tab)
        self.widget_2.setObjectName(u"widget_2")
        sizePolicy4.setHeightForWidth(self.widget_2.sizePolicy().hasHeightForWidth())
        self.widget_2.setSizePolicy(sizePolicy4)
        self.horizontalLayout_3 = QHBoxLayout(self.widget_2)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.vtk_control_buttons = QWidget(self.widget_2)
        self.vtk_control_buttons.setObjectName(u"vtk_control_buttons")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.vtk_control_buttons.sizePolicy().hasHeightForWidth())
        self.vtk_control_buttons.setSizePolicy(sizePolicy7)
        self.vtk_control_buttons.setStyleSheet(u".QWidget{\n"
"    background: rgb(32, 36, 37);\n"
"    font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.verticalLayout_8 = QVBoxLayout(self.vtk_control_buttons)
        self.verticalLayout_8.setSpacing(20)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(15, 6, 0, -1)
        self.pan_button = QPushButton(self.vtk_control_buttons)
        self.pan_button.setObjectName(u"pan_button")
        sizePolicy3.setHeightForWidth(self.pan_button.sizePolicy().hasHeightForWidth())
        self.pan_button.setSizePolicy(sizePolicy3)
        self.pan_button.setMinimumSize(QSize(85, 35))
        self.pan_button.setMaximumSize(QSize(35, 40))
        self.pan_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.pan_button.setStyleSheet(u"")
        self.pan_button.setCheckable(True)
        self.pan_button.setChecked(False)
        self.pan_button.setAutoExclusive(False)

        self.verticalLayout_8.addWidget(self.pan_button)

        self.zoom_in_button = QPushButton(self.vtk_control_buttons)
        self.zoom_in_button.setObjectName(u"zoom_in_button")
        sizePolicy3.setHeightForWidth(self.zoom_in_button.sizePolicy().hasHeightForWidth())
        self.zoom_in_button.setSizePolicy(sizePolicy3)
        self.zoom_in_button.setMinimumSize(QSize(85, 35))
        self.zoom_in_button.setMaximumSize(QSize(85, 35))
        self.zoom_in_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.zoom_in_button.setStyleSheet(u"")
        self.zoom_in_button.setCheckable(False)
        self.zoom_in_button.setChecked(False)

        self.verticalLayout_8.addWidget(self.zoom_in_button)

        self.zoom_out_button = QPushButton(self.vtk_control_buttons)
        self.zoom_out_button.setObjectName(u"zoom_out_button")
        sizePolicy3.setHeightForWidth(self.zoom_out_button.sizePolicy().hasHeightForWidth())
        self.zoom_out_button.setSizePolicy(sizePolicy3)
        self.zoom_out_button.setMinimumSize(QSize(85, 35))
        self.zoom_out_button.setMaximumSize(QSize(85, 35))
        self.zoom_out_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.zoom_out_button.setStyleSheet(u"")
        self.zoom_out_button.setCheckable(False)

        self.verticalLayout_8.addWidget(self.zoom_out_button)

        self.program_zoom_button = QPushButton(self.vtk_control_buttons)
        self.program_zoom_button.setObjectName(u"program_zoom_button")
        sizePolicy3.setHeightForWidth(self.program_zoom_button.sizePolicy().hasHeightForWidth())
        self.program_zoom_button.setSizePolicy(sizePolicy3)
        self.program_zoom_button.setMinimumSize(QSize(85, 35))
        self.program_zoom_button.setMaximumSize(QSize(85, 35))
        self.program_zoom_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.program_zoom_button.setStyleSheet(u"")
        self.program_zoom_button.setCheckable(False)

        self.verticalLayout_8.addWidget(self.program_zoom_button)

        self.machine_zoom_button = QPushButton(self.vtk_control_buttons)
        self.machine_zoom_button.setObjectName(u"machine_zoom_button")
        sizePolicy3.setHeightForWidth(self.machine_zoom_button.sizePolicy().hasHeightForWidth())
        self.machine_zoom_button.setSizePolicy(sizePolicy3)
        self.machine_zoom_button.setMinimumSize(QSize(85, 35))
        self.machine_zoom_button.setMaximumSize(QSize(85, 35))
        self.machine_zoom_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.machine_zoom_button.setStyleSheet(u"")
        self.machine_zoom_button.setCheckable(False)

        self.verticalLayout_8.addWidget(self.machine_zoom_button)

        self.path_button = QPushButton(self.vtk_control_buttons)
        self.path_button.setObjectName(u"path_button")
        sizePolicy3.setHeightForWidth(self.path_button.sizePolicy().hasHeightForWidth())
        self.path_button.setSizePolicy(sizePolicy3)
        self.path_button.setMinimumSize(QSize(85, 35))
        self.path_button.setMaximumSize(QSize(85, 35))
        self.path_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.path_button.setCheckable(False)

        self.verticalLayout_8.addWidget(self.path_button)

        self.clear_button = QPushButton(self.vtk_control_buttons)
        self.clear_button.setObjectName(u"clear_button")
        sizePolicy3.setHeightForWidth(self.clear_button.sizePolicy().hasHeightForWidth())
        self.clear_button.setSizePolicy(sizePolicy3)
        self.clear_button.setMinimumSize(QSize(85, 35))
        self.clear_button.setMaximumSize(QSize(85, 35))
        self.clear_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.clear_button.setStyleSheet(u"")
        self.clear_button.setCheckable(False)

        self.verticalLayout_8.addWidget(self.clear_button)

        self.view_breadcrumbs = QPushButton(self.vtk_control_buttons)
        self.view_breadcrumbs.setObjectName(u"view_breadcrumbs")
        sizePolicy3.setHeightForWidth(self.view_breadcrumbs.sizePolicy().hasHeightForWidth())
        self.view_breadcrumbs.setSizePolicy(sizePolicy3)
        self.view_breadcrumbs.setMinimumSize(QSize(85, 35))
        self.view_breadcrumbs.setMaximumSize(QSize(85, 35))
        font8 = QFont()
        font8.setFamilies([u"Probe Basic Bebas Mono"])
        font8.setPointSize(14)
        self.view_breadcrumbs.setFont(font8)
        self.view_breadcrumbs.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.view_breadcrumbs.setCheckable(True)

        self.verticalLayout_8.addWidget(self.view_breadcrumbs)

        self.widget_43 = QWidget(self.vtk_control_buttons)
        self.widget_43.setObjectName(u"widget_43")

        self.verticalLayout_8.addWidget(self.widget_43)


        self.horizontalLayout_3.addWidget(self.vtk_control_buttons)

        self.vtkbackplot = VTKBackPlot(self.widget_2)
        self.vtkbackplot.setObjectName(u"vtkbackplot")
        sizePolicy.setHeightForWidth(self.vtkbackplot.sizePolicy().hasHeightForWidth())
        self.vtkbackplot.setSizePolicy(sizePolicy)
        self.vtkbackplot.setProperty(u"backgroundColor", QColor(32, 36, 37))

        self.horizontalLayout_3.addWidget(self.vtkbackplot)


        self.horizontalLayout.addWidget(self.widget_2)

        self.tabWidget.addTab(self.main_tab, "")
        self.file_tab = QWidget()
        self.file_tab.setObjectName(u"file_tab")
        self.file_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout_9 = QHBoxLayout(self.file_tab)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(20, 20, 20, 20)
        self.horizontalLayout_120 = QHBoxLayout()
        self.horizontalLayout_120.setSpacing(15)
        self.horizontalLayout_120.setObjectName(u"horizontalLayout_120")
        self.horizontalLayout_120.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.horizontalLayout_120.setContentsMargins(0, 0, 0, 0)
        self.usb_file_frame = QFrame(self.file_tab)
        self.usb_file_frame.setObjectName(u"usb_file_frame")
        sizePolicy7.setHeightForWidth(self.usb_file_frame.sizePolicy().hasHeightForWidth())
        self.usb_file_frame.setSizePolicy(sizePolicy7)
        self.usb_file_frame.setMinimumSize(QSize(420, 0))
        self.usb_file_frame.setMaximumSize(QSize(420, 16777215))
        self.usb_file_frame.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.usb_file_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.usb_file_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_37 = QVBoxLayout(self.usb_file_frame)
        self.verticalLayout_37.setSpacing(9)
        self.verticalLayout_37.setObjectName(u"verticalLayout_37")
        self.horizontalLayout_124 = QHBoxLayout()
        self.horizontalLayout_124.setObjectName(u"horizontalLayout_124")
        self.horizontalLayout_124.setContentsMargins(5, -1, 5, -1)
        self.device_folder_up_button = QPushButton(self.usb_file_frame)
        self.device_folder_up_button.setObjectName(u"device_folder_up_button")
        sizePolicy3.setHeightForWidth(self.device_folder_up_button.sizePolicy().hasHeightForWidth())
        self.device_folder_up_button.setSizePolicy(sizePolicy3)
        self.device_folder_up_button.setMinimumSize(QSize(110, 35))
        self.device_folder_up_button.setMaximumSize(QSize(110, 35))
        self.device_folder_up_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_folder_up_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        icon7 = QIcon()
        icon7.addFile(u":/images/folder_up.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.device_folder_up_button.setIcon(icon7)
        self.device_folder_up_button.setIconSize(QSize(30, 17))

        self.horizontalLayout_124.addWidget(self.device_folder_up_button)

        self.removabledevicecombobox = RemovableDeviceComboBox(self.usb_file_frame)
        self.removabledevicecombobox.setObjectName(u"removabledevicecombobox")
        sizePolicy1.setHeightForWidth(self.removabledevicecombobox.sizePolicy().hasHeightForWidth())
        self.removabledevicecombobox.setSizePolicy(sizePolicy1)
        self.removabledevicecombobox.setMinimumSize(QSize(0, 35))
        self.removabledevicecombobox.setMaximumSize(QSize(16777215, 35))

        self.horizontalLayout_124.addWidget(self.removabledevicecombobox)

        self.device_eject_usb_button = QPushButton(self.usb_file_frame)
        self.device_eject_usb_button.setObjectName(u"device_eject_usb_button")
        sizePolicy3.setHeightForWidth(self.device_eject_usb_button.sizePolicy().hasHeightForWidth())
        self.device_eject_usb_button.setSizePolicy(sizePolicy3)
        self.device_eject_usb_button.setMinimumSize(QSize(100, 35))
        self.device_eject_usb_button.setMaximumSize(QSize(100, 35))
        self.device_eject_usb_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_eject_usb_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_124.addWidget(self.device_eject_usb_button)


        self.verticalLayout_37.addLayout(self.horizontalLayout_124)

        self.horizontalLayout_125 = QHBoxLayout()
        self.horizontalLayout_125.setObjectName(u"horizontalLayout_125")
        self.filesystemtable_2 = FileSystemTable(self.usb_file_frame)
        self.filesystemtable_2.setObjectName(u"filesystemtable_2")
        self.filesystemtable_2.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.filesystemtable_2.setStyleSheet(u"")
        self.filesystemtable_2.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.filesystemtable_2.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.filesystemtable_2.setShowGrid(False)
        self.filesystemtable_2.setSortingEnabled(True)
        self.filesystemtable_2.setProperty(u"fixedNameColumn", True)
        self.filesystemtable_2.setProperty(u"nameColumnsWidth", 250)
        self.filesystemtable_2.horizontalHeader().setCascadingSectionResizes(True)

        self.horizontalLayout_125.addWidget(self.filesystemtable_2)


        self.verticalLayout_37.addLayout(self.horizontalLayout_125)

        self.horizontalLayout_126 = QHBoxLayout()
        self.horizontalLayout_126.setSpacing(12)
        self.horizontalLayout_126.setObjectName(u"horizontalLayout_126")
        self.device_delete_item_button = QPushButton(self.usb_file_frame)
        self.device_delete_item_button.setObjectName(u"device_delete_item_button")
        sizePolicy3.setHeightForWidth(self.device_delete_item_button.sizePolicy().hasHeightForWidth())
        self.device_delete_item_button.setSizePolicy(sizePolicy3)
        self.device_delete_item_button.setMinimumSize(QSize(100, 35))
        self.device_delete_item_button.setMaximumSize(QSize(100, 35))
        self.device_delete_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_delete_item_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        icon8 = QIcon()
        icon8.addFile(u":/images/delete.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.device_delete_item_button.setIcon(icon8)
        self.device_delete_item_button.setIconSize(QSize(14, 14))

        self.horizontalLayout_126.addWidget(self.device_delete_item_button)

        self.device_rename_item_button = QPushButton(self.usb_file_frame)
        self.device_rename_item_button.setObjectName(u"device_rename_item_button")
        sizePolicy6.setHeightForWidth(self.device_rename_item_button.sizePolicy().hasHeightForWidth())
        self.device_rename_item_button.setSizePolicy(sizePolicy6)
        self.device_rename_item_button.setMinimumSize(QSize(90, 35))
        self.device_rename_item_button.setMaximumSize(QSize(16777215, 35))
        self.device_rename_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.device_rename_item_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_126.addWidget(self.device_rename_item_button)

        self.copy_from_usb_2 = QPushButton(self.usb_file_frame)
        self.copy_from_usb_2.setObjectName(u"copy_from_usb_2")
        sizePolicy3.setHeightForWidth(self.copy_from_usb_2.sizePolicy().hasHeightForWidth())
        self.copy_from_usb_2.setSizePolicy(sizePolicy3)
        self.copy_from_usb_2.setMinimumSize(QSize(100, 35))
        self.copy_from_usb_2.setMaximumSize(QSize(100, 35))
        self.copy_from_usb_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.copy_from_usb_2.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.copy_from_usb_2.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"    padding-right: 4px;\n"
"}")
        self.copy_from_usb_2.setIcon(icon5)

        self.horizontalLayout_126.addWidget(self.copy_from_usb_2)


        self.verticalLayout_37.addLayout(self.horizontalLayout_126)


        self.horizontalLayout_120.addWidget(self.usb_file_frame)

        self.main_file_frame = QFrame(self.file_tab)
        self.main_file_frame.setObjectName(u"main_file_frame")
        sizePolicy4.setHeightForWidth(self.main_file_frame.sizePolicy().hasHeightForWidth())
        self.main_file_frame.setSizePolicy(sizePolicy4)
        self.main_file_frame.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.main_file_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.main_file_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_35 = QVBoxLayout(self.main_file_frame)
        self.verticalLayout_35.setSpacing(9)
        self.verticalLayout_35.setObjectName(u"verticalLayout_35")
        self.horizontalLayout_121 = QHBoxLayout()
        self.horizontalLayout_121.setObjectName(u"horizontalLayout_121")
        self.horizontalLayout_121.setContentsMargins(5, -1, 5, -1)
        self.main_folder_up_button = QPushButton(self.main_file_frame)
        self.main_folder_up_button.setObjectName(u"main_folder_up_button")
        sizePolicy3.setHeightForWidth(self.main_folder_up_button.sizePolicy().hasHeightForWidth())
        self.main_folder_up_button.setSizePolicy(sizePolicy3)
        self.main_folder_up_button.setMinimumSize(QSize(110, 35))
        self.main_folder_up_button.setMaximumSize(QSize(110, 35))
        self.main_folder_up_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_folder_up_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.main_folder_up_button.setIcon(icon7)
        self.main_folder_up_button.setIconSize(QSize(30, 17))

        self.horizontalLayout_121.addWidget(self.main_folder_up_button)

        self.recentfilecombobox_2 = RecentFileComboBox(self.main_file_frame)
        self.recentfilecombobox_2.setObjectName(u"recentfilecombobox_2")
        sizePolicy1.setHeightForWidth(self.recentfilecombobox_2.sizePolicy().hasHeightForWidth())
        self.recentfilecombobox_2.setSizePolicy(sizePolicy1)
        self.recentfilecombobox_2.setMinimumSize(QSize(0, 35))
        self.recentfilecombobox_2.setMaximumSize(QSize(16777215, 35))

        self.horizontalLayout_121.addWidget(self.recentfilecombobox_2)

        self.main_load_gcode_button = QPushButton(self.main_file_frame)
        self.main_load_gcode_button.setObjectName(u"main_load_gcode_button")
        sizePolicy3.setHeightForWidth(self.main_load_gcode_button.sizePolicy().hasHeightForWidth())
        self.main_load_gcode_button.setSizePolicy(sizePolicy3)
        self.main_load_gcode_button.setMinimumSize(QSize(100, 35))
        self.main_load_gcode_button.setMaximumSize(QSize(100, 35))
        self.main_load_gcode_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_load_gcode_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_121.addWidget(self.main_load_gcode_button)


        self.verticalLayout_35.addLayout(self.horizontalLayout_121)

        self.horizontalLayout_122 = QHBoxLayout()
        self.horizontalLayout_122.setObjectName(u"horizontalLayout_122")
        self.filesystemtable = FileSystemTable(self.main_file_frame)
        self.filesystemtable.setObjectName(u"filesystemtable")
        self.filesystemtable.setFocusPolicy(Qt.FocusPolicy.WheelFocus)
        self.filesystemtable.setStyleSheet(u"")
        self.filesystemtable.setSizeAdjustPolicy(QAbstractScrollArea.SizeAdjustPolicy.AdjustIgnored)
        self.filesystemtable.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.filesystemtable.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.filesystemtable.setShowGrid(False)
        self.filesystemtable.setGridStyle(Qt.PenStyle.SolidLine)
        self.filesystemtable.setSortingEnabled(True)
        self.filesystemtable.setProperty(u"fixedNameColumn", True)
        self.filesystemtable.setProperty(u"nameColumnsWidth", 310)
        self.filesystemtable.horizontalHeader().setCascadingSectionResizes(True)
        self.filesystemtable.horizontalHeader().setMinimumSectionSize(20)
        self.filesystemtable.horizontalHeader().setStretchLastSection(True)

        self.horizontalLayout_122.addWidget(self.filesystemtable)


        self.verticalLayout_35.addLayout(self.horizontalLayout_122)

        self.horizontalLayout_123 = QHBoxLayout()
        self.horizontalLayout_123.setSpacing(6)
        self.horizontalLayout_123.setObjectName(u"horizontalLayout_123")
        self.usb_show_hide_button = VCPSettingsPushButton(self.main_file_frame)
        self.usb_show_hide_button.setObjectName(u"usb_show_hide_button")
        self.usb_show_hide_button.setEnabled(True)
        sizePolicy6.setHeightForWidth(self.usb_show_hide_button.sizePolicy().hasHeightForWidth())
        self.usb_show_hide_button.setSizePolicy(sizePolicy6)
        self.usb_show_hide_button.setMinimumSize(QSize(90, 35))
        self.usb_show_hide_button.setMaximumSize(QSize(16777215, 35))
        self.usb_show_hide_button.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 16pt;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255"
                        "));\n"
"}\n"
"\n"
"QPushButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"     background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}")
        self.usb_show_hide_button.setCheckable(True)

        self.horizontalLayout_123.addWidget(self.usb_show_hide_button)

        self.copy_to_usb_2 = QPushButton(self.main_file_frame)
        self.copy_to_usb_2.setObjectName(u"copy_to_usb_2")
        sizePolicy6.setHeightForWidth(self.copy_to_usb_2.sizePolicy().hasHeightForWidth())
        self.copy_to_usb_2.setSizePolicy(sizePolicy6)
        self.copy_to_usb_2.setMinimumSize(QSize(90, 35))
        self.copy_to_usb_2.setMaximumSize(QSize(16777215, 35))
        self.copy_to_usb_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.copy_to_usb_2.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.copy_to_usb_2.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"    padding-right: 8px;\n"
"}")
        self.copy_to_usb_2.setIcon(icon6)

        self.horizontalLayout_123.addWidget(self.copy_to_usb_2)

        self.main_delete_item_button = QPushButton(self.main_file_frame)
        self.main_delete_item_button.setObjectName(u"main_delete_item_button")
        sizePolicy6.setHeightForWidth(self.main_delete_item_button.sizePolicy().hasHeightForWidth())
        self.main_delete_item_button.setSizePolicy(sizePolicy6)
        self.main_delete_item_button.setMinimumSize(QSize(90, 35))
        self.main_delete_item_button.setMaximumSize(QSize(16777215, 35))
        self.main_delete_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_delete_item_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.main_delete_item_button.setIcon(icon8)
        self.main_delete_item_button.setIconSize(QSize(14, 14))

        self.horizontalLayout_123.addWidget(self.main_delete_item_button)

        self.main_new_file_button = QPushButton(self.main_file_frame)
        self.main_new_file_button.setObjectName(u"main_new_file_button")
        sizePolicy6.setHeightForWidth(self.main_new_file_button.sizePolicy().hasHeightForWidth())
        self.main_new_file_button.setSizePolicy(sizePolicy6)
        self.main_new_file_button.setMinimumSize(QSize(100, 35))
        self.main_new_file_button.setMaximumSize(QSize(16777215, 35))
        self.main_new_file_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_new_file_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        icon9 = QIcon()
        icon9.addFile(u":/images/new_file.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.main_new_file_button.setIcon(icon9)
        self.main_new_file_button.setIconSize(QSize(12, 16))

        self.horizontalLayout_123.addWidget(self.main_new_file_button)

        self.main_new_folder_button = QPushButton(self.main_file_frame)
        self.main_new_folder_button.setObjectName(u"main_new_folder_button")
        sizePolicy6.setHeightForWidth(self.main_new_folder_button.sizePolicy().hasHeightForWidth())
        self.main_new_folder_button.setSizePolicy(sizePolicy6)
        self.main_new_folder_button.setMinimumSize(QSize(125, 35))
        self.main_new_folder_button.setMaximumSize(QSize(16777215, 35))
        self.main_new_folder_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_new_folder_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        icon10 = QIcon()
        icon10.addFile(u":/images/new_folder.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.main_new_folder_button.setIcon(icon10)
        self.main_new_folder_button.setIconSize(QSize(28, 15))

        self.horizontalLayout_123.addWidget(self.main_new_folder_button)

        self.main_rename_item_button = QPushButton(self.main_file_frame)
        self.main_rename_item_button.setObjectName(u"main_rename_item_button")
        sizePolicy6.setHeightForWidth(self.main_rename_item_button.sizePolicy().hasHeightForWidth())
        self.main_rename_item_button.setSizePolicy(sizePolicy6)
        self.main_rename_item_button.setMinimumSize(QSize(90, 35))
        self.main_rename_item_button.setMaximumSize(QSize(16777215, 35))
        self.main_rename_item_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_rename_item_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_123.addWidget(self.main_rename_item_button)


        self.verticalLayout_35.addLayout(self.horizontalLayout_123)


        self.horizontalLayout_120.addWidget(self.main_file_frame)

        self.frame_40 = QFrame(self.file_tab)
        self.frame_40.setObjectName(u"frame_40")
        sizePolicy4.setHeightForWidth(self.frame_40.sizePolicy().hasHeightForWidth())
        self.frame_40.setSizePolicy(sizePolicy4)
        self.frame_40.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.frame_40.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_40.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_38 = QVBoxLayout(self.frame_40)
        self.verticalLayout_38.setSpacing(9)
        self.verticalLayout_38.setObjectName(u"verticalLayout_38")
        self.verticalLayout_38.setContentsMargins(10, 12, 10, 9)
        self.gcodeeditor_label = QLabel(self.frame_40)
        self.gcodeeditor_label.setObjectName(u"gcodeeditor_label")
        self.gcodeeditor_label.setMinimumSize(QSize(0, 30))
        self.gcodeeditor_label.setMaximumSize(QSize(16777215, 30))
        self.gcodeeditor_label.setStyleSheet(u"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: white;")
        self.gcodeeditor_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_38.addWidget(self.gcodeeditor_label)

        self.gcodeEditor_2 = GCodeEditor(self.frame_40)
        self.gcodeEditor_2.setObjectName(u"gcodeEditor_2")

        self.verticalLayout_38.addWidget(self.gcodeEditor_2)

        self.horizontalLayout_129 = QHBoxLayout()
        self.horizontalLayout_129.setObjectName(u"horizontalLayout_129")
        self.edit_gcode_button = QPushButton(self.frame_40)
        self.edit_gcode_button.setObjectName(u"edit_gcode_button")
        sizePolicy3.setHeightForWidth(self.edit_gcode_button.sizePolicy().hasHeightForWidth())
        self.edit_gcode_button.setSizePolicy(sizePolicy3)
        self.edit_gcode_button.setMinimumSize(QSize(100, 35))
        self.edit_gcode_button.setMaximumSize(QSize(100, 35))
        self.edit_gcode_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.edit_gcode_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.edit_gcode_button.setCheckable(True)

        self.horizontalLayout_129.addWidget(self.edit_gcode_button)

        self.find_replace_button = QPushButton(self.frame_40)
        self.find_replace_button.setObjectName(u"find_replace_button")
        sizePolicy3.setHeightForWidth(self.find_replace_button.sizePolicy().hasHeightForWidth())
        self.find_replace_button.setSizePolicy(sizePolicy3)
        self.find_replace_button.setMinimumSize(QSize(100, 35))
        self.find_replace_button.setMaximumSize(QSize(100, 35))
        self.find_replace_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.find_replace_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_129.addWidget(self.find_replace_button)

        self.save_button = QPushButton(self.frame_40)
        self.save_button.setObjectName(u"save_button")
        sizePolicy3.setHeightForWidth(self.save_button.sizePolicy().hasHeightForWidth())
        self.save_button.setSizePolicy(sizePolicy3)
        self.save_button.setMinimumSize(QSize(80, 35))
        self.save_button.setMaximumSize(QSize(80, 35))
        self.save_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.save_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_129.addWidget(self.save_button)

        self.save_as_button = QPushButton(self.frame_40)
        self.save_as_button.setObjectName(u"save_as_button")
        sizePolicy3.setHeightForWidth(self.save_as_button.sizePolicy().hasHeightForWidth())
        self.save_as_button.setSizePolicy(sizePolicy3)
        self.save_as_button.setMinimumSize(QSize(80, 35))
        self.save_as_button.setMaximumSize(QSize(80, 35))
        self.save_as_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.save_as_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_129.addWidget(self.save_as_button)

        self.undo_button = QPushButton(self.frame_40)
        self.undo_button.setObjectName(u"undo_button")
        sizePolicy3.setHeightForWidth(self.undo_button.sizePolicy().hasHeightForWidth())
        self.undo_button.setSizePolicy(sizePolicy3)
        self.undo_button.setMinimumSize(QSize(80, 35))
        self.undo_button.setMaximumSize(QSize(80, 35))
        self.undo_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.undo_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_129.addWidget(self.undo_button)


        self.verticalLayout_38.addLayout(self.horizontalLayout_129)


        self.horizontalLayout_120.addWidget(self.frame_40)


        self.horizontalLayout_9.addLayout(self.horizontalLayout_120)

        self.tabWidget.addTab(self.file_tab, "")
        self.offsets_tab = QWidget()
        self.offsets_tab.setObjectName(u"offsets_tab")
        self.offsets_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout_8 = QHBoxLayout(self.offsets_tab)
        self.horizontalLayout_8.setSpacing(15)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(20, 20, 20, 20)
        self.offset_tab_left_layout = QVBoxLayout()
        self.offset_tab_left_layout.setSpacing(0)
        self.offset_tab_left_layout.setObjectName(u"offset_tab_left_layout")
        self.offset_tab_left_layout.setContentsMargins(0, 0, 0, 0)
        self.offset_table_frame = QFrame(self.offsets_tab)
        self.offset_table_frame.setObjectName(u"offset_table_frame")
        sizePolicy7.setHeightForWidth(self.offset_table_frame.sizePolicy().hasHeightForWidth())
        self.offset_table_frame.setSizePolicy(sizePolicy7)
        self.offset_table_frame.setMinimumSize(QSize(560, 500))
        self.offset_table_frame.setMaximumSize(QSize(560, 16777215))
        self.offset_table_frame.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.verticalLayout_50 = QVBoxLayout(self.offset_table_frame)
        self.verticalLayout_50.setSpacing(15)
        self.verticalLayout_50.setObjectName(u"verticalLayout_50")
        self.verticalLayout_50.setContentsMargins(15, 15, 15, 9)
        self.wco_header_frame_3 = QLabel(self.offset_table_frame)
        self.wco_header_frame_3.setObjectName(u"wco_header_frame_3")
        sizePolicy6.setHeightForWidth(self.wco_header_frame_3.sizePolicy().hasHeightForWidth())
        self.wco_header_frame_3.setSizePolicy(sizePolicy6)
        self.wco_header_frame_3.setMinimumSize(QSize(0, 65))
        self.wco_header_frame_3.setMaximumSize(QSize(16777215, 65))
        self.wco_header_frame_3.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"    background: rgb(90, 90, 90);\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.wco_header_frame_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_50.addWidget(self.wco_header_frame_3)

        self.offset_table_layout = QHBoxLayout()
        self.offset_table_layout.setSpacing(0)
        self.offset_table_layout.setObjectName(u"offset_table_layout")
        self.offset_table_layout.setContentsMargins(-1, 0, -1, 0)
        self.offset_table = OffsetTable(self.offset_table_frame)
        self.offset_table.setObjectName(u"offset_table")
        sizePolicy3.setHeightForWidth(self.offset_table.sizePolicy().hasHeightForWidth())
        self.offset_table.setSizePolicy(sizePolicy3)
        self.offset_table.setMinimumSize(QSize(522, 428))
        self.offset_table.setMaximumSize(QSize(522, 428))
        self.offset_table.setStyleSheet(u"")
        self.offset_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.offset_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.offset_table.setSizeAdjustPolicy(QAbstractScrollArea.SizeAdjustPolicy.AdjustIgnored)
        self.offset_table.setAutoScroll(False)
        self.offset_table.setAutoScrollMargin(0)
        self.offset_table.setWordWrap(False)
        self.offset_table.setCornerButtonEnabled(False)
        self.offset_table.setProperty(u"currentRowColor", QColor(0, 38, 255))
        self.offset_table.horizontalHeader().setMinimumSectionSize(78)
        self.offset_table.horizontalHeader().setDefaultSectionSize(237)
        self.offset_table.horizontalHeader().setHighlightSections(False)
        self.offset_table.horizontalHeader().setStretchLastSection(False)
        self.offset_table.verticalHeader().setMinimumSectionSize(43)
        self.offset_table.verticalHeader().setDefaultSectionSize(43)
        self.offset_table.verticalHeader().setHighlightSections(False)

        self.offset_table_layout.addWidget(self.offset_table)


        self.verticalLayout_50.addLayout(self.offset_table_layout)

        self.offset_table_button_layout = QHBoxLayout()
        self.offset_table_button_layout.setSpacing(10)
        self.offset_table_button_layout.setObjectName(u"offset_table_button_layout")
        self.offset_table_button_layout.setContentsMargins(-1, 0, -1, 0)
        self.clear_selected_button = QPushButton(self.offset_table_frame)
        self.clear_selected_button.setObjectName(u"clear_selected_button")
        sizePolicy3.setHeightForWidth(self.clear_selected_button.sizePolicy().hasHeightForWidth())
        self.clear_selected_button.setSizePolicy(sizePolicy3)
        self.clear_selected_button.setMinimumSize(QSize(100, 36))
        self.clear_selected_button.setMaximumSize(QSize(150, 36))
        self.clear_selected_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.clear_selected_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.offset_table_button_layout.addWidget(self.clear_selected_button)

        self.clear_all_button = QPushButton(self.offset_table_frame)
        self.clear_all_button.setObjectName(u"clear_all_button")
        sizePolicy3.setHeightForWidth(self.clear_all_button.sizePolicy().hasHeightForWidth())
        self.clear_all_button.setSizePolicy(sizePolicy3)
        self.clear_all_button.setMinimumSize(QSize(100, 36))
        self.clear_all_button.setMaximumSize(QSize(150, 36))
        self.clear_all_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.clear_all_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.offset_table_button_layout.addWidget(self.clear_all_button)

        self.save_table_button = QPushButton(self.offset_table_frame)
        self.save_table_button.setObjectName(u"save_table_button")
        sizePolicy3.setHeightForWidth(self.save_table_button.sizePolicy().hasHeightForWidth())
        self.save_table_button.setSizePolicy(sizePolicy3)
        self.save_table_button.setMinimumSize(QSize(100, 36))
        self.save_table_button.setMaximumSize(QSize(150, 36))
        self.save_table_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.save_table_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.offset_table_button_layout.addWidget(self.save_table_button)

        self.reload_table_button = QPushButton(self.offset_table_frame)
        self.reload_table_button.setObjectName(u"reload_table_button")
        sizePolicy3.setHeightForWidth(self.reload_table_button.sizePolicy().hasHeightForWidth())
        self.reload_table_button.setSizePolicy(sizePolicy3)
        self.reload_table_button.setMinimumSize(QSize(100, 36))
        self.reload_table_button.setMaximumSize(QSize(150, 36))
        self.reload_table_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.reload_table_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.offset_table_button_layout.addWidget(self.reload_table_button)


        self.verticalLayout_50.addLayout(self.offset_table_button_layout)


        self.offset_tab_left_layout.addWidget(self.offset_table_frame)


        self.horizontalLayout_8.addLayout(self.offset_tab_left_layout)

        self.verticalLayout_41 = QVBoxLayout()
        self.verticalLayout_41.setSpacing(15)
        self.verticalLayout_41.setObjectName(u"verticalLayout_41")
        self.verticalLayout_41.setContentsMargins(0, -1, 0, 1)
        self.offset_dro_frame = QFrame(self.offsets_tab)
        self.offset_dro_frame.setObjectName(u"offset_dro_frame")
        sizePolicy7.setHeightForWidth(self.offset_dro_frame.sizePolicy().hasHeightForWidth())
        self.offset_dro_frame.setSizePolicy(sizePolicy7)
        self.offset_dro_frame.setMinimumSize(QSize(700, 0))
        self.offset_dro_frame.setMaximumSize(QSize(700, 16777215))
        self.offset_dro_frame.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.verticalLayout_39 = QVBoxLayout(self.offset_dro_frame)
        self.verticalLayout_39.setSpacing(15)
        self.verticalLayout_39.setObjectName(u"verticalLayout_39")
        self.verticalLayout_39.setContentsMargins(15, 15, 15, 9)
        self.offset_column_header_frame = QFrame(self.offset_dro_frame)
        self.offset_column_header_frame.setObjectName(u"offset_column_header_frame")
        sizePolicy6.setHeightForWidth(self.offset_column_header_frame.sizePolicy().hasHeightForWidth())
        self.offset_column_header_frame.setSizePolicy(sizePolicy6)
        self.offset_column_header_frame.setMinimumSize(QSize(0, 65))
        self.offset_column_header_frame.setMaximumSize(QSize(16777215, 65))
        self.offset_column_header_frame.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    background-color: rgb(90, 90, 90);\n"
"    padding: -5px;\n"
"}")
        self.offset_column_header_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.offset_column_header_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_42 = QVBoxLayout(self.offset_column_header_frame)
        self.verticalLayout_42.setSpacing(5)
        self.verticalLayout_42.setObjectName(u"verticalLayout_42")
        self.verticalLayout_42.setContentsMargins(10, 6, 11, 6)
        self.offset_column_header_layout = QHBoxLayout()
        self.offset_column_header_layout.setSpacing(13)
        self.offset_column_header_layout.setObjectName(u"offset_column_header_layout")
        self.offset_column_header_layout.setContentsMargins(0, -1, 0, -1)
        self.zero_column_header = QLabel(self.offset_column_header_frame)
        self.zero_column_header.setObjectName(u"zero_column_header")
        sizePolicy.setHeightForWidth(self.zero_column_header.sizePolicy().hasHeightForWidth())
        self.zero_column_header.setSizePolicy(sizePolicy)
        self.zero_column_header.setMinimumSize(QSize(55, 50))
        self.zero_column_header.setMaximumSize(QSize(55, 50))
        self.zero_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.zero_column_header.setWordWrap(True)

        self.offset_column_header_layout.addWidget(self.zero_column_header)

        self.axis_column_header = QLabel(self.offset_column_header_frame)
        self.axis_column_header.setObjectName(u"axis_column_header")
        sizePolicy.setHeightForWidth(self.axis_column_header.sizePolicy().hasHeightForWidth())
        self.axis_column_header.setSizePolicy(sizePolicy)
        self.axis_column_header.setMinimumSize(QSize(45, 50))
        self.axis_column_header.setMaximumSize(QSize(45, 50))
        self.axis_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.axis_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.axis_column_header.setWordWrap(True)

        self.offset_column_header_layout.addWidget(self.axis_column_header)

        self.work_column_header = QLabel(self.offset_column_header_frame)
        self.work_column_header.setObjectName(u"work_column_header")
        sizePolicy.setHeightForWidth(self.work_column_header.sizePolicy().hasHeightForWidth())
        self.work_column_header.setSizePolicy(sizePolicy)
        self.work_column_header.setMinimumSize(QSize(88, 50))
        self.work_column_header.setMaximumSize(QSize(16777215, 50))
        self.work_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.work_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.work_column_header.setWordWrap(True)

        self.offset_column_header_layout.addWidget(self.work_column_header)

        self.machine_column_header = QLabel(self.offset_column_header_frame)
        self.machine_column_header.setObjectName(u"machine_column_header")
        sizePolicy.setHeightForWidth(self.machine_column_header.sizePolicy().hasHeightForWidth())
        self.machine_column_header.setSizePolicy(sizePolicy)
        self.machine_column_header.setMinimumSize(QSize(85, 50))
        self.machine_column_header.setMaximumSize(QSize(16777215, 50))
        self.machine_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.machine_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.machine_column_header.setWordWrap(True)

        self.offset_column_header_layout.addWidget(self.machine_column_header)

        self.wc_offset_column_header = QLabel(self.offset_column_header_frame)
        self.wc_offset_column_header.setObjectName(u"wc_offset_column_header")
        sizePolicy.setHeightForWidth(self.wc_offset_column_header.sizePolicy().hasHeightForWidth())
        self.wc_offset_column_header.setSizePolicy(sizePolicy)
        self.wc_offset_column_header.setMinimumSize(QSize(60, 50))
        self.wc_offset_column_header.setMaximumSize(QSize(16777215, 50))
        self.wc_offset_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.wc_offset_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.wc_offset_column_header.setWordWrap(True)

        self.offset_column_header_layout.addWidget(self.wc_offset_column_header)

        self.ref_coilumn_header_9 = QLabel(self.offset_column_header_frame)
        self.ref_coilumn_header_9.setObjectName(u"ref_coilumn_header_9")
        sizePolicy6.setHeightForWidth(self.ref_coilumn_header_9.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_9.setSizePolicy(sizePolicy6)
        self.ref_coilumn_header_9.setMinimumSize(QSize(65, 50))
        self.ref_coilumn_header_9.setMaximumSize(QSize(16777215, 50))
        self.ref_coilumn_header_9.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.ref_coilumn_header_9.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ref_coilumn_header_9.setWordWrap(True)

        self.offset_column_header_layout.addWidget(self.ref_coilumn_header_9)

        self.tool_offset_column_header = QLabel(self.offset_column_header_frame)
        self.tool_offset_column_header.setObjectName(u"tool_offset_column_header")
        sizePolicy.setHeightForWidth(self.tool_offset_column_header.sizePolicy().hasHeightForWidth())
        self.tool_offset_column_header.setSizePolicy(sizePolicy)
        self.tool_offset_column_header.setMinimumSize(QSize(65, 50))
        self.tool_offset_column_header.setMaximumSize(QSize(16777215, 50))
        self.tool_offset_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.tool_offset_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.tool_offset_column_header.setWordWrap(True)

        self.offset_column_header_layout.addWidget(self.tool_offset_column_header)


        self.verticalLayout_42.addLayout(self.offset_column_header_layout)


        self.verticalLayout_39.addWidget(self.offset_column_header_frame)

        self.offset_dro_layout = QVBoxLayout()
        self.offset_dro_layout.setSpacing(20)
        self.offset_dro_layout.setObjectName(u"offset_dro_layout")
        self.offset_dro_layout.setContentsMargins(6, 1, 6, 9)

        self.verticalLayout_39.addLayout(self.offset_dro_layout)

        self.spacer_widget = QWidget(self.offset_dro_frame)
        self.spacer_widget.setObjectName(u"spacer_widget")
        sizePolicy8 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy8.setHorizontalStretch(0)
        sizePolicy8.setVerticalStretch(1)
        sizePolicy8.setHeightForWidth(self.spacer_widget.sizePolicy().hasHeightForWidth())
        self.spacer_widget.setSizePolicy(sizePolicy8)

        self.verticalLayout_39.addWidget(self.spacer_widget)


        self.verticalLayout_41.addWidget(self.offset_dro_frame)

        self.mdi_entry_box_offset = MDIEntry(self.offsets_tab)
        self.mdi_entry_box_offset.setObjectName(u"mdi_entry_box_offset")
        sizePolicy6.setHeightForWidth(self.mdi_entry_box_offset.sizePolicy().hasHeightForWidth())
        self.mdi_entry_box_offset.setSizePolicy(sizePolicy6)
        self.mdi_entry_box_offset.setMinimumSize(QSize(0, 40))
        self.mdi_entry_box_offset.setMaximumSize(QSize(16777215, 40))
        self.mdi_entry_box_offset.setFont(font7)
        self.mdi_entry_box_offset.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self.verticalLayout_41.addWidget(self.mdi_entry_box_offset)


        self.horizontalLayout_8.addLayout(self.verticalLayout_41)

        self.verticalLayout_36 = QVBoxLayout()
        self.verticalLayout_36.setSpacing(9)
        self.verticalLayout_36.setObjectName(u"verticalLayout_36")
        self.verticalLayout_36.setContentsMargins(-1, -1, 0, 1)
        self.offset_wco_frame = QFrame(self.offsets_tab)
        self.offset_wco_frame.setObjectName(u"offset_wco_frame")
        sizePolicy.setHeightForWidth(self.offset_wco_frame.sizePolicy().hasHeightForWidth())
        self.offset_wco_frame.setSizePolicy(sizePolicy)
        self.offset_wco_frame.setMaximumSize(QSize(360, 16777215))
        self.offset_wco_frame.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.verticalLayout_40 = QVBoxLayout(self.offset_wco_frame)
        self.verticalLayout_40.setSpacing(15)
        self.verticalLayout_40.setObjectName(u"verticalLayout_40")
        self.verticalLayout_40.setContentsMargins(15, 15, 15, 15)
        self.wco_header_frame = QLabel(self.offset_wco_frame)
        self.wco_header_frame.setObjectName(u"wco_header_frame")
        sizePolicy6.setHeightForWidth(self.wco_header_frame.sizePolicy().hasHeightForWidth())
        self.wco_header_frame.setSizePolicy(sizePolicy6)
        self.wco_header_frame.setMinimumSize(QSize(0, 65))
        self.wco_header_frame.setMaximumSize(QSize(16777215, 65))
        self.wco_header_frame.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"    background: rgb(90, 90, 90);\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.wco_header_frame.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_40.addWidget(self.wco_header_frame)

        self.wco_grid = QGridLayout()
        self.wco_grid.setObjectName(u"wco_grid")
        self.wco_grid.setHorizontalSpacing(12)
        self.wco_grid.setVerticalSpacing(25)
        self.wco_grid.setContentsMargins(-1, 15, -1, 15)
        self.g56_button = ActionButton(self.offset_wco_frame)
        self.g56_button.setObjectName(u"g56_button")
        self.g56_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g56_button.sizePolicy().hasHeightForWidth())
        self.g56_button.setSizePolicy(sizePolicy3)
        self.g56_button.setMinimumSize(QSize(90, 40))
        self.g56_button.setMaximumSize(QSize(90, 40))
        self.g56_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g56_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g56_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g56_button, 0, 2, 1, 1)

        self.g59_2_button = ActionButton(self.offset_wco_frame)
        self.g59_2_button.setObjectName(u"g59_2_button")
        self.g59_2_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g59_2_button.sizePolicy().hasHeightForWidth())
        self.g59_2_button.setSizePolicy(sizePolicy3)
        self.g59_2_button.setMinimumSize(QSize(90, 40))
        self.g59_2_button.setMaximumSize(QSize(90, 40))
        self.g59_2_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g59_2_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g59_2_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g59_2_button, 3, 1, 1, 1)

        self.g54_button = ActionButton(self.offset_wco_frame)
        self.g54_button.setObjectName(u"g54_button")
        self.g54_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g54_button.sizePolicy().hasHeightForWidth())
        self.g54_button.setSizePolicy(sizePolicy3)
        self.g54_button.setMinimumSize(QSize(90, 40))
        self.g54_button.setMaximumSize(QSize(90, 40))
        self.g54_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g54_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g54_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g54_button, 0, 0, 1, 1)

        self.g59_3_button = ActionButton(self.offset_wco_frame)
        self.g59_3_button.setObjectName(u"g59_3_button")
        self.g59_3_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g59_3_button.sizePolicy().hasHeightForWidth())
        self.g59_3_button.setSizePolicy(sizePolicy3)
        self.g59_3_button.setMinimumSize(QSize(90, 40))
        self.g59_3_button.setMaximumSize(QSize(90, 40))
        self.g59_3_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g59_3_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g59_3_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g59_3_button, 3, 2, 1, 1)

        self.g59_1_button = ActionButton(self.offset_wco_frame)
        self.g59_1_button.setObjectName(u"g59_1_button")
        self.g59_1_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g59_1_button.sizePolicy().hasHeightForWidth())
        self.g59_1_button.setSizePolicy(sizePolicy3)
        self.g59_1_button.setMinimumSize(QSize(90, 40))
        self.g59_1_button.setMaximumSize(QSize(90, 40))
        self.g59_1_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g59_1_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g59_1_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g59_1_button, 3, 0, 1, 1)

        self.g57_button = ActionButton(self.offset_wco_frame)
        self.g57_button.setObjectName(u"g57_button")
        self.g57_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g57_button.sizePolicy().hasHeightForWidth())
        self.g57_button.setSizePolicy(sizePolicy3)
        self.g57_button.setMinimumSize(QSize(90, 40))
        self.g57_button.setMaximumSize(QSize(90, 40))
        self.g57_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g57_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g57_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g57_button, 1, 0, 1, 1)

        self.g58_button = ActionButton(self.offset_wco_frame)
        self.g58_button.setObjectName(u"g58_button")
        self.g58_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g58_button.sizePolicy().hasHeightForWidth())
        self.g58_button.setSizePolicy(sizePolicy3)
        self.g58_button.setMinimumSize(QSize(90, 40))
        self.g58_button.setMaximumSize(QSize(90, 40))
        self.g58_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g58_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g58_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g58_button, 1, 1, 1, 1)

        self.g55_button = ActionButton(self.offset_wco_frame)
        self.g55_button.setObjectName(u"g55_button")
        self.g55_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g55_button.sizePolicy().hasHeightForWidth())
        self.g55_button.setSizePolicy(sizePolicy3)
        self.g55_button.setMinimumSize(QSize(90, 40))
        self.g55_button.setMaximumSize(QSize(90, 40))
        self.g55_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g55_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g55_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g55_button, 0, 1, 1, 1)

        self.g59_button = ActionButton(self.offset_wco_frame)
        self.g59_button.setObjectName(u"g59_button")
        self.g59_button.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.g59_button.sizePolicy().hasHeightForWidth())
        self.g59_button.setSizePolicy(sizePolicy3)
        self.g59_button.setMinimumSize(QSize(90, 40))
        self.g59_button.setMaximumSize(QSize(90, 40))
        self.g59_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.g59_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g59_button.setAutoExclusive(True)

        self.wco_grid.addWidget(self.g59_button, 1, 2, 1, 1)


        self.verticalLayout_40.addLayout(self.wco_grid)

        self.widget_40 = QWidget(self.offset_wco_frame)
        self.widget_40.setObjectName(u"widget_40")
        sizePolicy8.setHeightForWidth(self.widget_40.sizePolicy().hasHeightForWidth())
        self.widget_40.setSizePolicy(sizePolicy8)

        self.verticalLayout_40.addWidget(self.widget_40)

        self.wco_header_frame_2 = QLabel(self.offset_wco_frame)
        self.wco_header_frame_2.setObjectName(u"wco_header_frame_2")
        sizePolicy6.setHeightForWidth(self.wco_header_frame_2.sizePolicy().hasHeightForWidth())
        self.wco_header_frame_2.setSizePolicy(sizePolicy6)
        self.wco_header_frame_2.setMinimumSize(QSize(0, 40))
        self.wco_header_frame_2.setMaximumSize(QSize(16777215, 40))
        self.wco_header_frame_2.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"    background: rgb(90, 90, 90);\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.wco_header_frame_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_40.addWidget(self.wco_header_frame_2)

        self.g30_widget = QWidget(self.offset_wco_frame)
        self.g30_widget.setObjectName(u"g30_widget")
        sizePolicy8.setHeightForWidth(self.g30_widget.sizePolicy().hasHeightForWidth())
        self.g30_widget.setSizePolicy(sizePolicy8)
        self.verticalLayout_21 = QVBoxLayout(self.g30_widget)
        self.verticalLayout_21.setSpacing(20)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.verticalLayout_21.setContentsMargins(0, 1, 0, 1)
        self.set_g30_position = SubCallButton(self.g30_widget)
        self.set_g30_position.setObjectName(u"set_g30_position")
        self.set_g30_position.setMinimumSize(QSize(0, 40))
        self.set_g30_position.setMaximumSize(QSize(16777215, 40))
        self.set_g30_position.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.set_g30_position.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.verticalLayout_21.addWidget(self.set_g30_position)

        self.xz_g30_widget = QHBoxLayout()
        self.xz_g30_widget.setSpacing(2)
        self.xz_g30_widget.setObjectName(u"xz_g30_widget")
        self.xz_g30_widget.setContentsMargins(-1, -1, 8, -1)
        self.x_label = QLabel(self.g30_widget)
        self.x_label.setObjectName(u"x_label")
        sizePolicy3.setHeightForWidth(self.x_label.sizePolicy().hasHeightForWidth())
        self.x_label.setSizePolicy(sizePolicy3)
        self.x_label.setMinimumSize(QSize(20, 33))
        self.x_label.setMaximumSize(QSize(20, 33))
        self.x_label.setStyleSheet(u"QLabel{\n"
"font: 75 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 1px;\n"
"padding-left: 5px;\n"
"}")
        self.x_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.xz_g30_widget.addWidget(self.x_label)

        self.x_tool_change_position_5181 = VCPVarLineEdit(self.g30_widget)
        self.x_tool_change_position_5181.setObjectName(u"x_tool_change_position_5181")
        self.x_tool_change_position_5181.setMinimumSize(QSize(75, 33))
        self.x_tool_change_position_5181.setMaximumSize(QSize(16777215, 33))
        self.x_tool_change_position_5181.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_tool_change_position_5181.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.x_tool_change_position_5181.setProperty(u"varParameterNumber", 5181)

        self.xz_g30_widget.addWidget(self.x_tool_change_position_5181)

        self.z_label = QLabel(self.g30_widget)
        self.z_label.setObjectName(u"z_label")
        sizePolicy3.setHeightForWidth(self.z_label.sizePolicy().hasHeightForWidth())
        self.z_label.setSizePolicy(sizePolicy3)
        self.z_label.setMinimumSize(QSize(23, 33))
        self.z_label.setMaximumSize(QSize(23, 33))
        self.z_label.setStyleSheet(u"QLabel{\n"
"font: 75 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 1px;\n"
"padding-left: 5px;\n"
"}")
        self.z_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.xz_g30_widget.addWidget(self.z_label)

        self.z_tool_change_position_5183 = VCPVarLineEdit(self.g30_widget)
        self.z_tool_change_position_5183.setObjectName(u"z_tool_change_position_5183")
        self.z_tool_change_position_5183.setMinimumSize(QSize(75, 33))
        self.z_tool_change_position_5183.setMaximumSize(QSize(16777215, 33))
        self.z_tool_change_position_5183.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_tool_change_position_5183.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.z_tool_change_position_5183.setProperty(u"varParameterNumber", 5183)

        self.xz_g30_widget.addWidget(self.z_tool_change_position_5183)


        self.verticalLayout_21.addLayout(self.xz_g30_widget)


        self.verticalLayout_40.addWidget(self.g30_widget)

        self.use_tcp = VCPVarPushButton(self.offset_wco_frame)
        self.use_tcp.setObjectName(u"use_tcp")
        self.use_tcp.setMinimumSize(QSize(0, 40))
        self.use_tcp.setMaximumSize(QSize(16777215, 40))
        self.use_tcp.setProperty(u"varParameterNumber", 3972)

        self.verticalLayout_40.addWidget(self.use_tcp)


        self.verticalLayout_36.addWidget(self.offset_wco_frame)


        self.horizontalLayout_8.addLayout(self.verticalLayout_36)

        self.tabWidget.addTab(self.offsets_tab, "")
        self.touch_off_tab = QWidget()
        self.touch_off_tab.setObjectName(u"touch_off_tab")
        self.touch_off_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout_5 = QHBoxLayout(self.touch_off_tab)
        self.horizontalLayout_5.setSpacing(20)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(20, 20, 20, 20)
        self.widget_4 = QWidget(self.touch_off_tab)
        self.widget_4.setObjectName(u"widget_4")
        self.widget_4.setFont(font8)
        self.horizontalLayout_67 = QHBoxLayout(self.widget_4)
        self.horizontalLayout_67.setSpacing(15)
        self.horizontalLayout_67.setObjectName(u"horizontalLayout_67")
        self.horizontalLayout_67.setContentsMargins(0, 0, 0, 0)
        self.widget_50 = QWidget(self.widget_4)
        self.widget_50.setObjectName(u"widget_50")
        sizePolicy7.setHeightForWidth(self.widget_50.sizePolicy().hasHeightForWidth())
        self.widget_50.setSizePolicy(sizePolicy7)
        self.widget_50.setMinimumSize(QSize(1000, 0))
        self.widget_50.setMaximumSize(QSize(1000, 16777215))
        self.verticalLayout_47 = QVBoxLayout(self.widget_50)
        self.verticalLayout_47.setSpacing(15)
        self.verticalLayout_47.setObjectName(u"verticalLayout_47")
        self.verticalLayout_47.setContentsMargins(0, 0, 0, 0)
        self.lathetooltouchoff = LatheToolTouchOff(self.widget_50)
        self.lathetooltouchoff.setObjectName(u"lathetooltouchoff")
        sizePolicy7.setHeightForWidth(self.lathetooltouchoff.sizePolicy().hasHeightForWidth())
        self.lathetooltouchoff.setSizePolicy(sizePolicy7)
        self.lathetooltouchoff.setMaximumSize(QSize(1000, 580))

        self.verticalLayout_47.addWidget(self.lathetooltouchoff)

        self.mdi_entry_box_8 = MDIEntry(self.widget_50)
        self.mdi_entry_box_8.setObjectName(u"mdi_entry_box_8")
        sizePolicy6.setHeightForWidth(self.mdi_entry_box_8.sizePolicy().hasHeightForWidth())
        self.mdi_entry_box_8.setSizePolicy(sizePolicy6)
        self.mdi_entry_box_8.setMinimumSize(QSize(800, 35))
        self.mdi_entry_box_8.setMaximumSize(QSize(16777215, 35))
        self.mdi_entry_box_8.setFont(font7)
        self.mdi_entry_box_8.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self.verticalLayout_47.addWidget(self.mdi_entry_box_8)


        self.horizontalLayout_67.addWidget(self.widget_50)

        self.widget_7 = QWidget(self.widget_4)
        self.widget_7.setObjectName(u"widget_7")
        sizePolicy4.setHeightForWidth(self.widget_7.sizePolicy().hasHeightForWidth())
        self.widget_7.setSizePolicy(sizePolicy4)
        self.widget_7.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.verticalLayout_13 = QVBoxLayout(self.widget_7)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(15, 0, 15, 0)
        self.frame_52 = QFrame(self.widget_7)
        self.frame_52.setObjectName(u"frame_52")
        sizePolicy.setHeightForWidth(self.frame_52.sizePolicy().hasHeightForWidth())
        self.frame_52.setSizePolicy(sizePolicy)
        self.frame_52.setMinimumSize(QSize(0, 90))
        self.frame_52.setMaximumSize(QSize(280, 90))
        self.frame_52.setStyleSheet(u"QFrame{\n"
"color: rgb(46, 52, 54);\n"
"border-style: solid;\n"
"border-color: rgb(186, 189, 182);\n"
"background-color: rgb(51, 57, 59);\n"
"border-width: 2px;\n"
"border-radius: 6px;\n"
"padding-top: 0px;\n"
"padding-bottom: 0px;\n"
"padding-left: 10px;\n"
"padding-right: 10px;\n"
"}")
        self.verticalLayout_53 = QVBoxLayout(self.frame_52)
        self.verticalLayout_53.setSpacing(9)
        self.verticalLayout_53.setObjectName(u"verticalLayout_53")
        self.verticalLayout_53.setContentsMargins(1, 9, 1, 9)
        self.widget_76 = QWidget(self.frame_52)
        self.widget_76.setObjectName(u"widget_76")
        sizePolicy6.setHeightForWidth(self.widget_76.sizePolicy().hasHeightForWidth())
        self.widget_76.setSizePolicy(sizePolicy6)
        self.horizontalLayout_92 = QHBoxLayout(self.widget_76)
        self.horizontalLayout_92.setSpacing(15)
        self.horizontalLayout_92.setObjectName(u"horizontalLayout_92")
        self.horizontalLayout_92.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_92.setContentsMargins(2, 2, 2, 2)
        self.widget_72 = QWidget(self.widget_76)
        self.widget_72.setObjectName(u"widget_72")
        sizePolicy6.setHeightForWidth(self.widget_72.sizePolicy().hasHeightForWidth())
        self.widget_72.setSizePolicy(sizePolicy6)
        self.horizontalLayout_84 = QHBoxLayout(self.widget_72)
        self.horizontalLayout_84.setSpacing(15)
        self.horizontalLayout_84.setObjectName(u"horizontalLayout_84")
        self.horizontalLayout_84.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_84.setContentsMargins(2, 6, 2, 6)
        self.m6_tool_call_touch_panel = SubCallButton(self.widget_72)
        self.m6_tool_call_touch_panel.setObjectName(u"m6_tool_call_touch_panel")
        self.m6_tool_call_touch_panel.setEnabled(False)
        sizePolicy9 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy9.setHorizontalStretch(100)
        sizePolicy9.setVerticalStretch(0)
        sizePolicy9.setHeightForWidth(self.m6_tool_call_touch_panel.sizePolicy().hasHeightForWidth())
        self.m6_tool_call_touch_panel.setSizePolicy(sizePolicy9)
        self.m6_tool_call_touch_panel.setMinimumSize(QSize(100, 45))
        self.m6_tool_call_touch_panel.setMaximumSize(QSize(16777215, 45))
        self.m6_tool_call_touch_panel.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_84.addWidget(self.m6_tool_call_touch_panel)

        self.tool_number_entry_touch_panel = VCPLineEdit(self.widget_72)
        self.tool_number_entry_touch_panel.setObjectName(u"tool_number_entry_touch_panel")
        self.tool_number_entry_touch_panel.setEnabled(False)
        sizePolicy9.setHeightForWidth(self.tool_number_entry_touch_panel.sizePolicy().hasHeightForWidth())
        self.tool_number_entry_touch_panel.setSizePolicy(sizePolicy9)
        self.tool_number_entry_touch_panel.setMinimumSize(QSize(100, 40))
        self.tool_number_entry_touch_panel.setMaximumSize(QSize(16777215, 40))
        self.tool_number_entry_touch_panel.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.tool_number_entry_touch_panel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_84.addWidget(self.tool_number_entry_touch_panel)


        self.horizontalLayout_92.addWidget(self.widget_72)


        self.verticalLayout_53.addWidget(self.widget_76)


        self.verticalLayout_13.addWidget(self.frame_52)

        self.widget_17 = QWidget(self.widget_7)
        self.widget_17.setObjectName(u"widget_17")
        sizePolicy8.setHeightForWidth(self.widget_17.sizePolicy().hasHeightForWidth())
        self.widget_17.setSizePolicy(sizePolicy8)
        self.verticalLayout_6 = QVBoxLayout(self.widget_17)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.tool_length_8 = StatusLabel(self.widget_17)
        self.tool_length_8.setObjectName(u"tool_length_8")
        sizePolicy8.setHeightForWidth(self.tool_length_8.sizePolicy().hasHeightForWidth())
        self.tool_length_8.setSizePolicy(sizePolicy8)
        self.tool_length_8.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.tool_length_8.setWordWrap(True)
        self.tool_length_8.setIndent(4)

        self.verticalLayout_6.addWidget(self.tool_length_8)


        self.verticalLayout_13.addWidget(self.widget_17)

        self.tool_orientation_label = QLabel(self.widget_7)
        self.tool_orientation_label.setObjectName(u"tool_orientation_label")
        sizePolicy6.setHeightForWidth(self.tool_orientation_label.sizePolicy().hasHeightForWidth())
        self.tool_orientation_label.setSizePolicy(sizePolicy6)
        self.tool_orientation_label.setMinimumSize(QSize(0, 42))
        self.tool_orientation_label.setMaximumSize(QSize(16777215, 42))
        self.tool_orientation_label.setStyleSheet(u"QLabel{\n"
"    color: white;\n"
"	font: 16.5pt \"Probe Basic Bebas Mono\";\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 1px;\n"
"    border-radius: 3px;\n"
"    background-color: rgb(90, 90, 90);\n"
"    padding: -5px;\n"
"}")
        self.tool_orientation_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_13.addWidget(self.tool_orientation_label)

        self.widget_14 = QWidget(self.widget_7)
        self.widget_14.setObjectName(u"widget_14")
        self.widget_14.setMaximumSize(QSize(16777215, 15))

        self.verticalLayout_13.addWidget(self.widget_14)

        self.stackedWidget_82 = QStackedWidget(self.widget_7)
        self.stackedWidget_82.setObjectName(u"stackedWidget_82")
        sizePolicy3.setHeightForWidth(self.stackedWidget_82.sizePolicy().hasHeightForWidth())
        self.stackedWidget_82.setSizePolicy(sizePolicy3)
        self.stackedWidget_82.setMinimumSize(QSize(250, 250))
        self.stackedWidget_82.setMaximumSize(QSize(250, 250))
        self.stackedWidget_82Page1 = QWidget()
        self.stackedWidget_82Page1.setObjectName(u"stackedWidget_82Page1")
        self.gridLayout_8 = QGridLayout(self.stackedWidget_82Page1)
        self.gridLayout_8.setSpacing(0)
        self.gridLayout_8.setObjectName(u"gridLayout_8")
        self.gridLayout_8.setContentsMargins(5, 0, 0, 0)
        self.lathe_control_point_9 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup = QButtonGroup(Form)
        self.lathecontrolpointbtngroup.setObjectName(u"lathecontrolpointbtngroup")
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_9)
        self.lathe_control_point_9.setObjectName(u"lathe_control_point_9")
        self.lathe_control_point_9.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_9.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_9.setSizePolicy(sizePolicy3)
        self.lathe_control_point_9.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_9.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_9.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon11 = QIcon()
        icon11.addFile(u":/images/lathe_control_point_9.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_9.setIcon(icon11)
        self.lathe_control_point_9.setIconSize(QSize(50, 50))
        self.lathe_control_point_9.setCheckable(True)
        self.lathe_control_point_9.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_9, 2, 1, 1, 1)

        self.lathe_control_point_5 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_5)
        self.lathe_control_point_5.setObjectName(u"lathe_control_point_5")
        self.lathe_control_point_5.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_5.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_5.setSizePolicy(sizePolicy3)
        self.lathe_control_point_5.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_5.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_5.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon12 = QIcon()
        icon12.addFile(u":/images/lathe_control_point_5.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_5.setIcon(icon12)
        self.lathe_control_point_5.setIconSize(QSize(65, 65))
        self.lathe_control_point_5.setCheckable(True)
        self.lathe_control_point_5.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_5, 2, 0, 1, 1)

        self.lathe_control_point_7 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_7)
        self.lathe_control_point_7.setObjectName(u"lathe_control_point_7")
        self.lathe_control_point_7.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_7.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_7.setSizePolicy(sizePolicy3)
        self.lathe_control_point_7.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_7.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_7.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon13 = QIcon()
        icon13.addFile(u":/images/lathe_control_point_7.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_7.setIcon(icon13)
        self.lathe_control_point_7.setIconSize(QSize(65, 65))
        self.lathe_control_point_7.setCheckable(True)
        self.lathe_control_point_7.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_7, 2, 2, 1, 1)

        self.lathe_control_point_2 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_2)
        self.lathe_control_point_2.setObjectName(u"lathe_control_point_2")
        self.lathe_control_point_2.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_2.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_2.setSizePolicy(sizePolicy3)
        self.lathe_control_point_2.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_2.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_2.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon14 = QIcon()
        icon14.addFile(u":/images/lathe_control_point_2.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_2.setIcon(icon14)
        self.lathe_control_point_2.setIconSize(QSize(65, 65))
        self.lathe_control_point_2.setCheckable(True)
        self.lathe_control_point_2.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_2, 3, 2, 1, 1)

        self.lathe_control_point_3 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_3)
        self.lathe_control_point_3.setObjectName(u"lathe_control_point_3")
        self.lathe_control_point_3.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_3.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_3.setSizePolicy(sizePolicy3)
        self.lathe_control_point_3.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_3.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_3.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon15 = QIcon()
        icon15.addFile(u":/images/lathe_control_point_3.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_3.setIcon(icon15)
        self.lathe_control_point_3.setIconSize(QSize(65, 65))
        self.lathe_control_point_3.setCheckable(True)
        self.lathe_control_point_3.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_3, 1, 2, 1, 1)

        self.lathe_control_point_6 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_6)
        self.lathe_control_point_6.setObjectName(u"lathe_control_point_6")
        self.lathe_control_point_6.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_6.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_6.setSizePolicy(sizePolicy3)
        self.lathe_control_point_6.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_6.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_6.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon16 = QIcon()
        icon16.addFile(u":/images/lathe_control_point_6.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_6.setIcon(icon16)
        self.lathe_control_point_6.setIconSize(QSize(65, 65))
        self.lathe_control_point_6.setCheckable(True)
        self.lathe_control_point_6.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_6, 3, 1, 1, 1)

        self.lathe_control_point_4 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_4)
        self.lathe_control_point_4.setObjectName(u"lathe_control_point_4")
        self.lathe_control_point_4.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_4.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_4.setSizePolicy(sizePolicy3)
        self.lathe_control_point_4.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_4.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_4.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon17 = QIcon()
        icon17.addFile(u":/images/lathe_control_point_4.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_4.setIcon(icon17)
        self.lathe_control_point_4.setIconSize(QSize(65, 65))
        self.lathe_control_point_4.setCheckable(True)
        self.lathe_control_point_4.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_4, 1, 0, 1, 1)

        self.lathe_control_point_1 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_1)
        self.lathe_control_point_1.setObjectName(u"lathe_control_point_1")
        self.lathe_control_point_1.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_1.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_1.setSizePolicy(sizePolicy3)
        self.lathe_control_point_1.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_1.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_1.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon18 = QIcon()
        icon18.addFile(u":/images/lathe_control_point_1.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_1.setIcon(icon18)
        self.lathe_control_point_1.setIconSize(QSize(65, 65))
        self.lathe_control_point_1.setCheckable(True)
        self.lathe_control_point_1.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_1, 3, 0, 1, 1)

        self.lathe_control_point_8 = ActionButton(self.stackedWidget_82Page1)
        self.lathecontrolpointbtngroup.addButton(self.lathe_control_point_8)
        self.lathe_control_point_8.setObjectName(u"lathe_control_point_8")
        self.lathe_control_point_8.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_8.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_8.setSizePolicy(sizePolicy3)
        self.lathe_control_point_8.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_8.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_8.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon19 = QIcon()
        icon19.addFile(u":/images/lathe_control_point_8.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_8.setIcon(icon19)
        self.lathe_control_point_8.setIconSize(QSize(65, 65))
        self.lathe_control_point_8.setCheckable(True)
        self.lathe_control_point_8.setAutoExclusive(True)

        self.gridLayout_8.addWidget(self.lathe_control_point_8, 1, 1, 1, 1)

        self.stackedWidget_82.addWidget(self.stackedWidget_82Page1)
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.gridLayout = QGridLayout(self.page)
        self.gridLayout.setObjectName(u"gridLayout")
        self.lathe_control_point_5_inverse = ActionButton(self.page)
        self.lathe_control_point_5_inverse.setObjectName(u"lathe_control_point_5_inverse")
        self.lathe_control_point_5_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_5_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_5_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_5_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_5_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_5_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon20 = QIcon()
        icon20.addFile(u":/images/lathe_control_point_5_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_5_inverse.setIcon(icon20)
        self.lathe_control_point_5_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_5_inverse.setCheckable(True)
        self.lathe_control_point_5_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_5_inverse, 1, 0, 1, 1)

        self.lathe_control_point_1_inverse = ActionButton(self.page)
        self.lathe_control_point_1_inverse.setObjectName(u"lathe_control_point_1_inverse")
        self.lathe_control_point_1_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_1_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_1_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_1_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_1_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_1_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon21 = QIcon()
        icon21.addFile(u":/images/lathe_control_point_1_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_1_inverse.setIcon(icon21)
        self.lathe_control_point_1_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_1_inverse.setCheckable(True)
        self.lathe_control_point_1_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_1_inverse, 0, 0, 1, 1)

        self.lathe_control_point_9_inverse = ActionButton(self.page)
        self.lathe_control_point_9_inverse.setObjectName(u"lathe_control_point_9_inverse")
        self.lathe_control_point_9_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_9_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_9_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_9_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_9_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_9_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon22 = QIcon()
        icon22.addFile(u":/images/lathe_control_point_9_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_9_inverse.setIcon(icon22)
        self.lathe_control_point_9_inverse.setIconSize(QSize(50, 50))
        self.lathe_control_point_9_inverse.setCheckable(True)
        self.lathe_control_point_9_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_9_inverse, 1, 1, 1, 1)

        self.lathe_control_point_7_inverse = ActionButton(self.page)
        self.lathe_control_point_7_inverse.setObjectName(u"lathe_control_point_7_inverse")
        self.lathe_control_point_7_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_7_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_7_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_7_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_7_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_7_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon23 = QIcon()
        icon23.addFile(u":/images/lathe_control_point_7_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_7_inverse.setIcon(icon23)
        self.lathe_control_point_7_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_7_inverse.setCheckable(True)
        self.lathe_control_point_7_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_7_inverse, 1, 2, 1, 1)

        self.lathe_control_point_6_inverse = ActionButton(self.page)
        self.lathe_control_point_6_inverse.setObjectName(u"lathe_control_point_6_inverse")
        self.lathe_control_point_6_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_6_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_6_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_6_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_6_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_6_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon24 = QIcon()
        icon24.addFile(u":/images/lathe_control_point_6_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_6_inverse.setIcon(icon24)
        self.lathe_control_point_6_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_6_inverse.setCheckable(True)
        self.lathe_control_point_6_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_6_inverse, 0, 1, 1, 1)

        self.lathe_control_point_2_inverse = ActionButton(self.page)
        self.lathe_control_point_2_inverse.setObjectName(u"lathe_control_point_2_inverse")
        self.lathe_control_point_2_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_2_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_2_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_2_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_2_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_2_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon25 = QIcon()
        icon25.addFile(u":/images/lathe_control_point_2_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_2_inverse.setIcon(icon25)
        self.lathe_control_point_2_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_2_inverse.setCheckable(True)
        self.lathe_control_point_2_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_2_inverse, 0, 2, 1, 1)

        self.lathe_control_point_3_inverse = ActionButton(self.page)
        self.lathe_control_point_3_inverse.setObjectName(u"lathe_control_point_3_inverse")
        self.lathe_control_point_3_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_3_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_3_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_3_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_3_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_3_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon26 = QIcon()
        icon26.addFile(u":/images/lathe_control_point_3_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_3_inverse.setIcon(icon26)
        self.lathe_control_point_3_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_3_inverse.setCheckable(True)
        self.lathe_control_point_3_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_3_inverse, 2, 2, 1, 1)

        self.lathe_control_point_8_inverse = ActionButton(self.page)
        self.lathe_control_point_8_inverse.setObjectName(u"lathe_control_point_8_inverse")
        self.lathe_control_point_8_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_8_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_8_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_8_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_8_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_8_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon27 = QIcon()
        icon27.addFile(u":/images/lathe_control_point_8_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_8_inverse.setIcon(icon27)
        self.lathe_control_point_8_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_8_inverse.setCheckable(True)
        self.lathe_control_point_8_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_8_inverse, 2, 1, 1, 1)

        self.lathe_control_point_4_inverse = ActionButton(self.page)
        self.lathe_control_point_4_inverse.setObjectName(u"lathe_control_point_4_inverse")
        self.lathe_control_point_4_inverse.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.lathe_control_point_4_inverse.sizePolicy().hasHeightForWidth())
        self.lathe_control_point_4_inverse.setSizePolicy(sizePolicy3)
        self.lathe_control_point_4_inverse.setMinimumSize(QSize(70, 70))
        self.lathe_control_point_4_inverse.setMaximumSize(QSize(70, 70))
        self.lathe_control_point_4_inverse.setStyleSheet(u"ActionButton{\n"
"    border: none;\n"
"    background: none;\n"
"}\n"
"\n"
"ActionButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"ActionButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"")
        icon28 = QIcon()
        icon28.addFile(u":/images/lathe_control_point_4_inverse.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.lathe_control_point_4_inverse.setIcon(icon28)
        self.lathe_control_point_4_inverse.setIconSize(QSize(65, 65))
        self.lathe_control_point_4_inverse.setCheckable(True)
        self.lathe_control_point_4_inverse.setAutoExclusive(True)

        self.gridLayout.addWidget(self.lathe_control_point_4_inverse, 2, 0, 1, 1)

        self.stackedWidget_82.addWidget(self.page)

        self.verticalLayout_13.addWidget(self.stackedWidget_82)

        self.widget_12 = QWidget(self.widget_7)
        self.widget_12.setObjectName(u"widget_12")

        self.verticalLayout_13.addWidget(self.widget_12)

        self.widget_16 = QWidget(self.widget_7)
        self.widget_16.setObjectName(u"widget_16")
        self.widget_16.setMaximumSize(QSize(16777215, 15))

        self.verticalLayout_13.addWidget(self.widget_16)

        self.m01_break_button_20 = ActionButton(self.widget_7)
        self.m01_break_button_20.setObjectName(u"m01_break_button_20")
        sizePolicy6.setHeightForWidth(self.m01_break_button_20.sizePolicy().hasHeightForWidth())
        self.m01_break_button_20.setSizePolicy(sizePolicy6)
        self.m01_break_button_20.setMinimumSize(QSize(0, 45))
        self.m01_break_button_20.setMaximumSize(QSize(16777215, 45))
        self.m01_break_button_20.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.m01_break_button_20.setStyleSheet(u"QPushButton {\n"
"   	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.verticalLayout_13.addWidget(self.m01_break_button_20)


        self.horizontalLayout_67.addWidget(self.widget_7)

        self.tool_offset_stacked_widget = QStackedWidget(self.widget_4)
        self.tool_offset_stacked_widget.setObjectName(u"tool_offset_stacked_widget")
        sizePolicy6.setHeightForWidth(self.tool_offset_stacked_widget.sizePolicy().hasHeightForWidth())
        self.tool_offset_stacked_widget.setSizePolicy(sizePolicy6)
        self.tool_offset_stacked_widget.setMinimumSize(QSize(290, 0))
        self.tool_offset_stacked_widget.setMaximumSize(QSize(290, 630))
        self.tool_absolute_offset_page = QWidget()
        self.tool_absolute_offset_page.setObjectName(u"tool_absolute_offset_page")
        self.verticalLayout_10 = QVBoxLayout(self.tool_absolute_offset_page)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(7, 0, 0, 0)
        self.frame_51 = QFrame(self.tool_absolute_offset_page)
        self.frame_51.setObjectName(u"frame_51")
        sizePolicy7.setHeightForWidth(self.frame_51.sizePolicy().hasHeightForWidth())
        self.frame_51.setSizePolicy(sizePolicy7)
        self.frame_51.setMinimumSize(QSize(280, 0))
        self.frame_51.setMaximumSize(QSize(280, 16777215))
        self.verticalLayout_52 = QVBoxLayout(self.frame_51)
        self.verticalLayout_52.setSpacing(9)
        self.verticalLayout_52.setObjectName(u"verticalLayout_52")
        self.verticalLayout_52.setContentsMargins(19, 22, 19, 9)
        self.widget_9 = QWidget(self.frame_51)
        self.widget_9.setObjectName(u"widget_9")
        sizePolicy6.setHeightForWidth(self.widget_9.sizePolicy().hasHeightForWidth())
        self.widget_9.setSizePolicy(sizePolicy6)
        self.horizontalLayout_85 = QHBoxLayout(self.widget_9)
        self.horizontalLayout_85.setSpacing(12)
        self.horizontalLayout_85.setObjectName(u"horizontalLayout_85")
        self.horizontalLayout_85.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_85.setContentsMargins(2, 2, 2, 3)
        self.x_offset_touch_value_3102 = VCPVarLineEdit(self.widget_9)
        self.x_offset_touch_value_3102.setObjectName(u"x_offset_touch_value_3102")
        sizePolicy6.setHeightForWidth(self.x_offset_touch_value_3102.sizePolicy().hasHeightForWidth())
        self.x_offset_touch_value_3102.setSizePolicy(sizePolicy6)
        self.x_offset_touch_value_3102.setMinimumSize(QSize(0, 40))
        self.x_offset_touch_value_3102.setMaximumSize(QSize(16777215, 40))
        self.x_offset_touch_value_3102.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_offset_touch_value_3102.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.x_offset_touch_value_3102.setProperty(u"highPrecisionStorage", False)
        self.x_offset_touch_value_3102.setProperty(u"displayDecimals", 6)
        self.x_offset_touch_value_3102.setProperty(u"varParameterNumber", 3102)

        self.horizontalLayout_85.addWidget(self.x_offset_touch_value_3102)

        self.touch_off_x = SubCallButton(self.widget_9)
        self.touch_off_x.setObjectName(u"touch_off_x")
        sizePolicy6.setHeightForWidth(self.touch_off_x.sizePolicy().hasHeightForWidth())
        self.touch_off_x.setSizePolicy(sizePolicy6)
        self.touch_off_x.setMinimumSize(QSize(110, 40))
        self.touch_off_x.setMaximumSize(QSize(110, 40))
        self.touch_off_x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.touch_off_x.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_85.addWidget(self.touch_off_x)


        self.verticalLayout_52.addWidget(self.widget_9)

        self.widget_73 = QWidget(self.frame_51)
        self.widget_73.setObjectName(u"widget_73")
        sizePolicy6.setHeightForWidth(self.widget_73.sizePolicy().hasHeightForWidth())
        self.widget_73.setSizePolicy(sizePolicy6)
        self.horizontalLayout_86 = QHBoxLayout(self.widget_73)
        self.horizontalLayout_86.setSpacing(15)
        self.horizontalLayout_86.setObjectName(u"horizontalLayout_86")
        self.horizontalLayout_86.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_86.setContentsMargins(2, 4, 2, 4)
        self.touch_off_z = SubCallButton(self.widget_73)
        self.touch_off_z.setObjectName(u"touch_off_z")
        sizePolicy6.setHeightForWidth(self.touch_off_z.sizePolicy().hasHeightForWidth())
        self.touch_off_z.setSizePolicy(sizePolicy6)
        self.touch_off_z.setMinimumSize(QSize(110, 40))
        self.touch_off_z.setMaximumSize(QSize(16777215, 40))
        self.touch_off_z.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.touch_off_z.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_86.addWidget(self.touch_off_z)


        self.verticalLayout_52.addWidget(self.widget_73)

        self.widget_20 = QWidget(self.frame_51)
        self.widget_20.setObjectName(u"widget_20")
        sizePolicy6.setHeightForWidth(self.widget_20.sizePolicy().hasHeightForWidth())
        self.widget_20.setSizePolicy(sizePolicy6)
        self.widget_20.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.horizontalLayout_46 = QHBoxLayout(self.widget_20)
        self.horizontalLayout_46.setSpacing(9)
        self.horizontalLayout_46.setObjectName(u"horizontalLayout_46")
        self.horizontalLayout_46.setContentsMargins(2, 3, 2, 12)
        self.mt_z_offset_label_4 = QLabel(self.widget_20)
        self.mt_z_offset_label_4.setObjectName(u"mt_z_offset_label_4")
        self.mt_z_offset_label_4.setMinimumSize(QSize(0, 40))
        self.mt_z_offset_label_4.setMaximumSize(QSize(16777215, 40))
        self.mt_z_offset_label_4.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.mt_z_offset_label_4.setStyleSheet(u"QLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"    padding: -5px;\n"
"}")
        self.mt_z_offset_label_4.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.mt_z_offset_label_4.setMargin(0)
        self.mt_z_offset_label_4.setIndent(-1)

        self.horizontalLayout_46.addWidget(self.mt_z_offset_label_4)

        self.gage_thickness_3101 = VCPVarLineEdit(self.widget_20)
        self.gage_thickness_3101.setObjectName(u"gage_thickness_3101")
        sizePolicy6.setHeightForWidth(self.gage_thickness_3101.sizePolicy().hasHeightForWidth())
        self.gage_thickness_3101.setSizePolicy(sizePolicy6)
        self.gage_thickness_3101.setMinimumSize(QSize(110, 40))
        self.gage_thickness_3101.setMaximumSize(QSize(110, 40))
        self.gage_thickness_3101.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.gage_thickness_3101.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.gage_thickness_3101.setProperty(u"highPrecisionStorage", False)
        self.gage_thickness_3101.setProperty(u"displayDecimals", 6)
        self.gage_thickness_3101.setProperty(u"varParameterNumber", 3101)

        self.horizontalLayout_46.addWidget(self.gage_thickness_3101)


        self.verticalLayout_52.addWidget(self.widget_20)

        self.widget_75 = QWidget(self.frame_51)
        self.widget_75.setObjectName(u"widget_75")
        sizePolicy.setHeightForWidth(self.widget_75.sizePolicy().hasHeightForWidth())
        self.widget_75.setSizePolicy(sizePolicy)
        self.verticalLayout_15 = QVBoxLayout(self.widget_75)
        self.verticalLayout_15.setSpacing(9)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(6, 6, 6, 1)
        self.horizontalLayout_29 = QHBoxLayout()
        self.horizontalLayout_29.setSpacing(3)
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.horizontalLayout_29.setContentsMargins(-1, 2, 0, 2)
        self.label_61 = QLabel(self.widget_75)
        self.label_61.setObjectName(u"label_61")
        sizePolicy6.setHeightForWidth(self.label_61.sizePolicy().hasHeightForWidth())
        self.label_61.setSizePolicy(sizePolicy6)
        self.label_61.setMinimumSize(QSize(35, 33))
        self.label_61.setMaximumSize(QSize(16777215, 33))
        self.label_61.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_61.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_61.setWordWrap(True)

        self.horizontalLayout_29.addWidget(self.label_61)

        self.tool_length_13 = StatusLabel(self.widget_75)
        self.tool_length_13.setObjectName(u"tool_length_13")
        sizePolicy4.setHeightForWidth(self.tool_length_13.sizePolicy().hasHeightForWidth())
        self.tool_length_13.setSizePolicy(sizePolicy4)
        self.tool_length_13.setMinimumSize(QSize(90, 35))
        self.tool_length_13.setMaximumSize(QSize(70, 35))
        self.tool_length_13.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_29.addWidget(self.tool_length_13)


        self.verticalLayout_15.addLayout(self.horizontalLayout_29)

        self.horizontalLayout_32 = QHBoxLayout()
        self.horizontalLayout_32.setSpacing(3)
        self.horizontalLayout_32.setObjectName(u"horizontalLayout_32")
        self.horizontalLayout_32.setContentsMargins(-1, 2, 0, 2)
        self.label_54 = QLabel(self.widget_75)
        self.label_54.setObjectName(u"label_54")
        sizePolicy6.setHeightForWidth(self.label_54.sizePolicy().hasHeightForWidth())
        self.label_54.setSizePolicy(sizePolicy6)
        self.label_54.setMinimumSize(QSize(35, 33))
        self.label_54.setMaximumSize(QSize(16777215, 33))
        self.label_54.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_54.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_54.setWordWrap(True)

        self.horizontalLayout_32.addWidget(self.label_54)

        self.tool_diameter_7 = StatusLabel(self.widget_75)
        self.tool_diameter_7.setObjectName(u"tool_diameter_7")
        sizePolicy4.setHeightForWidth(self.tool_diameter_7.sizePolicy().hasHeightForWidth())
        self.tool_diameter_7.setSizePolicy(sizePolicy4)
        self.tool_diameter_7.setMinimumSize(QSize(90, 35))
        self.tool_diameter_7.setMaximumSize(QSize(70, 35))
        self.tool_diameter_7.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_32.addWidget(self.tool_diameter_7)


        self.verticalLayout_15.addLayout(self.horizontalLayout_32)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setSpacing(3)
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.horizontalLayout_30.setContentsMargins(-1, 2, 0, 2)
        self.label_53 = QLabel(self.widget_75)
        self.label_53.setObjectName(u"label_53")
        sizePolicy6.setHeightForWidth(self.label_53.sizePolicy().hasHeightForWidth())
        self.label_53.setSizePolicy(sizePolicy6)
        self.label_53.setMinimumSize(QSize(35, 33))
        self.label_53.setMaximumSize(QSize(16777215, 33))
        self.label_53.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_53.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_53.setWordWrap(True)

        self.horizontalLayout_30.addWidget(self.label_53)

        self.tool_diameter_6 = StatusLabel(self.widget_75)
        self.tool_diameter_6.setObjectName(u"tool_diameter_6")
        sizePolicy4.setHeightForWidth(self.tool_diameter_6.sizePolicy().hasHeightForWidth())
        self.tool_diameter_6.setSizePolicy(sizePolicy4)
        self.tool_diameter_6.setMinimumSize(QSize(90, 35))
        self.tool_diameter_6.setMaximumSize(QSize(70, 35))
        self.tool_diameter_6.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_30.addWidget(self.tool_diameter_6)


        self.verticalLayout_15.addLayout(self.horizontalLayout_30)

        self.horizontalLayout_31 = QHBoxLayout()
        self.horizontalLayout_31.setSpacing(3)
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.horizontalLayout_31.setContentsMargins(-1, 2, 0, 2)
        self.label_66 = QLabel(self.widget_75)
        self.label_66.setObjectName(u"label_66")
        sizePolicy6.setHeightForWidth(self.label_66.sizePolicy().hasHeightForWidth())
        self.label_66.setSizePolicy(sizePolicy6)
        self.label_66.setMinimumSize(QSize(35, 33))
        self.label_66.setMaximumSize(QSize(16777215, 33))
        self.label_66.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_66.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_66.setWordWrap(True)

        self.horizontalLayout_31.addWidget(self.label_66)

        self.tool_length_14 = StatusLabel(self.widget_75)
        self.tool_length_14.setObjectName(u"tool_length_14")
        sizePolicy4.setHeightForWidth(self.tool_length_14.sizePolicy().hasHeightForWidth())
        self.tool_length_14.setSizePolicy(sizePolicy4)
        self.tool_length_14.setMinimumSize(QSize(90, 35))
        self.tool_length_14.setMaximumSize(QSize(70, 35))
        self.tool_length_14.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_31.addWidget(self.tool_length_14)


        self.verticalLayout_15.addLayout(self.horizontalLayout_31)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setSpacing(3)
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.horizontalLayout_24.setContentsMargins(-1, 2, 0, 2)
        self.label_64 = QLabel(self.widget_75)
        self.label_64.setObjectName(u"label_64")
        sizePolicy6.setHeightForWidth(self.label_64.sizePolicy().hasHeightForWidth())
        self.label_64.setSizePolicy(sizePolicy6)
        self.label_64.setMinimumSize(QSize(35, 33))
        self.label_64.setMaximumSize(QSize(16777215, 33))
        self.label_64.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_64.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_64.setWordWrap(True)

        self.horizontalLayout_24.addWidget(self.label_64)

        self.tool_length_11 = StatusLabel(self.widget_75)
        self.tool_length_11.setObjectName(u"tool_length_11")
        sizePolicy4.setHeightForWidth(self.tool_length_11.sizePolicy().hasHeightForWidth())
        self.tool_length_11.setSizePolicy(sizePolicy4)
        self.tool_length_11.setMinimumSize(QSize(90, 35))
        self.tool_length_11.setMaximumSize(QSize(70, 35))
        self.tool_length_11.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_24.addWidget(self.tool_length_11)


        self.verticalLayout_15.addLayout(self.horizontalLayout_24)

        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setSpacing(3)
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.horizontalLayout_26.setContentsMargins(-1, 2, 0, 2)
        self.label_52 = QLabel(self.widget_75)
        self.label_52.setObjectName(u"label_52")
        sizePolicy6.setHeightForWidth(self.label_52.sizePolicy().hasHeightForWidth())
        self.label_52.setSizePolicy(sizePolicy6)
        self.label_52.setMinimumSize(QSize(35, 33))
        self.label_52.setMaximumSize(QSize(16777215, 33))
        self.label_52.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_52.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_52.setWordWrap(True)

        self.horizontalLayout_26.addWidget(self.label_52)

        self.tool_diameter_5 = StatusLabel(self.widget_75)
        self.tool_diameter_5.setObjectName(u"tool_diameter_5")
        sizePolicy4.setHeightForWidth(self.tool_diameter_5.sizePolicy().hasHeightForWidth())
        self.tool_diameter_5.setSizePolicy(sizePolicy4)
        self.tool_diameter_5.setMinimumSize(QSize(90, 35))
        self.tool_diameter_5.setMaximumSize(QSize(70, 35))
        self.tool_diameter_5.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_26.addWidget(self.tool_diameter_5)


        self.verticalLayout_15.addLayout(self.horizontalLayout_26)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setSpacing(3)
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.horizontalLayout_25.setContentsMargins(-1, 2, 0, 2)
        self.label_65 = QLabel(self.widget_75)
        self.label_65.setObjectName(u"label_65")
        sizePolicy6.setHeightForWidth(self.label_65.sizePolicy().hasHeightForWidth())
        self.label_65.setSizePolicy(sizePolicy6)
        self.label_65.setMinimumSize(QSize(35, 33))
        self.label_65.setMaximumSize(QSize(16777215, 33))
        self.label_65.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_65.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_65.setWordWrap(True)

        self.horizontalLayout_25.addWidget(self.label_65)

        self.tool_length_12 = StatusLabel(self.widget_75)
        self.tool_length_12.setObjectName(u"tool_length_12")
        sizePolicy4.setHeightForWidth(self.tool_length_12.sizePolicy().hasHeightForWidth())
        self.tool_length_12.setSizePolicy(sizePolicy4)
        self.tool_length_12.setMinimumSize(QSize(90, 35))
        self.tool_length_12.setMaximumSize(QSize(70, 35))
        self.tool_length_12.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_25.addWidget(self.tool_length_12)


        self.verticalLayout_15.addLayout(self.horizontalLayout_25)


        self.verticalLayout_52.addWidget(self.widget_75)


        self.verticalLayout_10.addWidget(self.frame_51)

        self.tool_offset_stacked_widget.addWidget(self.tool_absolute_offset_page)
        self.tool_master_offset_page = QWidget()
        self.tool_master_offset_page.setObjectName(u"tool_master_offset_page")
        self.verticalLayout_11 = QVBoxLayout(self.tool_master_offset_page)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(7, 0, 0, 0)
        self.frame_50 = QFrame(self.tool_master_offset_page)
        self.frame_50.setObjectName(u"frame_50")
        sizePolicy7.setHeightForWidth(self.frame_50.sizePolicy().hasHeightForWidth())
        self.frame_50.setSizePolicy(sizePolicy7)
        self.frame_50.setMinimumSize(QSize(280, 0))
        self.frame_50.setMaximumSize(QSize(280, 16777215))
        self.verticalLayout_49 = QVBoxLayout(self.frame_50)
        self.verticalLayout_49.setSpacing(9)
        self.verticalLayout_49.setObjectName(u"verticalLayout_49")
        self.verticalLayout_49.setContentsMargins(19, 22, 19, 9)
        self.widget_56 = QWidget(self.frame_50)
        self.widget_56.setObjectName(u"widget_56")
        sizePolicy6.setHeightForWidth(self.widget_56.sizePolicy().hasHeightForWidth())
        self.widget_56.setSizePolicy(sizePolicy6)
        self.horizontalLayout_82 = QHBoxLayout(self.widget_56)
        self.horizontalLayout_82.setSpacing(12)
        self.horizontalLayout_82.setObjectName(u"horizontalLayout_82")
        self.horizontalLayout_82.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_82.setContentsMargins(2, 2, 2, 2)
        self.x_offset_touch_value_mt_3102 = VCPVarLineEdit(self.widget_56)
        self.x_offset_touch_value_mt_3102.setObjectName(u"x_offset_touch_value_mt_3102")
        sizePolicy6.setHeightForWidth(self.x_offset_touch_value_mt_3102.sizePolicy().hasHeightForWidth())
        self.x_offset_touch_value_mt_3102.setSizePolicy(sizePolicy6)
        self.x_offset_touch_value_mt_3102.setMinimumSize(QSize(0, 40))
        self.x_offset_touch_value_mt_3102.setMaximumSize(QSize(16777215, 40))
        self.x_offset_touch_value_mt_3102.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_offset_touch_value_mt_3102.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.x_offset_touch_value_mt_3102.setProperty(u"highPrecisionStorage", False)
        self.x_offset_touch_value_mt_3102.setProperty(u"displayDecimals", 6)
        self.x_offset_touch_value_mt_3102.setProperty(u"varParameterNumber", 3102)

        self.horizontalLayout_82.addWidget(self.x_offset_touch_value_mt_3102)

        self.touch_x = SubCallButton(self.widget_56)
        self.touch_x.setObjectName(u"touch_x")
        sizePolicy6.setHeightForWidth(self.touch_x.sizePolicy().hasHeightForWidth())
        self.touch_x.setSizePolicy(sizePolicy6)
        self.touch_x.setMinimumSize(QSize(110, 40))
        self.touch_x.setMaximumSize(QSize(110, 40))
        self.touch_x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.touch_x.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_82.addWidget(self.touch_x)


        self.verticalLayout_49.addWidget(self.widget_56)

        self.widget_78 = QWidget(self.frame_50)
        self.widget_78.setObjectName(u"widget_78")
        sizePolicy6.setHeightForWidth(self.widget_78.sizePolicy().hasHeightForWidth())
        self.widget_78.setSizePolicy(sizePolicy6)
        self.horizontalLayout_90 = QHBoxLayout(self.widget_78)
        self.horizontalLayout_90.setSpacing(12)
        self.horizontalLayout_90.setObjectName(u"horizontalLayout_90")
        self.horizontalLayout_90.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.horizontalLayout_90.setContentsMargins(2, 5, 2, 5)
        self.mt_z_offset_label_5 = QLabel(self.widget_78)
        self.mt_z_offset_label_5.setObjectName(u"mt_z_offset_label_5")
        self.mt_z_offset_label_5.setMinimumSize(QSize(30, 40))
        self.mt_z_offset_label_5.setMaximumSize(QSize(30, 40))
        self.mt_z_offset_label_5.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.mt_z_offset_label_5.setStyleSheet(u"QLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"    padding: -5px;\n"
"}")
        self.mt_z_offset_label_5.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.mt_z_offset_label_5.setMargin(0)
        self.mt_z_offset_label_5.setIndent(-1)

        self.horizontalLayout_90.addWidget(self.mt_z_offset_label_5)

        self.master_tool_number_3100 = VCPVarLineEdit(self.widget_78)
        self.master_tool_number_3100.setObjectName(u"master_tool_number_3100")
        self.master_tool_number_3100.setMinimumSize(QSize(0, 40))
        self.master_tool_number_3100.setMaximumSize(QSize(16777215, 40))
        self.master_tool_number_3100.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.master_tool_number_3100.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.master_tool_number_3100.setProperty(u"highPrecisionStorage", False)
        self.master_tool_number_3100.setProperty(u"displayDecimals", 0)
        self.master_tool_number_3100.setProperty(u"varParameterNumber", 3100)
        self.master_tool_number_3100.setProperty(u"autoWriteEnabled", True)

        self.horizontalLayout_90.addWidget(self.master_tool_number_3100)

        self.touch_z = SubCallButton(self.widget_78)
        self.touch_z.setObjectName(u"touch_z")
        sizePolicy6.setHeightForWidth(self.touch_z.sizePolicy().hasHeightForWidth())
        self.touch_z.setSizePolicy(sizePolicy6)
        self.touch_z.setMinimumSize(QSize(110, 40))
        self.touch_z.setMaximumSize(QSize(110, 40))
        self.touch_z.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.touch_z.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_90.addWidget(self.touch_z)


        self.verticalLayout_49.addWidget(self.widget_78)

        self.widget_36 = QWidget(self.frame_50)
        self.widget_36.setObjectName(u"widget_36")
        sizePolicy6.setHeightForWidth(self.widget_36.sizePolicy().hasHeightForWidth())
        self.widget_36.setSizePolicy(sizePolicy6)
        self.horizontalLayout_48 = QHBoxLayout(self.widget_36)
        self.horizontalLayout_48.setSpacing(9)
        self.horizontalLayout_48.setObjectName(u"horizontalLayout_48")
        self.horizontalLayout_48.setContentsMargins(2, 2, 2, 12)
        self.mt_z_offset_label_3 = QLabel(self.widget_36)
        self.mt_z_offset_label_3.setObjectName(u"mt_z_offset_label_3")
        self.mt_z_offset_label_3.setMinimumSize(QSize(0, 40))
        self.mt_z_offset_label_3.setMaximumSize(QSize(16777215, 40))
        self.mt_z_offset_label_3.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.mt_z_offset_label_3.setStyleSheet(u"QLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"    padding: -5px;\n"
"}")
        self.mt_z_offset_label_3.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.mt_z_offset_label_3.setMargin(0)
        self.mt_z_offset_label_3.setIndent(-1)

        self.horizontalLayout_48.addWidget(self.mt_z_offset_label_3)

        self.gage_thickness_mt_3101 = VCPVarLineEdit(self.widget_36)
        self.gage_thickness_mt_3101.setObjectName(u"gage_thickness_mt_3101")
        sizePolicy6.setHeightForWidth(self.gage_thickness_mt_3101.sizePolicy().hasHeightForWidth())
        self.gage_thickness_mt_3101.setSizePolicy(sizePolicy6)
        self.gage_thickness_mt_3101.setMinimumSize(QSize(110, 40))
        self.gage_thickness_mt_3101.setMaximumSize(QSize(110, 40))
        self.gage_thickness_mt_3101.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.gage_thickness_mt_3101.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.gage_thickness_mt_3101.setProperty(u"highPrecisionStorage", False)
        self.gage_thickness_mt_3101.setProperty(u"displayDecimals", 6)
        self.gage_thickness_mt_3101.setProperty(u"varParameterNumber", 3101)

        self.horizontalLayout_48.addWidget(self.gage_thickness_mt_3101)


        self.verticalLayout_49.addWidget(self.widget_36)

        self.widget_79 = QWidget(self.frame_50)
        self.widget_79.setObjectName(u"widget_79")
        sizePolicy.setHeightForWidth(self.widget_79.sizePolicy().hasHeightForWidth())
        self.widget_79.setSizePolicy(sizePolicy)
        self.verticalLayout_71 = QVBoxLayout(self.widget_79)
        self.verticalLayout_71.setSpacing(9)
        self.verticalLayout_71.setObjectName(u"verticalLayout_71")
        self.verticalLayout_71.setContentsMargins(6, 6, 6, 1)
        self.horizontalLayout_49 = QHBoxLayout()
        self.horizontalLayout_49.setSpacing(3)
        self.horizontalLayout_49.setObjectName(u"horizontalLayout_49")
        self.horizontalLayout_49.setContentsMargins(-1, 2, 0, 2)
        self.label_67 = QLabel(self.widget_79)
        self.label_67.setObjectName(u"label_67")
        sizePolicy6.setHeightForWidth(self.label_67.sizePolicy().hasHeightForWidth())
        self.label_67.setSizePolicy(sizePolicy6)
        self.label_67.setMinimumSize(QSize(35, 33))
        self.label_67.setMaximumSize(QSize(16777215, 33))
        self.label_67.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_67.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_67.setWordWrap(True)

        self.horizontalLayout_49.addWidget(self.label_67)

        self.tool_length_15 = StatusLabel(self.widget_79)
        self.tool_length_15.setObjectName(u"tool_length_15")
        sizePolicy4.setHeightForWidth(self.tool_length_15.sizePolicy().hasHeightForWidth())
        self.tool_length_15.setSizePolicy(sizePolicy4)
        self.tool_length_15.setMinimumSize(QSize(90, 35))
        self.tool_length_15.setMaximumSize(QSize(70, 35))
        self.tool_length_15.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_49.addWidget(self.tool_length_15)


        self.verticalLayout_71.addLayout(self.horizontalLayout_49)

        self.horizontalLayout_51 = QHBoxLayout()
        self.horizontalLayout_51.setSpacing(3)
        self.horizontalLayout_51.setObjectName(u"horizontalLayout_51")
        self.horizontalLayout_51.setContentsMargins(-1, 2, 0, 2)
        self.label_55 = QLabel(self.widget_79)
        self.label_55.setObjectName(u"label_55")
        sizePolicy6.setHeightForWidth(self.label_55.sizePolicy().hasHeightForWidth())
        self.label_55.setSizePolicy(sizePolicy6)
        self.label_55.setMinimumSize(QSize(35, 33))
        self.label_55.setMaximumSize(QSize(16777215, 33))
        self.label_55.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_55.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_55.setWordWrap(True)

        self.horizontalLayout_51.addWidget(self.label_55)

        self.tool_diameter_8 = StatusLabel(self.widget_79)
        self.tool_diameter_8.setObjectName(u"tool_diameter_8")
        sizePolicy4.setHeightForWidth(self.tool_diameter_8.sizePolicy().hasHeightForWidth())
        self.tool_diameter_8.setSizePolicy(sizePolicy4)
        self.tool_diameter_8.setMinimumSize(QSize(90, 35))
        self.tool_diameter_8.setMaximumSize(QSize(70, 35))
        self.tool_diameter_8.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_51.addWidget(self.tool_diameter_8)


        self.verticalLayout_71.addLayout(self.horizontalLayout_51)

        self.horizontalLayout_64 = QHBoxLayout()
        self.horizontalLayout_64.setSpacing(3)
        self.horizontalLayout_64.setObjectName(u"horizontalLayout_64")
        self.horizontalLayout_64.setContentsMargins(-1, 2, 0, 2)
        self.label_57 = QLabel(self.widget_79)
        self.label_57.setObjectName(u"label_57")
        sizePolicy6.setHeightForWidth(self.label_57.sizePolicy().hasHeightForWidth())
        self.label_57.setSizePolicy(sizePolicy6)
        self.label_57.setMinimumSize(QSize(35, 33))
        self.label_57.setMaximumSize(QSize(16777215, 33))
        self.label_57.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_57.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_57.setWordWrap(True)

        self.horizontalLayout_64.addWidget(self.label_57)

        self.tool_diameter_9 = StatusLabel(self.widget_79)
        self.tool_diameter_9.setObjectName(u"tool_diameter_9")
        sizePolicy4.setHeightForWidth(self.tool_diameter_9.sizePolicy().hasHeightForWidth())
        self.tool_diameter_9.setSizePolicy(sizePolicy4)
        self.tool_diameter_9.setMinimumSize(QSize(90, 35))
        self.tool_diameter_9.setMaximumSize(QSize(70, 35))
        self.tool_diameter_9.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_64.addWidget(self.tool_diameter_9)


        self.verticalLayout_71.addLayout(self.horizontalLayout_64)

        self.horizontalLayout_65 = QHBoxLayout()
        self.horizontalLayout_65.setSpacing(3)
        self.horizontalLayout_65.setObjectName(u"horizontalLayout_65")
        self.horizontalLayout_65.setContentsMargins(-1, 2, 0, 2)
        self.label_68 = QLabel(self.widget_79)
        self.label_68.setObjectName(u"label_68")
        sizePolicy6.setHeightForWidth(self.label_68.sizePolicy().hasHeightForWidth())
        self.label_68.setSizePolicy(sizePolicy6)
        self.label_68.setMinimumSize(QSize(35, 33))
        self.label_68.setMaximumSize(QSize(16777215, 33))
        self.label_68.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_68.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_68.setWordWrap(True)

        self.horizontalLayout_65.addWidget(self.label_68)

        self.tool_length_16 = StatusLabel(self.widget_79)
        self.tool_length_16.setObjectName(u"tool_length_16")
        sizePolicy4.setHeightForWidth(self.tool_length_16.sizePolicy().hasHeightForWidth())
        self.tool_length_16.setSizePolicy(sizePolicy4)
        self.tool_length_16.setMinimumSize(QSize(90, 35))
        self.tool_length_16.setMaximumSize(QSize(70, 35))
        self.tool_length_16.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_65.addWidget(self.tool_length_16)


        self.verticalLayout_71.addLayout(self.horizontalLayout_65)

        self.horizontalLayout_73 = QHBoxLayout()
        self.horizontalLayout_73.setSpacing(3)
        self.horizontalLayout_73.setObjectName(u"horizontalLayout_73")
        self.horizontalLayout_73.setContentsMargins(-1, 2, 0, 2)
        self.label_69 = QLabel(self.widget_79)
        self.label_69.setObjectName(u"label_69")
        sizePolicy6.setHeightForWidth(self.label_69.sizePolicy().hasHeightForWidth())
        self.label_69.setSizePolicy(sizePolicy6)
        self.label_69.setMinimumSize(QSize(35, 33))
        self.label_69.setMaximumSize(QSize(16777215, 33))
        self.label_69.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_69.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_69.setWordWrap(True)

        self.horizontalLayout_73.addWidget(self.label_69)

        self.tool_length_17 = StatusLabel(self.widget_79)
        self.tool_length_17.setObjectName(u"tool_length_17")
        sizePolicy4.setHeightForWidth(self.tool_length_17.sizePolicy().hasHeightForWidth())
        self.tool_length_17.setSizePolicy(sizePolicy4)
        self.tool_length_17.setMinimumSize(QSize(90, 35))
        self.tool_length_17.setMaximumSize(QSize(70, 35))
        self.tool_length_17.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_73.addWidget(self.tool_length_17)


        self.verticalLayout_71.addLayout(self.horizontalLayout_73)

        self.horizontalLayout_77 = QHBoxLayout()
        self.horizontalLayout_77.setSpacing(3)
        self.horizontalLayout_77.setObjectName(u"horizontalLayout_77")
        self.horizontalLayout_77.setContentsMargins(-1, 2, 0, 2)
        self.label_58 = QLabel(self.widget_79)
        self.label_58.setObjectName(u"label_58")
        sizePolicy6.setHeightForWidth(self.label_58.sizePolicy().hasHeightForWidth())
        self.label_58.setSizePolicy(sizePolicy6)
        self.label_58.setMinimumSize(QSize(35, 33))
        self.label_58.setMaximumSize(QSize(16777215, 33))
        self.label_58.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_58.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_58.setWordWrap(True)

        self.horizontalLayout_77.addWidget(self.label_58)

        self.tool_diameter_10 = StatusLabel(self.widget_79)
        self.tool_diameter_10.setObjectName(u"tool_diameter_10")
        sizePolicy4.setHeightForWidth(self.tool_diameter_10.sizePolicy().hasHeightForWidth())
        self.tool_diameter_10.setSizePolicy(sizePolicy4)
        self.tool_diameter_10.setMinimumSize(QSize(90, 35))
        self.tool_diameter_10.setMaximumSize(QSize(70, 35))
        self.tool_diameter_10.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_77.addWidget(self.tool_diameter_10)


        self.verticalLayout_71.addLayout(self.horizontalLayout_77)

        self.horizontalLayout_80 = QHBoxLayout()
        self.horizontalLayout_80.setSpacing(3)
        self.horizontalLayout_80.setObjectName(u"horizontalLayout_80")
        self.horizontalLayout_80.setContentsMargins(-1, 2, 0, 2)
        self.label_70 = QLabel(self.widget_79)
        self.label_70.setObjectName(u"label_70")
        sizePolicy6.setHeightForWidth(self.label_70.sizePolicy().hasHeightForWidth())
        self.label_70.setSizePolicy(sizePolicy6)
        self.label_70.setMinimumSize(QSize(35, 33))
        self.label_70.setMaximumSize(QSize(16777215, 33))
        self.label_70.setStyleSheet(u"QLabel{\n"
"font: 16pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_70.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_70.setWordWrap(True)

        self.horizontalLayout_80.addWidget(self.label_70)

        self.tool_length_18 = StatusLabel(self.widget_79)
        self.tool_length_18.setObjectName(u"tool_length_18")
        sizePolicy4.setHeightForWidth(self.tool_length_18.sizePolicy().hasHeightForWidth())
        self.tool_length_18.setSizePolicy(sizePolicy4)
        self.tool_length_18.setMinimumSize(QSize(90, 35))
        self.tool_length_18.setMaximumSize(QSize(70, 35))
        self.tool_length_18.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_80.addWidget(self.tool_length_18)


        self.verticalLayout_71.addLayout(self.horizontalLayout_80)


        self.verticalLayout_49.addWidget(self.widget_79)


        self.verticalLayout_11.addWidget(self.frame_50)

        self.tool_offset_stacked_widget.addWidget(self.tool_master_offset_page)

        self.horizontalLayout_67.addWidget(self.tool_offset_stacked_widget)


        self.horizontalLayout_5.addWidget(self.widget_4)

        self.tabWidget.addTab(self.touch_off_tab, "")
        self.tooling_tab = QWidget()
        self.tooling_tab.setObjectName(u"tooling_tab")
        self.tooling_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout_41 = QHBoxLayout(self.tooling_tab)
        self.horizontalLayout_41.setSpacing(15)
        self.horizontalLayout_41.setObjectName(u"horizontalLayout_41")
        self.horizontalLayout_41.setContentsMargins(20, 20, 20, 20)
        self.horizontalLayout_40 = QHBoxLayout()
        self.horizontalLayout_40.setObjectName(u"horizontalLayout_40")
        self.horizontalLayout_40.setContentsMargins(0, 0, -1, 0)
        self.frame_13 = QFrame(self.tooling_tab)
        self.frame_13.setObjectName(u"frame_13")
        self.frame_13.setEnabled(True)
        sizePolicy.setHeightForWidth(self.frame_13.sizePolicy().hasHeightForWidth())
        self.frame_13.setSizePolicy(sizePolicy)
        self.frame_13.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.verticalLayout_20 = QVBoxLayout(self.frame_13)
        self.verticalLayout_20.setSpacing(9)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.verticalLayout_20.setContentsMargins(-1, 9, -1, -1)
        self.horizontalLayout_38 = QHBoxLayout()
        self.horizontalLayout_38.setObjectName(u"horizontalLayout_38")
        self.horizontalLayout_38.setContentsMargins(5, 5, 5, -1)
        self.tooltable = LatheToolTable(self.frame_13)
        self.tooltable.setObjectName(u"tooltable")
        self.tooltable.setEnabled(True)
        self.tooltable.setProperty(u"currentToolColor", QColor(42, 56, 255))
        self.tooltable.horizontalHeader().setMinimumSectionSize(20)
        self.tooltable.horizontalHeader().setDefaultSectionSize(90)
        self.tooltable.verticalHeader().setMinimumSectionSize(30)
        self.tooltable.verticalHeader().setDefaultSectionSize(35)

        self.horizontalLayout_38.addWidget(self.tooltable)


        self.verticalLayout_20.addLayout(self.horizontalLayout_38)

        self.horizontalLayout_37 = QHBoxLayout()
        self.horizontalLayout_37.setObjectName(u"horizontalLayout_37")
        self.tool_table_delete_button = QPushButton(self.frame_13)
        self.tool_table_delete_button.setObjectName(u"tool_table_delete_button")
        sizePolicy3.setHeightForWidth(self.tool_table_delete_button.sizePolicy().hasHeightForWidth())
        self.tool_table_delete_button.setSizePolicy(sizePolicy3)
        self.tool_table_delete_button.setMinimumSize(QSize(120, 33))
        self.tool_table_delete_button.setMaximumSize(QSize(120, 33))
        self.tool_table_delete_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tool_table_delete_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_37.addWidget(self.tool_table_delete_button)

        self.tool_table_add_tool_button = QPushButton(self.frame_13)
        self.tool_table_add_tool_button.setObjectName(u"tool_table_add_tool_button")
        sizePolicy3.setHeightForWidth(self.tool_table_add_tool_button.sizePolicy().hasHeightForWidth())
        self.tool_table_add_tool_button.setSizePolicy(sizePolicy3)
        self.tool_table_add_tool_button.setMinimumSize(QSize(120, 33))
        self.tool_table_add_tool_button.setMaximumSize(QSize(120, 33))
        self.tool_table_add_tool_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tool_table_add_tool_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_37.addWidget(self.tool_table_add_tool_button)

        self.tool_table_save_button = QPushButton(self.frame_13)
        self.tool_table_save_button.setObjectName(u"tool_table_save_button")
        sizePolicy3.setHeightForWidth(self.tool_table_save_button.sizePolicy().hasHeightForWidth())
        self.tool_table_save_button.setSizePolicy(sizePolicy3)
        self.tool_table_save_button.setMinimumSize(QSize(120, 33))
        self.tool_table_save_button.setMaximumSize(QSize(120, 33))
        self.tool_table_save_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tool_table_save_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_37.addWidget(self.tool_table_save_button)

        self.tool_table_reload_button = QPushButton(self.frame_13)
        self.tool_table_reload_button.setObjectName(u"tool_table_reload_button")
        self.tool_table_reload_button.setEnabled(True)
        sizePolicy3.setHeightForWidth(self.tool_table_reload_button.sizePolicy().hasHeightForWidth())
        self.tool_table_reload_button.setSizePolicy(sizePolicy3)
        self.tool_table_reload_button.setMinimumSize(QSize(140, 33))
        self.tool_table_reload_button.setMaximumSize(QSize(140, 33))
        self.tool_table_reload_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.tool_table_reload_button.setStyleSheet(u"QPushButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_37.addWidget(self.tool_table_reload_button)


        self.verticalLayout_20.addLayout(self.horizontalLayout_37)


        self.horizontalLayout_40.addWidget(self.frame_13)


        self.horizontalLayout_41.addLayout(self.horizontalLayout_40)

        self.verticalLayout_26 = QVBoxLayout()
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.verticalLayout_26.setContentsMargins(0, -1, 0, 1)
        self.frame_28 = QFrame(self.tooling_tab)
        self.frame_28.setObjectName(u"frame_28")
        sizePolicy6.setHeightForWidth(self.frame_28.sizePolicy().hasHeightForWidth())
        self.frame_28.setSizePolicy(sizePolicy6)
        self.frame_28.setMinimumSize(QSize(570, 60))
        self.frame_28.setMaximumSize(QSize(16777215, 60))
        self.frame_28.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_108 = QHBoxLayout(self.frame_28)
        self.horizontalLayout_108.setObjectName(u"horizontalLayout_108")
        self.horizontalLayout_108.setContentsMargins(5, -1, 5, -1)
        self.horizontalLayout_109 = QHBoxLayout()
        self.horizontalLayout_109.setSpacing(3)
        self.horizontalLayout_109.setObjectName(u"horizontalLayout_109")
        self.label_56 = QLabel(self.frame_28)
        self.label_56.setObjectName(u"label_56")
        sizePolicy3.setHeightForWidth(self.label_56.sizePolicy().hasHeightForWidth())
        self.label_56.setSizePolicy(sizePolicy3)
        self.label_56.setMinimumSize(QSize(60, 33))
        self.label_56.setMaximumSize(QSize(60, 33))
        self.label_56.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: none;\n"
"}")
        self.label_56.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_56.setWordWrap(True)

        self.horizontalLayout_109.addWidget(self.label_56)

        self.tool_length_7 = StatusLabel(self.frame_28)
        self.tool_length_7.setObjectName(u"tool_length_7")
        sizePolicy.setHeightForWidth(self.tool_length_7.sizePolicy().hasHeightForWidth())
        self.tool_length_7.setSizePolicy(sizePolicy)
        self.tool_length_7.setMinimumSize(QSize(70, 33))
        self.tool_length_7.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.tool_length_7.setIndent(4)

        self.horizontalLayout_109.addWidget(self.tool_length_7)


        self.horizontalLayout_108.addLayout(self.horizontalLayout_109)


        self.verticalLayout_26.addWidget(self.frame_28)

        self.frame_10 = QFrame(self.tooling_tab)
        self.frame_10.setObjectName(u"frame_10")
        sizePolicy7.setHeightForWidth(self.frame_10.sizePolicy().hasHeightForWidth())
        self.frame_10.setSizePolicy(sizePolicy7)
        self.frame_10.setMinimumSize(QSize(580, 0))
        self.frame_10.setMaximumSize(QSize(580, 16777215))
        self.frame_10.setStyleSheet(u"QFrame{\n"
"border-style: none;\n"
"border-color: transparent;\n"
"background-color: transparent;\n"
"border-width: 2px;\n"
"border-radius: 6px;\n"
"}")
        self.frame_11 = QFrame(self.frame_10)
        self.frame_11.setObjectName(u"frame_11")
        self.frame_11.setGeometry(QRect(21, 216, 200, 50))
        sizePolicy3.setHeightForWidth(self.frame_11.sizePolicy().hasHeightForWidth())
        self.frame_11.setSizePolicy(sizePolicy3)
        self.frame_11.setMinimumSize(QSize(200, 30))
        self.frame_11.setMaximumSize(QSize(200, 55))
        self.frame_11.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_98 = QHBoxLayout(self.frame_11)
        self.horizontalLayout_98.setObjectName(u"horizontalLayout_98")
        self.horizontalLayout_98.setContentsMargins(5, 6, 10, 6)
        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setSpacing(3)
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.label_59 = QLabel(self.frame_11)
        self.label_59.setObjectName(u"label_59")
        sizePolicy6.setHeightForWidth(self.label_59.sizePolicy().hasHeightForWidth())
        self.label_59.setSizePolicy(sizePolicy6)
        self.label_59.setMinimumSize(QSize(35, 33))
        self.label_59.setMaximumSize(QSize(16777215, 33))
        self.label_59.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_59.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_59.setWordWrap(True)

        self.horizontalLayout_17.addWidget(self.label_59)

        self.tool_length_5 = StatusLabel(self.frame_11)
        self.tool_length_5.setObjectName(u"tool_length_5")
        sizePolicy4.setHeightForWidth(self.tool_length_5.sizePolicy().hasHeightForWidth())
        self.tool_length_5.setSizePolicy(sizePolicy4)
        self.tool_length_5.setMinimumSize(QSize(70, 33))
        self.tool_length_5.setMaximumSize(QSize(70, 33))
        self.tool_length_5.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_17.addWidget(self.tool_length_5)


        self.horizontalLayout_98.addLayout(self.horizontalLayout_17)

        self.frame_12 = QFrame(self.frame_10)
        self.frame_12.setObjectName(u"frame_12")
        self.frame_12.setGeometry(QRect(21, 338, 200, 50))
        sizePolicy3.setHeightForWidth(self.frame_12.sizePolicy().hasHeightForWidth())
        self.frame_12.setSizePolicy(sizePolicy3)
        self.frame_12.setMinimumSize(QSize(200, 30))
        self.frame_12.setMaximumSize(QSize(200, 55))
        self.frame_12.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_99 = QHBoxLayout(self.frame_12)
        self.horizontalLayout_99.setObjectName(u"horizontalLayout_99")
        self.horizontalLayout_99.setContentsMargins(5, 6, 10, 6)
        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setSpacing(3)
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.label_49 = QLabel(self.frame_12)
        self.label_49.setObjectName(u"label_49")
        sizePolicy6.setHeightForWidth(self.label_49.sizePolicy().hasHeightForWidth())
        self.label_49.setSizePolicy(sizePolicy6)
        self.label_49.setMinimumSize(QSize(35, 33))
        self.label_49.setMaximumSize(QSize(16777215, 33))
        self.label_49.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_49.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_49.setWordWrap(True)

        self.horizontalLayout_18.addWidget(self.label_49)

        self.tool_diameter_2 = StatusLabel(self.frame_12)
        self.tool_diameter_2.setObjectName(u"tool_diameter_2")
        sizePolicy4.setHeightForWidth(self.tool_diameter_2.sizePolicy().hasHeightForWidth())
        self.tool_diameter_2.setSizePolicy(sizePolicy4)
        self.tool_diameter_2.setMinimumSize(QSize(70, 33))
        self.tool_diameter_2.setMaximumSize(QSize(70, 33))
        self.tool_diameter_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_18.addWidget(self.tool_diameter_2)


        self.horizontalLayout_99.addLayout(self.horizontalLayout_18)

        self.label_28 = QLabel(self.frame_10)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(260, 70, 300, 347))
        sizePolicy3.setHeightForWidth(self.label_28.sizePolicy().hasHeightForWidth())
        self.label_28.setSizePolicy(sizePolicy3)
        self.label_28.setMinimumSize(QSize(300, 347))
        self.label_28.setMaximumSize(QSize(300, 347))
        self.label_28.setPixmap(QPixmap(u":/images/lathe_tool_graphic.png"))
        self.label_28.setScaledContents(True)
        self.frame_14 = QFrame(self.frame_10)
        self.frame_14.setObjectName(u"frame_14")
        self.frame_14.setGeometry(QRect(21, 277, 200, 50))
        sizePolicy3.setHeightForWidth(self.frame_14.sizePolicy().hasHeightForWidth())
        self.frame_14.setSizePolicy(sizePolicy3)
        self.frame_14.setMinimumSize(QSize(200, 30))
        self.frame_14.setMaximumSize(QSize(200, 55))
        self.frame_14.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_132 = QHBoxLayout(self.frame_14)
        self.horizontalLayout_132.setObjectName(u"horizontalLayout_132")
        self.horizontalLayout_132.setContentsMargins(5, 6, 10, 6)
        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setSpacing(3)
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.label_62 = QLabel(self.frame_14)
        self.label_62.setObjectName(u"label_62")
        sizePolicy6.setHeightForWidth(self.label_62.sizePolicy().hasHeightForWidth())
        self.label_62.setSizePolicy(sizePolicy6)
        self.label_62.setMinimumSize(QSize(35, 33))
        self.label_62.setMaximumSize(QSize(16777215, 33))
        self.label_62.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_62.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_62.setWordWrap(True)

        self.horizontalLayout_20.addWidget(self.label_62)

        self.tool_length_9 = StatusLabel(self.frame_14)
        self.tool_length_9.setObjectName(u"tool_length_9")
        sizePolicy4.setHeightForWidth(self.tool_length_9.sizePolicy().hasHeightForWidth())
        self.tool_length_9.setSizePolicy(sizePolicy4)
        self.tool_length_9.setMinimumSize(QSize(70, 33))
        self.tool_length_9.setMaximumSize(QSize(70, 33))
        self.tool_length_9.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_20.addWidget(self.tool_length_9)


        self.horizontalLayout_132.addLayout(self.horizontalLayout_20)

        self.frame_29 = QFrame(self.frame_10)
        self.frame_29.setObjectName(u"frame_29")
        self.frame_29.setGeometry(QRect(21, 39, 200, 50))
        sizePolicy3.setHeightForWidth(self.frame_29.sizePolicy().hasHeightForWidth())
        self.frame_29.setSizePolicy(sizePolicy3)
        self.frame_29.setMinimumSize(QSize(200, 30))
        self.frame_29.setMaximumSize(QSize(200, 55))
        self.frame_29.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_133 = QHBoxLayout(self.frame_29)
        self.horizontalLayout_133.setObjectName(u"horizontalLayout_133")
        self.horizontalLayout_133.setContentsMargins(5, 6, 10, 6)
        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setSpacing(3)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.label_60 = QLabel(self.frame_29)
        self.label_60.setObjectName(u"label_60")
        sizePolicy6.setHeightForWidth(self.label_60.sizePolicy().hasHeightForWidth())
        self.label_60.setSizePolicy(sizePolicy6)
        self.label_60.setMinimumSize(QSize(35, 33))
        self.label_60.setMaximumSize(QSize(16777215, 33))
        self.label_60.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_60.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_60.setWordWrap(True)

        self.horizontalLayout_28.addWidget(self.label_60)

        self.tool_length_6 = StatusLabel(self.frame_29)
        self.tool_length_6.setObjectName(u"tool_length_6")
        sizePolicy4.setHeightForWidth(self.tool_length_6.sizePolicy().hasHeightForWidth())
        self.tool_length_6.setSizePolicy(sizePolicy4)
        self.tool_length_6.setMinimumSize(QSize(50, 33))
        self.tool_length_6.setMaximumSize(QSize(70, 33))
        self.tool_length_6.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_28.addWidget(self.tool_length_6)


        self.horizontalLayout_133.addLayout(self.horizontalLayout_28)

        self.frame_15 = QFrame(self.frame_10)
        self.frame_15.setObjectName(u"frame_15")
        self.frame_15.setGeometry(QRect(21, 399, 200, 50))
        sizePolicy3.setHeightForWidth(self.frame_15.sizePolicy().hasHeightForWidth())
        self.frame_15.setSizePolicy(sizePolicy3)
        self.frame_15.setMinimumSize(QSize(200, 30))
        self.frame_15.setMaximumSize(QSize(200, 55))
        self.frame_15.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_135 = QHBoxLayout(self.frame_15)
        self.horizontalLayout_135.setObjectName(u"horizontalLayout_135")
        self.horizontalLayout_135.setContentsMargins(5, 6, 10, 6)
        self.horizontalLayout_21 = QHBoxLayout()
        self.horizontalLayout_21.setSpacing(3)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.label_63 = QLabel(self.frame_15)
        self.label_63.setObjectName(u"label_63")
        sizePolicy6.setHeightForWidth(self.label_63.sizePolicy().hasHeightForWidth())
        self.label_63.setSizePolicy(sizePolicy6)
        self.label_63.setMinimumSize(QSize(35, 33))
        self.label_63.setMaximumSize(QSize(16777215, 33))
        self.label_63.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_63.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_63.setWordWrap(True)

        self.horizontalLayout_21.addWidget(self.label_63)

        self.tool_length_10 = StatusLabel(self.frame_15)
        self.tool_length_10.setObjectName(u"tool_length_10")
        sizePolicy4.setHeightForWidth(self.tool_length_10.sizePolicy().hasHeightForWidth())
        self.tool_length_10.setSizePolicy(sizePolicy4)
        self.tool_length_10.setMinimumSize(QSize(70, 33))
        self.tool_length_10.setMaximumSize(QSize(70, 33))
        self.tool_length_10.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_21.addWidget(self.tool_length_10)


        self.horizontalLayout_135.addLayout(self.horizontalLayout_21)

        self.frame_17 = QFrame(self.frame_10)
        self.frame_17.setObjectName(u"frame_17")
        self.frame_17.setGeometry(QRect(21, 97, 200, 50))
        sizePolicy3.setHeightForWidth(self.frame_17.sizePolicy().hasHeightForWidth())
        self.frame_17.setSizePolicy(sizePolicy3)
        self.frame_17.setMinimumSize(QSize(200, 30))
        self.frame_17.setMaximumSize(QSize(200, 55))
        self.frame_17.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_102 = QHBoxLayout(self.frame_17)
        self.horizontalLayout_102.setObjectName(u"horizontalLayout_102")
        self.horizontalLayout_102.setContentsMargins(5, 6, 10, 6)
        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setSpacing(3)
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.label_50 = QLabel(self.frame_17)
        self.label_50.setObjectName(u"label_50")
        sizePolicy6.setHeightForWidth(self.label_50.sizePolicy().hasHeightForWidth())
        self.label_50.setSizePolicy(sizePolicy6)
        self.label_50.setMinimumSize(QSize(35, 33))
        self.label_50.setMaximumSize(QSize(16777215, 33))
        self.label_50.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_50.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_50.setWordWrap(True)

        self.horizontalLayout_19.addWidget(self.label_50)

        self.tool_diameter_3 = StatusLabel(self.frame_17)
        self.tool_diameter_3.setObjectName(u"tool_diameter_3")
        sizePolicy4.setHeightForWidth(self.tool_diameter_3.sizePolicy().hasHeightForWidth())
        self.tool_diameter_3.setSizePolicy(sizePolicy4)
        self.tool_diameter_3.setMinimumSize(QSize(70, 33))
        self.tool_diameter_3.setMaximumSize(QSize(70, 33))
        self.tool_diameter_3.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_19.addWidget(self.tool_diameter_3)


        self.horizontalLayout_102.addLayout(self.horizontalLayout_19)

        self.frame_18 = QFrame(self.frame_10)
        self.frame_18.setObjectName(u"frame_18")
        self.frame_18.setGeometry(QRect(21, 156, 200, 50))
        sizePolicy3.setHeightForWidth(self.frame_18.sizePolicy().hasHeightForWidth())
        self.frame_18.setSizePolicy(sizePolicy3)
        self.frame_18.setMinimumSize(QSize(200, 30))
        self.frame_18.setMaximumSize(QSize(200, 55))
        self.frame_18.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout_103 = QHBoxLayout(self.frame_18)
        self.horizontalLayout_103.setObjectName(u"horizontalLayout_103")
        self.horizontalLayout_103.setContentsMargins(5, 6, 10, 6)
        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setSpacing(3)
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.label_51 = QLabel(self.frame_18)
        self.label_51.setObjectName(u"label_51")
        sizePolicy6.setHeightForWidth(self.label_51.sizePolicy().hasHeightForWidth())
        self.label_51.setSizePolicy(sizePolicy6)
        self.label_51.setMinimumSize(QSize(35, 33))
        self.label_51.setMaximumSize(QSize(16777215, 33))
        self.label_51.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"padding-right: 0px;\n"
"padding-left: 0px;\n"
"border-style: transparent;\n"
"background-color: transparent;\n"
"}")
        self.label_51.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_51.setWordWrap(True)

        self.horizontalLayout_23.addWidget(self.label_51)

        self.tool_diameter_4 = StatusLabel(self.frame_18)
        self.tool_diameter_4.setObjectName(u"tool_diameter_4")
        sizePolicy4.setHeightForWidth(self.tool_diameter_4.sizePolicy().hasHeightForWidth())
        self.tool_diameter_4.setSizePolicy(sizePolicy4)
        self.tool_diameter_4.setMinimumSize(QSize(70, 33))
        self.tool_diameter_4.setMaximumSize(QSize(70, 33))
        self.tool_diameter_4.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_23.addWidget(self.tool_diameter_4)


        self.horizontalLayout_103.addLayout(self.horizontalLayout_23)


        self.verticalLayout_26.addWidget(self.frame_10)

        self.mdi_entry_box_4 = MDIEntry(self.tooling_tab)
        self.mdi_entry_box_4.setObjectName(u"mdi_entry_box_4")
        sizePolicy6.setHeightForWidth(self.mdi_entry_box_4.sizePolicy().hasHeightForWidth())
        self.mdi_entry_box_4.setSizePolicy(sizePolicy6)
        self.mdi_entry_box_4.setMinimumSize(QSize(570, 40))
        self.mdi_entry_box_4.setMaximumSize(QSize(16777215, 40))
        self.mdi_entry_box_4.setFont(font7)
        self.mdi_entry_box_4.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self.verticalLayout_26.addWidget(self.mdi_entry_box_4)


        self.horizontalLayout_41.addLayout(self.verticalLayout_26)

        self.tabWidget.addTab(self.tooling_tab, "")
        self.probing_tab = QWidget()
        self.probing_tab.setObjectName(u"probing_tab")
        self.probing_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout_70 = QHBoxLayout(self.probing_tab)
        self.horizontalLayout_70.setObjectName(u"horizontalLayout_70")
        self.horizontalLayout_70.setContentsMargins(20, 20, 20, 20)
        self.widget_10 = QWidget(self.probing_tab)
        self.widget_10.setObjectName(u"widget_10")
        self.verticalLayout_14 = QVBoxLayout(self.widget_10)
        self.verticalLayout_14.setSpacing(20)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 0, 0)

        self.horizontalLayout_70.addWidget(self.widget_10)

        self.widget_44 = QWidget(self.probing_tab)
        self.widget_44.setObjectName(u"widget_44")
        sizePolicy10 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy10.setHorizontalStretch(1)
        sizePolicy10.setVerticalStretch(0)
        sizePolicy10.setHeightForWidth(self.widget_44.sizePolicy().hasHeightForWidth())
        self.widget_44.setSizePolicy(sizePolicy10)
        self.widget_44.setMinimumSize(QSize(530, 0))
        self.widget_44.setMaximumSize(QSize(530, 16777215))
        self.widget_44.setStyleSheet(u"")
        self.verticalLayout_43 = QVBoxLayout(self.widget_44)
        self.verticalLayout_43.setObjectName(u"verticalLayout_43")
        self.verticalLayout_43.setContentsMargins(-1, 6, 6, 9)
        self.label_90 = QLabel(self.widget_44)
        self.label_90.setObjectName(u"label_90")
        sizePolicy6.setHeightForWidth(self.label_90.sizePolicy().hasHeightForWidth())
        self.label_90.setSizePolicy(sizePolicy6)
        self.label_90.setMinimumSize(QSize(0, 27))
        self.label_90.setMaximumSize(QSize(16777215, 27))
        self.label_90.setFont(font2)
        self.label_90.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.label_90.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_43.addWidget(self.label_90)

        self.widget_15 = QWidget(self.widget_44)
        self.widget_15.setObjectName(u"widget_15")
        self.widget_15.setMinimumSize(QSize(112, 90))
        self.widget_15.setMaximumSize(QSize(16777215, 100))
        self.verticalLayout_28 = QVBoxLayout(self.widget_15)
        self.verticalLayout_28.setSpacing(0)
        self.verticalLayout_28.setObjectName(u"verticalLayout_28")
        self.verticalLayout_28.setContentsMargins(9, 0, 9, 0)
        self.horizontalWidget = QWidget(self.widget_15)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        sizePolicy.setHeightForWidth(self.horizontalWidget.sizePolicy().hasHeightForWidth())
        self.horizontalWidget.setSizePolicy(sizePolicy)
        self.horizontalWidget.setMinimumSize(QSize(440, 0))
        self.horizontalLayout_47 = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout_47.setSpacing(9)
        self.horizontalLayout_47.setObjectName(u"horizontalLayout_47")
        self.horizontalLayout_47.setContentsMargins(1, 1, 1, 1)
        self.actionbutton_28 = ActionButton(self.horizontalWidget)
        self.actionbutton_28.setObjectName(u"actionbutton_28")
        sizePolicy3.setHeightForWidth(self.actionbutton_28.sizePolicy().hasHeightForWidth())
        self.actionbutton_28.setSizePolicy(sizePolicy3)
        self.actionbutton_28.setMinimumSize(QSize(75, 38))
        self.actionbutton_28.setMaximumSize(QSize(70, 38))
        self.actionbutton_28.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_28.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_28.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_28)

        self.actionbutton_29 = ActionButton(self.horizontalWidget)
        self.actionbutton_29.setObjectName(u"actionbutton_29")
        sizePolicy3.setHeightForWidth(self.actionbutton_29.sizePolicy().hasHeightForWidth())
        self.actionbutton_29.setSizePolicy(sizePolicy3)
        self.actionbutton_29.setMinimumSize(QSize(75, 38))
        self.actionbutton_29.setMaximumSize(QSize(70, 38))
        self.actionbutton_29.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_29.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_29.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_29)

        self.actionbutton_30 = ActionButton(self.horizontalWidget)
        self.actionbutton_30.setObjectName(u"actionbutton_30")
        sizePolicy3.setHeightForWidth(self.actionbutton_30.sizePolicy().hasHeightForWidth())
        self.actionbutton_30.setSizePolicy(sizePolicy3)
        self.actionbutton_30.setMinimumSize(QSize(75, 38))
        self.actionbutton_30.setMaximumSize(QSize(70, 38))
        self.actionbutton_30.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_30.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_30.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_30)

        self.actionbutton_31 = ActionButton(self.horizontalWidget)
        self.actionbutton_31.setObjectName(u"actionbutton_31")
        sizePolicy3.setHeightForWidth(self.actionbutton_31.sizePolicy().hasHeightForWidth())
        self.actionbutton_31.setSizePolicy(sizePolicy3)
        self.actionbutton_31.setMinimumSize(QSize(75, 38))
        self.actionbutton_31.setMaximumSize(QSize(70, 38))
        self.actionbutton_31.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_31.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_31.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_31)

        self.actionbutton_60 = ActionButton(self.horizontalWidget)
        self.actionbutton_60.setObjectName(u"actionbutton_60")
        sizePolicy3.setHeightForWidth(self.actionbutton_60.sizePolicy().hasHeightForWidth())
        self.actionbutton_60.setSizePolicy(sizePolicy3)
        self.actionbutton_60.setMinimumSize(QSize(75, 38))
        self.actionbutton_60.setMaximumSize(QSize(70, 38))
        self.actionbutton_60.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_60.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_60.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_60)

        self.actionbutton_61 = ActionButton(self.horizontalWidget)
        self.actionbutton_61.setObjectName(u"actionbutton_61")
        sizePolicy3.setHeightForWidth(self.actionbutton_61.sizePolicy().hasHeightForWidth())
        self.actionbutton_61.setSizePolicy(sizePolicy3)
        self.actionbutton_61.setMinimumSize(QSize(75, 38))
        self.actionbutton_61.setMaximumSize(QSize(70, 38))
        self.actionbutton_61.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_61.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_61.setAutoExclusive(True)

        self.horizontalLayout_47.addWidget(self.actionbutton_61)


        self.verticalLayout_28.addWidget(self.horizontalWidget)

        self.horizontalWidget_2 = QWidget(self.widget_15)
        self.horizontalWidget_2.setObjectName(u"horizontalWidget_2")
        sizePolicy.setHeightForWidth(self.horizontalWidget_2.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_2.setSizePolicy(sizePolicy)
        self.horizontalWidget_2.setMinimumSize(QSize(440, 0))
        self.horizontalLayout_62 = QHBoxLayout(self.horizontalWidget_2)
        self.horizontalLayout_62.setSpacing(9)
        self.horizontalLayout_62.setObjectName(u"horizontalLayout_62")
        self.horizontalLayout_62.setContentsMargins(1, 1, 1, 1)
        self.actionbutton_62 = ActionButton(self.horizontalWidget_2)
        self.actionbutton_62.setObjectName(u"actionbutton_62")
        sizePolicy3.setHeightForWidth(self.actionbutton_62.sizePolicy().hasHeightForWidth())
        self.actionbutton_62.setSizePolicy(sizePolicy3)
        self.actionbutton_62.setMinimumSize(QSize(75, 38))
        self.actionbutton_62.setMaximumSize(QSize(70, 38))
        self.actionbutton_62.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_62.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_62.setAutoExclusive(True)

        self.horizontalLayout_62.addWidget(self.actionbutton_62)

        self.actionbutton_63 = ActionButton(self.horizontalWidget_2)
        self.actionbutton_63.setObjectName(u"actionbutton_63")
        sizePolicy3.setHeightForWidth(self.actionbutton_63.sizePolicy().hasHeightForWidth())
        self.actionbutton_63.setSizePolicy(sizePolicy3)
        self.actionbutton_63.setMinimumSize(QSize(75, 38))
        self.actionbutton_63.setMaximumSize(QSize(70, 38))
        self.actionbutton_63.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_63.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_63.setAutoExclusive(True)

        self.horizontalLayout_62.addWidget(self.actionbutton_63)

        self.actionbutton_64 = ActionButton(self.horizontalWidget_2)
        self.actionbutton_64.setObjectName(u"actionbutton_64")
        sizePolicy3.setHeightForWidth(self.actionbutton_64.sizePolicy().hasHeightForWidth())
        self.actionbutton_64.setSizePolicy(sizePolicy3)
        self.actionbutton_64.setMinimumSize(QSize(75, 38))
        self.actionbutton_64.setMaximumSize(QSize(70, 38))
        self.actionbutton_64.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_64.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_64.setAutoExclusive(True)

        self.horizontalLayout_62.addWidget(self.actionbutton_64)

        self.probe_Position_only = VCPVarPushButton(self.horizontalWidget_2)
        self.probe_Position_only.setObjectName(u"probe_Position_only")
        sizePolicy3.setHeightForWidth(self.probe_Position_only.sizePolicy().hasHeightForWidth())
        self.probe_Position_only.setSizePolicy(sizePolicy3)
        self.probe_Position_only.setMinimumSize(QSize(244, 38))
        self.probe_Position_only.setMaximumSize(QSize(244, 38))
        self.probe_Position_only.setProperty(u"varParameterNumber", 3030)

        self.horizontalLayout_62.addWidget(self.probe_Position_only)


        self.verticalLayout_28.addWidget(self.horizontalWidget_2)


        self.verticalLayout_43.addWidget(self.widget_15)

        self.label_91 = QLabel(self.widget_44)
        self.label_91.setObjectName(u"label_91")
        sizePolicy6.setHeightForWidth(self.label_91.sizePolicy().hasHeightForWidth())
        self.label_91.setSizePolicy(sizePolicy6)
        self.label_91.setMinimumSize(QSize(0, 27))
        self.label_91.setMaximumSize(QSize(16777215, 27))
        self.label_91.setFont(font2)
        self.label_91.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.verticalLayout_43.addWidget(self.label_91)

        self.verticalLayout_33 = QVBoxLayout()
        self.verticalLayout_33.setSpacing(6)
        self.verticalLayout_33.setObjectName(u"verticalLayout_33")
        self.verticalLayout_33.setContentsMargins(-1, 0, 9, -1)
        self.horizontalLayout_154 = QHBoxLayout()
        self.horizontalLayout_154.setObjectName(u"horizontalLayout_154")
        self.horizontalLayout_154.setContentsMargins(-1, 1, -1, 1)
        self.ref_coilumn_header_19 = QLabel(self.widget_44)
        self.ref_coilumn_header_19.setObjectName(u"ref_coilumn_header_19")
        sizePolicy.setHeightForWidth(self.ref_coilumn_header_19.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_19.setSizePolicy(sizePolicy)
        self.ref_coilumn_header_19.setStyleSheet(u"")
        self.ref_coilumn_header_19.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_154.addWidget(self.ref_coilumn_header_19)

        self.label_92 = QLabel(self.widget_44)
        self.label_92.setObjectName(u"label_92")
        sizePolicy3.setHeightForWidth(self.label_92.sizePolicy().hasHeightForWidth())
        self.label_92.setSizePolicy(sizePolicy3)
        self.label_92.setMinimumSize(QSize(140, 31))
        self.label_92.setMaximumSize(QSize(150, 31))
        self.label_92.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_92.setLineWidth(0)
        self.label_92.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_92.setIndent(0)

        self.horizontalLayout_154.addWidget(self.label_92)

        self.probe_tool_number = VCPVarLineEdit(self.widget_44)
        self.probe_tool_number.setObjectName(u"probe_tool_number")
        sizePolicy3.setHeightForWidth(self.probe_tool_number.sizePolicy().hasHeightForWidth())
        self.probe_tool_number.setSizePolicy(sizePolicy3)
        self.probe_tool_number.setMinimumSize(QSize(100, 31))
        self.probe_tool_number.setMaximumSize(QSize(100, 31))
        self.probe_tool_number.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.probe_tool_number.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.probe_tool_number.setProperty(u"displayDecimals", 0)
        self.probe_tool_number.setProperty(u"varParameterNumber", 3014)

        self.horizontalLayout_154.addWidget(self.probe_tool_number)

        self.label_93 = QLabel(self.widget_44)
        self.label_93.setObjectName(u"label_93")
        sizePolicy3.setHeightForWidth(self.label_93.sizePolicy().hasHeightForWidth())
        self.label_93.setSizePolicy(sizePolicy3)
        self.label_93.setMinimumSize(QSize(140, 31))
        self.label_93.setMaximumSize(QSize(140, 31))
        self.label_93.setBaseSize(QSize(140, 30))
        self.label_93.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_93.setLineWidth(0)
        self.label_93.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_93.setIndent(0)

        self.horizontalLayout_154.addWidget(self.label_93)

        self.step_off_width = VCPVarLineEdit(self.widget_44)
        self.step_off_width.setObjectName(u"step_off_width")
        sizePolicy3.setHeightForWidth(self.step_off_width.sizePolicy().hasHeightForWidth())
        self.step_off_width.setSizePolicy(sizePolicy3)
        self.step_off_width.setMinimumSize(QSize(100, 31))
        self.step_off_width.setMaximumSize(QSize(100, 31))
        self.step_off_width.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.step_off_width.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.step_off_width.setProperty(u"varParameterNumber", 3015)

        self.horizontalLayout_154.addWidget(self.step_off_width)


        self.verticalLayout_33.addLayout(self.horizontalLayout_154)

        self.horizontalLayout_155 = QHBoxLayout()
        self.horizontalLayout_155.setObjectName(u"horizontalLayout_155")
        self.horizontalLayout_155.setContentsMargins(-1, 1, -1, 1)
        self.ref_coilumn_header_20 = QLabel(self.widget_44)
        self.ref_coilumn_header_20.setObjectName(u"ref_coilumn_header_20")
        sizePolicy.setHeightForWidth(self.ref_coilumn_header_20.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_20.setSizePolicy(sizePolicy)
        self.ref_coilumn_header_20.setStyleSheet(u"")
        self.ref_coilumn_header_20.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_155.addWidget(self.ref_coilumn_header_20)

        self.label_94 = QLabel(self.widget_44)
        self.label_94.setObjectName(u"label_94")
        sizePolicy3.setHeightForWidth(self.label_94.sizePolicy().hasHeightForWidth())
        self.label_94.setSizePolicy(sizePolicy3)
        self.label_94.setMinimumSize(QSize(140, 31))
        self.label_94.setMaximumSize(QSize(150, 31))
        self.label_94.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_94.setLineWidth(0)
        self.label_94.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_94.setIndent(0)

        self.horizontalLayout_155.addWidget(self.label_94)

        self.probe_fast_fr = VCPVarLineEdit(self.widget_44)
        self.probe_fast_fr.setObjectName(u"probe_fast_fr")
        sizePolicy3.setHeightForWidth(self.probe_fast_fr.sizePolicy().hasHeightForWidth())
        self.probe_fast_fr.setSizePolicy(sizePolicy3)
        self.probe_fast_fr.setMinimumSize(QSize(100, 31))
        self.probe_fast_fr.setMaximumSize(QSize(100, 31))
        self.probe_fast_fr.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.probe_fast_fr.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.probe_fast_fr.setProperty(u"displayDecimals", 1)
        self.probe_fast_fr.setProperty(u"varParameterNumber", 3016)

        self.horizontalLayout_155.addWidget(self.probe_fast_fr)

        self.label_95 = QLabel(self.widget_44)
        self.label_95.setObjectName(u"label_95")
        sizePolicy3.setHeightForWidth(self.label_95.sizePolicy().hasHeightForWidth())
        self.label_95.setSizePolicy(sizePolicy3)
        self.label_95.setMinimumSize(QSize(140, 31))
        self.label_95.setMaximumSize(QSize(140, 31))
        self.label_95.setBaseSize(QSize(140, 30))
        self.label_95.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_95.setLineWidth(0)
        self.label_95.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_95.setIndent(0)

        self.horizontalLayout_155.addWidget(self.label_95)

        self.probe_slow_fr = VCPVarLineEdit(self.widget_44)
        self.probe_slow_fr.setObjectName(u"probe_slow_fr")
        sizePolicy3.setHeightForWidth(self.probe_slow_fr.sizePolicy().hasHeightForWidth())
        self.probe_slow_fr.setSizePolicy(sizePolicy3)
        self.probe_slow_fr.setMinimumSize(QSize(100, 31))
        self.probe_slow_fr.setMaximumSize(QSize(100, 31))
        self.probe_slow_fr.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.probe_slow_fr.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.probe_slow_fr.setProperty(u"displayDecimals", 1)
        self.probe_slow_fr.setProperty(u"varParameterNumber", 3017)

        self.horizontalLayout_155.addWidget(self.probe_slow_fr)


        self.verticalLayout_33.addLayout(self.horizontalLayout_155)

        self.horizontalLayout_156 = QHBoxLayout()
        self.horizontalLayout_156.setObjectName(u"horizontalLayout_156")
        self.horizontalLayout_156.setContentsMargins(-1, 1, -1, 1)
        self.ref_coilumn_header_21 = QLabel(self.widget_44)
        self.ref_coilumn_header_21.setObjectName(u"ref_coilumn_header_21")
        sizePolicy.setHeightForWidth(self.ref_coilumn_header_21.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_21.setSizePolicy(sizePolicy)
        self.ref_coilumn_header_21.setStyleSheet(u"")
        self.ref_coilumn_header_21.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_156.addWidget(self.ref_coilumn_header_21)

        self.label_96 = QLabel(self.widget_44)
        self.label_96.setObjectName(u"label_96")
        sizePolicy3.setHeightForWidth(self.label_96.sizePolicy().hasHeightForWidth())
        self.label_96.setSizePolicy(sizePolicy3)
        self.label_96.setMinimumSize(QSize(140, 31))
        self.label_96.setMaximumSize(QSize(150, 31))
        self.label_96.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_96.setLineWidth(0)
        self.label_96.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_96.setIndent(0)

        self.horizontalLayout_156.addWidget(self.label_96)

        self.max_x_distance = VCPVarLineEdit(self.widget_44)
        self.max_x_distance.setObjectName(u"max_x_distance")
        sizePolicy3.setHeightForWidth(self.max_x_distance.sizePolicy().hasHeightForWidth())
        self.max_x_distance.setSizePolicy(sizePolicy3)
        self.max_x_distance.setMinimumSize(QSize(100, 31))
        self.max_x_distance.setMaximumSize(QSize(100, 31))
        self.max_x_distance.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.max_x_distance.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.max_x_distance.setProperty(u"varParameterNumber", 3018)

        self.horizontalLayout_156.addWidget(self.max_x_distance)

        self.label_97 = QLabel(self.widget_44)
        self.label_97.setObjectName(u"label_97")
        sizePolicy3.setHeightForWidth(self.label_97.sizePolicy().hasHeightForWidth())
        self.label_97.setSizePolicy(sizePolicy3)
        self.label_97.setMinimumSize(QSize(140, 31))
        self.label_97.setMaximumSize(QSize(140, 31))
        self.label_97.setBaseSize(QSize(140, 30))
        self.label_97.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_97.setLineWidth(0)
        self.label_97.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_97.setIndent(0)

        self.horizontalLayout_156.addWidget(self.label_97)

        self.x_clearance = VCPVarLineEdit(self.widget_44)
        self.x_clearance.setObjectName(u"x_clearance")
        sizePolicy3.setHeightForWidth(self.x_clearance.sizePolicy().hasHeightForWidth())
        self.x_clearance.setSizePolicy(sizePolicy3)
        self.x_clearance.setMinimumSize(QSize(100, 31))
        self.x_clearance.setMaximumSize(QSize(100, 31))
        self.x_clearance.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_clearance.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.x_clearance.setProperty(u"varParameterNumber", 3019)

        self.horizontalLayout_156.addWidget(self.x_clearance)


        self.verticalLayout_33.addLayout(self.horizontalLayout_156)

        self.horizontalLayout_157 = QHBoxLayout()
        self.horizontalLayout_157.setObjectName(u"horizontalLayout_157")
        self.horizontalLayout_157.setContentsMargins(-1, 1, -1, 1)
        self.ref_coilumn_header_22 = QLabel(self.widget_44)
        self.ref_coilumn_header_22.setObjectName(u"ref_coilumn_header_22")
        sizePolicy.setHeightForWidth(self.ref_coilumn_header_22.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_22.setSizePolicy(sizePolicy)
        self.ref_coilumn_header_22.setStyleSheet(u"")
        self.ref_coilumn_header_22.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_157.addWidget(self.ref_coilumn_header_22)

        self.label_98 = QLabel(self.widget_44)
        self.label_98.setObjectName(u"label_98")
        sizePolicy3.setHeightForWidth(self.label_98.sizePolicy().hasHeightForWidth())
        self.label_98.setSizePolicy(sizePolicy3)
        self.label_98.setMinimumSize(QSize(140, 31))
        self.label_98.setMaximumSize(QSize(150, 31))
        self.label_98.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_98.setLineWidth(0)
        self.label_98.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_98.setIndent(0)

        self.horizontalLayout_157.addWidget(self.label_98)

        self.max_z_distance = VCPVarLineEdit(self.widget_44)
        self.max_z_distance.setObjectName(u"max_z_distance")
        sizePolicy3.setHeightForWidth(self.max_z_distance.sizePolicy().hasHeightForWidth())
        self.max_z_distance.setSizePolicy(sizePolicy3)
        self.max_z_distance.setMinimumSize(QSize(100, 31))
        self.max_z_distance.setMaximumSize(QSize(100, 31))
        self.max_z_distance.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.max_z_distance.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.max_z_distance.setProperty(u"varParameterNumber", 3020)

        self.horizontalLayout_157.addWidget(self.max_z_distance)

        self.label_99 = QLabel(self.widget_44)
        self.label_99.setObjectName(u"label_99")
        sizePolicy3.setHeightForWidth(self.label_99.sizePolicy().hasHeightForWidth())
        self.label_99.setSizePolicy(sizePolicy3)
        self.label_99.setMinimumSize(QSize(140, 31))
        self.label_99.setMaximumSize(QSize(140, 31))
        self.label_99.setBaseSize(QSize(140, 30))
        self.label_99.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_99.setLineWidth(0)
        self.label_99.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_99.setIndent(0)

        self.horizontalLayout_157.addWidget(self.label_99)

        self.z_clearance = VCPVarLineEdit(self.widget_44)
        self.z_clearance.setObjectName(u"z_clearance")
        sizePolicy3.setHeightForWidth(self.z_clearance.sizePolicy().hasHeightForWidth())
        self.z_clearance.setSizePolicy(sizePolicy3)
        self.z_clearance.setMinimumSize(QSize(100, 31))
        self.z_clearance.setMaximumSize(QSize(100, 31))
        self.z_clearance.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_clearance.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.z_clearance.setProperty(u"varParameterNumber", 3021)

        self.horizontalLayout_157.addWidget(self.z_clearance)


        self.verticalLayout_33.addLayout(self.horizontalLayout_157)

        self.horizontalLayout_158 = QHBoxLayout()
        self.horizontalLayout_158.setObjectName(u"horizontalLayout_158")
        self.horizontalLayout_158.setContentsMargins(1, 1, 1, 1)
        self.ref_coilumn_header_23 = QLabel(self.widget_44)
        self.ref_coilumn_header_23.setObjectName(u"ref_coilumn_header_23")
        sizePolicy.setHeightForWidth(self.ref_coilumn_header_23.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_23.setSizePolicy(sizePolicy)
        self.ref_coilumn_header_23.setStyleSheet(u"")
        self.ref_coilumn_header_23.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_158.addWidget(self.ref_coilumn_header_23)

        self.label_100 = QLabel(self.widget_44)
        self.label_100.setObjectName(u"label_100")
        sizePolicy3.setHeightForWidth(self.label_100.sizePolicy().hasHeightForWidth())
        self.label_100.setSizePolicy(sizePolicy3)
        self.label_100.setMinimumSize(QSize(140, 31))
        self.label_100.setMaximumSize(QSize(150, 31))
        self.label_100.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_100.setLineWidth(0)
        self.label_100.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_100.setIndent(0)

        self.horizontalLayout_158.addWidget(self.label_100)

        self.extra_probe_depth = VCPVarLineEdit(self.widget_44)
        self.extra_probe_depth.setObjectName(u"extra_probe_depth")
        sizePolicy3.setHeightForWidth(self.extra_probe_depth.sizePolicy().hasHeightForWidth())
        self.extra_probe_depth.setSizePolicy(sizePolicy3)
        self.extra_probe_depth.setMinimumSize(QSize(100, 31))
        self.extra_probe_depth.setMaximumSize(QSize(100, 31))
        self.extra_probe_depth.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.extra_probe_depth.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.extra_probe_depth.setProperty(u"varParameterNumber", 3022)

        self.horizontalLayout_158.addWidget(self.extra_probe_depth)

        self.label_101 = QLabel(self.widget_44)
        self.label_101.setObjectName(u"label_101")
        sizePolicy3.setHeightForWidth(self.label_101.sizePolicy().hasHeightForWidth())
        self.label_101.setSizePolicy(sizePolicy3)
        self.label_101.setMinimumSize(QSize(140, 31))
        self.label_101.setMaximumSize(QSize(140, 31))
        self.label_101.setBaseSize(QSize(140, 30))
        self.label_101.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_101.setLineWidth(0)
        self.label_101.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_101.setIndent(0)

        self.horizontalLayout_158.addWidget(self.label_101)

        self.edge_width = VCPVarLineEdit(self.widget_44)
        self.edge_width.setObjectName(u"edge_width")
        sizePolicy3.setHeightForWidth(self.edge_width.sizePolicy().hasHeightForWidth())
        self.edge_width.setSizePolicy(sizePolicy3)
        self.edge_width.setMinimumSize(QSize(100, 31))
        self.edge_width.setMaximumSize(QSize(100, 31))
        self.edge_width.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.edge_width.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.edge_width.setProperty(u"varParameterNumber", 3023)

        self.horizontalLayout_158.addWidget(self.edge_width)


        self.verticalLayout_33.addLayout(self.horizontalLayout_158)


        self.verticalLayout_43.addLayout(self.verticalLayout_33)

        self.widget_19 = QWidget(self.widget_44)
        self.widget_19.setObjectName(u"widget_19")
        sizePolicy6.setHeightForWidth(self.widget_19.sizePolicy().hasHeightForWidth())
        self.widget_19.setSizePolicy(sizePolicy6)
        self.widget_19.setMinimumSize(QSize(0, 33))
        self.widget_19.setMaximumSize(QSize(16777215, 33))
        self.horizontalLayout_63 = QHBoxLayout(self.widget_19)
        self.horizontalLayout_63.setSpacing(1)
        self.horizontalLayout_63.setObjectName(u"horizontalLayout_63")
        self.horizontalLayout_63.setContentsMargins(0, 0, 0, 0)
        self.label_102 = QLabel(self.widget_19)
        self.label_102.setObjectName(u"label_102")
        sizePolicy6.setHeightForWidth(self.label_102.sizePolicy().hasHeightForWidth())
        self.label_102.setSizePolicy(sizePolicy6)
        self.label_102.setMinimumSize(QSize(0, 27))
        self.label_102.setMaximumSize(QSize(16777215, 27))
        self.label_102.setFont(font2)
        self.label_102.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-top-left-radius: 5px;\n"
"    border-bottom-left-radius: 5px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_63.addWidget(self.label_102)

        self.reset_all_data = SubCallButton(self.widget_19)
        self.reset_all_data.setObjectName(u"reset_all_data")
        sizePolicy3.setHeightForWidth(self.reset_all_data.sizePolicy().hasHeightForWidth())
        self.reset_all_data.setSizePolicy(sizePolicy3)
        self.reset_all_data.setMinimumSize(QSize(120, 27))
        self.reset_all_data.setMaximumSize(QSize(120, 27))
        self.reset_all_data.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.reset_all_data.setStyleSheet(u".SubCallButton{\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"	font: 14pt \"Probe Basic Bebas Mono\";\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargra"
                        "dient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_63.addWidget(self.reset_all_data)

        self.x_data_reset1 = SubCallButton(self.widget_19)
        self.x_data_reset1.setObjectName(u"x_data_reset1")
        sizePolicy3.setHeightForWidth(self.x_data_reset1.sizePolicy().hasHeightForWidth())
        self.x_data_reset1.setSizePolicy(sizePolicy3)
        self.x_data_reset1.setMinimumSize(QSize(110, 27))
        self.x_data_reset1.setMaximumSize(QSize(110, 27))
        self.x_data_reset1.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.x_data_reset1.setStyleSheet(u".SubCallButton{\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"	font: 14pt \"Probe Basic Bebas Mono\";\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargra"
                        "dient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_63.addWidget(self.x_data_reset1)

        self.z_data_reset1 = SubCallButton(self.widget_19)
        self.z_data_reset1.setObjectName(u"z_data_reset1")
        sizePolicy3.setHeightForWidth(self.z_data_reset1.sizePolicy().hasHeightForWidth())
        self.z_data_reset1.setSizePolicy(sizePolicy3)
        self.z_data_reset1.setMinimumSize(QSize(110, 27))
        self.z_data_reset1.setMaximumSize(QSize(110, 27))
        self.z_data_reset1.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.z_data_reset1.setStyleSheet(u"SubCallButton{\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-top-right-radius: 5px;\n"
"    border-bottom-right-radius: 5px;\n"
"	font: 14pt \"Probe Basic Bebas Mono\";\n"
"  	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradi"
                        "ent(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_63.addWidget(self.z_data_reset1)


        self.verticalLayout_43.addWidget(self.widget_19)

        self.verticalLayout_44 = QVBoxLayout()
        self.verticalLayout_44.setSpacing(6)
        self.verticalLayout_44.setObjectName(u"verticalLayout_44")
        self.verticalLayout_44.setContentsMargins(-1, 0, 9, 3)
        self.horizontalLayout_160 = QHBoxLayout()
        self.horizontalLayout_160.setObjectName(u"horizontalLayout_160")
        self.horizontalLayout_160.setContentsMargins(1, 1, 1, 1)
        self.label_108 = QLabel(self.widget_44)
        self.label_108.setObjectName(u"label_108")
        sizePolicy6.setHeightForWidth(self.label_108.sizePolicy().hasHeightForWidth())
        self.label_108.setSizePolicy(sizePolicy6)
        self.label_108.setMinimumSize(QSize(0, 31))
        self.label_108.setMaximumSize(QSize(16777215, 31))
        self.label_108.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_108.setFrameShape(QFrame.Shape.NoFrame)
        self.label_108.setLineWidth(0)
        self.label_108.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_108.setIndent(0)

        self.horizontalLayout_160.addWidget(self.label_108)

        self.x_minus_probed_position = StatusLabel(self.widget_44)
        self.x_minus_probed_position.setObjectName(u"x_minus_probed_position")
        sizePolicy3.setHeightForWidth(self.x_minus_probed_position.sizePolicy().hasHeightForWidth())
        self.x_minus_probed_position.setSizePolicy(sizePolicy3)
        self.x_minus_probed_position.setMinimumSize(QSize(80, 31))
        self.x_minus_probed_position.setMaximumSize(QSize(80, 31))
        self.x_minus_probed_position.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_160.addWidget(self.x_minus_probed_position)

        self.label_110 = QLabel(self.widget_44)
        self.label_110.setObjectName(u"label_110")
        sizePolicy6.setHeightForWidth(self.label_110.sizePolicy().hasHeightForWidth())
        self.label_110.setSizePolicy(sizePolicy6)
        self.label_110.setMinimumSize(QSize(0, 31))
        self.label_110.setMaximumSize(QSize(16777215, 31))
        self.label_110.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_110.setLineWidth(0)
        self.label_110.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_110.setIndent(0)

        self.horizontalLayout_160.addWidget(self.label_110)

        self.z_minus_probed_position = StatusLabel(self.widget_44)
        self.z_minus_probed_position.setObjectName(u"z_minus_probed_position")
        sizePolicy3.setHeightForWidth(self.z_minus_probed_position.sizePolicy().hasHeightForWidth())
        self.z_minus_probed_position.setSizePolicy(sizePolicy3)
        self.z_minus_probed_position.setMinimumSize(QSize(80, 31))
        self.z_minus_probed_position.setMaximumSize(QSize(80, 31))
        self.z_minus_probed_position.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.z_minus_probed_position.setMargin(2)

        self.horizontalLayout_160.addWidget(self.z_minus_probed_position)

        self.label_107 = QLabel(self.widget_44)
        self.label_107.setObjectName(u"label_107")
        sizePolicy3.setHeightForWidth(self.label_107.sizePolicy().hasHeightForWidth())
        self.label_107.setSizePolicy(sizePolicy3)
        self.label_107.setMinimumSize(QSize(80, 31))
        self.label_107.setMaximumSize(QSize(80, 31))
        self.label_107.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_107.setLineWidth(0)
        self.label_107.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_107.setIndent(0)

        self.horizontalLayout_160.addWidget(self.label_107)

        self.avg_diameter = StatusLabel(self.widget_44)
        self.avg_diameter.setObjectName(u"avg_diameter")
        sizePolicy3.setHeightForWidth(self.avg_diameter.sizePolicy().hasHeightForWidth())
        self.avg_diameter.setSizePolicy(sizePolicy3)
        self.avg_diameter.setMinimumSize(QSize(80, 31))
        self.avg_diameter.setMaximumSize(QSize(80, 31))
        self.avg_diameter.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_160.addWidget(self.avg_diameter)


        self.verticalLayout_44.addLayout(self.horizontalLayout_160)

        self.horizontalLayout_162 = QHBoxLayout()
        self.horizontalLayout_162.setObjectName(u"horizontalLayout_162")
        self.horizontalLayout_162.setContentsMargins(1, 1, 1, 1)
        self.label_111 = QLabel(self.widget_44)
        self.label_111.setObjectName(u"label_111")
        sizePolicy6.setHeightForWidth(self.label_111.sizePolicy().hasHeightForWidth())
        self.label_111.setSizePolicy(sizePolicy6)
        self.label_111.setMinimumSize(QSize(0, 31))
        self.label_111.setMaximumSize(QSize(16777215, 31))
        self.label_111.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_111.setLineWidth(0)
        self.label_111.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_111.setIndent(0)

        self.horizontalLayout_162.addWidget(self.label_111)

        self.edge_delta = StatusLabel(self.widget_44)
        self.edge_delta.setObjectName(u"edge_delta")
        sizePolicy3.setHeightForWidth(self.edge_delta.sizePolicy().hasHeightForWidth())
        self.edge_delta.setSizePolicy(sizePolicy3)
        self.edge_delta.setMinimumSize(QSize(80, 31))
        self.edge_delta.setMaximumSize(QSize(80, 31))
        self.edge_delta.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_162.addWidget(self.edge_delta)

        self.label_112 = QLabel(self.widget_44)
        self.label_112.setObjectName(u"label_112")
        sizePolicy3.setHeightForWidth(self.label_112.sizePolicy().hasHeightForWidth())
        self.label_112.setSizePolicy(sizePolicy3)
        self.label_112.setMinimumSize(QSize(80, 31))
        self.label_112.setMaximumSize(QSize(80, 31))
        self.label_112.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_112.setLineWidth(0)
        self.label_112.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_112.setIndent(0)

        self.horizontalLayout_162.addWidget(self.label_112)

        self.edge_angle = StatusLabel(self.widget_44)
        self.edge_angle.setObjectName(u"edge_angle")
        sizePolicy3.setHeightForWidth(self.edge_angle.sizePolicy().hasHeightForWidth())
        self.edge_angle.setSizePolicy(sizePolicy3)
        self.edge_angle.setMinimumSize(QSize(80, 31))
        self.edge_angle.setMaximumSize(QSize(80, 31))
        self.edge_angle.setTextFormat(Qt.TextFormat.RichText)
        self.edge_angle.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_162.addWidget(self.edge_angle)

        self.label_114 = QLabel(self.widget_44)
        self.label_114.setObjectName(u"label_114")
        sizePolicy3.setHeightForWidth(self.label_114.sizePolicy().hasHeightForWidth())
        self.label_114.setSizePolicy(sizePolicy3)
        self.label_114.setMinimumSize(QSize(80, 31))
        self.label_114.setMaximumSize(QSize(80, 31))
        self.label_114.setStyleSheet(u"QLabel{\n"
"font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"color: white;\n"
"}")
        self.label_114.setLineWidth(0)
        self.label_114.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_114.setIndent(0)

        self.horizontalLayout_162.addWidget(self.label_114)

        self.y_center_probed = StatusLabel(self.widget_44)
        self.y_center_probed.setObjectName(u"y_center_probed")
        sizePolicy3.setHeightForWidth(self.y_center_probed.sizePolicy().hasHeightForWidth())
        self.y_center_probed.setSizePolicy(sizePolicy3)
        self.y_center_probed.setMinimumSize(QSize(80, 31))
        self.y_center_probed.setMaximumSize(QSize(80, 31))
        self.y_center_probed.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.y_center_probed.setMargin(2)

        self.horizontalLayout_162.addWidget(self.y_center_probed)


        self.verticalLayout_44.addLayout(self.horizontalLayout_162)


        self.verticalLayout_43.addLayout(self.verticalLayout_44)

        self.mdi_entry_box_6 = MDIEntry(self.widget_44)
        self.mdi_entry_box_6.setObjectName(u"mdi_entry_box_6")
        self.mdi_entry_box_6.setMinimumSize(QSize(0, 42))
        self.mdi_entry_box_6.setMaximumSize(QSize(16777215, 42))
        self.mdi_entry_box_6.setFont(font7)
        self.mdi_entry_box_6.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self.verticalLayout_43.addWidget(self.mdi_entry_box_6)


        self.horizontalLayout_70.addWidget(self.widget_44)

        self.horizontalLayout_100 = QHBoxLayout()
        self.horizontalLayout_100.setObjectName(u"horizontalLayout_100")
        self.frame_23 = QFrame(self.probing_tab)
        self.frame_23.setObjectName(u"frame_23")
        sizePolicy10.setHeightForWidth(self.frame_23.sizePolicy().hasHeightForWidth())
        self.frame_23.setSizePolicy(sizePolicy10)
        self.frame_23.setStyleSheet(u"QFrame {\n"
"    border: none;\n"
"    border-radius: 0px;\n"
"    background-color: transparent;\n"
"}")
        self.frame_23.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_23.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_23)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.probe_tab_widget = QTabWidget(self.frame_23)
        self.probe_tab_widget.setObjectName(u"probe_tab_widget")
        sizePolicy4.setHeightForWidth(self.probe_tab_widget.sizePolicy().hasHeightForWidth())
        self.probe_tab_widget.setSizePolicy(sizePolicy4)
        font9 = QFont()
        font9.setFamilies([u"Probe Basic Bebas Mono"])
        font9.setPointSize(13)
        self.probe_tab_widget.setFont(font9)
        self.probe_tab_widget.setStyleSheet(u"QTabWidget::pane {\n"
"    border: 0px;\n"
"}\n"
"\n"
"\n"
"QTabWidget QTabBar::tab {\n"
"    min-width: 145px;\n"
"    min-height: 30px;\n"
"    font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.probe_tab_widget.setTabPosition(QTabWidget.TabPosition.North)
        self.probe_tab_widget.setTabShape(QTabWidget.TabShape.Rounded)
        self.probe_tab_widget.setIconSize(QSize(25, 16))
        self.outside_corners_tab = QWidget()
        self.outside_corners_tab.setObjectName(u"outside_corners_tab")
        self.probe_tab_widget.addTab(self.outside_corners_tab, "")
        self.inside_corners_tab = QWidget()
        self.inside_corners_tab.setObjectName(u"inside_corners_tab")
        self.horizontalLayout_66 = QHBoxLayout(self.inside_corners_tab)
        self.horizontalLayout_66.setObjectName(u"horizontalLayout_66")
        self.probe_tab_widget.addTab(self.inside_corners_tab, "")
        self.boss_and_pocket_tab = QWidget()
        self.boss_and_pocket_tab.setObjectName(u"boss_and_pocket_tab")
        self.horizontalLayout_69 = QHBoxLayout(self.boss_and_pocket_tab)
        self.horizontalLayout_69.setObjectName(u"horizontalLayout_69")
        self.probe_tab_widget.addTab(self.boss_and_pocket_tab, "")
        self.valley_and_ridge_tab = QWidget()
        self.valley_and_ridge_tab.setObjectName(u"valley_and_ridge_tab")
        self.horizontalLayout_74 = QHBoxLayout(self.valley_and_ridge_tab)
        self.horizontalLayout_74.setObjectName(u"horizontalLayout_74")
        self.probe_tab_widget.addTab(self.valley_and_ridge_tab, "")
        self.rotary_axis_tab = QWidget()
        self.rotary_axis_tab.setObjectName(u"rotary_axis_tab")
        self.probe_tab_widget.addTab(self.rotary_axis_tab, "")
        self.multi_axis_tab = QWidget()
        self.multi_axis_tab.setObjectName(u"multi_axis_tab")
        self.probe_tab_widget.addTab(self.multi_axis_tab, "")
        self.probe_help_tab = QWidget()
        self.probe_help_tab.setObjectName(u"probe_help_tab")
        self.horizontalLayout_52 = QHBoxLayout(self.probe_help_tab)
        self.horizontalLayout_52.setObjectName(u"horizontalLayout_52")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(-1, -1, -1, 15)
        self.tabWidget_2 = QTabWidget(self.probe_help_tab)
        self.tabWidget_2.setObjectName(u"tabWidget_2")
        sizePolicy11 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.MinimumExpanding)
        sizePolicy11.setHorizontalStretch(0)
        sizePolicy11.setVerticalStretch(0)
        sizePolicy11.setHeightForWidth(self.tabWidget_2.sizePolicy().hasHeightForWidth())
        self.tabWidget_2.setSizePolicy(sizePolicy11)
        self.tabWidget_2.setFont(font9)
        self.tabWidget_2.setTabPosition(QTabWidget.TabPosition.South)
        self.tab_5 = QWidget()
        self.tab_5.setObjectName(u"tab_5")
        self.horizontalLayout_60 = QHBoxLayout(self.tab_5)
        self.horizontalLayout_60.setObjectName(u"horizontalLayout_60")
        self.horizontalLayout_59 = QHBoxLayout()
        self.horizontalLayout_59.setObjectName(u"horizontalLayout_59")
        self.label = QLabel(self.tab_5)
        self.label.setObjectName(u"label")
        self.label.setMinimumSize(QSize(541, 451))
        self.label.setMaximumSize(QSize(541, 451))
        self.label.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/step_off_width.png);\n"
"}")
        self.label.setScaledContents(True)
        self.label.setIndent(0)

        self.horizontalLayout_59.addWidget(self.label)


        self.horizontalLayout_60.addLayout(self.horizontalLayout_59)

        self.tabWidget_2.addTab(self.tab_5, "")
        self.tab_6 = QWidget()
        self.tab_6.setObjectName(u"tab_6")
        self.horizontalLayout_58 = QHBoxLayout(self.tab_6)
        self.horizontalLayout_58.setObjectName(u"horizontalLayout_58")
        self.horizontalLayout_57 = QHBoxLayout()
        self.horizontalLayout_57.setObjectName(u"horizontalLayout_57")
        self.label_2 = QLabel(self.tab_6)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(411, 331))
        self.label_2.setMaximumSize(QSize(411, 331))
        self.label_2.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/extra_probe_depth.png);\n"
"}")
        self.label_2.setScaledContents(True)
        self.label_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_2.setWordWrap(True)
        self.label_2.setIndent(0)

        self.horizontalLayout_57.addWidget(self.label_2)


        self.horizontalLayout_58.addLayout(self.horizontalLayout_57)

        self.tabWidget_2.addTab(self.tab_6, "")
        self.tab_8 = QWidget()
        self.tab_8.setObjectName(u"tab_8")
        self.horizontalLayout_56 = QHBoxLayout(self.tab_8)
        self.horizontalLayout_56.setObjectName(u"horizontalLayout_56")
        self.horizontalLayout_55 = QHBoxLayout()
        self.horizontalLayout_55.setObjectName(u"horizontalLayout_55")
        self.label_3 = QLabel(self.tab_8)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setMinimumSize(QSize(785, 407))
        self.label_3.setMaximumSize(QSize(785, 407))
        self.label_3.setAutoFillBackground(False)
        self.label_3.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/max_distance.png);\n"
"}")
        self.label_3.setFrameShape(QFrame.Shape.NoFrame)
        self.label_3.setFrameShadow(QFrame.Shadow.Plain)
        self.label_3.setLineWidth(0)
        self.label_3.setMidLineWidth(0)
        self.label_3.setScaledContents(True)
        self.label_3.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_3.setIndent(0)

        self.horizontalLayout_55.addWidget(self.label_3)


        self.horizontalLayout_56.addLayout(self.horizontalLayout_55)

        self.tabWidget_2.addTab(self.tab_8, "")
        self.tab_9 = QWidget()
        self.tab_9.setObjectName(u"tab_9")
        self.horizontalLayout_54 = QHBoxLayout(self.tab_9)
        self.horizontalLayout_54.setObjectName(u"horizontalLayout_54")
        self.horizontalLayout_53 = QHBoxLayout()
        self.horizontalLayout_53.setObjectName(u"horizontalLayout_53")
        self.label_4 = QLabel(self.tab_9)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setMinimumSize(QSize(791, 391))
        self.label_4.setMaximumSize(QSize(791, 391))
        self.label_4.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(46, 54, 56);\n"
"    border-width: 3px;\n"
"    border-radius: 10px;\n"
"    background: rgb(245, 240, 255);\n"
"	image: url(:/images/clearance.png);\n"
"}")
        self.label_4.setScaledContents(True)
        self.label_4.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_4.setIndent(0)

        self.horizontalLayout_53.addWidget(self.label_4)


        self.horizontalLayout_54.addLayout(self.horizontalLayout_53)

        self.tabWidget_2.addTab(self.tab_9, "")
        self.tab_11 = QWidget()
        self.tab_11.setObjectName(u"tab_11")
        self.tabWidget_2.addTab(self.tab_11, "")
        self.tab_12 = QWidget()
        self.tab_12.setObjectName(u"tab_12")
        self.tabWidget_2.addTab(self.tab_12, "")

        self.verticalLayout_3.addWidget(self.tabWidget_2)


        self.horizontalLayout_52.addLayout(self.verticalLayout_3)

        self.probe_tab_widget.addTab(self.probe_help_tab, "")

        self.horizontalLayout_2.addWidget(self.probe_tab_widget)


        self.horizontalLayout_100.addWidget(self.frame_23)


        self.horizontalLayout_70.addLayout(self.horizontalLayout_100)

        self.tabWidget.addTab(self.probing_tab, "")
        self.settings_tab = QWidget()
        self.settings_tab.setObjectName(u"settings_tab")
        self.settings_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout_6 = QHBoxLayout(self.settings_tab)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(20, 20, 20, 20)
        self.widget_38 = QWidget(self.settings_tab)
        self.widget_38.setObjectName(u"widget_38")
        sizePolicy4.setHeightForWidth(self.widget_38.sizePolicy().hasHeightForWidth())
        self.widget_38.setSizePolicy(sizePolicy4)

        self.horizontalLayout_6.addWidget(self.widget_38)

        self.widget_24 = QWidget(self.settings_tab)
        self.widget_24.setObjectName(u"widget_24")
        sizePolicy8.setHeightForWidth(self.widget_24.sizePolicy().hasHeightForWidth())
        self.widget_24.setSizePolicy(sizePolicy8)
        self.widget_24.setMaximumSize(QSize(520, 16777215))
        self.verticalLayout_27 = QVBoxLayout(self.widget_24)
        self.verticalLayout_27.setSpacing(12)
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.verticalLayout_27.setContentsMargins(0, 0, 0, 0)
        self.frame_24 = QFrame(self.widget_24)
        self.frame_24.setObjectName(u"frame_24")
        sizePolicy3.setHeightForWidth(self.frame_24.sizePolicy().hasHeightForWidth())
        self.frame_24.setSizePolicy(sizePolicy3)
        self.frame_24.setMinimumSize(QSize(500, 100))
        self.frame_24.setMaximumSize(QSize(500, 100))
        self.frame_24.setStyleSheet(u"")
        self.verticalLayout_23 = QVBoxLayout(self.frame_24)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.work_column_header_11 = QLabel(self.frame_24)
        self.work_column_header_11.setObjectName(u"work_column_header_11")
        self.work_column_header_11.setEnabled(False)
        sizePolicy6.setHeightForWidth(self.work_column_header_11.sizePolicy().hasHeightForWidth())
        self.work_column_header_11.setSizePolicy(sizePolicy6)
        self.work_column_header_11.setMinimumSize(QSize(100, 25))
        self.work_column_header_11.setMaximumSize(QSize(16777215, 25))
        self.work_column_header_11.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.work_column_header_11.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_23.addWidget(self.work_column_header_11)

        self.widget_82 = QWidget(self.frame_24)
        self.widget_82.setObjectName(u"widget_82")
        sizePolicy8.setHeightForWidth(self.widget_82.sizePolicy().hasHeightForWidth())
        self.widget_82.setSizePolicy(sizePolicy8)
        self.horizontalLayout_167 = QHBoxLayout(self.widget_82)
        self.horizontalLayout_167.setSpacing(12)
        self.horizontalLayout_167.setObjectName(u"horizontalLayout_167")
        self.horizontalLayout_167.setContentsMargins(3, 3, 3, 3)
        self.spindle_calculated_rpm = VCPSettingsPushButton(self.widget_82)
        self.spindlerpmsourcebtnGroup = QButtonGroup(Form)
        self.spindlerpmsourcebtnGroup.setObjectName(u"spindlerpmsourcebtnGroup")
        self.spindlerpmsourcebtnGroup.addButton(self.spindle_calculated_rpm)
        self.spindle_calculated_rpm.setObjectName(u"spindle_calculated_rpm")
        self.spindle_calculated_rpm.setEnabled(True)
        sizePolicy.setHeightForWidth(self.spindle_calculated_rpm.sizePolicy().hasHeightForWidth())
        self.spindle_calculated_rpm.setSizePolicy(sizePolicy)
        self.spindle_calculated_rpm.setChecked(False)
        self.spindle_calculated_rpm.setProperty(u"page", 0)

        self.horizontalLayout_167.addWidget(self.spindle_calculated_rpm)

        self.spindle_encodr_rpm = VCPSettingsPushButton(self.widget_82)
        self.spindlerpmsourcebtnGroup.addButton(self.spindle_encodr_rpm)
        self.spindle_encodr_rpm.setObjectName(u"spindle_encodr_rpm")
        self.spindle_encodr_rpm.setEnabled(True)
        sizePolicy.setHeightForWidth(self.spindle_encodr_rpm.sizePolicy().hasHeightForWidth())
        self.spindle_encodr_rpm.setSizePolicy(sizePolicy)
        self.spindle_encodr_rpm.setChecked(True)
        self.spindle_encodr_rpm.setProperty(u"page", 1)

        self.horizontalLayout_167.addWidget(self.spindle_encodr_rpm)


        self.verticalLayout_23.addWidget(self.widget_82)


        self.verticalLayout_27.addWidget(self.frame_24)

        self.frame_26 = QFrame(self.widget_24)
        self.frame_26.setObjectName(u"frame_26")
        sizePolicy3.setHeightForWidth(self.frame_26.sizePolicy().hasHeightForWidth())
        self.frame_26.setSizePolicy(sizePolicy3)
        self.frame_26.setMinimumSize(QSize(500, 0))
        self.frame_26.setMaximumSize(QSize(500, 16777215))
        self.frame_26.setStyleSheet(u"")
        self.verticalLayout_54 = QVBoxLayout(self.frame_26)
        self.verticalLayout_54.setObjectName(u"verticalLayout_54")
        self.startup_settings_label = QLabel(self.frame_26)
        self.startup_settings_label.setObjectName(u"startup_settings_label")
        self.startup_settings_label.setEnabled(True)
        sizePolicy6.setHeightForWidth(self.startup_settings_label.sizePolicy().hasHeightForWidth())
        self.startup_settings_label.setSizePolicy(sizePolicy6)
        self.startup_settings_label.setMinimumSize(QSize(100, 25))
        self.startup_settings_label.setMaximumSize(QSize(16777215, 25))
        self.startup_settings_label.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.startup_settings_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_54.addWidget(self.startup_settings_label)

        self.widget_3 = QWidget(self.frame_26)
        self.widget_3.setObjectName(u"widget_3")
        self.horizontalLayout_12 = QHBoxLayout(self.widget_3)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.startup_tab_label = QLabel(self.widget_3)
        self.startup_tab_label.setObjectName(u"startup_tab_label")
        self.startup_tab_label.setEnabled(True)
        sizePolicy6.setHeightForWidth(self.startup_tab_label.sizePolicy().hasHeightForWidth())
        self.startup_tab_label.setSizePolicy(sizePolicy6)
        self.startup_tab_label.setMinimumSize(QSize(165, 25))
        self.startup_tab_label.setMaximumSize(QSize(165, 25))
        self.startup_tab_label.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.startup_tab_label.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_12.addWidget(self.startup_tab_label)

        self.startup_tab_combobox = QComboBox(self.widget_3)
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.addItem("")
        self.startup_tab_combobox.setObjectName(u"startup_tab_combobox")
        sizePolicy1.setHeightForWidth(self.startup_tab_combobox.sizePolicy().hasHeightForWidth())
        self.startup_tab_combobox.setSizePolicy(sizePolicy1)
        self.startup_tab_combobox.setMinimumSize(QSize(200, 40))
        self.startup_tab_combobox.setMaximumSize(QSize(16777215, 40))

        self.horizontalLayout_12.addWidget(self.startup_tab_combobox)


        self.verticalLayout_54.addWidget(self.widget_3)

        self.widget_11 = QWidget(self.frame_26)
        self.widget_11.setObjectName(u"widget_11")
        self.horizontalLayout_50 = QHBoxLayout(self.widget_11)
        self.horizontalLayout_50.setObjectName(u"horizontalLayout_50")
        self.startup_tab_label_2 = QLabel(self.widget_11)
        self.startup_tab_label_2.setObjectName(u"startup_tab_label_2")
        self.startup_tab_label_2.setEnabled(True)
        sizePolicy6.setHeightForWidth(self.startup_tab_label_2.sizePolicy().hasHeightForWidth())
        self.startup_tab_label_2.setSizePolicy(sizePolicy6)
        self.startup_tab_label_2.setMinimumSize(QSize(165, 25))
        self.startup_tab_label_2.setMaximumSize(QSize(165, 25))
        self.startup_tab_label_2.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.startup_tab_label_2.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_50.addWidget(self.startup_tab_label_2)

        self.startup_sb_tab_combobox = QComboBox(self.widget_11)
        self.startup_sb_tab_combobox.addItem("")
        self.startup_sb_tab_combobox.addItem("")
        self.startup_sb_tab_combobox.addItem("")
        self.startup_sb_tab_combobox.addItem("")
        self.startup_sb_tab_combobox.setObjectName(u"startup_sb_tab_combobox")
        sizePolicy1.setHeightForWidth(self.startup_sb_tab_combobox.sizePolicy().hasHeightForWidth())
        self.startup_sb_tab_combobox.setSizePolicy(sizePolicy1)
        self.startup_sb_tab_combobox.setMinimumSize(QSize(200, 40))

        self.horizontalLayout_50.addWidget(self.startup_sb_tab_combobox)


        self.verticalLayout_54.addWidget(self.widget_11)


        self.verticalLayout_27.addWidget(self.frame_26)

        self.widget_28 = QWidget(self.widget_24)
        self.widget_28.setObjectName(u"widget_28")
        sizePolicy5.setHeightForWidth(self.widget_28.sizePolicy().hasHeightForWidth())
        self.widget_28.setSizePolicy(sizePolicy5)

        self.verticalLayout_27.addWidget(self.widget_28)


        self.horizontalLayout_6.addWidget(self.widget_24)

        self.tabWidget.addTab(self.settings_tab, "")
        self.status_tab = QWidget()
        self.status_tab.setObjectName(u"status_tab")
        self.status_tab.setMaximumSize(QSize(16777215, 650))
        self.horizontalLayout_15 = QHBoxLayout(self.status_tab)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.horizontalLayout_15.setContentsMargins(20, 20, 20, 20)
        self.widget_25 = QWidget(self.status_tab)
        self.widget_25.setObjectName(u"widget_25")
        self.widget_25.setStyleSheet(u"")
        self.horizontalLayout_13 = QHBoxLayout(self.widget_25)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.horizontalLayout_13.setContentsMargins(-1, 0, -1, 0)
        self.label_5 = QLabel(self.widget_25)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setTextFormat(Qt.TextFormat.AutoText)
        self.label_5.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.label_5.setWordWrap(True)
        self.label_5.setOpenExternalLinks(True)
        self.label_5.setTextInteractionFlags(Qt.TextInteractionFlag.LinksAccessibleByKeyboard|Qt.TextInteractionFlag.LinksAccessibleByMouse|Qt.TextInteractionFlag.TextBrowserInteraction|Qt.TextInteractionFlag.TextSelectableByKeyboard|Qt.TextInteractionFlag.TextSelectableByMouse)

        self.horizontalLayout_13.addWidget(self.label_5)


        self.horizontalLayout_15.addWidget(self.widget_25)

        self.widget_61 = QWidget(self.status_tab)
        self.widget_61.setObjectName(u"widget_61")
        sizePolicy7.setHeightForWidth(self.widget_61.sizePolicy().hasHeightForWidth())
        self.widget_61.setSizePolicy(sizePolicy7)
        self.widget_61.setMinimumSize(QSize(450, 0))
        self.verticalLayout_45 = QVBoxLayout(self.widget_61)
        self.verticalLayout_45.setSpacing(15)
        self.verticalLayout_45.setObjectName(u"verticalLayout_45")
        self.verticalLayout_45.setContentsMargins(0, 0, 0, 0)
        self.frame_39 = QFrame(self.widget_61)
        self.frame_39.setObjectName(u"frame_39")
        sizePolicy.setHeightForWidth(self.frame_39.sizePolicy().hasHeightForWidth())
        self.frame_39.setSizePolicy(sizePolicy)
        self.frame_39.setStyleSheet(u".QFrame{\n"
"    background-color: rgb(51, 57, 59);\n"
"}")
        self.verticalLayout_48 = QVBoxLayout(self.frame_39)
        self.verticalLayout_48.setSpacing(6)
        self.verticalLayout_48.setObjectName(u"verticalLayout_48")
        self.verticalLayout_48.setContentsMargins(-1, 0, -1, 3)
        self.notificationwidget = NotificationWidget(self.frame_39)
        self.notificationwidget.setObjectName(u"notificationwidget")
        self.notificationwidget.setStyleSheet(u"QLabel {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    color: white;\n"
"    font-size: 16pt;\n"
"}\n"
"")

        self.verticalLayout_48.addWidget(self.notificationwidget)


        self.verticalLayout_45.addWidget(self.frame_39)


        self.horizontalLayout_15.addWidget(self.widget_61)

        self.tabWidget.addTab(self.status_tab, "")

        self.verticalLayout_30.addWidget(self.tabWidget)


        self.horizontalLayout_101.addLayout(self.verticalLayout_30)

        self.side_bar = QWidget(self.centralwidget)
        self.side_bar.setObjectName(u"side_bar")
        sizePolicy7.setHeightForWidth(self.side_bar.sizePolicy().hasHeightForWidth())
        self.side_bar.setSizePolicy(sizePolicy7)
        self.side_bar.setMinimumSize(QSize(253, 0))
        self.side_bar.setMaximumSize(QSize(253, 16777215))
        self.side_bar.setStyleSheet(u"")
        self.verticalLayout_12 = QVBoxLayout(self.side_bar)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.widget_83 = QWidget(self.side_bar)
        self.widget_83.setObjectName(u"widget_83")
        self.widget_83.setStyleSheet(u".QWidget {\n"
"    Background: rgb(146, 150, 149);\n"
"}")
        self.horizontalLayout_36 = QHBoxLayout(self.widget_83)
        self.horizontalLayout_36.setSpacing(0)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.horizontalLayout_36.setContentsMargins(0, 0, 0, 6)
        self.side_bar_2 = QWidget(self.widget_83)
        self.side_bar_2.setObjectName(u"side_bar_2")
        self.verticalLayout_9 = QVBoxLayout(self.side_bar_2)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(4, 1, 3, 2)
        self.widget_84 = QWidget(self.side_bar_2)
        self.widget_84.setObjectName(u"widget_84")
        self.verticalLayout_19 = QVBoxLayout(self.widget_84)
        self.verticalLayout_19.setSpacing(0)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(0, 0, 0, 0)
        self.label_239 = QLabel(self.widget_84)
        self.label_239.setObjectName(u"label_239")
        self.label_239.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.label_239.sizePolicy().hasHeightForWidth())
        self.label_239.setSizePolicy(sizePolicy3)
        self.label_239.setMinimumSize(QSize(201, 0))
        self.label_239.setMaximumSize(QSize(201, 20))
        self.label_239.setStyleSheet(u"QLabel{\n"
"    color: white;\n"
"    font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.label_239.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_19.addWidget(self.label_239)

        self.frame_36 = QFrame(self.widget_84)
        self.frame_36.setObjectName(u"frame_36")
        sizePolicy7.setHeightForWidth(self.frame_36.sizePolicy().hasHeightForWidth())
        self.frame_36.setSizePolicy(sizePolicy7)
        self.frame_36.setMinimumSize(QSize(201, 0))
        self.frame_36.setMaximumSize(QSize(201, 16777215))
        self.frame_36.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_36.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_34 = QVBoxLayout(self.frame_36)
        self.verticalLayout_34.setSpacing(12)
        self.verticalLayout_34.setObjectName(u"verticalLayout_34")
        self.verticalLayout_34.setContentsMargins(6, 12, 6, 12)
        self.sidebar_widget = QStackedWidget(self.frame_36)
        self.sidebar_widget.setObjectName(u"sidebar_widget")
        self.sidebar_widget.setStyleSheet(u".QWidget{\n"
"    background: rgb(46, 52, 54);\n"
"}")
        self.sb_page_1 = QWidget()
        self.sb_page_1.setObjectName(u"sb_page_1")
        self.sb_page_1.setStyleSheet(u"")
        self.verticalLayout_65 = QVBoxLayout(self.sb_page_1)
        self.verticalLayout_65.setSpacing(6)
        self.verticalLayout_65.setObjectName(u"verticalLayout_65")
        self.verticalLayout_65.setContentsMargins(0, 9, 0, -1)
        self.jog_button_stacked_widget = QStackedWidget(self.sb_page_1)
        self.jog_button_stacked_widget.setObjectName(u"jog_button_stacked_widget")
        self.xz_front = QWidget()
        self.xz_front.setObjectName(u"xz_front")
        self.verticalLayout = QVBoxLayout(self.xz_front)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.xz_front_post_grid = QGridLayout()
        self.xz_front_post_grid.setObjectName(u"xz_front_post_grid")
        self.xz_front_post_grid.setHorizontalSpacing(0)
        self.xz_front_post_grid.setVerticalSpacing(12)
        self.x_plus_jogbutton = ActionButton(self.xz_front)
        self.x_plus_jogbutton.setObjectName(u"x_plus_jogbutton")
        sizePolicy3.setHeightForWidth(self.x_plus_jogbutton.sizePolicy().hasHeightForWidth())
        self.x_plus_jogbutton.setSizePolicy(sizePolicy3)
        self.x_plus_jogbutton.setMinimumSize(QSize(56, 0))
        self.x_plus_jogbutton.setMaximumSize(QSize(56, 56))
        icon29 = QIcon()
        icon29.addFile(u":/images/x_plus_jog_button_lathe_front.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.x_plus_jogbutton.setIcon(icon29)
        self.x_plus_jogbutton.setIconSize(QSize(48, 48))

        self.xz_front_post_grid.addWidget(self.x_plus_jogbutton, 2, 1, 1, 1)

        self.x_minus_jogbutton = ActionButton(self.xz_front)
        self.x_minus_jogbutton.setObjectName(u"x_minus_jogbutton")
        sizePolicy3.setHeightForWidth(self.x_minus_jogbutton.sizePolicy().hasHeightForWidth())
        self.x_minus_jogbutton.setSizePolicy(sizePolicy3)
        self.x_minus_jogbutton.setMinimumSize(QSize(56, 0))
        self.x_minus_jogbutton.setMaximumSize(QSize(56, 56))
        icon30 = QIcon()
        icon30.addFile(u":/images/x_minus_jog_button_lathe_front.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.x_minus_jogbutton.setIcon(icon30)
        self.x_minus_jogbutton.setIconSize(QSize(48, 48))

        self.xz_front_post_grid.addWidget(self.x_minus_jogbutton, 0, 1, 1, 1)

        self.z_plus_jogbutton = ActionButton(self.xz_front)
        self.z_plus_jogbutton.setObjectName(u"z_plus_jogbutton")
        self.z_plus_jogbutton.setMinimumSize(QSize(56, 0))
        self.z_plus_jogbutton.setMaximumSize(QSize(56, 56))
        icon31 = QIcon()
        icon31.addFile(u":/images/z_plus_jog_button_lathe.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.z_plus_jogbutton.setIcon(icon31)
        self.z_plus_jogbutton.setIconSize(QSize(48, 48))

        self.xz_front_post_grid.addWidget(self.z_plus_jogbutton, 1, 2, 1, 1)

        self.z_minus_jogbutton = ActionButton(self.xz_front)
        self.z_minus_jogbutton.setObjectName(u"z_minus_jogbutton")
        self.z_minus_jogbutton.setMinimumSize(QSize(56, 0))
        self.z_minus_jogbutton.setMaximumSize(QSize(56, 56))
        icon32 = QIcon()
        icon32.addFile(u":/images/z_minus_jog_button_lathe.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.z_minus_jogbutton.setIcon(icon32)
        self.z_minus_jogbutton.setIconSize(QSize(48, 48))

        self.xz_front_post_grid.addWidget(self.z_minus_jogbutton, 1, 0, 1, 1)


        self.verticalLayout.addLayout(self.xz_front_post_grid)

        self.jog_button_stacked_widget.addWidget(self.xz_front)
        self.xz_back = QWidget()
        self.xz_back.setObjectName(u"xz_back")
        self.verticalLayout_2 = QVBoxLayout(self.xz_back)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.xz_back_post_grid = QGridLayout()
        self.xz_back_post_grid.setObjectName(u"xz_back_post_grid")
        self.xz_back_post_grid.setHorizontalSpacing(0)
        self.xz_back_post_grid.setVerticalSpacing(12)
        self.z_plus_jogbutton_2 = ActionButton(self.xz_back)
        self.z_plus_jogbutton_2.setObjectName(u"z_plus_jogbutton_2")
        self.z_plus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.z_plus_jogbutton_2.setMaximumSize(QSize(56, 56))
        self.z_plus_jogbutton_2.setIcon(icon31)
        self.z_plus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xz_back_post_grid.addWidget(self.z_plus_jogbutton_2, 1, 2, 1, 1)

        self.z_minus_jogbutton_2 = ActionButton(self.xz_back)
        self.z_minus_jogbutton_2.setObjectName(u"z_minus_jogbutton_2")
        self.z_minus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.z_minus_jogbutton_2.setMaximumSize(QSize(56, 56))
        self.z_minus_jogbutton_2.setIcon(icon32)
        self.z_minus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xz_back_post_grid.addWidget(self.z_minus_jogbutton_2, 1, 0, 1, 1)

        self.x_plus_jogbutton_2 = ActionButton(self.xz_back)
        self.x_plus_jogbutton_2.setObjectName(u"x_plus_jogbutton_2")
        sizePolicy3.setHeightForWidth(self.x_plus_jogbutton_2.sizePolicy().hasHeightForWidth())
        self.x_plus_jogbutton_2.setSizePolicy(sizePolicy3)
        self.x_plus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.x_plus_jogbutton_2.setMaximumSize(QSize(56, 56))
        icon33 = QIcon()
        icon33.addFile(u":/images/x_plus_jog_button_lathe.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.x_plus_jogbutton_2.setIcon(icon33)
        self.x_plus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xz_back_post_grid.addWidget(self.x_plus_jogbutton_2, 0, 1, 1, 1)

        self.x_minus_jogbutton_2 = ActionButton(self.xz_back)
        self.x_minus_jogbutton_2.setObjectName(u"x_minus_jogbutton_2")
        sizePolicy3.setHeightForWidth(self.x_minus_jogbutton_2.sizePolicy().hasHeightForWidth())
        self.x_minus_jogbutton_2.setSizePolicy(sizePolicy3)
        self.x_minus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.x_minus_jogbutton_2.setMaximumSize(QSize(56, 56))
        icon34 = QIcon()
        icon34.addFile(u":/images/x_minus_jog_button_lathe.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.x_minus_jogbutton_2.setIcon(icon34)
        self.x_minus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xz_back_post_grid.addWidget(self.x_minus_jogbutton_2, 2, 1, 1, 1)


        self.verticalLayout_2.addLayout(self.xz_back_post_grid)

        self.jog_button_stacked_widget.addWidget(self.xz_back)
        self.xzc_front = QWidget()
        self.xzc_front.setObjectName(u"xzc_front")
        self.verticalLayout_5 = QVBoxLayout(self.xzc_front)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.xzc_front_post_grid = QGridLayout()
        self.xzc_front_post_grid.setObjectName(u"xzc_front_post_grid")
        self.xzc_front_post_grid.setHorizontalSpacing(6)
        self.xzc_front_post_grid.setVerticalSpacing(12)
        self.c_minus_jogbutton = ActionButton(self.xzc_front)
        self.c_minus_jogbutton.setObjectName(u"c_minus_jogbutton")
        sizePolicy3.setHeightForWidth(self.c_minus_jogbutton.sizePolicy().hasHeightForWidth())
        self.c_minus_jogbutton.setSizePolicy(sizePolicy3)
        self.c_minus_jogbutton.setMinimumSize(QSize(56, 0))
        self.c_minus_jogbutton.setMaximumSize(QSize(56, 56))
        icon35 = QIcon()
        icon35.addFile(u":/images/c_minus_jog_button_down.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.c_minus_jogbutton.setIcon(icon35)
        self.c_minus_jogbutton.setIconSize(QSize(48, 48))

        self.xzc_front_post_grid.addWidget(self.c_minus_jogbutton, 2, 0, 1, 1)

        self.z_minus_jogbutton_3 = ActionButton(self.xzc_front)
        self.z_minus_jogbutton_3.setObjectName(u"z_minus_jogbutton_3")
        self.z_minus_jogbutton_3.setMinimumSize(QSize(56, 0))
        self.z_minus_jogbutton_3.setMaximumSize(QSize(56, 56))
        self.z_minus_jogbutton_3.setIcon(icon32)
        self.z_minus_jogbutton_3.setIconSize(QSize(48, 48))

        self.xzc_front_post_grid.addWidget(self.z_minus_jogbutton_3, 1, 0, 1, 1)

        self.c_plus_jogbutton = ActionButton(self.xzc_front)
        self.c_plus_jogbutton.setObjectName(u"c_plus_jogbutton")
        sizePolicy3.setHeightForWidth(self.c_plus_jogbutton.sizePolicy().hasHeightForWidth())
        self.c_plus_jogbutton.setSizePolicy(sizePolicy3)
        self.c_plus_jogbutton.setMinimumSize(QSize(56, 0))
        self.c_plus_jogbutton.setMaximumSize(QSize(56, 56))
        icon36 = QIcon()
        icon36.addFile(u":/images/c_plus_jog_button_up.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.c_plus_jogbutton.setIcon(icon36)
        self.c_plus_jogbutton.setIconSize(QSize(48, 48))

        self.xzc_front_post_grid.addWidget(self.c_plus_jogbutton, 0, 0, 1, 1)

        self.z_plus_jogbutton_3 = ActionButton(self.xzc_front)
        self.z_plus_jogbutton_3.setObjectName(u"z_plus_jogbutton_3")
        self.z_plus_jogbutton_3.setMinimumSize(QSize(56, 0))
        self.z_plus_jogbutton_3.setMaximumSize(QSize(56, 56))
        self.z_plus_jogbutton_3.setIcon(icon31)
        self.z_plus_jogbutton_3.setIconSize(QSize(48, 48))

        self.xzc_front_post_grid.addWidget(self.z_plus_jogbutton_3, 1, 2, 1, 1)

        self.x_minus_jogbutton_3 = ActionButton(self.xzc_front)
        self.x_minus_jogbutton_3.setObjectName(u"x_minus_jogbutton_3")
        sizePolicy3.setHeightForWidth(self.x_minus_jogbutton_3.sizePolicy().hasHeightForWidth())
        self.x_minus_jogbutton_3.setSizePolicy(sizePolicy3)
        self.x_minus_jogbutton_3.setMinimumSize(QSize(56, 0))
        self.x_minus_jogbutton_3.setMaximumSize(QSize(56, 56))
        self.x_minus_jogbutton_3.setIcon(icon30)
        self.x_minus_jogbutton_3.setIconSize(QSize(48, 48))

        self.xzc_front_post_grid.addWidget(self.x_minus_jogbutton_3, 0, 1, 1, 1)

        self.x_plus_jogbutton_3 = ActionButton(self.xzc_front)
        self.x_plus_jogbutton_3.setObjectName(u"x_plus_jogbutton_3")
        sizePolicy3.setHeightForWidth(self.x_plus_jogbutton_3.sizePolicy().hasHeightForWidth())
        self.x_plus_jogbutton_3.setSizePolicy(sizePolicy3)
        self.x_plus_jogbutton_3.setMinimumSize(QSize(56, 0))
        self.x_plus_jogbutton_3.setMaximumSize(QSize(56, 56))
        self.x_plus_jogbutton_3.setIcon(icon29)
        self.x_plus_jogbutton_3.setIconSize(QSize(48, 48))

        self.xzc_front_post_grid.addWidget(self.x_plus_jogbutton_3, 2, 1, 1, 1)


        self.verticalLayout_5.addLayout(self.xzc_front_post_grid)

        self.jog_button_stacked_widget.addWidget(self.xzc_front)
        self.xzc_back = QWidget()
        self.xzc_back.setObjectName(u"xzc_back")
        self.verticalLayout_7 = QVBoxLayout(self.xzc_back)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.xzc_back_post_grid = QGridLayout()
        self.xzc_back_post_grid.setObjectName(u"xzc_back_post_grid")
        self.xzc_back_post_grid.setHorizontalSpacing(6)
        self.xzc_back_post_grid.setVerticalSpacing(12)
        self.z_plus_jogbutton_4 = ActionButton(self.xzc_back)
        self.z_plus_jogbutton_4.setObjectName(u"z_plus_jogbutton_4")
        self.z_plus_jogbutton_4.setMinimumSize(QSize(56, 0))
        self.z_plus_jogbutton_4.setMaximumSize(QSize(56, 56))
        self.z_plus_jogbutton_4.setIcon(icon31)
        self.z_plus_jogbutton_4.setIconSize(QSize(48, 48))

        self.xzc_back_post_grid.addWidget(self.z_plus_jogbutton_4, 1, 2, 1, 1)

        self.x_plus_jogbutton_4 = ActionButton(self.xzc_back)
        self.x_plus_jogbutton_4.setObjectName(u"x_plus_jogbutton_4")
        sizePolicy3.setHeightForWidth(self.x_plus_jogbutton_4.sizePolicy().hasHeightForWidth())
        self.x_plus_jogbutton_4.setSizePolicy(sizePolicy3)
        self.x_plus_jogbutton_4.setMinimumSize(QSize(56, 0))
        self.x_plus_jogbutton_4.setMaximumSize(QSize(56, 56))
        self.x_plus_jogbutton_4.setIcon(icon33)
        self.x_plus_jogbutton_4.setIconSize(QSize(48, 48))

        self.xzc_back_post_grid.addWidget(self.x_plus_jogbutton_4, 0, 1, 1, 1)

        self.z_minus_jogbutton_4 = ActionButton(self.xzc_back)
        self.z_minus_jogbutton_4.setObjectName(u"z_minus_jogbutton_4")
        self.z_minus_jogbutton_4.setMinimumSize(QSize(56, 0))
        self.z_minus_jogbutton_4.setMaximumSize(QSize(56, 56))
        self.z_minus_jogbutton_4.setIcon(icon32)
        self.z_minus_jogbutton_4.setIconSize(QSize(48, 48))

        self.xzc_back_post_grid.addWidget(self.z_minus_jogbutton_4, 1, 0, 1, 1)

        self.x_minus_jogbutton_4 = ActionButton(self.xzc_back)
        self.x_minus_jogbutton_4.setObjectName(u"x_minus_jogbutton_4")
        sizePolicy3.setHeightForWidth(self.x_minus_jogbutton_4.sizePolicy().hasHeightForWidth())
        self.x_minus_jogbutton_4.setSizePolicy(sizePolicy3)
        self.x_minus_jogbutton_4.setMinimumSize(QSize(56, 0))
        self.x_minus_jogbutton_4.setMaximumSize(QSize(56, 56))
        self.x_minus_jogbutton_4.setIcon(icon34)
        self.x_minus_jogbutton_4.setIconSize(QSize(48, 48))

        self.xzc_back_post_grid.addWidget(self.x_minus_jogbutton_4, 2, 1, 1, 1)

        self.c_plus_jogbutton_2 = ActionButton(self.xzc_back)
        self.c_plus_jogbutton_2.setObjectName(u"c_plus_jogbutton_2")
        sizePolicy3.setHeightForWidth(self.c_plus_jogbutton_2.sizePolicy().hasHeightForWidth())
        self.c_plus_jogbutton_2.setSizePolicy(sizePolicy3)
        self.c_plus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.c_plus_jogbutton_2.setMaximumSize(QSize(56, 56))
        self.c_plus_jogbutton_2.setIcon(icon36)
        self.c_plus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xzc_back_post_grid.addWidget(self.c_plus_jogbutton_2, 0, 0, 1, 1)

        self.c_minus_jogbutton_2 = ActionButton(self.xzc_back)
        self.c_minus_jogbutton_2.setObjectName(u"c_minus_jogbutton_2")
        sizePolicy3.setHeightForWidth(self.c_minus_jogbutton_2.sizePolicy().hasHeightForWidth())
        self.c_minus_jogbutton_2.setSizePolicy(sizePolicy3)
        self.c_minus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.c_minus_jogbutton_2.setMaximumSize(QSize(56, 56))
        self.c_minus_jogbutton_2.setIcon(icon35)
        self.c_minus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xzc_back_post_grid.addWidget(self.c_minus_jogbutton_2, 2, 0, 1, 1)


        self.verticalLayout_7.addLayout(self.xzc_back_post_grid)

        self.jog_button_stacked_widget.addWidget(self.xzc_back)
        self.xyzc_front = QWidget()
        self.xyzc_front.setObjectName(u"xyzc_front")
        self.verticalLayout_17 = QVBoxLayout(self.xyzc_front)
        self.verticalLayout_17.setSpacing(0)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(0, 0, 0, 0)
        self.xyzc_front_post_grid = QGridLayout()
        self.xyzc_front_post_grid.setObjectName(u"xyzc_front_post_grid")
        self.xyzc_front_post_grid.setHorizontalSpacing(6)
        self.xyzc_front_post_grid.setVerticalSpacing(12)
        self.z_plus_jogbutton_5 = ActionButton(self.xyzc_front)
        self.z_plus_jogbutton_5.setObjectName(u"z_plus_jogbutton_5")
        self.z_plus_jogbutton_5.setMinimumSize(QSize(56, 0))
        self.z_plus_jogbutton_5.setMaximumSize(QSize(56, 56))
        self.z_plus_jogbutton_5.setIcon(icon31)
        self.z_plus_jogbutton_5.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.z_plus_jogbutton_5, 1, 2, 1, 1)

        self.z_minus_jogbutton_5 = ActionButton(self.xyzc_front)
        self.z_minus_jogbutton_5.setObjectName(u"z_minus_jogbutton_5")
        self.z_minus_jogbutton_5.setMinimumSize(QSize(56, 0))
        self.z_minus_jogbutton_5.setMaximumSize(QSize(56, 56))
        self.z_minus_jogbutton_5.setIcon(icon32)
        self.z_minus_jogbutton_5.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.z_minus_jogbutton_5, 1, 0, 1, 1)

        self.c_plus_jogbutton_3 = ActionButton(self.xyzc_front)
        self.c_plus_jogbutton_3.setObjectName(u"c_plus_jogbutton_3")
        sizePolicy3.setHeightForWidth(self.c_plus_jogbutton_3.sizePolicy().hasHeightForWidth())
        self.c_plus_jogbutton_3.setSizePolicy(sizePolicy3)
        self.c_plus_jogbutton_3.setMinimumSize(QSize(56, 0))
        self.c_plus_jogbutton_3.setMaximumSize(QSize(56, 56))
        self.c_plus_jogbutton_3.setIcon(icon36)
        self.c_plus_jogbutton_3.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.c_plus_jogbutton_3, 0, 0, 1, 1)

        self.c_minus_jogbutton_3 = ActionButton(self.xyzc_front)
        self.c_minus_jogbutton_3.setObjectName(u"c_minus_jogbutton_3")
        sizePolicy3.setHeightForWidth(self.c_minus_jogbutton_3.sizePolicy().hasHeightForWidth())
        self.c_minus_jogbutton_3.setSizePolicy(sizePolicy3)
        self.c_minus_jogbutton_3.setMinimumSize(QSize(56, 0))
        self.c_minus_jogbutton_3.setMaximumSize(QSize(56, 56))
        self.c_minus_jogbutton_3.setIcon(icon35)
        self.c_minus_jogbutton_3.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.c_minus_jogbutton_3, 2, 0, 1, 1)

        self.y_minus_jogbutton = ActionButton(self.xyzc_front)
        self.y_minus_jogbutton.setObjectName(u"y_minus_jogbutton")
        sizePolicy3.setHeightForWidth(self.y_minus_jogbutton.sizePolicy().hasHeightForWidth())
        self.y_minus_jogbutton.setSizePolicy(sizePolicy3)
        self.y_minus_jogbutton.setMinimumSize(QSize(56, 0))
        self.y_minus_jogbutton.setMaximumSize(QSize(56, 56))
        icon37 = QIcon()
        icon37.addFile(u":/images/y_minus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.y_minus_jogbutton.setIcon(icon37)
        self.y_minus_jogbutton.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.y_minus_jogbutton, 2, 2, 1, 1)

        self.y_plus_jogbutton = ActionButton(self.xyzc_front)
        self.y_plus_jogbutton.setObjectName(u"y_plus_jogbutton")
        sizePolicy3.setHeightForWidth(self.y_plus_jogbutton.sizePolicy().hasHeightForWidth())
        self.y_plus_jogbutton.setSizePolicy(sizePolicy3)
        self.y_plus_jogbutton.setMinimumSize(QSize(56, 0))
        self.y_plus_jogbutton.setMaximumSize(QSize(56, 56))
        icon38 = QIcon()
        icon38.addFile(u":/images/y_plus_jog_button.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.y_plus_jogbutton.setIcon(icon38)
        self.y_plus_jogbutton.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.y_plus_jogbutton, 0, 2, 1, 1)

        self.x_minus_jogbutton_5 = ActionButton(self.xyzc_front)
        self.x_minus_jogbutton_5.setObjectName(u"x_minus_jogbutton_5")
        sizePolicy3.setHeightForWidth(self.x_minus_jogbutton_5.sizePolicy().hasHeightForWidth())
        self.x_minus_jogbutton_5.setSizePolicy(sizePolicy3)
        self.x_minus_jogbutton_5.setMinimumSize(QSize(56, 0))
        self.x_minus_jogbutton_5.setMaximumSize(QSize(56, 56))
        self.x_minus_jogbutton_5.setIcon(icon30)
        self.x_minus_jogbutton_5.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.x_minus_jogbutton_5, 0, 1, 1, 1)

        self.x_plus_jogbutton_5 = ActionButton(self.xyzc_front)
        self.x_plus_jogbutton_5.setObjectName(u"x_plus_jogbutton_5")
        sizePolicy3.setHeightForWidth(self.x_plus_jogbutton_5.sizePolicy().hasHeightForWidth())
        self.x_plus_jogbutton_5.setSizePolicy(sizePolicy3)
        self.x_plus_jogbutton_5.setMinimumSize(QSize(56, 0))
        self.x_plus_jogbutton_5.setMaximumSize(QSize(56, 56))
        self.x_plus_jogbutton_5.setIcon(icon29)
        self.x_plus_jogbutton_5.setIconSize(QSize(48, 48))

        self.xyzc_front_post_grid.addWidget(self.x_plus_jogbutton_5, 2, 1, 1, 1)


        self.verticalLayout_17.addLayout(self.xyzc_front_post_grid)

        self.jog_button_stacked_widget.addWidget(self.xyzc_front)
        self.xyzc_back = QWidget()
        self.xyzc_back.setObjectName(u"xyzc_back")
        self.verticalLayout_18 = QVBoxLayout(self.xyzc_back)
        self.verticalLayout_18.setSpacing(0)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setContentsMargins(0, 0, 0, 0)
        self.xyzc_back_post_grid = QGridLayout()
        self.xyzc_back_post_grid.setObjectName(u"xyzc_back_post_grid")
        self.xyzc_back_post_grid.setHorizontalSpacing(6)
        self.xyzc_back_post_grid.setVerticalSpacing(12)
        self.z_plus_jogbutton_6 = ActionButton(self.xyzc_back)
        self.z_plus_jogbutton_6.setObjectName(u"z_plus_jogbutton_6")
        self.z_plus_jogbutton_6.setMinimumSize(QSize(56, 0))
        self.z_plus_jogbutton_6.setMaximumSize(QSize(56, 56))
        self.z_plus_jogbutton_6.setIcon(icon31)
        self.z_plus_jogbutton_6.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.z_plus_jogbutton_6, 1, 2, 1, 1)

        self.x_plus_jogbutton_6 = ActionButton(self.xyzc_back)
        self.x_plus_jogbutton_6.setObjectName(u"x_plus_jogbutton_6")
        sizePolicy3.setHeightForWidth(self.x_plus_jogbutton_6.sizePolicy().hasHeightForWidth())
        self.x_plus_jogbutton_6.setSizePolicy(sizePolicy3)
        self.x_plus_jogbutton_6.setMinimumSize(QSize(56, 0))
        self.x_plus_jogbutton_6.setMaximumSize(QSize(56, 56))
        self.x_plus_jogbutton_6.setIcon(icon33)
        self.x_plus_jogbutton_6.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.x_plus_jogbutton_6, 0, 1, 1, 1)

        self.z_minus_jogbutton_6 = ActionButton(self.xyzc_back)
        self.z_minus_jogbutton_6.setObjectName(u"z_minus_jogbutton_6")
        self.z_minus_jogbutton_6.setMinimumSize(QSize(56, 0))
        self.z_minus_jogbutton_6.setMaximumSize(QSize(56, 56))
        self.z_minus_jogbutton_6.setIcon(icon32)
        self.z_minus_jogbutton_6.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.z_minus_jogbutton_6, 1, 0, 1, 1)

        self.x_minus_jogbutton_6 = ActionButton(self.xyzc_back)
        self.x_minus_jogbutton_6.setObjectName(u"x_minus_jogbutton_6")
        sizePolicy3.setHeightForWidth(self.x_minus_jogbutton_6.sizePolicy().hasHeightForWidth())
        self.x_minus_jogbutton_6.setSizePolicy(sizePolicy3)
        self.x_minus_jogbutton_6.setMinimumSize(QSize(56, 0))
        self.x_minus_jogbutton_6.setMaximumSize(QSize(56, 56))
        self.x_minus_jogbutton_6.setIcon(icon34)
        self.x_minus_jogbutton_6.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.x_minus_jogbutton_6, 2, 1, 1, 1)

        self.c_plus_jogbutton_4 = ActionButton(self.xyzc_back)
        self.c_plus_jogbutton_4.setObjectName(u"c_plus_jogbutton_4")
        sizePolicy3.setHeightForWidth(self.c_plus_jogbutton_4.sizePolicy().hasHeightForWidth())
        self.c_plus_jogbutton_4.setSizePolicy(sizePolicy3)
        self.c_plus_jogbutton_4.setMinimumSize(QSize(56, 0))
        self.c_plus_jogbutton_4.setMaximumSize(QSize(56, 56))
        self.c_plus_jogbutton_4.setIcon(icon36)
        self.c_plus_jogbutton_4.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.c_plus_jogbutton_4, 0, 0, 1, 1)

        self.c_minus_jogbutton_4 = ActionButton(self.xyzc_back)
        self.c_minus_jogbutton_4.setObjectName(u"c_minus_jogbutton_4")
        sizePolicy3.setHeightForWidth(self.c_minus_jogbutton_4.sizePolicy().hasHeightForWidth())
        self.c_minus_jogbutton_4.setSizePolicy(sizePolicy3)
        self.c_minus_jogbutton_4.setMinimumSize(QSize(56, 0))
        self.c_minus_jogbutton_4.setMaximumSize(QSize(56, 56))
        self.c_minus_jogbutton_4.setIcon(icon35)
        self.c_minus_jogbutton_4.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.c_minus_jogbutton_4, 2, 0, 1, 1)

        self.y_minus_jogbutton_2 = ActionButton(self.xyzc_back)
        self.y_minus_jogbutton_2.setObjectName(u"y_minus_jogbutton_2")
        sizePolicy3.setHeightForWidth(self.y_minus_jogbutton_2.sizePolicy().hasHeightForWidth())
        self.y_minus_jogbutton_2.setSizePolicy(sizePolicy3)
        self.y_minus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.y_minus_jogbutton_2.setMaximumSize(QSize(56, 56))
        self.y_minus_jogbutton_2.setIcon(icon37)
        self.y_minus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.y_minus_jogbutton_2, 2, 2, 1, 1)

        self.y_plus_jogbutton_2 = ActionButton(self.xyzc_back)
        self.y_plus_jogbutton_2.setObjectName(u"y_plus_jogbutton_2")
        sizePolicy3.setHeightForWidth(self.y_plus_jogbutton_2.sizePolicy().hasHeightForWidth())
        self.y_plus_jogbutton_2.setSizePolicy(sizePolicy3)
        self.y_plus_jogbutton_2.setMinimumSize(QSize(56, 0))
        self.y_plus_jogbutton_2.setMaximumSize(QSize(56, 56))
        self.y_plus_jogbutton_2.setIcon(icon38)
        self.y_plus_jogbutton_2.setIconSize(QSize(48, 48))

        self.xyzc_back_post_grid.addWidget(self.y_plus_jogbutton_2, 0, 2, 1, 1)


        self.verticalLayout_18.addLayout(self.xyzc_back_post_grid)

        self.jog_button_stacked_widget.addWidget(self.xyzc_back)

        self.verticalLayout_65.addWidget(self.jog_button_stacked_widget)

        self.widget_6 = QWidget(self.sb_page_1)
        self.widget_6.setObjectName(u"widget_6")
        self.horizontalLayout_4 = QHBoxLayout(self.widget_6)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 10, 0, 9)
        self.jogincrement = JogIncrementWidget(self.widget_6)
        self.jogincrement.setObjectName(u"jogincrement")
        sizePolicy7.setHeightForWidth(self.jogincrement.sizePolicy().hasHeightForWidth())
        self.jogincrement.setSizePolicy(sizePolicy7)
        self.jogincrement.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}\n"
"\n"
"")
        self.jogincrement.setProperty(u"diameter", 0)
        self.jogincrement.setProperty(u"alignment", Qt.AlignmentFlag.AlignCenter)
        self.jogincrement.setProperty(u"orientation", Qt.Orientation.Vertical)
        self.jogincrement.setProperty(u"layoutSpacing", 15)

        self.horizontalLayout_4.addWidget(self.jogincrement)

        self.widget_22 = QWidget(self.widget_6)
        self.widget_22.setObjectName(u"widget_22")
        sizePolicy7.setHeightForWidth(self.widget_22.sizePolicy().hasHeightForWidth())
        self.widget_22.setSizePolicy(sizePolicy7)
        self.widget_22.setMinimumSize(QSize(60, 0))
        self.widget_22.setMaximumSize(QSize(60, 16777215))
        self.widget_22.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.verticalLayout_22 = QVBoxLayout(self.widget_22)
        self.verticalLayout_22.setSpacing(12)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.verticalLayout_22.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.verticalLayout_22.setContentsMargins(5, 3, 9, 2)
        self.fr_override_dro = StatusLabel(self.widget_22)
        self.fr_override_dro.setObjectName(u"fr_override_dro")
        self.fr_override_dro.setMinimumSize(QSize(48, 0))
        self.fr_override_dro.setMaximumSize(QSize(48, 38))
        self.fr_override_dro.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_22.addWidget(self.fr_override_dro)

        self.linear_jog_slider = VCPSettingsSlider(self.widget_22)
        self.linear_jog_slider.setObjectName(u"linear_jog_slider")
        sizePolicy7.setHeightForWidth(self.linear_jog_slider.sizePolicy().hasHeightForWidth())
        self.linear_jog_slider.setSizePolicy(sizePolicy7)
        self.linear_jog_slider.setMinimumSize(QSize(50, 0))
        self.linear_jog_slider.setMaximumSize(QSize(50, 16777215))
        self.linear_jog_slider.setStyleSheet(u"")
        self.linear_jog_slider.setMaximum(100)
        self.linear_jog_slider.setSliderPosition(50)

        self.verticalLayout_22.addWidget(self.linear_jog_slider)


        self.horizontalLayout_4.addWidget(self.widget_22)


        self.verticalLayout_65.addWidget(self.widget_6)

        self.sidebar_widget.addWidget(self.sb_page_1)
        self.sb_page_2 = QWidget()
        self.sb_page_2.setObjectName(u"sb_page_2")
        self.sb_page_2.setStyleSheet(u"")
        self.verticalLayout_63 = QVBoxLayout(self.sb_page_2)
        self.verticalLayout_63.setObjectName(u"verticalLayout_63")
        self.verticalLayout_63.setContentsMargins(-1, 15, -1, -1)
        self.widget_5 = QWidget(self.sb_page_2)
        self.widget_5.setObjectName(u"widget_5")
        sizePolicy3.setHeightForWidth(self.widget_5.sizePolicy().hasHeightForWidth())
        self.widget_5.setSizePolicy(sizePolicy3)
        self.widget_5.setMinimumSize(QSize(171, 0))
        self.widget_5.setMaximumSize(QSize(171, 16777215))
        self.gridLayout_10 = QGridLayout(self.widget_5)
        self.gridLayout_10.setSpacing(15)
        self.gridLayout_10.setObjectName(u"gridLayout_10")
        self.gridLayout_10.setContentsMargins(0, 0, 15, 6)
        self.actionbutton_g58_5 = ActionButton(self.widget_5)
        self.actionbutton_g58_5.setObjectName(u"actionbutton_g58_5")
        self.actionbutton_g58_5.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g58_5.sizePolicy().hasHeightForWidth())
        self.actionbutton_g58_5.setSizePolicy(sizePolicy3)
        self.actionbutton_g58_5.setMinimumSize(QSize(75, 0))
        self.actionbutton_g58_5.setMaximumSize(QSize(75, 40))
        self.actionbutton_g58_5.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g58_5.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g58_5.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g58_5, 4, 0, 1, 1)

        self.actionbutton_g59_16 = ActionButton(self.widget_5)
        self.actionbutton_g59_16.setObjectName(u"actionbutton_g59_16")
        self.actionbutton_g59_16.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g59_16.sizePolicy().hasHeightForWidth())
        self.actionbutton_g59_16.setSizePolicy(sizePolicy3)
        self.actionbutton_g59_16.setMinimumSize(QSize(75, 0))
        self.actionbutton_g59_16.setMaximumSize(QSize(75, 40))
        self.actionbutton_g59_16.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g59_16.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g59_16.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g59_16, 9, 0, 1, 1)

        self.actionbutton_g54_5 = ActionButton(self.widget_5)
        self.actionbutton_g54_5.setObjectName(u"actionbutton_g54_5")
        self.actionbutton_g54_5.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g54_5.sizePolicy().hasHeightForWidth())
        self.actionbutton_g54_5.setSizePolicy(sizePolicy3)
        self.actionbutton_g54_5.setMinimumSize(QSize(75, 0))
        self.actionbutton_g54_5.setMaximumSize(QSize(75, 40))
        self.actionbutton_g54_5.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g54_5.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g54_5.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g54_5, 0, 0, 1, 1)

        self.actionbutton_g56_5 = ActionButton(self.widget_5)
        self.actionbutton_g56_5.setObjectName(u"actionbutton_g56_5")
        self.actionbutton_g56_5.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g56_5.sizePolicy().hasHeightForWidth())
        self.actionbutton_g56_5.setSizePolicy(sizePolicy3)
        self.actionbutton_g56_5.setMinimumSize(QSize(75, 0))
        self.actionbutton_g56_5.setMaximumSize(QSize(75, 40))
        self.actionbutton_g56_5.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g56_5.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g56_5.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g56_5, 2, 0, 1, 1)

        self.actionbutton_g55_5 = ActionButton(self.widget_5)
        self.actionbutton_g55_5.setObjectName(u"actionbutton_g55_5")
        self.actionbutton_g55_5.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g55_5.sizePolicy().hasHeightForWidth())
        self.actionbutton_g55_5.setSizePolicy(sizePolicy3)
        self.actionbutton_g55_5.setMinimumSize(QSize(75, 0))
        self.actionbutton_g55_5.setMaximumSize(QSize(75, 40))
        self.actionbutton_g55_5.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g55_5.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g55_5.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g55_5, 0, 1, 1, 1)

        self.actionbutton_g57_5 = ActionButton(self.widget_5)
        self.actionbutton_g57_5.setObjectName(u"actionbutton_g57_5")
        self.actionbutton_g57_5.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g57_5.sizePolicy().hasHeightForWidth())
        self.actionbutton_g57_5.setSizePolicy(sizePolicy3)
        self.actionbutton_g57_5.setMinimumSize(QSize(75, 0))
        self.actionbutton_g57_5.setMaximumSize(QSize(75, 40))
        self.actionbutton_g57_5.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g57_5.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g57_5.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g57_5, 2, 1, 1, 1)

        self.actionbutton_g59_17 = ActionButton(self.widget_5)
        self.actionbutton_g59_17.setObjectName(u"actionbutton_g59_17")
        self.actionbutton_g59_17.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g59_17.sizePolicy().hasHeightForWidth())
        self.actionbutton_g59_17.setSizePolicy(sizePolicy3)
        self.actionbutton_g59_17.setMinimumSize(QSize(75, 0))
        self.actionbutton_g59_17.setMaximumSize(QSize(75, 40))
        self.actionbutton_g59_17.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g59_17.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g59_17.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g59_17, 4, 1, 1, 1)

        self.actionbutton_g59_18 = ActionButton(self.widget_5)
        self.actionbutton_g59_18.setObjectName(u"actionbutton_g59_18")
        self.actionbutton_g59_18.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g59_18.sizePolicy().hasHeightForWidth())
        self.actionbutton_g59_18.setSizePolicy(sizePolicy3)
        self.actionbutton_g59_18.setMinimumSize(QSize(75, 0))
        self.actionbutton_g59_18.setMaximumSize(QSize(75, 40))
        self.actionbutton_g59_18.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g59_18.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g59_18.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g59_18, 7, 1, 1, 1)

        self.actionbutton_g59_19 = ActionButton(self.widget_5)
        self.actionbutton_g59_19.setObjectName(u"actionbutton_g59_19")
        self.actionbutton_g59_19.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.actionbutton_g59_19.sizePolicy().hasHeightForWidth())
        self.actionbutton_g59_19.setSizePolicy(sizePolicy3)
        self.actionbutton_g59_19.setMinimumSize(QSize(75, 0))
        self.actionbutton_g59_19.setMaximumSize(QSize(75, 40))
        self.actionbutton_g59_19.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.actionbutton_g59_19.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.actionbutton_g59_19.setAutoExclusive(True)

        self.gridLayout_10.addWidget(self.actionbutton_g59_19, 7, 0, 1, 1)


        self.verticalLayout_63.addWidget(self.widget_5, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)

        self.widget_47 = QWidget(self.sb_page_2)
        self.widget_47.setObjectName(u"widget_47")
        sizePolicy8.setHeightForWidth(self.widget_47.sizePolicy().hasHeightForWidth())
        self.widget_47.setSizePolicy(sizePolicy8)
        self.verticalLayout_67 = QVBoxLayout(self.widget_47)
        self.verticalLayout_67.setSpacing(20)
        self.verticalLayout_67.setObjectName(u"verticalLayout_67")
        self.verticalLayout_67.setContentsMargins(15, -1, 15, 20)
        self.widget_48 = QWidget(self.widget_47)
        self.widget_48.setObjectName(u"widget_48")

        self.verticalLayout_67.addWidget(self.widget_48)

        self.ref_all_button_3 = ActionButton(self.widget_47)
        self.ref_all_button_3.setObjectName(u"ref_all_button_3")
        sizePolicy1.setHeightForWidth(self.ref_all_button_3.sizePolicy().hasHeightForWidth())
        self.ref_all_button_3.setSizePolicy(sizePolicy1)
        self.ref_all_button_3.setMinimumSize(QSize(62, 0))
        self.ref_all_button_3.setMaximumSize(QSize(16777215, 40))
        self.ref_all_button_3.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.ref_all_button_3.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.verticalLayout_67.addWidget(self.ref_all_button_3)

        self.axisactionbutton_12 = ActionButton(self.widget_47)
        self.axisactionbutton_12.setObjectName(u"axisactionbutton_12")
        sizePolicy6.setHeightForWidth(self.axisactionbutton_12.sizePolicy().hasHeightForWidth())
        self.axisactionbutton_12.setSizePolicy(sizePolicy6)
        self.axisactionbutton_12.setMinimumSize(QSize(60, 0))
        self.axisactionbutton_12.setMaximumSize(QSize(16777215, 40))
        self.axisactionbutton_12.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.verticalLayout_67.addWidget(self.axisactionbutton_12)

        self.axisactionbutton_14 = ActionButton(self.widget_47)
        self.axisactionbutton_14.setObjectName(u"axisactionbutton_14")
        sizePolicy6.setHeightForWidth(self.axisactionbutton_14.sizePolicy().hasHeightForWidth())
        self.axisactionbutton_14.setSizePolicy(sizePolicy6)
        self.axisactionbutton_14.setMinimumSize(QSize(60, 0))
        self.axisactionbutton_14.setMaximumSize(QSize(16777215, 40))
        self.axisactionbutton_14.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.verticalLayout_67.addWidget(self.axisactionbutton_14)


        self.verticalLayout_63.addWidget(self.widget_47)

        self.sidebar_widget.addWidget(self.sb_page_2)
        self.sb_page_3 = QWidget()
        self.sb_page_3.setObjectName(u"sb_page_3")
        self.sb_page_3.setStyleSheet(u"")
        self.verticalLayout_68 = QVBoxLayout(self.sb_page_3)
        self.verticalLayout_68.setSpacing(9)
        self.verticalLayout_68.setObjectName(u"verticalLayout_68")
        self.verticalLayout_68.setContentsMargins(0, 30, 0, 0)
        self.statuslabel = StatusLabel(self.sb_page_3)
        self.statuslabel.setObjectName(u"statuslabel")
        self.statuslabel.setStyleSheet(u"StatusLabel {\n"
"    border: none;\n"
"    color: white;\n"
"    background: transparent;\n"
"    font: 18pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_68.addWidget(self.statuslabel)

        self.widget_13 = QWidget(self.sb_page_3)
        self.widget_13.setObjectName(u"widget_13")
        sizePolicy.setHeightForWidth(self.widget_13.sizePolicy().hasHeightForWidth())
        self.widget_13.setSizePolicy(sizePolicy)
        self.widget_13.setStyleSheet(u"padding-left: 10px;")
        self.horizontalLayout_7 = QHBoxLayout(self.widget_13)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.statuslabel_2 = StatusLabel(self.widget_13)
        self.statuslabel_2.setObjectName(u"statuslabel_2")
        self.statuslabel_2.setStyleSheet(u"StatusLabel {\n"
"    border: none;\n"
"    color: white;\n"
"    background: transparent;\n"
"    font: 32pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_7.addWidget(self.statuslabel_2)

        self.dro_entry_x_main_3 = DROLineEdit(self.widget_13)
        self.dro_entry_x_main_3.setObjectName(u"dro_entry_x_main_3")
        sizePolicy6.setHeightForWidth(self.dro_entry_x_main_3.sizePolicy().hasHeightForWidth())
        self.dro_entry_x_main_3.setSizePolicy(sizePolicy6)
        self.dro_entry_x_main_3.setStyleSheet(u"DROLineEdit{\n"
"    border: none;\n"
"    color: rgb(94, 115, 255);\n"
"    background: transparent;\n"
"    font: 36pt \"Probe Basic Bebas Mono\";\n"
"    padding-right: 10px;\n"
"}")
        self.dro_entry_x_main_3.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.dro_entry_x_main_3.setProperty(u"referenceType", 1)
        self.dro_entry_x_main_3.setProperty(u"axisNumber", 0)
        self.dro_entry_x_main_3.setProperty(u"latheMode", 0)

        self.horizontalLayout_7.addWidget(self.dro_entry_x_main_3)


        self.verticalLayout_68.addWidget(self.widget_13)

        self.widget_23 = QWidget(self.sb_page_3)
        self.widget_23.setObjectName(u"widget_23")
        self.widget_23.setMaximumSize(QSize(200, 16777215))
        self.widget_23.setStyleSheet(u"padding-left: 10px;")
        self.horizontalLayout_10 = QHBoxLayout(self.widget_23)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.statuslabel_3 = StatusLabel(self.widget_23)
        self.statuslabel_3.setObjectName(u"statuslabel_3")
        self.statuslabel_3.setStyleSheet(u"StatusLabel {\n"
"    border: none;\n"
"    color: white;\n"
"    background: transparent;\n"
"    font: 32pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_10.addWidget(self.statuslabel_3)

        self.dro_entry_z_main_3 = DROLineEdit(self.widget_23)
        self.dro_entry_z_main_3.setObjectName(u"dro_entry_z_main_3")
        sizePolicy6.setHeightForWidth(self.dro_entry_z_main_3.sizePolicy().hasHeightForWidth())
        self.dro_entry_z_main_3.setSizePolicy(sizePolicy6)
        self.dro_entry_z_main_3.setStyleSheet(u"DROLineEdit{\n"
"    border: none;\n"
"    color: rgb(94, 115, 255);\n"
"    background: transparent;\n"
"    font: 36pt \"Probe Basic Bebas Mono\";\n"
"    padding-right: 10px;\n"
"}")
        self.dro_entry_z_main_3.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.dro_entry_z_main_3.setProperty(u"referenceType", 1)
        self.dro_entry_z_main_3.setProperty(u"axisNumber", 2)
        self.dro_entry_z_main_3.setProperty(u"latheMode", 0)

        self.horizontalLayout_10.addWidget(self.dro_entry_z_main_3)


        self.verticalLayout_68.addWidget(self.widget_23)

        self.widget = QWidget(self.sb_page_3)
        self.widget.setObjectName(u"widget")
        sizePolicy8.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy8)

        self.verticalLayout_68.addWidget(self.widget)

        self.sidebar_widget.addWidget(self.sb_page_3)
        self.sb_page_4 = QWidget()
        self.sb_page_4.setObjectName(u"sb_page_4")
        self.sidebar_widget.addWidget(self.sb_page_4)

        self.verticalLayout_34.addWidget(self.sidebar_widget)

        self.horizontalWidget_4 = QWidget(self.frame_36)
        self.horizontalWidget_4.setObjectName(u"horizontalWidget_4")
        sizePolicy6.setHeightForWidth(self.horizontalWidget_4.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_4.setSizePolicy(sizePolicy6)
        self.horizontalWidget_4.setMinimumSize(QSize(0, 0))
        self.horizontalWidget_4.setMaximumSize(QSize(16777215, 42))
        self.horizontalWidget_4.setStyleSheet(u".QWidget{\n"
"    background: rgb(46, 52, 54);\n"
"}")
        self.horizontalLayout_16 = QHBoxLayout(self.horizontalWidget_4)
        self.horizontalLayout_16.setSpacing(8)
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.horizontalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.manual_mode_button = ActionButton(self.horizontalWidget_4)
        self.manual_mode_button.setObjectName(u"manual_mode_button")
        self.manual_mode_button.setEnabled(False)
        sizePolicy6.setHeightForWidth(self.manual_mode_button.sizePolicy().hasHeightForWidth())
        self.manual_mode_button.setSizePolicy(sizePolicy6)
        self.manual_mode_button.setMinimumSize(QSize(0, 40))
        self.manual_mode_button.setMaximumSize(QSize(16777215, 40))
        self.manual_mode_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.manual_mode_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.manual_mode_button.setCheckable(True)
        self.manual_mode_button.setAutoExclusive(True)

        self.horizontalLayout_16.addWidget(self.manual_mode_button)

        self.auto_mode_button = ActionButton(self.horizontalWidget_4)
        self.auto_mode_button.setObjectName(u"auto_mode_button")
        self.auto_mode_button.setEnabled(False)
        sizePolicy6.setHeightForWidth(self.auto_mode_button.sizePolicy().hasHeightForWidth())
        self.auto_mode_button.setSizePolicy(sizePolicy6)
        self.auto_mode_button.setMinimumSize(QSize(0, 40))
        self.auto_mode_button.setMaximumSize(QSize(16777215, 40))
        self.auto_mode_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.auto_mode_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.auto_mode_button.setCheckable(True)
        self.auto_mode_button.setAutoExclusive(True)

        self.horizontalLayout_16.addWidget(self.auto_mode_button)

        self.mdi_mode_button = ActionButton(self.horizontalWidget_4)
        self.mdi_mode_button.setObjectName(u"mdi_mode_button")
        self.mdi_mode_button.setEnabled(False)
        sizePolicy6.setHeightForWidth(self.mdi_mode_button.sizePolicy().hasHeightForWidth())
        self.mdi_mode_button.setSizePolicy(sizePolicy6)
        self.mdi_mode_button.setMinimumSize(QSize(0, 40))
        self.mdi_mode_button.setMaximumSize(QSize(16777215, 40))
        self.mdi_mode_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.mdi_mode_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.mdi_mode_button.setCheckable(True)
        self.mdi_mode_button.setAutoExclusive(True)

        self.horizontalLayout_16.addWidget(self.mdi_mode_button)


        self.verticalLayout_34.addWidget(self.horizontalWidget_4)


        self.verticalLayout_19.addWidget(self.frame_36)


        self.verticalLayout_9.addWidget(self.widget_84)


        self.horizontalLayout_36.addWidget(self.side_bar_2)

        self.widget_32 = QWidget(self.widget_83)
        self.widget_32.setObjectName(u"widget_32")
        sizePolicy7.setHeightForWidth(self.widget_32.sizePolicy().hasHeightForWidth())
        self.widget_32.setSizePolicy(sizePolicy7)
        self.widget_32.setMinimumSize(QSize(35, 0))
        self.widget_32.setMaximumSize(QSize(35, 16777215))
        self.verticalLayout_69 = QVBoxLayout(self.widget_32)
        self.verticalLayout_69.setSpacing(0)
        self.verticalLayout_69.setObjectName(u"verticalLayout_69")
        self.verticalLayout_69.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.verticalLayout_69.setContentsMargins(0, 0, 0, 0)
        self.statuslabel_19 = StatusLabel(self.widget_32)
        self.statuslabel_19.setObjectName(u"statuslabel_19")
        self.statuslabel_19.setEnabled(False)
        sizePolicy12 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy12.setHorizontalStretch(0)
        sizePolicy12.setVerticalStretch(1)
        sizePolicy12.setHeightForWidth(self.statuslabel_19.sizePolicy().hasHeightForWidth())
        self.statuslabel_19.setSizePolicy(sizePolicy12)
        self.statuslabel_19.setMinimumSize(QSize(35, 0))
        self.statuslabel_19.setMaximumSize(QSize(35, 16777215))
        self.statuslabel_19.setStyleSheet(u"QLabel{\n"
"    color: white;\n"
"    font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_19.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.statuslabel_19.setWordWrap(True)
        self.statuslabel_19.setIndent(0)

        self.verticalLayout_69.addWidget(self.statuslabel_19, 0, Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)

        self.label_240 = QLabel(self.widget_32)
        self.label_240.setObjectName(u"label_240")
        sizePolicy13 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy13.setHorizontalStretch(0)
        sizePolicy13.setVerticalStretch(1)
        sizePolicy13.setHeightForWidth(self.label_240.sizePolicy().hasHeightForWidth())
        self.label_240.setSizePolicy(sizePolicy13)
        self.label_240.setMinimumSize(QSize(35, 0))
        self.label_240.setMaximumSize(QSize(35, 9))

        self.verticalLayout_69.addWidget(self.label_240)

        self.statuslabel_26 = StatusLabel(self.widget_32)
        self.statuslabel_26.setObjectName(u"statuslabel_26")
        sizePolicy12.setHeightForWidth(self.statuslabel_26.sizePolicy().hasHeightForWidth())
        self.statuslabel_26.setSizePolicy(sizePolicy12)
        self.statuslabel_26.setMinimumSize(QSize(35, 0))
        self.statuslabel_26.setMaximumSize(QSize(35, 16777215))
        self.statuslabel_26.setStyleSheet(u"QLabel{\n"
"    color: white;\n"
"    font: 75 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_26.setAlignment(Qt.AlignmentFlag.AlignBottom|Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft)
        self.statuslabel_26.setWordWrap(True)
        self.statuslabel_26.setIndent(0)

        self.verticalLayout_69.addWidget(self.statuslabel_26, 0, Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)

        self.label_241 = QLabel(self.widget_32)
        self.label_241.setObjectName(u"label_241")
        sizePolicy8.setHeightForWidth(self.label_241.sizePolicy().hasHeightForWidth())
        self.label_241.setSizePolicy(sizePolicy8)
        self.label_241.setMinimumSize(QSize(35, 0))
        self.label_241.setMaximumSize(QSize(35, 16777215))

        self.verticalLayout_69.addWidget(self.label_241)


        self.horizontalLayout_36.addWidget(self.widget_32, 0, Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)


        self.verticalLayout_12.addWidget(self.widget_83)

        self.widget_33 = QWidget(self.side_bar)
        self.widget_33.setObjectName(u"widget_33")
        self.widget_33.setMaximumSize(QSize(250, 16777215))
        self.widget_33.setStyleSheet(u"min-height: 30px;")
        self.horizontalLayout_39 = QHBoxLayout(self.widget_33)
        self.horizontalLayout_39.setSpacing(0)
        self.horizontalLayout_39.setObjectName(u"horizontalLayout_39")
        self.horizontalLayout_39.setContentsMargins(0, 3, 0, 2)
        self.jog_tab = QPushButton(self.widget_33)
        self.sidebartabGroup = QButtonGroup(Form)
        self.sidebartabGroup.setObjectName(u"sidebartabGroup")
        self.sidebartabGroup.addButton(self.jog_tab)
        self.jog_tab.setObjectName(u"jog_tab")
        sizePolicy4.setHeightForWidth(self.jog_tab.sizePolicy().hasHeightForWidth())
        self.jog_tab.setSizePolicy(sizePolicy4)
        self.jog_tab.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.jog_tab.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 2px;\n"
"    border-top-left-radius: 4px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 4px;\n"
"    border-bottom-right-radius: 0px;\n"
"    min-height: 34px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 255), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123,"
                        " 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.jog_tab.setCheckable(True)
        self.jog_tab.setChecked(True)
        self.jog_tab.setAutoExclusive(True)
        self.jog_tab.setProperty(u"page", 0)

        self.horizontalLayout_39.addWidget(self.jog_tab)

        self.offset_tab = QPushButton(self.widget_33)
        self.sidebartabGroup.addButton(self.offset_tab)
        self.offset_tab.setObjectName(u"offset_tab")
        sizePolicy4.setHeightForWidth(self.offset_tab.sizePolicy().hasHeightForWidth())
        self.offset_tab.setSizePolicy(sizePolicy4)
        self.offset_tab.setMinimumSize(QSize(0, 38))
        self.offset_tab.setMaximumSize(QSize(16777215, 40))
        self.offset_tab.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.offset_tab.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"    min-height: 34px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 255), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123,"
                        " 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.offset_tab.setCheckable(True)
        self.offset_tab.setAutoExclusive(True)
        self.offset_tab.setProperty(u"page", 1)

        self.horizontalLayout_39.addWidget(self.offset_tab)

        self.dro_tab = QPushButton(self.widget_33)
        self.sidebartabGroup.addButton(self.dro_tab)
        self.dro_tab.setObjectName(u"dro_tab")
        sizePolicy4.setHeightForWidth(self.dro_tab.sizePolicy().hasHeightForWidth())
        self.dro_tab.setSizePolicy(sizePolicy4)
        self.dro_tab.setMinimumSize(QSize(0, 38))
        self.dro_tab.setMaximumSize(QSize(16777215, 40))
        self.dro_tab.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.dro_tab.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 1px;\n"
"    border-left-width: 1px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"    min-height: 34px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 255), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123,"
                        " 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.dro_tab.setCheckable(True)
        self.dro_tab.setAutoExclusive(True)
        self.dro_tab.setProperty(u"page", 2)

        self.horizontalLayout_39.addWidget(self.dro_tab)

        self.user_sb_tab = QPushButton(self.widget_33)
        self.sidebartabGroup.addButton(self.user_sb_tab)
        self.user_sb_tab.setObjectName(u"user_sb_tab")
        sizePolicy4.setHeightForWidth(self.user_sb_tab.sizePolicy().hasHeightForWidth())
        self.user_sb_tab.setSizePolicy(sizePolicy4)
        self.user_sb_tab.setMinimumSize(QSize(0, 38))
        self.user_sb_tab.setMaximumSize(QSize(16777215, 40))
        self.user_sb_tab.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.user_sb_tab.setStyleSheet(u"QPushButton {\n"
"    color: white;\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #4e4e4e, stop: 1.0 #3a3a3a);\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-top-width: 2px;\n"
"    border-bottom-width: 2px;\n"
"    border-right-width: 2px;\n"
"    border-left-width: 1px;\n"
"    border-top-left-radius: 0px;\n"
"    border-top-right-radius: 4px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 4px;\n"
"    min-height: 34px;\n"
"}\n"
"\n"
"QPushButton:pressed, QPushButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(112, 112, 238, 255), stop:0.121053 rgba(123, 123, 232, 255), stop:0.3 rgba(85, 85, 238, 255), stop:0.694737 rgba(85, 85, 238, 255), stop:0.915789 rgba(123,"
                        " 123, 232, 255), stop:1 rgba(112, 112, 238, 255))\n"
"}")
        self.user_sb_tab.setCheckable(True)
        self.user_sb_tab.setAutoExclusive(True)
        self.user_sb_tab.setProperty(u"page", 3)

        self.horizontalLayout_39.addWidget(self.user_sb_tab)


        self.verticalLayout_12.addWidget(self.widget_33)


        self.horizontalLayout_101.addWidget(self.side_bar)


        self.verticalLayout_31.addLayout(self.horizontalLayout_101)

        self.main_control_screen_layout_panel = QHBoxLayout()
        self.main_control_screen_layout_panel.setSpacing(0)
        self.main_control_screen_layout_panel.setObjectName(u"main_control_screen_layout_panel")
        self.main_control_screen_layout_panel.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.main_control_screen_layout_panel.setContentsMargins(12, 0, 12, 0)
        self.main_control_qframe_2 = QFrame(self.centralwidget)
        self.main_control_qframe_2.setObjectName(u"main_control_qframe_2")
        sizePolicy3.setHeightForWidth(self.main_control_qframe_2.sizePolicy().hasHeightForWidth())
        self.main_control_qframe_2.setSizePolicy(sizePolicy3)
        self.main_control_qframe_2.setMinimumSize(QSize(340, 340))
        self.main_control_qframe_2.setMaximumSize(QSize(340, 340))
        self.main_control_qframe_2.setStyleSheet(u".QFrame{\n"
"    border-right-width:1px;\n"
"}")
        self.verticalLayout_29 = QVBoxLayout(self.main_control_qframe_2)
        self.verticalLayout_29.setSpacing(6)
        self.verticalLayout_29.setObjectName(u"verticalLayout_29")
        self.verticalLayout_29.setContentsMargins(15, 12, 15, 3)
        self.horizontalLayout_93 = QHBoxLayout()
        self.horizontalLayout_93.setSpacing(6)
        self.horizontalLayout_93.setObjectName(u"horizontalLayout_93")
        self.horizontalLayout_93.setContentsMargins(-1, -1, -1, 3)
        self.cycle_start_button = ActionButton(self.main_control_qframe_2)
        self.cycle_start_button.setObjectName(u"cycle_start_button")
        sizePolicy6.setHeightForWidth(self.cycle_start_button.sizePolicy().hasHeightForWidth())
        self.cycle_start_button.setSizePolicy(sizePolicy6)
        self.cycle_start_button.setMinimumSize(QSize(0, 50))
        self.cycle_start_button.setMaximumSize(QSize(16777215, 50))
        self.cycle_start_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.cycle_start_button.setStyleSheet(u"QPushButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}\n"
"\n"
"QPushButton[style='active']{\n"
"	background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
"QPushButton[style='active'][flashState='false']{\n"
"	background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"")

        self.horizontalLayout_93.addWidget(self.cycle_start_button)

        self.ref_coilumn_header_25 = QLabel(self.main_control_qframe_2)
        self.ref_coilumn_header_25.setObjectName(u"ref_coilumn_header_25")
        sizePolicy14 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy14.setHorizontalStretch(1)
        sizePolicy14.setVerticalStretch(0)
        sizePolicy14.setHeightForWidth(self.ref_coilumn_header_25.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_25.setSizePolicy(sizePolicy14)
        self.ref_coilumn_header_25.setMinimumSize(QSize(3, 52))
        self.ref_coilumn_header_25.setMaximumSize(QSize(3, 52))
        self.ref_coilumn_header_25.setStyleSheet(u"")
        self.ref_coilumn_header_25.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_93.addWidget(self.ref_coilumn_header_25)

        self.stop_button = ActionButton(self.main_control_qframe_2)
        self.stop_button.setObjectName(u"stop_button")
        sizePolicy6.setHeightForWidth(self.stop_button.sizePolicy().hasHeightForWidth())
        self.stop_button.setSizePolicy(sizePolicy6)
        self.stop_button.setMinimumSize(QSize(0, 50))
        self.stop_button.setMaximumSize(QSize(16777215, 50))
        self.stop_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.stop_button.setStyleSheet(u"QPushButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_93.addWidget(self.stop_button)


        self.verticalLayout_29.addLayout(self.horizontalLayout_93)

        self.user_buttons_layout = QVBoxLayout()
        self.user_buttons_layout.setSpacing(0)
        self.user_buttons_layout.setObjectName(u"user_buttons_layout")
        self.user_buttons_layout.setContentsMargins(-1, 0, -1, 3)

        self.verticalLayout_29.addLayout(self.user_buttons_layout)

        self.line_2 = QFrame(self.main_control_qframe_2)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setMinimumSize(QSize(0, 2))
        self.line_2.setMaximumSize(QSize(16777215, 2))
        self.line_2.setStyleSheet(u"color:rgb(186, 189, 182);")
        self.line_2.setLineWidth(0)
        self.line_2.setMidLineWidth(1)
        self.line_2.setFrameShape(QFrame.Shape.HLine)
        self.line_2.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_29.addWidget(self.line_2)

        self.widget_8 = QWidget(self.main_control_qframe_2)
        self.widget_8.setObjectName(u"widget_8")
        sizePolicy4.setHeightForWidth(self.widget_8.sizePolicy().hasHeightForWidth())
        self.widget_8.setSizePolicy(sizePolicy4)
        self.widget_8.setMinimumSize(QSize(300, 0))
        self.widget_8.setMaximumSize(QSize(300, 16777215))
        self.horizontalLayout_94 = QHBoxLayout(self.widget_8)
        self.horizontalLayout_94.setObjectName(u"horizontalLayout_94")
        self.horizontalLayout_94.setContentsMargins(1, 3, 4, 8)
        self.power_button = ActionButton(self.widget_8)
        self.power_button.setObjectName(u"power_button")
        sizePolicy3.setHeightForWidth(self.power_button.sizePolicy().hasHeightForWidth())
        self.power_button.setSizePolicy(sizePolicy3)
        self.power_button.setMinimumSize(QSize(75, 35))
        self.power_button.setMaximumSize(QSize(75, 35))
        self.power_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.power_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.power_button.setCheckable(True)

        self.horizontalLayout_94.addWidget(self.power_button)

        self.ref_coilumn_header_16 = QLabel(self.widget_8)
        self.ref_coilumn_header_16.setObjectName(u"ref_coilumn_header_16")
        sizePolicy.setHeightForWidth(self.ref_coilumn_header_16.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_16.setSizePolicy(sizePolicy)
        self.ref_coilumn_header_16.setStyleSheet(u"")
        self.ref_coilumn_header_16.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_94.addWidget(self.ref_coilumn_header_16)

        self.widget_21 = QWidget(self.widget_8)
        self.widget_21.setObjectName(u"widget_21")
        self.widget_21.setMinimumSize(QSize(90, 32))
        self.widget_21.setMaximumSize(QSize(90, 32))
        self.horizontalLayout_42 = QHBoxLayout(self.widget_21)
        self.horizontalLayout_42.setSpacing(0)
        self.horizontalLayout_42.setObjectName(u"horizontalLayout_42")
        self.horizontalLayout_42.setContentsMargins(0, 1, 0, 1)
        self.timerhours = HalLabel(self.widget_21)
        self.timerhours.setObjectName(u"timerhours")
        sizePolicy6.setHeightForWidth(self.timerhours.sizePolicy().hasHeightForWidth())
        self.timerhours.setSizePolicy(sizePolicy6)
        self.timerhours.setMinimumSize(QSize(0, 32))
        self.timerhours.setMaximumSize(QSize(16777215, 32))
        self.timerhours.setTextFormat(Qt.TextFormat.AutoText)
        self.timerhours.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.timerhours.setIndent(2)

        self.horizontalLayout_42.addWidget(self.timerhours)

        self.timer_div1 = QLabel(self.widget_21)
        self.timer_div1.setObjectName(u"timer_div1")
        sizePolicy3.setHeightForWidth(self.timer_div1.sizePolicy().hasHeightForWidth())
        self.timer_div1.setSizePolicy(sizePolicy3)
        self.timer_div1.setMinimumSize(QSize(4, 32))
        self.timer_div1.setMaximumSize(QSize(4, 32))
        self.timer_div1.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.timer_div1.setIndent(-1)

        self.horizontalLayout_42.addWidget(self.timer_div1)

        self.timerminutes = HalLabel(self.widget_21)
        self.timerminutes.setObjectName(u"timerminutes")
        sizePolicy3.setHeightForWidth(self.timerminutes.sizePolicy().hasHeightForWidth())
        self.timerminutes.setSizePolicy(sizePolicy3)
        self.timerminutes.setMinimumSize(QSize(24, 32))
        self.timerminutes.setMaximumSize(QSize(24, 32))
        self.timerminutes.setTextFormat(Qt.TextFormat.AutoText)
        self.timerminutes.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.timerminutes.setIndent(0)

        self.horizontalLayout_42.addWidget(self.timerminutes)

        self.timer_div = QLabel(self.widget_21)
        self.timer_div.setObjectName(u"timer_div")
        sizePolicy3.setHeightForWidth(self.timer_div.sizePolicy().hasHeightForWidth())
        self.timer_div.setSizePolicy(sizePolicy3)
        self.timer_div.setMinimumSize(QSize(4, 32))
        self.timer_div.setMaximumSize(QSize(4, 32))
        self.timer_div.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.timer_div.setIndent(1)

        self.horizontalLayout_42.addWidget(self.timer_div)

        self.timerseconds = HalLabel(self.widget_21)
        self.timerseconds.setObjectName(u"timerseconds")
        sizePolicy6.setHeightForWidth(self.timerseconds.sizePolicy().hasHeightForWidth())
        self.timerseconds.setSizePolicy(sizePolicy6)
        self.timerseconds.setMinimumSize(QSize(0, 32))
        self.timerseconds.setMaximumSize(QSize(16777215, 32))
        self.timerseconds.setTextFormat(Qt.TextFormat.AutoText)
        self.timerseconds.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.timerseconds.setIndent(2)

        self.horizontalLayout_42.addWidget(self.timerseconds)


        self.horizontalLayout_94.addWidget(self.widget_21)

        self.ref_coilumn_header_18 = QLabel(self.widget_8)
        self.ref_coilumn_header_18.setObjectName(u"ref_coilumn_header_18")
        sizePolicy.setHeightForWidth(self.ref_coilumn_header_18.sizePolicy().hasHeightForWidth())
        self.ref_coilumn_header_18.setSizePolicy(sizePolicy)
        self.ref_coilumn_header_18.setStyleSheet(u"")
        self.ref_coilumn_header_18.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_94.addWidget(self.ref_coilumn_header_18)

        self.exit_button = ActionButton(self.widget_8)
        self.exit_button.setObjectName(u"exit_button")
        sizePolicy3.setHeightForWidth(self.exit_button.sizePolicy().hasHeightForWidth())
        self.exit_button.setSizePolicy(sizePolicy3)
        self.exit_button.setMinimumSize(QSize(75, 35))
        self.exit_button.setMaximumSize(QSize(75, 35))
        self.exit_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.exit_button.setStyleSheet(u"background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(226, 64, 64, 255), stop:0.446154 rgba(204, 0, 0, 255), stop:0.764103 rgba(225, 67, 67, 255), stop:1 rgba(249, 142, 142, 255))")
        self.exit_button.setCheckable(True)

        self.horizontalLayout_94.addWidget(self.exit_button)


        self.verticalLayout_29.addWidget(self.widget_8)


        self.main_control_screen_layout_panel.addWidget(self.main_control_qframe_2)

        self.main_dro_qframe_3 = QFrame(self.centralwidget)
        self.main_dro_qframe_3.setObjectName(u"main_dro_qframe_3")
        sizePolicy3.setHeightForWidth(self.main_dro_qframe_3.sizePolicy().hasHeightForWidth())
        self.main_dro_qframe_3.setSizePolicy(sizePolicy3)
        self.main_dro_qframe_3.setMinimumSize(QSize(170, 340))
        self.main_dro_qframe_3.setMaximumSize(QSize(170, 340))
        self.main_dro_qframe_3.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_dro_qframe_3.setStyleSheet(u".QFrame{\n"
"    border-left-width: 1px;\n"
"    border-right-width:1px;\n"
"}")
        self.verticalLayout_70 = QVBoxLayout(self.main_dro_qframe_3)
        self.verticalLayout_70.setSpacing(12)
        self.verticalLayout_70.setObjectName(u"verticalLayout_70")
        self.verticalLayout_70.setContentsMargins(15, 14, 15, 12)
        self.widget_86 = QWidget(self.main_dro_qframe_3)
        self.widget_86.setObjectName(u"widget_86")
        self.horizontalLayout_145 = QHBoxLayout(self.widget_86)
        self.horizontalLayout_145.setSpacing(12)
        self.horizontalLayout_145.setObjectName(u"horizontalLayout_145")
        self.horizontalLayout_145.setContentsMargins(0, 0, 0, 0)
        self.m6_tool_call_main_panel = SubCallButton(self.widget_86)
        self.m6_tool_call_main_panel.setObjectName(u"m6_tool_call_main_panel")
        self.m6_tool_call_main_panel.setEnabled(False)
        sizePolicy6.setHeightForWidth(self.m6_tool_call_main_panel.sizePolicy().hasHeightForWidth())
        self.m6_tool_call_main_panel.setSizePolicy(sizePolicy6)
        self.m6_tool_call_main_panel.setMinimumSize(QSize(50, 40))
        self.m6_tool_call_main_panel.setMaximumSize(QSize(16777215, 40))
        self.m6_tool_call_main_panel.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.horizontalLayout_145.addWidget(self.m6_tool_call_main_panel)

        self.tool_number_entry_main_panel = VCPLineEdit(self.widget_86)
        self.tool_number_entry_main_panel.setObjectName(u"tool_number_entry_main_panel")
        self.tool_number_entry_main_panel.setEnabled(False)
        sizePolicy6.setHeightForWidth(self.tool_number_entry_main_panel.sizePolicy().hasHeightForWidth())
        self.tool_number_entry_main_panel.setSizePolicy(sizePolicy6)
        self.tool_number_entry_main_panel.setMinimumSize(QSize(50, 38))
        self.tool_number_entry_main_panel.setMaximumSize(QSize(16777215, 38))
        self.tool_number_entry_main_panel.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.tool_number_entry_main_panel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_145.addWidget(self.tool_number_entry_main_panel)


        self.verticalLayout_70.addWidget(self.widget_86)

        self.diameter_mode_button_2 = MDIButton(self.main_dro_qframe_3)
        self.diameter_mode_button_2.setObjectName(u"diameter_mode_button_2")
        self.diameter_mode_button_2.setEnabled(False)
        sizePolicy.setHeightForWidth(self.diameter_mode_button_2.sizePolicy().hasHeightForWidth())
        self.diameter_mode_button_2.setSizePolicy(sizePolicy)
        self.diameter_mode_button_2.setMinimumSize(QSize(0, 40))
        self.diameter_mode_button_2.setMaximumSize(QSize(16777215, 40))
        self.diameter_mode_button_2.setStyleSheet(u"MDIButton {\n"
"   	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.diameter_mode_button_2.setIconSize(QSize(20, 20))
        self.diameter_mode_button_2.setCheckable(True)
        self.diameter_mode_button_2.setChecked(True)
        self.diameter_mode_button_2.setAutoExclusive(True)

        self.verticalLayout_70.addWidget(self.diameter_mode_button_2)

        self.radius_mode_button_2 = MDIButton(self.main_dro_qframe_3)
        self.radius_mode_button_2.setObjectName(u"radius_mode_button_2")
        self.radius_mode_button_2.setEnabled(False)
        sizePolicy.setHeightForWidth(self.radius_mode_button_2.sizePolicy().hasHeightForWidth())
        self.radius_mode_button_2.setSizePolicy(sizePolicy)
        self.radius_mode_button_2.setMinimumSize(QSize(0, 40))
        self.radius_mode_button_2.setMaximumSize(QSize(16777215, 40))
        self.radius_mode_button_2.setStyleSheet(u"MDIButton {\n"
"   	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.radius_mode_button_2.setIconSize(QSize(20, 20))
        self.radius_mode_button_2.setCheckable(True)
        self.radius_mode_button_2.setChecked(False)
        self.radius_mode_button_2.setAutoExclusive(True)

        self.verticalLayout_70.addWidget(self.radius_mode_button_2)

        self.go_to_g30_button_2 = SubCallButton(self.main_dro_qframe_3)
        self.go_to_g30_button_2.setObjectName(u"go_to_g30_button_2")
        sizePolicy1.setHeightForWidth(self.go_to_g30_button_2.sizePolicy().hasHeightForWidth())
        self.go_to_g30_button_2.setSizePolicy(sizePolicy1)
        self.go_to_g30_button_2.setMinimumSize(QSize(0, 40))
        self.go_to_g30_button_2.setMaximumSize(QSize(16777215, 40))
        self.go_to_g30_button_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.go_to_g30_button_2.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.verticalLayout_70.addWidget(self.go_to_g30_button_2)

        self.go_to_zero_button_2 = SubCallButton(self.main_dro_qframe_3)
        self.go_to_zero_button_2.setObjectName(u"go_to_zero_button_2")
        sizePolicy1.setHeightForWidth(self.go_to_zero_button_2.sizePolicy().hasHeightForWidth())
        self.go_to_zero_button_2.setSizePolicy(sizePolicy1)
        self.go_to_zero_button_2.setMinimumSize(QSize(0, 40))
        self.go_to_zero_button_2.setMaximumSize(QSize(16777215, 40))
        self.go_to_zero_button_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.go_to_zero_button_2.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.verticalLayout_70.addWidget(self.go_to_zero_button_2)

        self.go_to_home_button_2 = SubCallButton(self.main_dro_qframe_3)
        self.go_to_home_button_2.setObjectName(u"go_to_home_button_2")
        sizePolicy1.setHeightForWidth(self.go_to_home_button_2.sizePolicy().hasHeightForWidth())
        self.go_to_home_button_2.setSizePolicy(sizePolicy1)
        self.go_to_home_button_2.setMinimumSize(QSize(0, 40))
        self.go_to_home_button_2.setMaximumSize(QSize(16777215, 40))
        self.go_to_home_button_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.go_to_home_button_2.setStyleSheet(u".SubCallButton {\n"
"    color: white;\n"
"    border-color: black;\n"
"    border-style: solid;\n"
"    border-radius: 5px;\n"
"    border-width: 2px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
".SubCallButton {\n"
"    font-family: \"Probe Basic Bebas Mono\";\n"
"    font-size: 15pt;\n"
"}\n"
"\n"
".SubCallButton:disabled {\n"
"    border-color: gray;\n"
"}\n"
"\n"
".SubCallButton:hover {\n"
"    background:  qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                     stop: 0 #A19E9E, stop: 1.0 #5C5959);\n"
"}\n"
"\n"
".SubCallButton:pressed {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126"
                        ", 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked[option=\"true\"] {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}\n"
"\n"
".SubCallButton:checked {\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")

        self.verticalLayout_70.addWidget(self.go_to_home_button_2)


        self.main_control_screen_layout_panel.addWidget(self.main_dro_qframe_3)

        self.main_dro_qframe_2 = QFrame(self.centralwidget)
        self.main_dro_qframe_2.setObjectName(u"main_dro_qframe_2")
        sizePolicy3.setHeightForWidth(self.main_dro_qframe_2.sizePolicy().hasHeightForWidth())
        self.main_dro_qframe_2.setSizePolicy(sizePolicy3)
        self.main_dro_qframe_2.setMinimumSize(QSize(490, 340))
        self.main_dro_qframe_2.setMaximumSize(QSize(490, 340))
        self.main_dro_qframe_2.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_dro_qframe_2.setStyleSheet(u".QFrame{\n"
"    border-left-width: 1px;\n"
"    border-right-width:1px;\n"
"}")
        self.verticalLayout_46 = QVBoxLayout(self.main_dro_qframe_2)
        self.verticalLayout_46.setSpacing(9)
        self.verticalLayout_46.setObjectName(u"verticalLayout_46")
        self.verticalLayout_46.setContentsMargins(15, 15, 15, 12)
        self.dro_display_layout = QVBoxLayout()
        self.dro_display_layout.setSpacing(12)
        self.dro_display_layout.setObjectName(u"dro_display_layout")

        self.verticalLayout_46.addLayout(self.dro_display_layout)


        self.main_control_screen_layout_panel.addWidget(self.main_dro_qframe_2)

        self.jog_and_spindle_qframe = QFrame(self.centralwidget)
        self.jog_and_spindle_qframe.setObjectName(u"jog_and_spindle_qframe")
        sizePolicy3.setHeightForWidth(self.jog_and_spindle_qframe.sizePolicy().hasHeightForWidth())
        self.jog_and_spindle_qframe.setSizePolicy(sizePolicy3)
        self.jog_and_spindle_qframe.setMinimumSize(QSize(440, 340))
        self.jog_and_spindle_qframe.setMaximumSize(QSize(440, 340))
        self.jog_and_spindle_qframe.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.jog_and_spindle_qframe.setStyleSheet(u".QFrame{\n"
"    border-left-width: 1px;\n"
"    border-right-width:1px;\n"
"}")
        self.verticalLayout_51 = QVBoxLayout(self.jog_and_spindle_qframe)
        self.verticalLayout_51.setSpacing(12)
        self.verticalLayout_51.setObjectName(u"verticalLayout_51")
        self.verticalLayout_51.setContentsMargins(15, 14, 15, 9)
        self.widget_30 = QWidget(self.jog_and_spindle_qframe)
        self.widget_30.setObjectName(u"widget_30")
        sizePolicy8.setHeightForWidth(self.widget_30.sizePolicy().hasHeightForWidth())
        self.widget_30.setSizePolicy(sizePolicy8)
        self.horizontalLayout_14 = QHBoxLayout(self.widget_30)
        self.horizontalLayout_14.setSpacing(9)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.horizontalLayout_14.setContentsMargins(1, 1, 1, 1)
        self.widget_26 = QWidget(self.widget_30)
        self.widget_26.setObjectName(u"widget_26")
        self.verticalLayout_24 = QVBoxLayout(self.widget_26)
        self.verticalLayout_24.setSpacing(15)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.verticalLayout_24.setContentsMargins(0, 0, 2, 0)
        self.widget_29 = QWidget(self.widget_26)
        self.widget_29.setObjectName(u"widget_29")
        sizePolicy4.setHeightForWidth(self.widget_29.sizePolicy().hasHeightForWidth())
        self.widget_29.setSizePolicy(sizePolicy4)
        self.horizontalLayout_22 = QHBoxLayout(self.widget_29)
        self.horizontalLayout_22.setSpacing(9)
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.horizontalLayout_22.setContentsMargins(0, 2, 0, 2)
        self.g96_rpm_mode_button = MDIButton(self.widget_29)
        self.rpmcontrolbtnGroup = QButtonGroup(Form)
        self.rpmcontrolbtnGroup.setObjectName(u"rpmcontrolbtnGroup")
        self.rpmcontrolbtnGroup.addButton(self.g96_rpm_mode_button)
        self.g96_rpm_mode_button.setObjectName(u"g96_rpm_mode_button")
        sizePolicy6.setHeightForWidth(self.g96_rpm_mode_button.sizePolicy().hasHeightForWidth())
        self.g96_rpm_mode_button.setSizePolicy(sizePolicy6)
        self.g96_rpm_mode_button.setMinimumSize(QSize(100, 40))
        self.g96_rpm_mode_button.setMaximumSize(QSize(16777215, 40))
        self.g96_rpm_mode_button.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.g96_rpm_mode_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g96_rpm_mode_button.setCheckable(True)
        self.g96_rpm_mode_button.setChecked(False)
        self.g96_rpm_mode_button.setAutoExclusive(True)

        self.horizontalLayout_22.addWidget(self.g96_rpm_mode_button)

        self.g97_rpm_mode_button = MDIButton(self.widget_29)
        self.rpmcontrolbtnGroup.addButton(self.g97_rpm_mode_button)
        self.g97_rpm_mode_button.setObjectName(u"g97_rpm_mode_button")
        sizePolicy6.setHeightForWidth(self.g97_rpm_mode_button.sizePolicy().hasHeightForWidth())
        self.g97_rpm_mode_button.setSizePolicy(sizePolicy6)
        self.g97_rpm_mode_button.setMinimumSize(QSize(100, 40))
        self.g97_rpm_mode_button.setMaximumSize(QSize(16777215, 40))
        self.g97_rpm_mode_button.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.g97_rpm_mode_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.g97_rpm_mode_button.setCheckable(True)
        self.g97_rpm_mode_button.setChecked(False)
        self.g97_rpm_mode_button.setAutoExclusive(True)

        self.horizontalLayout_22.addWidget(self.g97_rpm_mode_button)


        self.verticalLayout_24.addWidget(self.widget_29)

        self.widget_80 = QWidget(self.widget_26)
        self.widget_80.setObjectName(u"widget_80")
        self.horizontalLayout_79 = QHBoxLayout(self.widget_80)
        self.horizontalLayout_79.setSpacing(9)
        self.horizontalLayout_79.setObjectName(u"horizontalLayout_79")
        self.horizontalLayout_79.setContentsMargins(0, 2, 0, 2)
        self.feed_upm_button = MDIButton(self.widget_80)
        self.feedtypebtnGroup = QButtonGroup(Form)
        self.feedtypebtnGroup.setObjectName(u"feedtypebtnGroup")
        self.feedtypebtnGroup.addButton(self.feed_upm_button)
        self.feed_upm_button.setObjectName(u"feed_upm_button")
        sizePolicy3.setHeightForWidth(self.feed_upm_button.sizePolicy().hasHeightForWidth())
        self.feed_upm_button.setSizePolicy(sizePolicy3)
        self.feed_upm_button.setMinimumSize(QSize(100, 40))
        self.feed_upm_button.setMaximumSize(QSize(100, 40))
        self.feed_upm_button.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.feed_upm_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.feed_upm_button.setCheckable(True)
        self.feed_upm_button.setChecked(False)
        self.feed_upm_button.setAutoExclusive(True)

        self.horizontalLayout_79.addWidget(self.feed_upm_button)

        self.feed_per_unit = VCPSettingsLineEdit(self.widget_80)
        self.feed_per_unit.setObjectName(u"feed_per_unit")
        self.feed_per_unit.setMinimumSize(QSize(100, 38))
        self.feed_per_unit.setMaximumSize(QSize(100, 38))
        self.feed_per_unit.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.feed_per_unit.setStyleSheet(u"VCPSettingsLineEdit[style='active']{\n"
"    background-color:rgb(105, 109, 255);\n"
"    border-color:rgb(105, 109, 255);\n"
"}\n"
"\n"
"VCPSettingsLineEdit[style='inactive']{\n"
"}")
        self.feed_per_unit.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.feed_per_unit.setProperty(u"displayDecimals", 1)

        self.horizontalLayout_79.addWidget(self.feed_per_unit)


        self.verticalLayout_24.addWidget(self.widget_80)

        self.widget_65 = QWidget(self.widget_26)
        self.widget_65.setObjectName(u"widget_65")
        self.horizontalLayout_76 = QHBoxLayout(self.widget_65)
        self.horizontalLayout_76.setSpacing(9)
        self.horizontalLayout_76.setObjectName(u"horizontalLayout_76")
        self.horizontalLayout_76.setContentsMargins(0, 2, 0, 2)
        self.feed_per_rev_button = MDIButton(self.widget_65)
        self.feedtypebtnGroup.addButton(self.feed_per_rev_button)
        self.feed_per_rev_button.setObjectName(u"feed_per_rev_button")
        sizePolicy3.setHeightForWidth(self.feed_per_rev_button.sizePolicy().hasHeightForWidth())
        self.feed_per_rev_button.setSizePolicy(sizePolicy3)
        self.feed_per_rev_button.setMinimumSize(QSize(100, 40))
        self.feed_per_rev_button.setMaximumSize(QSize(100, 40))
        self.feed_per_rev_button.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.feed_per_rev_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.feed_per_rev_button.setCheckable(True)
        self.feed_per_rev_button.setChecked(False)
        self.feed_per_rev_button.setAutoExclusive(True)

        self.horizontalLayout_76.addWidget(self.feed_per_rev_button)

        self.feed_unit_per_rev = VCPSettingsLineEdit(self.widget_65)
        self.feed_unit_per_rev.setObjectName(u"feed_unit_per_rev")
        self.feed_unit_per_rev.setMinimumSize(QSize(100, 38))
        self.feed_unit_per_rev.setMaximumSize(QSize(100, 38))
        self.feed_unit_per_rev.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.feed_unit_per_rev.setStyleSheet(u"VCPSettingsLineEdit[style='active']{\n"
"    background-color:rgb(105, 109, 255);\n"
"    border-color:rgb(105, 109, 255);\n"
"}\n"
"\n"
"VCPSettingsLineEdit[style='inactive']{\n"
"}")
        self.feed_unit_per_rev.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_76.addWidget(self.feed_unit_per_rev)


        self.verticalLayout_24.addWidget(self.widget_65)


        self.horizontalLayout_14.addWidget(self.widget_26)

        self.line_3 = QFrame(self.widget_30)
        self.line_3.setObjectName(u"line_3")
        self.line_3.setMinimumSize(QSize(2, 0))
        self.line_3.setMaximumSize(QSize(2, 16777215))
        self.line_3.setAutoFillBackground(False)
        self.line_3.setStyleSheet(u"background-color: rgb(186, 189, 182);")
        self.line_3.setLineWidth(1)
        self.line_3.setMidLineWidth(1)
        self.line_3.setFrameShape(QFrame.Shape.VLine)
        self.line_3.setFrameShadow(QFrame.Shadow.Sunken)

        self.horizontalLayout_14.addWidget(self.line_3)

        self.widget_31 = QWidget(self.widget_30)
        self.widget_31.setObjectName(u"widget_31")
        sizePolicy4.setHeightForWidth(self.widget_31.sizePolicy().hasHeightForWidth())
        self.widget_31.setSizePolicy(sizePolicy4)
        self.verticalLayout_16 = QVBoxLayout(self.widget_31)
        self.verticalLayout_16.setSpacing(15)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.widget_34 = QWidget(self.widget_31)
        self.widget_34.setObjectName(u"widget_34")
        self.horizontalLayout_33 = QHBoxLayout(self.widget_34)
        self.horizontalLayout_33.setObjectName(u"horizontalLayout_33")
        self.horizontalLayout_33.setContentsMargins(0, 2, 0, 2)
        self.statuslabel_9 = StatusLabel(self.widget_34)
        self.statuslabel_9.setObjectName(u"statuslabel_9")
        sizePolicy6.setHeightForWidth(self.statuslabel_9.sizePolicy().hasHeightForWidth())
        self.statuslabel_9.setSizePolicy(sizePolicy6)
        self.statuslabel_9.setMinimumSize(QSize(0, 30))
        self.statuslabel_9.setMaximumSize(QSize(70, 30))
        self.statuslabel_9.setStyleSheet(u"StatusLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_9.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_33.addWidget(self.statuslabel_9)

        self.rpm_s_word = VCPSettingsLineEdit(self.widget_34)
        self.rpm_s_word.setObjectName(u"rpm_s_word")
        self.rpm_s_word.setMinimumSize(QSize(95, 38))
        self.rpm_s_word.setMaximumSize(QSize(95, 38))
        self.rpm_s_word.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.rpm_s_word.setStyleSheet(u"VCPSettingsLineEdit[style='active']{\n"
"    background-color:rgb(105, 109, 255);\n"
"    border-color:rgb(105, 109, 255);\n"
"}\n"
"\n"
"VCPSettingsLineEdit[style='inactive']{\n"
"}")
        self.rpm_s_word.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.rpm_s_word.setProperty(u"displayDecimals", 0)

        self.horizontalLayout_33.addWidget(self.rpm_s_word)


        self.verticalLayout_16.addWidget(self.widget_34)

        self.widget_66 = QWidget(self.widget_31)
        self.widget_66.setObjectName(u"widget_66")
        self.horizontalLayout_150 = QHBoxLayout(self.widget_66)
        self.horizontalLayout_150.setSpacing(9)
        self.horizontalLayout_150.setObjectName(u"horizontalLayout_150")
        self.horizontalLayout_150.setContentsMargins(0, 2, 0, 2)
        self.statuslabel_7 = StatusLabel(self.widget_66)
        self.statuslabel_7.setObjectName(u"statuslabel_7")
        sizePolicy6.setHeightForWidth(self.statuslabel_7.sizePolicy().hasHeightForWidth())
        self.statuslabel_7.setSizePolicy(sizePolicy6)
        self.statuslabel_7.setMinimumSize(QSize(0, 30))
        self.statuslabel_7.setMaximumSize(QSize(70, 30))
        self.statuslabel_7.setStyleSheet(u"StatusLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_7.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_150.addWidget(self.statuslabel_7)

        self.css_max_rpm = VCPSettingsLineEdit(self.widget_66)
        self.css_max_rpm.setObjectName(u"css_max_rpm")
        self.css_max_rpm.setMinimumSize(QSize(95, 38))
        self.css_max_rpm.setMaximumSize(QSize(95, 38))
        self.css_max_rpm.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.css_max_rpm.setStyleSheet(u"VCPSettingsLineEdit[style='active']{\n"
"    background-color:rgb(105, 109, 255);\n"
"    border-color:rgb(105, 109, 255);\n"
"}\n"
"\n"
"VCPSettingsLineEdit[style='inactive']{\n"
"}")
        self.css_max_rpm.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.css_max_rpm.setProperty(u"displayDecimals", 0)

        self.horizontalLayout_150.addWidget(self.css_max_rpm)


        self.verticalLayout_16.addWidget(self.widget_66)

        self.widget_35 = QWidget(self.widget_31)
        self.widget_35.setObjectName(u"widget_35")
        self.horizontalLayout_27 = QHBoxLayout(self.widget_35)
        self.horizontalLayout_27.setSpacing(9)
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.horizontalLayout_27.setContentsMargins(0, 2, 0, 2)
        self.statuslabel_6 = StatusLabel(self.widget_35)
        self.statuslabel_6.setObjectName(u"statuslabel_6")
        sizePolicy6.setHeightForWidth(self.statuslabel_6.sizePolicy().hasHeightForWidth())
        self.statuslabel_6.setSizePolicy(sizePolicy6)
        self.statuslabel_6.setMaximumSize(QSize(70, 30))
        self.statuslabel_6.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.statuslabel_6.setStyleSheet(u"StatusLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_6.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_27.addWidget(self.statuslabel_6)

        self.css_surface_speed = VCPSettingsLineEdit(self.widget_35)
        self.css_surface_speed.setObjectName(u"css_surface_speed")
        self.css_surface_speed.setMinimumSize(QSize(95, 38))
        self.css_surface_speed.setMaximumSize(QSize(95, 38))
        self.css_surface_speed.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.css_surface_speed.setStyleSheet(u"VCPSettingsLineEdit[style='active']{\n"
"    background-color:rgb(105, 109, 255);\n"
"    border-color:rgb(105, 109, 255);\n"
"}\n"
"\n"
"VCPSettingsLineEdit[style='inactive']{\n"
"}")
        self.css_surface_speed.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.css_surface_speed.setProperty(u"displayDecimals", 0)

        self.horizontalLayout_27.addWidget(self.css_surface_speed)


        self.verticalLayout_16.addWidget(self.widget_35)


        self.horizontalLayout_14.addWidget(self.widget_31)


        self.verticalLayout_51.addWidget(self.widget_30)

        self.line_4 = QFrame(self.jog_and_spindle_qframe)
        self.line_4.setObjectName(u"line_4")
        self.line_4.setMaximumSize(QSize(16777215, 2))
        self.line_4.setLineWidth(0)
        self.line_4.setMidLineWidth(1)
        self.line_4.setFrameShape(QFrame.Shape.HLine)
        self.line_4.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_51.addWidget(self.line_4)

        self.widget_70 = QWidget(self.jog_and_spindle_qframe)
        self.widget_70.setObjectName(u"widget_70")
        self.horizontalLayout_152 = QHBoxLayout(self.widget_70)
        self.horizontalLayout_152.setSpacing(9)
        self.horizontalLayout_152.setObjectName(u"horizontalLayout_152")
        self.horizontalLayout_152.setContentsMargins(0, 1, 0, 1)
        self.statuslabel_4 = StatusLabel(self.widget_70)
        self.statuslabel_4.setObjectName(u"statuslabel_4")
        sizePolicy6.setHeightForWidth(self.statuslabel_4.sizePolicy().hasHeightForWidth())
        self.statuslabel_4.setSizePolicy(sizePolicy6)
        self.statuslabel_4.setMinimumSize(QSize(40, 30))
        self.statuslabel_4.setMaximumSize(QSize(40, 30))
        self.statuslabel_4.setStyleSheet(u"StatusLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_152.addWidget(self.statuslabel_4)

        self.statuslabel_27 = StatusLabel(self.widget_70)
        self.statuslabel_27.setObjectName(u"statuslabel_27")
        sizePolicy6.setHeightForWidth(self.statuslabel_27.sizePolicy().hasHeightForWidth())
        self.statuslabel_27.setSizePolicy(sizePolicy6)
        self.statuslabel_27.setMinimumSize(QSize(100, 38))
        self.statuslabel_27.setMaximumSize(QSize(100, 38))
        self.statuslabel_27.setStyleSheet(u"QLabel {\n"
"    border-style: solid;\n"
"    border-color: rgb(96, 96, 97);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: white;\n"
"    background: rgb(86, 86, 87);\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_27.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_152.addWidget(self.statuslabel_27)

        self.statuslabel_8 = StatusLabel(self.widget_70)
        self.statuslabel_8.setObjectName(u"statuslabel_8")
        sizePolicy6.setHeightForWidth(self.statuslabel_8.sizePolicy().hasHeightForWidth())
        self.statuslabel_8.setSizePolicy(sizePolicy6)
        self.statuslabel_8.setMinimumSize(QSize(50, 30))
        self.statuslabel_8.setMaximumSize(QSize(50, 30))
        self.statuslabel_8.setStyleSheet(u"StatusLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.statuslabel_8.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_152.addWidget(self.statuslabel_8)

        self.widget_27 = QWidget(self.widget_70)
        self.widget_27.setObjectName(u"widget_27")
        sizePolicy4.setHeightForWidth(self.widget_27.sizePolicy().hasHeightForWidth())
        self.widget_27.setSizePolicy(sizePolicy4)

        self.horizontalLayout_152.addWidget(self.widget_27)

        self.widget_77 = QWidget(self.widget_70)
        self.widget_77.setObjectName(u"widget_77")
        self.horizontalLayout_153 = QHBoxLayout(self.widget_77)
        self.horizontalLayout_153.setSpacing(9)
        self.horizontalLayout_153.setObjectName(u"horizontalLayout_153")
        self.horizontalLayout_153.setContentsMargins(0, 2, 0, 2)
        self.spindle_rpm_source_widget = QStackedWidget(self.widget_77)
        self.spindle_rpm_source_widget.setObjectName(u"spindle_rpm_source_widget")
        sizePolicy3.setHeightForWidth(self.spindle_rpm_source_widget.sizePolicy().hasHeightForWidth())
        self.spindle_rpm_source_widget.setSizePolicy(sizePolicy3)
        self.spindle_rpm_source_widget.setMinimumSize(QSize(100, 38))
        self.spindle_rpm_source_widget.setMaximumSize(QSize(100, 38))
        self.spindle_rpm_source_widget.setStyleSheet(u"QWidget {\n"
"    border-style: solid;\n"
"    border-color: rgb(96, 96, 97);\n"
"    border-width: 1px;\n"
"    border-radius: 5px;\n"
"    color: white;\n"
"    background: rgb(86, 86, 87);\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.spindle_rpm_source_widget.setLineWidth(1)
        self.spindle_status_rpm = QWidget()
        self.spindle_status_rpm.setObjectName(u"spindle_status_rpm")
        sizePolicy6.setHeightForWidth(self.spindle_status_rpm.sizePolicy().hasHeightForWidth())
        self.spindle_status_rpm.setSizePolicy(sizePolicy6)
        self.verticalLayout_32 = QVBoxLayout(self.spindle_status_rpm)
        self.verticalLayout_32.setSpacing(0)
        self.verticalLayout_32.setObjectName(u"verticalLayout_32")
        self.verticalLayout_32.setContentsMargins(0, 0, 0, 0)
        self.spindle_stat_rpm = StatusLabel(self.spindle_status_rpm)
        self.spindle_stat_rpm.setObjectName(u"spindle_stat_rpm")
        sizePolicy6.setHeightForWidth(self.spindle_stat_rpm.sizePolicy().hasHeightForWidth())
        self.spindle_stat_rpm.setSizePolicy(sizePolicy6)
        self.spindle_stat_rpm.setMinimumSize(QSize(82, 38))
        self.spindle_stat_rpm.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_32.addWidget(self.spindle_stat_rpm)

        self.spindle_rpm_source_widget.addWidget(self.spindle_status_rpm)
        self.spindle_encode_rpm = QWidget()
        self.spindle_encode_rpm.setObjectName(u"spindle_encode_rpm")
        self.spindle_encode_rpm.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.spindle_encode_rpm.sizePolicy().hasHeightForWidth())
        self.spindle_encode_rpm.setSizePolicy(sizePolicy3)
        self.spindle_encode_rpm.setAutoFillBackground(False)
        self._4 = QHBoxLayout(self.spindle_encode_rpm)
        self._4.setSpacing(0)
        self._4.setObjectName(u"_4")
        self._4.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self._4.setContentsMargins(0, 0, 0, 0)
        self.spindle_encoder_rpm = HalLabel(self.spindle_encode_rpm)
        self.spindle_encoder_rpm.setObjectName(u"spindle_encoder_rpm")
        sizePolicy6.setHeightForWidth(self.spindle_encoder_rpm.sizePolicy().hasHeightForWidth())
        self.spindle_encoder_rpm.setSizePolicy(sizePolicy6)
        self.spindle_encoder_rpm.setMinimumSize(QSize(82, 38))
        self.spindle_encoder_rpm.setTextFormat(Qt.TextFormat.AutoText)
        self.spindle_encoder_rpm.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self._4.addWidget(self.spindle_encoder_rpm)

        self.spindle_rpm_source_widget.addWidget(self.spindle_encode_rpm)

        self.horizontalLayout_153.addWidget(self.spindle_rpm_source_widget)

        self.rpm_label_9 = QLabel(self.widget_77)
        self.rpm_label_9.setObjectName(u"rpm_label_9")
        sizePolicy6.setHeightForWidth(self.rpm_label_9.sizePolicy().hasHeightForWidth())
        self.rpm_label_9.setSizePolicy(sizePolicy6)
        self.rpm_label_9.setMinimumSize(QSize(32, 30))
        self.rpm_label_9.setMaximumSize(QSize(32, 30))
        self.rpm_label_9.setStyleSheet(u"QLabel{\n"
"    border: none;\n"
"    color: rgb(238, 238, 236);\n"
"    background: transparent;\n"
"	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.rpm_label_9.setLineWidth(0)
        self.rpm_label_9.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.rpm_label_9.setWordWrap(False)
        self.rpm_label_9.setIndent(0)

        self.horizontalLayout_153.addWidget(self.rpm_label_9)


        self.horizontalLayout_152.addWidget(self.widget_77)


        self.verticalLayout_51.addWidget(self.widget_70)

        self.line = QFrame(self.jog_and_spindle_qframe)
        self.line.setObjectName(u"line")
        self.line.setMaximumSize(QSize(16777215, 2))
        self.line.setStyleSheet(u"color:rgb(186, 189, 182);")
        self.line.setLineWidth(0)
        self.line.setMidLineWidth(1)
        self.line.setFrameShape(QFrame.Shape.HLine)
        self.line.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_51.addWidget(self.line)

        self.spindle_controls_stacked_widget = VCPStackedWidget(self.jog_and_spindle_qframe)
        self.spindle_controls_stacked_widget.setObjectName(u"spindle_controls_stacked_widget")
        self.g96_spindle_control_page = QWidget()
        self.g96_spindle_control_page.setObjectName(u"g96_spindle_control_page")
        self.horizontalLayout_43 = QHBoxLayout(self.g96_spindle_control_page)
        self.horizontalLayout_43.setObjectName(u"horizontalLayout_43")
        self.horizontalLayout_43.setContentsMargins(1, 2, 1, 2)
        self.spindle_rev_m4_mdi_button = MDIButton(self.g96_spindle_control_page)
        self.spindle_rev_m4_mdi_button.setObjectName(u"spindle_rev_m4_mdi_button")
        self.spindle_rev_m4_mdi_button.setMinimumSize(QSize(130, 42))
        self.spindle_rev_m4_mdi_button.setMaximumSize(QSize(16777215, 42))
        self.spindle_rev_m4_mdi_button.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.spindle_rev_m4_mdi_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}\n"
"\n"
"QPushButton[style='inactive']{\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton[style='active']{\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")
        icon39 = QIcon()
        icon39.addFile(u":/images/ccw_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.spindle_rev_m4_mdi_button.setIcon(icon39)

        self.horizontalLayout_43.addWidget(self.spindle_rev_m4_mdi_button)

        self.widget_68 = QWidget(self.g96_spindle_control_page)
        self.widget_68.setObjectName(u"widget_68")

        self.horizontalLayout_43.addWidget(self.widget_68)

        self.spindle_stop_m5_mdi_button = MDIButton(self.g96_spindle_control_page)
        self.spindle_stop_m5_mdi_button.setObjectName(u"spindle_stop_m5_mdi_button")
        self.spindle_stop_m5_mdi_button.setMinimumSize(QSize(100, 42))
        self.spindle_stop_m5_mdi_button.setMaximumSize(QSize(16777215, 42))
        self.spindle_stop_m5_mdi_button.setLayoutDirection(Qt.LayoutDirection.RightToLeft)

        self.horizontalLayout_43.addWidget(self.spindle_stop_m5_mdi_button)

        self.widget_69 = QWidget(self.g96_spindle_control_page)
        self.widget_69.setObjectName(u"widget_69")

        self.horizontalLayout_43.addWidget(self.widget_69)

        self.spindle_fwd_m3_mdi_button = MDIButton(self.g96_spindle_control_page)
        self.spindle_fwd_m3_mdi_button.setObjectName(u"spindle_fwd_m3_mdi_button")
        self.spindle_fwd_m3_mdi_button.setMinimumSize(QSize(130, 42))
        self.spindle_fwd_m3_mdi_button.setMaximumSize(QSize(16777215, 42))
        self.spindle_fwd_m3_mdi_button.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.spindle_fwd_m3_mdi_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}\n"
"\n"
"QPushButton[style='inactive']{\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton[style='active']{\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")
        icon40 = QIcon()
        icon40.addFile(u":/images/cw_arrow.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.spindle_fwd_m3_mdi_button.setIcon(icon40)

        self.horizontalLayout_43.addWidget(self.spindle_fwd_m3_mdi_button)

        self.spindle_controls_stacked_widget.addWidget(self.g96_spindle_control_page)
        self.g97_spindle_control_page = QWidget()
        self.g97_spindle_control_page.setObjectName(u"g97_spindle_control_page")
        self.horizontalLayout_44 = QHBoxLayout(self.g97_spindle_control_page)
        self.horizontalLayout_44.setObjectName(u"horizontalLayout_44")
        self.horizontalLayout_44.setContentsMargins(1, 2, 1, 2)
        self.spindle_rev_m4_mdi_button_2 = MDIButton(self.g97_spindle_control_page)
        self.spindle_rev_m4_mdi_button_2.setObjectName(u"spindle_rev_m4_mdi_button_2")
        self.spindle_rev_m4_mdi_button_2.setMinimumSize(QSize(130, 42))
        self.spindle_rev_m4_mdi_button_2.setMaximumSize(QSize(16777215, 42))
        self.spindle_rev_m4_mdi_button_2.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.spindle_rev_m4_mdi_button_2.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}\n"
"\n"
"QPushButton[style='inactive']{\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton[style='active']{\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")
        self.spindle_rev_m4_mdi_button_2.setIcon(icon39)

        self.horizontalLayout_44.addWidget(self.spindle_rev_m4_mdi_button_2)

        self.widget_85 = QWidget(self.g97_spindle_control_page)
        self.widget_85.setObjectName(u"widget_85")

        self.horizontalLayout_44.addWidget(self.widget_85)

        self.spindle_stop_m5_mdi_button_2 = MDIButton(self.g97_spindle_control_page)
        self.spindle_stop_m5_mdi_button_2.setObjectName(u"spindle_stop_m5_mdi_button_2")
        self.spindle_stop_m5_mdi_button_2.setMinimumSize(QSize(100, 42))
        self.spindle_stop_m5_mdi_button_2.setMaximumSize(QSize(16777215, 42))
        self.spindle_stop_m5_mdi_button_2.setLayoutDirection(Qt.LayoutDirection.RightToLeft)

        self.horizontalLayout_44.addWidget(self.spindle_stop_m5_mdi_button_2)

        self.widget_81 = QWidget(self.g97_spindle_control_page)
        self.widget_81.setObjectName(u"widget_81")

        self.horizontalLayout_44.addWidget(self.widget_81)

        self.spindle_fwd_m3_mdi_button_2 = MDIButton(self.g97_spindle_control_page)
        self.spindle_fwd_m3_mdi_button_2.setObjectName(u"spindle_fwd_m3_mdi_button_2")
        self.spindle_fwd_m3_mdi_button_2.setMinimumSize(QSize(130, 42))
        self.spindle_fwd_m3_mdi_button_2.setMaximumSize(QSize(16777215, 42))
        self.spindle_fwd_m3_mdi_button_2.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.spindle_fwd_m3_mdi_button_2.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}\n"
"\n"
"QPushButton[style='inactive']{\n"
"    background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255));\n"
"}\n"
"\n"
"QPushButton[style='active']{\n"
"    background:  qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(85, 85, 238, 255), stop:0.544974 rgba(90, 91, 239, 255), stop:1 rgba(126, 135, 243, 255));\n"
"}")
        self.spindle_fwd_m3_mdi_button_2.setIcon(icon40)

        self.horizontalLayout_44.addWidget(self.spindle_fwd_m3_mdi_button_2)

        self.spindle_controls_stacked_widget.addWidget(self.g97_spindle_control_page)

        self.verticalLayout_51.addWidget(self.spindle_controls_stacked_widget)


        self.main_control_screen_layout_panel.addWidget(self.jog_and_spindle_qframe)

        self.main_override_tool_qframe = QFrame(self.centralwidget)
        self.main_override_tool_qframe.setObjectName(u"main_override_tool_qframe")
        sizePolicy6.setHeightForWidth(self.main_override_tool_qframe.sizePolicy().hasHeightForWidth())
        self.main_override_tool_qframe.setSizePolicy(sizePolicy6)
        self.main_override_tool_qframe.setMinimumSize(QSize(200, 340))
        self.main_override_tool_qframe.setMaximumSize(QSize(16777215, 340))
        self.main_override_tool_qframe.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.main_override_tool_qframe.setStyleSheet(u".QFrame{\n"
"    padding-left: 8px;\n"
"    padding-right: 8px;\n"
"    border-left-width: 1px;\n"
"}")
        self.gridLayout_3 = QGridLayout(self.main_override_tool_qframe)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setHorizontalSpacing(10)
        self.gridLayout_3.setVerticalSpacing(15)
        self.gridLayout_3.setContentsMargins(15, 14, 15, 6)
        self.actionslider_7 = ActionSlider(self.main_override_tool_qframe)
        self.actionslider_7.setObjectName(u"actionslider_7")
        self.actionslider_7.setMinimumSize(QSize(0, 50))
        self.actionslider_7.setOrientation(Qt.Orientation.Horizontal)

        self.gridLayout_3.addWidget(self.actionslider_7, 5, 0, 1, 1)

        self.statuslabel_22 = StatusLabel(self.main_override_tool_qframe)
        self.statuslabel_22.setObjectName(u"statuslabel_22")
        sizePolicy3.setHeightForWidth(self.statuslabel_22.sizePolicy().hasHeightForWidth())
        self.statuslabel_22.setSizePolicy(sizePolicy3)
        self.statuslabel_22.setMinimumSize(QSize(50, 36))
        self.statuslabel_22.setMaximumSize(QSize(50, 36))
        self.statuslabel_22.setLineWidth(0)
        self.statuslabel_22.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.statuslabel_22.setMargin(-6)
        self.statuslabel_22.setIndent(0)

        self.gridLayout_3.addWidget(self.statuslabel_22, 5, 2, 1, 1)

        self.widget_63 = QWidget(self.main_override_tool_qframe)
        self.widget_63.setObjectName(u"widget_63")
        self.widget_63.setMaximumSize(QSize(16777215, 42))
        self.horizontalLayout_72 = QHBoxLayout(self.widget_63)
        self.horizontalLayout_72.setSpacing(15)
        self.horizontalLayout_72.setObjectName(u"horizontalLayout_72")
        self.horizontalLayout_72.setContentsMargins(0, 0, 0, 0)
        self.spindle_load_indicator = HalBarIndicator(self.widget_63)
        self.spindle_load_indicator.setObjectName(u"spindle_load_indicator")
        self.spindle_load_indicator.setMinimumSize(QSize(0, 30))
        self.spindle_load_indicator.setMaximumSize(QSize(16777215, 30))
        self.spindle_load_indicator.setFont(font8)
        self.spindle_load_indicator.setStyleSheet(u"")
        self.spindle_load_indicator.setProperty(u"value", 100.000000000000000)
        self.spindle_load_indicator.setProperty(u"maximum", 150.000000000000000)
        self.spindle_load_indicator.setProperty(u"textColor", QColor(255, 255, 255))

        self.horizontalLayout_72.addWidget(self.spindle_load_indicator)

        self.work_column_header_9 = QLabel(self.widget_63)
        self.work_column_header_9.setObjectName(u"work_column_header_9")
        self.work_column_header_9.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.work_column_header_9.sizePolicy().hasHeightForWidth())
        self.work_column_header_9.setSizePolicy(sizePolicy3)
        self.work_column_header_9.setMinimumSize(QSize(55, 40))
        self.work_column_header_9.setMaximumSize(QSize(55, 40))
        self.work_column_header_9.setStyleSheet(u"QLabel{\n"
"color: white;\n"
"border-style: solid;\n"
"border-color: rgb(176, 179,172);\n"
"border-width: 1px;\n"
"border-radius: 4px;\n"
"background-color: rgb(90, 90, 90);\n"
"font: 13pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.work_column_header_9.setLineWidth(0)
        self.work_column_header_9.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.work_column_header_9.setWordWrap(False)
        self.work_column_header_9.setMargin(-6)
        self.work_column_header_9.setIndent(0)

        self.horizontalLayout_72.addWidget(self.work_column_header_9)


        self.gridLayout_3.addWidget(self.widget_63, 0, 0, 1, 4)

        self.statuslabel_24 = StatusLabel(self.main_override_tool_qframe)
        self.statuslabel_24.setObjectName(u"statuslabel_24")
        sizePolicy3.setHeightForWidth(self.statuslabel_24.sizePolicy().hasHeightForWidth())
        self.statuslabel_24.setSizePolicy(sizePolicy3)
        self.statuslabel_24.setMinimumSize(QSize(50, 36))
        self.statuslabel_24.setMaximumSize(QSize(50, 36))
        self.statuslabel_24.setToolTipDuration(-1)
        self.statuslabel_24.setLineWidth(0)
        self.statuslabel_24.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.statuslabel_24.setMargin(-6)
        self.statuslabel_24.setProperty(u"conv_factor", 60.000000000000000)

        self.gridLayout_3.addWidget(self.statuslabel_24, 1, 2, 1, 1)

        self.statuslabel_5 = StatusLabel(self.main_override_tool_qframe)
        self.statuslabel_5.setObjectName(u"statuslabel_5")
        sizePolicy3.setHeightForWidth(self.statuslabel_5.sizePolicy().hasHeightForWidth())
        self.statuslabel_5.setSizePolicy(sizePolicy3)
        self.statuslabel_5.setMinimumSize(QSize(50, 36))
        self.statuslabel_5.setMaximumSize(QSize(50, 36))
        self.statuslabel_5.setToolTipDuration(-3)
        self.statuslabel_5.setLineWidth(0)
        self.statuslabel_5.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.statuslabel_5.setMargin(-6)
        self.statuslabel_5.setIndent(0)

        self.gridLayout_3.addWidget(self.statuslabel_5, 2, 2, 1, 1)

        self.actionbutton_59 = ActionButton(self.main_override_tool_qframe)
        self.actionbutton_59.setObjectName(u"actionbutton_59")
        self.actionbutton_59.setMinimumSize(QSize(55, 48))
        self.actionbutton_59.setMaximumSize(QSize(55, 48))
        self.actionbutton_59.setStyleSheet(u"QPushButton {\n"
"   	font: 12pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.gridLayout_3.addWidget(self.actionbutton_59, 5, 3, 1, 1)

        self.actionslider_6 = ActionSlider(self.main_override_tool_qframe)
        self.actionslider_6.setObjectName(u"actionslider_6")
        self.actionslider_6.setMinimumSize(QSize(0, 50))
        self.actionslider_6.setOrientation(Qt.Orientation.Horizontal)

        self.gridLayout_3.addWidget(self.actionslider_6, 4, 0, 1, 1)

        self.actionbutton_58 = ActionButton(self.main_override_tool_qframe)
        self.actionbutton_58.setObjectName(u"actionbutton_58")
        self.actionbutton_58.setMinimumSize(QSize(55, 48))
        self.actionbutton_58.setMaximumSize(QSize(55, 48))
        self.actionbutton_58.setStyleSheet(u"QPushButton {\n"
"   	font: 12pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.gridLayout_3.addWidget(self.actionbutton_58, 1, 3, 1, 1)

        self.statuslabel_32 = StatusLabel(self.main_override_tool_qframe)
        self.statuslabel_32.setObjectName(u"statuslabel_32")
        sizePolicy3.setHeightForWidth(self.statuslabel_32.sizePolicy().hasHeightForWidth())
        self.statuslabel_32.setSizePolicy(sizePolicy3)
        self.statuslabel_32.setMinimumSize(QSize(55, 36))
        self.statuslabel_32.setMaximumSize(QSize(55, 36))
        self.statuslabel_32.setLineWidth(0)
        self.statuslabel_32.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.statuslabel_32.setMargin(-6)
        self.statuslabel_32.setIndent(0)

        self.gridLayout_3.addWidget(self.statuslabel_32, 4, 2, 1, 1)

        self.actionbutton_56 = ActionButton(self.main_override_tool_qframe)
        self.actionbutton_56.setObjectName(u"actionbutton_56")
        self.actionbutton_56.setMinimumSize(QSize(55, 48))
        self.actionbutton_56.setMaximumSize(QSize(55, 48))
        self.actionbutton_56.setStyleSheet(u"QPushButton {\n"
"   	font: 12pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.gridLayout_3.addWidget(self.actionbutton_56, 4, 3, 1, 1)

        self.actionslider_9 = ActionSlider(self.main_override_tool_qframe)
        self.actionslider_9.setObjectName(u"actionslider_9")
        self.actionslider_9.setMinimumSize(QSize(0, 50))
        self.actionslider_9.setMaximum(100)
        self.actionslider_9.setOrientation(Qt.Orientation.Horizontal)

        self.gridLayout_3.addWidget(self.actionslider_9, 2, 0, 1, 1)

        self.actionbutton_57 = ActionButton(self.main_override_tool_qframe)
        self.actionbutton_57.setObjectName(u"actionbutton_57")
        self.actionbutton_57.setMinimumSize(QSize(55, 48))
        self.actionbutton_57.setMaximumSize(QSize(55, 48))
        self.actionbutton_57.setStyleSheet(u"QPushButton {\n"
"   	font: 12pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.gridLayout_3.addWidget(self.actionbutton_57, 2, 3, 1, 1)

        self.max_velocity_slider = ActionSlider(self.main_override_tool_qframe)
        self.max_velocity_slider.setObjectName(u"max_velocity_slider")
        self.max_velocity_slider.setMinimumSize(QSize(0, 50))
        self.max_velocity_slider.setOrientation(Qt.Orientation.Horizontal)

        self.gridLayout_3.addWidget(self.max_velocity_slider, 1, 0, 1, 1)


        self.main_control_screen_layout_panel.addWidget(self.main_override_tool_qframe)


        self.verticalLayout_31.addLayout(self.main_control_screen_layout_panel)

        Form.setCentralWidget(self.centralwidget)
        self.menuBar = QMenuBar(Form)
        self.menuBar.setObjectName(u"menuBar")
        self.menuBar.setGeometry(QRect(0, 0, 1927, 25))
        self.menuBar.setMinimumSize(QSize(0, 25))
        self.menuBar.setStyleSheet(u"QMenuBar {\n"
"color: white;\n"
"background: rgb(118, 122, 124);\n"
"font: 11pt Probe Basic Bebas Mono;\n"
"}")
        self.menuExit = QMenu(self.menuBar)
        self.menuExit.setObjectName(u"menuExit")
        self.menuRecentFiles = QMenu(self.menuExit)
        self.menuRecentFiles.setObjectName(u"menuRecentFiles")
        self.menuMachine = QMenu(self.menuBar)
        self.menuMachine.setObjectName(u"menuMachine")
        self.menuHoming = QMenu(self.menuMachine)
        self.menuHoming.setObjectName(u"menuHoming")
        self.menuCooling = QMenu(self.menuMachine)
        self.menuCooling.setObjectName(u"menuCooling")
        self.menuView = QMenu(self.menuBar)
        self.menuView.setObjectName(u"menuView")
        Form.setMenuBar(self.menuBar)
        self.statusBar = QStatusBar(Form)
        self.statusBar.setObjectName(u"statusBar")
        Form.setStatusBar(self.statusBar)

        self.menuBar.addAction(self.menuExit.menuAction())
        self.menuBar.addAction(self.menuMachine.menuAction())
        self.menuBar.addAction(self.menuView.menuAction())
        self.menuExit.addAction(self.actionOpen)
        self.menuExit.addAction(self.menuRecentFiles.menuAction())
        self.menuExit.addAction(self.actionReload)
        self.menuExit.addAction(self.actionClose)
        self.menuExit.addAction(self.actionSave_As)
        self.menuExit.addSeparator()
        self.menuExit.addAction(self.actionExit)
        self.menuRecentFiles.addAction(self.actionFile1)
        self.menuMachine.addAction(self.action_EmergencyStop_toggle)
        self.menuMachine.addAction(self.action_MachinePower_toggle)
        self.menuMachine.addSeparator()
        self.menuMachine.addAction(self.actionRun_Program)
        self.menuMachine.addAction(self.menuHoming.menuAction())
        self.menuMachine.addAction(self.menuCooling.menuAction())
        self.menuHoming.addAction(self.actionHome_All)
        self.menuHoming.addAction(self.actionHome_X)
        self.menuHoming.addAction(self.actionHome_Y)
        self.menuHoming.addAction(self.actionHome_Z)
        self.menuCooling.addAction(self.action_Mist_toggle)
        self.menuCooling.addAction(self.action_Flood_toggle)
        self.menuView.addAction(self.actionReport_Actual_Position)
        self.menuView.addAction(self.actionTest)

        self.retranslateUi(Form)
        self.tool_number_entry_main_panel.returnPressed.connect(self.m6_tool_call_main_panel.click)
        self.feed_unit_per_rev.returnPressed.connect(self.feed_per_rev_button.click)
        self.css_surface_speed.returnPressed.connect(self.g96_rpm_mode_button.click)
        self.feed_per_unit.returnPressed.connect(self.feed_upm_button.click)
        self.rpm_s_word.returnPressed.connect(self.g97_rpm_mode_button.click)
        self.css_max_rpm.returnPressed.connect(self.g96_rpm_mode_button.click)
        self.pan_button.toggled.connect(self.vtkbackplot.enable_panning)
        self.path_button.clicked.connect(self.vtkbackplot.setViewPath)
        self.btn_pause_mdi.toggled.connect(self.mdihistory.toggleQueue)
        self.removabledevicecombobox.usbPresent.connect(self.device_eject_usb_button.setEnabled)
        self.enter.clicked.connect(self.mdihistory.submit)
        self.main_new_file_button.clicked.connect(self.filesystemtable.newFile)
        self.main_delete_item_button.clicked.connect(self.filesystemtable.deleteItem)
        self.btn_row_down_mdi.clicked.connect(self.mdihistory.moveRowItemDown)
        self.btn_row_up_mdi.clicked.connect(self.mdihistory.moveRowItemUp)
        self.device_folder_up_button.clicked.connect(self.filesystemtable_2.viewParentDirectory)
        self.main_rename_item_button.clicked.connect(self.filesystemtable.rename)
        self.mdiEntry.returnPressed.connect(self.enter.click)
        self.copy_to_usb_2.clicked.connect(self.filesystemtable.doFileTransfer)
        self.machine_zoom_button.clicked.connect(self.vtkbackplot.setViewMachine)
        self.main_new_folder_button.clicked.connect(self.filesystemtable.newFolder)
        self.btn_clear_queue_mdi.clicked.connect(self.mdihistory.clearQueue)
        self.save_table_button.clicked.connect(self.offset_table.saveOffsetTable)
        self.clear_button.clicked.connect(self.vtkbackplot.clearLivePlot)
        self.program_zoom_button.clicked.connect(self.vtkbackplot.setViewProgram)
        self.btn_run_from_line_mdi.clicked.connect(self.mdihistory.runFromSelection)
        self.removabledevicecombobox.currentDeviceEjectable.connect(self.device_eject_usb_button.setEnabled)
        self.zoom_out_button.clicked.connect(self.vtkbackplot.zoomOut)
        self.tool_table_reload_button.released.connect(self.m6_tool_call_main_panel.animateClick)
        self.btn_del_history_row_mdi.clicked.connect(self.mdihistory.removeSelectedItem)
        self.main_load_gcode_button.clicked.connect(self.filesystemtable.loadSelectedFile)
        self.device_eject_usb_button.clicked.connect(self.removabledevicecombobox.ejectDevice)
        self.reload_table_button.clicked.connect(self.offset_table.loadOffsetTable)
        self.device_rename_item_button.clicked.connect(self.filesystemtable_2.rename)
        self.btn_copy_to_editor_mdi.clicked.connect(self.mdihistory.copySelectionToGcodeEditor)
        self.filesystemtable.transferFileRequest.connect(self.filesystemtable_2.transferFile)
        self.tool_table_reload_button.clicked.connect(self.tooltable.loadToolTable)
        self.tool_table_add_tool_button.clicked.connect(self.tooltable.addTool)
        self.usb_show_hide_button.toggled.connect(self.usb_file_frame.setHidden)
        self.tool_table_save_button.clicked.connect(self.tooltable.saveToolTable)
        self.zoom_in_button.clicked.connect(self.vtkbackplot.zoomIn)
        self.filesystemtable_2.atDeviceRoot.connect(self.device_folder_up_button.setDisabled)
        self.btn_run_selection_mdi.clicked.connect(self.mdihistory.runSelection)
        self.view_breadcrumbs.toggled.connect(self.vtkbackplot.enableBreadcrumbs)
        self.m01_break_button_20.pressed.connect(self.lathetooltouchoff.reset_tools)
        self.tool_table_delete_button.clicked.connect(self.tooltable.deleteSelectedTool)
        self.device_delete_item_button.clicked.connect(self.filesystemtable_2.deleteItem)
        self.main_folder_up_button.clicked.connect(self.filesystemtable.viewParentDirectory)
        self.filesystemtable_2.transferFileRequest.connect(self.filesystemtable.transferFile)
        self.copy_from_usb_2.clicked.connect(self.filesystemtable_2.doFileTransfer)
        self.usb_show_hide_button.toggled.connect(self.copy_to_usb_2.setHidden)
        self.clear_selected_button.clicked.connect(self.offset_table.deleteSelectedOffset)
        self.tool_number_entry_touch_panel.returnPressed.connect(self.m6_tool_call_touch_panel.click)
        self.btn_del_all_mdi.clicked.connect(self.mdihistory.removeAll)
        self.removabledevicecombobox.currentPathChanged.connect(self.filesystemtable_2.setRootPath)
        self.clear_all_button.clicked.connect(self.offset_table.clearOffsetTable)
        self.edit_gcode_button.toggled.connect(self.gcodeEditor_2.EditorReadWrite)
        self.find_replace_button.clicked.connect(self.gcodeEditor_2.findDialog)
        self.save_button.clicked.connect(self.gcodeEditor_2.saveFile)
        self.save_as_button.clicked.connect(self.gcodeEditor_2.saveFileAs)
        self.undo_button.clicked.connect(self.gcodeEditor_2.undo)

        self.tabWidget.setCurrentIndex(7)
        self.gcode_mdi.setCurrentIndex(0)
        self.stackedWidget_82.setCurrentIndex(0)
        self.tool_offset_stacked_widget.setCurrentIndex(1)
        self.probe_tab_widget.setCurrentIndex(0)
        self.tabWidget_2.setCurrentIndex(3)
        self.sidebar_widget.setCurrentIndex(0)
        self.jog_button_stacked_widget.setCurrentIndex(0)
        self.spindle_rpm_source_widget.setCurrentIndex(1)
        self.spindle_controls_stacked_widget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Probe Basic Lathe", None))
        self.actionExit.setText(QCoreApplication.translate("Form", u"Exit", None))
        self.actionOpen.setText(QCoreApplication.translate("Form", u"&Open ...", None))
#if QT_CONFIG(shortcut)
        self.actionOpen.setShortcut(QCoreApplication.translate("Form", u"O", None))
#endif // QT_CONFIG(shortcut)
        self.actionClose.setText(QCoreApplication.translate("Form", u"Close", None))
        self.actionReload.setText(QCoreApplication.translate("Form", u"&Reload", None))
#if QT_CONFIG(shortcut)
        self.actionReload.setShortcut(QCoreApplication.translate("Form", u"Ctrl+R", None))
#endif // QT_CONFIG(shortcut)
        self.actionSave_As.setText(QCoreApplication.translate("Form", u"Save As ...", None))
        self.actionHome_X.setText(QCoreApplication.translate("Form", u"Home &X", None))
        self.actionHome_Y.setText(QCoreApplication.translate("Form", u"Home &Y", None))
        self.actionHome_Z.setText(QCoreApplication.translate("Form", u"Home &Z", None))
        self.action_EmergencyStop_toggle.setText(QCoreApplication.translate("Form", u"Toggle E-stop", None))
#if QT_CONFIG(shortcut)
        self.action_EmergencyStop_toggle.setShortcut(QCoreApplication.translate("Form", u"F1", None))
#endif // QT_CONFIG(shortcut)
        self.action_MachinePower_toggle.setText(QCoreApplication.translate("Form", u"Machine Power", None))
#if QT_CONFIG(shortcut)
        self.action_MachinePower_toggle.setShortcut(QCoreApplication.translate("Form", u"F2", None))
#endif // QT_CONFIG(shortcut)
        self.actionHome_All.setText(QCoreApplication.translate("Form", u"Home All", None))
        self.actionRun_Program.setText(QCoreApplication.translate("Form", u"Run Program", None))
#if QT_CONFIG(shortcut)
        self.actionRun_Program.setShortcut(QCoreApplication.translate("Form", u"R", None))
#endif // QT_CONFIG(shortcut)
        self.actionFile1.setText(QCoreApplication.translate("Form", u"File1", None))
        self.actionReport_Actual_Position.setText(QCoreApplication.translate("Form", u"Report Actual Position", None))
        self.actionTest.setText(QCoreApplication.translate("Form", u"Test", None))
        self.action_Mist_toggle.setText(QCoreApplication.translate("Form", u"Mist On", None))
#if QT_CONFIG(shortcut)
        self.action_Mist_toggle.setShortcut(QCoreApplication.translate("Form", u"F7", None))
#endif // QT_CONFIG(shortcut)
        self.action_Flood_toggle.setText(QCoreApplication.translate("Form", u"Flood On", None))
#if QT_CONFIG(shortcut)
        self.action_Flood_toggle.setShortcut(QCoreApplication.translate("Form", u"F8", None))
#endif // QT_CONFIG(shortcut)
        self.recentfilecombobox.setProperty(u"resource", "")
        self.find_m6_button.setText(QCoreApplication.translate("Form", u"FIND M6", None))
#if QT_CONFIG(tooltip)
        self.run_from_line_Num.setToolTip(QCoreApplication.translate("Form", u"<html><head/><body><p><span style=\" font-weight:600; font-style:italic; text-decoration: underline; color:#ff0000;\">IMPORTANT WARNING!!!</span></p><p><span style=\" font-weight:600; color:#ff0000;\">RUN FROM LINE </span><span style=\" color:#000000;\">does </span><span style=\" font-weight:600; color:#ff0000;\">NOT </span><span style=\" color:#000000;\">account for any</span></p><p><span style=\" color:#000000;\">preceding commands such as but not limited </span></p><p><span style=\" color:#000000;\">too the following:</span></p><p><span style=\" color:#000000;\">- XYZ positioning move Commands</span></p><p><span style=\" color:#000000;\">- Feedrate Commands</span></p><p><span style=\" color:#000000;\">- G5x Work Offset Commands</span></p><p><span style=\" color:#000000;\">- Tool Change Commands</span></p><p><span style=\" color:#000000;\">- Tool length offsets that need to be active</span></p><p><span style=\" color:#000000;\">- Spindle or Coolant ON Commands</span></p><p><span style=\" color:#000000;\">- A"
                        "NY Commands not on the current line</span></p><p><span style=\" font-weight:600; color:#ff0000;\">It is recommended to be run from a previous</span></p><p><span style=\" font-weight:600; color:#ff0000;\">tool change line that reissues all of those </span></p><p><span style=\" font-weight:600; color:#ff0000;\">commands to avoid unexpected behavior!</span></p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.run_from_line_Num.setText("")
        self.run_from_line_Num.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.run_from_line_Btn.setText(QCoreApplication.translate("Form", u"SET QUE", None))
        self.mdihistory.setProperty(u"mdiEntrylineName", QCoreApplication.translate("Form", u"mdiEntry", None))
        self.btn_del_history_row_mdi.setText(QCoreApplication.translate("Form", u"DEL SEL", None))
        self.btn_del_all_mdi.setText(QCoreApplication.translate("Form", u"DEL ALL", None))
        self.btn_clear_queue_mdi.setText(QCoreApplication.translate("Form", u"CLR QUE", None))
        self.btn_pause_mdi.setText(QCoreApplication.translate("Form", u"PAUSE", None))
        self.btn_run_from_line_mdi.setText(QCoreApplication.translate("Form", u"RUN FROM", None))
        self.btn_run_selection_mdi.setText(QCoreApplication.translate("Form", u"RUN SEL", None))
        self.btn_copy_to_editor_mdi.setText(QCoreApplication.translate("Form", u"GCODE", None))
        self.btnMdiBksp.setText("")
        self.L.setText(QCoreApplication.translate("Form", u"L", None))
        self.subtract.setText(QCoreApplication.translate("Form", u"-", None))
        self.NP2.setText(QCoreApplication.translate("Form", u"2", None))
        self.btnMdiSpace.setText(QCoreApplication.translate("Form", u"SPACE", None))
        self.K.setText(QCoreApplication.translate("Form", u"K", None))
        self.X.setText(QCoreApplication.translate("Form", u"X", None))
        self.T.setText(QCoreApplication.translate("Form", u"T", None))
        self.R.setText(QCoreApplication.translate("Form", u"R", None))
        self.P.setText(QCoreApplication.translate("Form", u"P", None))
        self.D.setText(QCoreApplication.translate("Form", u"D", None))
        self.NP9.setText(QCoreApplication.translate("Form", u"9", None))
        self.NP8.setText(QCoreApplication.translate("Form", u"8", None))
        self.decimal.setText(QCoreApplication.translate("Form", u".", None))
        self.NP0.setText(QCoreApplication.translate("Form", u"0", None))
        self.J.setText(QCoreApplication.translate("Form", u"J", None))
        self.H.setText(QCoreApplication.translate("Form", u"H", None))
        self.A.setText(QCoreApplication.translate("Form", u"A", None))
        self.G.setText(QCoreApplication.translate("Form", u"G", None))
        self.NP3.setText(QCoreApplication.translate("Form", u"3", None))
        self.Z.setText(QCoreApplication.translate("Form", u"Z", None))
        self.F.setText(QCoreApplication.translate("Form", u"F", None))
        self.enter.setText(QCoreApplication.translate("Form", u"ENTER", None))
        self.M.setText(QCoreApplication.translate("Form", u"M", None))
        self.Q.setText(QCoreApplication.translate("Form", u"Q", None))
        self.NP4.setText(QCoreApplication.translate("Form", u"4", None))
        self.NP5.setText(QCoreApplication.translate("Form", u"5", None))
        self.NP6.setText(QCoreApplication.translate("Form", u"6", None))
        self.Y.setText(QCoreApplication.translate("Form", u"Y", None))
        self.O.setText(QCoreApplication.translate("Form", u"O", None))
        self.S.setText(QCoreApplication.translate("Form", u"S", None))
        self.I.setText(QCoreApplication.translate("Form", u"I", None))
        self.B.setText(QCoreApplication.translate("Form", u"B", None))
        self.NP1.setText(QCoreApplication.translate("Form", u"1", None))
        self.NP7.setText(QCoreApplication.translate("Form", u"7", None))
        self.btnMdiRight_arrow.setText("")
        self.btnMdiLeft_arrow.setText("")
        self.mdiEntry.setPlaceholderText(QCoreApplication.translate("Form", u"MDI", None))
        self.mdiEntry.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.gcode_page.setText(QCoreApplication.translate("Form", u"GCODE", None))
        self.mdi_page.setText(QCoreApplication.translate("Form", u"MDI", None))
        self.pan_button.setText(QCoreApplication.translate("Form", u"PAN", None))
        self.zoom_in_button.setText(QCoreApplication.translate("Form", u"ZOOM +", None))
        self.zoom_out_button.setText(QCoreApplication.translate("Form", u"ZOOM -", None))
        self.program_zoom_button.setText(QCoreApplication.translate("Form", u"PGM EXT", None))
        self.machine_zoom_button.setText(QCoreApplication.translate("Form", u"MCH EXT", None))
        self.path_button.setStyleSheet("")
        self.path_button.setText(QCoreApplication.translate("Form", u"PATH", None))
        self.clear_button.setText(QCoreApplication.translate("Form", u"CLEAR", None))
        self.view_breadcrumbs.setText(QCoreApplication.translate("Form", u"Tracer", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.main_tab), QCoreApplication.translate("Form", u"MAIN", None))
        self.device_folder_up_button.setText(QCoreApplication.translate("Form", u"  FOLDER UP", None))
        self.device_eject_usb_button.setText(QCoreApplication.translate("Form", u"EJECT USB", None))
        self.filesystemtable_2.setProperty(u"hiddenColumns", QCoreApplication.translate("Form", u"2, 4,1", None))
        self.device_delete_item_button.setText(QCoreApplication.translate("Form", u" DELETE", None))
        self.device_rename_item_button.setText(QCoreApplication.translate("Form", u"RENAME", None))
        self.copy_from_usb_2.setText(QCoreApplication.translate("Form", u"TO PC  ", None))
        self.main_folder_up_button.setText(QCoreApplication.translate("Form", u"  FOLDER UP", None))
        self.main_load_gcode_button.setText(QCoreApplication.translate("Form", u"LOAD G-CODE", None))
        self.filesystemtable.setProperty(u"hiddenColumns", QCoreApplication.translate("Form", u"2", None))
        self.usb_show_hide_button.setText(QCoreApplication.translate("Form", u"HIDE USB", None))
        self.usb_show_hide_button.setProperty(u"settingName", QCoreApplication.translate("Form", u"startup-settings.usb-hide-show", None))
        self.usb_show_hide_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"usb_hide_show\", \"property\": \"Text\", \"expression\": \"'SHOW USB' if ch[0] else 'HIDE USB'\", \"channels\": [{\"url\": \"settings:startup-settings.usb-hide-show\", \"trigger\": true}]}]", None))
        self.copy_to_usb_2.setText(QCoreApplication.translate("Form", u" TO USB", None))
        self.main_delete_item_button.setText(QCoreApplication.translate("Form", u" DELETE", None))
        self.main_new_file_button.setText(QCoreApplication.translate("Form", u" NEW FILE", None))
        self.main_new_folder_button.setText(QCoreApplication.translate("Form", u" NEW FOLDER", None))
        self.main_rename_item_button.setText(QCoreApplication.translate("Form", u"RENAME", None))
        self.gcodeeditor_label.setText(QCoreApplication.translate("Form", u"G-CODE FILE EDITOR", None))
        self.edit_gcode_button.setText(QCoreApplication.translate("Form", u"EDIT G-CODE", None))
        self.find_replace_button.setText(QCoreApplication.translate("Form", u"FIND/REPLACE", None))
        self.save_button.setText(QCoreApplication.translate("Form", u"SAVE", None))
        self.save_as_button.setText(QCoreApplication.translate("Form", u"SAVE AS", None))
        self.undo_button.setText(QCoreApplication.translate("Form", u"UNDO", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.file_tab), QCoreApplication.translate("Form", u"FILE", None))
        self.wco_header_frame_3.setText(QCoreApplication.translate("Form", u"WORK COORDINATE STORED OFFSETS", None))
        self.offset_table.setProperty(u"displayColumns", QCoreApplication.translate("Form", u"XYZC", None))
        self.clear_selected_button.setText(QCoreApplication.translate("Form", u"CLEAR SELECTED", None))
        self.clear_all_button.setText(QCoreApplication.translate("Form", u"CLEAR ALL", None))
#if QT_CONFIG(tooltip)
        self.save_table_button.setToolTip(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\"><img src=\":/images/floppy_disc.png\"/></p><p align=\"center\">Saves the Offsets Table Changes</p></body></html>", None))
#endif // QT_CONFIG(tooltip)
        self.save_table_button.setText(QCoreApplication.translate("Form", u"SAVE TABLE", None))
        self.reload_table_button.setText(QCoreApplication.translate("Form", u"RELOAD TABLE", None))
        self.zero_column_header.setText(QCoreApplication.translate("Form", u"SET TO ZERO", None))
        self.axis_column_header.setText(QCoreApplication.translate("Form", u"AXIS", None))
        self.work_column_header.setText(QCoreApplication.translate("Form", u"WC CURRENT POSITION", None))
        self.machine_column_header.setText(QCoreApplication.translate("Form", u"MACHINE\n"
"COORDS", None))
        self.wc_offset_column_header.setText(QCoreApplication.translate("Form", u"WC\n"
"OFFSET", None))
        self.ref_coilumn_header_9.setText(QCoreApplication.translate("Form", u"G52/G92\n"
"OFFSET", None))
        self.tool_offset_column_header.setText(QCoreApplication.translate("Form", u"TOOL\n"
"OFFSET", None))
        self.mdi_entry_box_offset.setPlaceholderText(QCoreApplication.translate("Form", u"MDI", None))
        self.mdi_entry_box_offset.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.wco_header_frame.setText(QCoreApplication.translate("Form", u"WORK COORDINATE OFFSETS", None))
        self.g56_button.setText(QCoreApplication.translate("Form", u"G56", None))
        self.g56_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G56", None))
        self.g59_2_button.setText(QCoreApplication.translate("Form", u"G59.2", None))
        self.g59_2_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.2", None))
        self.g54_button.setText(QCoreApplication.translate("Form", u"G54", None))
        self.g54_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G54", None))
        self.g59_3_button.setText(QCoreApplication.translate("Form", u"G59.3", None))
        self.g59_3_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.3", None))
        self.g59_1_button.setText(QCoreApplication.translate("Form", u"G59.1", None))
        self.g59_1_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.1", None))
        self.g57_button.setText(QCoreApplication.translate("Form", u"G57", None))
        self.g57_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G57", None))
        self.g58_button.setText(QCoreApplication.translate("Form", u"G58", None))
        self.g58_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G58", None))
        self.g55_button.setText(QCoreApplication.translate("Form", u"G55", None))
        self.g55_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G55", None))
        self.g59_button.setText(QCoreApplication.translate("Form", u"G59", None))
        self.g59_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59", None))
        self.wco_header_frame_2.setText(QCoreApplication.translate("Form", u"TOOL CHANGE POSITION", None))
        self.set_g30_position.setText(QCoreApplication.translate("Form", u"SET G30 POSITION TOOL CHANGE POSITION", None))
        self.set_g30_position.setProperty(u"filename", QCoreApplication.translate("Form", u"set_g30_position.ngc", None))
        self.x_label.setText(QCoreApplication.translate("Form", u"X", None))
        self.x_tool_change_position_5181.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.x_tool_change_position_5181.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Value\", \"expression\": \"ch[0][44]\", \"name\": \"x_axis_g30_set_position\"}]", None))
        self.x_tool_change_position_5181.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.z_label.setText(QCoreApplication.translate("Form", u"Z", None))
        self.z_tool_change_position_5183.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_tool_change_position_5183.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Value\", \"expression\": \"ch[0][46]\", \"name\": \"z_axis_g30_set_position\"}]", None))
        self.z_tool_change_position_5183.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.use_tcp.setText(QCoreApplication.translate("Form", u"USE TOOL CHANGE POSITION FOR M6", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.offsets_tab), QCoreApplication.translate("Form", u"OFFSETS", None))
        self.mdi_entry_box_8.setPlaceholderText(QCoreApplication.translate("Form", u"MDI", None))
        self.mdi_entry_box_8.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.m6_tool_call_touch_panel.setText(QCoreApplication.translate("Form", u"T", None))
        self.m6_tool_call_touch_panel.setProperty(u"filename", QCoreApplication.translate("Form", u"m6_tool_call_touch_panel.ngc", None))
        self.tool_number_entry_touch_panel.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?tool_number\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"str(ch[0])\", \"name\": \"update tool num\"}, {\"channels\": [{\"url\": \"status:task_state?text\", \"trigger\": true}, {\"url\": \"status:interp_state?text\", \"trigger\": true}], \"property\": \"Enable\", \"expression\": \"ch[0] == 'On' and ch[1] == 'Idle'\", \"name\": \"enable/disable\"}]", None))
        self.tool_number_entry_touch_panel.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.tool_length_8.setText(QCoreApplication.translate("Form", u"No Tool Loaded", None))
        self.tool_length_8.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_8.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?Remark\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"tool_remark\"}]", None))
        self.tool_length_8.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_8.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.tool_orientation_label.setText(QCoreApplication.translate("Form", u"TOOL ORIENTATION", None))
        self.lathe_control_point_9.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 9 else False\", \"name\": \"orientation_9\"}]", None))
        self.lathe_control_point_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 5 else False\", \"name\": \"orientation_5\"}]", None))
        self.lathe_control_point_7.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Enable\", \"expression\": \"True if ch[0][ch[1]].orientation == 7 else False\", \"name\": \"orientation_7\"}]", None))
        self.lathe_control_point_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 2 else False\", \"name\": \"orientation_2\"}]", None))
        self.lathe_control_point_3.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 3 else False\", \"name\": \"orientation_3\"}]", None))
        self.lathe_control_point_6.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 6 else False\", \"name\": \"orientation_6\"}]", None))
        self.lathe_control_point_4.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation ==4 else False\", \"name\": \"orientation_4\"}]", None))
        self.lathe_control_point_1.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 1 else False\", \"name\": \"orientation_1\"}]", None))
        self.lathe_control_point_8.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": true}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 8 else False\", \"name\": \"orientation_8\"}]", None))
        self.lathe_control_point_5_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 5 else False\", \"name\": \"orientation_5\"}]", None))
        self.lathe_control_point_1_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 1 else False\", \"name\": \"orientation_1\"}]", None))
        self.lathe_control_point_9_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 9 else False\", \"name\": \"orientation_9\"}]", None))
        self.lathe_control_point_7_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Enable\", \"expression\": \"True if ch[0][ch[1]].orientation == 7 else False\", \"name\": \"orientation_7\"}]", None))
        self.lathe_control_point_6_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 6 else False\", \"name\": \"orientation_6\"}]", None))
        self.lathe_control_point_2_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 2 else False\", \"name\": \"orientation_2\"}]", None))
        self.lathe_control_point_3_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 3 else False\", \"name\": \"orientation_3\"}]", None))
        self.lathe_control_point_8_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation == 8 else False\", \"name\": \"orientation_8\"}]", None))
        self.lathe_control_point_4_inverse.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_table\", \"trigger\": false}, {\"url\": \"status:tool_in_spindle\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if ch[0][ch[1]].orientation ==4 else False\", \"name\": \"orientation_4\"}]", None))
        self.m01_break_button_20.setText(QCoreApplication.translate("Form", u"RESET TOOL", None))
        self.x_offset_touch_value_3102.setText(QCoreApplication.translate("Form", u"0.000000", None))
        self.x_offset_touch_value_3102.setPlaceholderText(QCoreApplication.translate("Form", u"0.000000", None))
        self.x_offset_touch_value_3102.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.touch_off_x.setText(QCoreApplication.translate("Form", u"TOUCH X RAD", None))
        self.touch_off_x.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"rad_diam_display_rule\", \"property\": \"Text\", \"expression\": \"'TOUCH X DIAM' if \\\"G7\\\" in ch[0] else 'TOUCH X RAD'\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.touch_off_x.setProperty(u"filename", QCoreApplication.translate("Form", u"touch_off_x.ngc", None))
        self.touch_off_z.setText(QCoreApplication.translate("Form", u"TOUCH OFF  Z", None))
        self.touch_off_z.setProperty(u"filename", QCoreApplication.translate("Form", u"touch_off_z.ngc", None))
        self.mt_z_offset_label_4.setText(QCoreApplication.translate("Form", u"GAGE BLOCK", None))
        self.gage_thickness_3101.setText(QCoreApplication.translate("Form", u"0.000000", None))
        self.gage_thickness_3101.setPlaceholderText(QCoreApplication.translate("Form", u"0.000000", None))
        self.gage_thickness_3101.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.label_61.setText(QCoreApplication.translate("Form", u"T - TOOL NUMBER", None))
        self.tool_length_13.setText(QCoreApplication.translate("Form", u"0", None))
        self.tool_length_13.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_13.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_in_spindle?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"current_tool\"}]", None))
        self.tool_length_13.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_13.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_54.setText(QCoreApplication.translate("Form", u"X - OFFSET", None))
        self.tool_diameter_7.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_7.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_7.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?x\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"x_offset\"}]", None))
        self.tool_diameter_7.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_7.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_53.setText(QCoreApplication.translate("Form", u"Z - OFFSET", None))
        self.tool_diameter_6.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_6.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_6.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?z\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"z_offset\"}]", None))
        self.tool_diameter_6.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_6.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_66.setText(QCoreApplication.translate("Form", u"I - FRONT ANGLE", None))
        self.tool_length_14.setText(QCoreApplication.translate("Form", u"0.00", None))
        self.tool_length_14.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_14.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?I\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.2f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.2f}\\\".format(ch[0])\", \"name\": \"tool_front_angle\"}]", None))
        self.tool_length_14.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_14.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_64.setText(QCoreApplication.translate("Form", u"J - BACK ANGLE", None))
        self.tool_length_11.setText(QCoreApplication.translate("Form", u"0.00", None))
        self.tool_length_11.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_11.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?J\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.2f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.2f}\\\".format(ch[0])\", \"name\": \"tool_back_angle\"}]", None))
        self.tool_length_11.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_11.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_52.setText(QCoreApplication.translate("Form", u"D - DIAMETER", None))
        self.tool_diameter_5.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_5.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?diameter\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"tool_diameter\"}]", None))
        self.tool_diameter_5.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_5.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_65.setText(QCoreApplication.translate("Form", u"Q - ORIENTATION", None))
        self.tool_length_12.setText(QCoreApplication.translate("Form", u"1", None))
        self.tool_length_12.setProperty(u"format", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.tool_length_12.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?q\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.0f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.0f}\\\".format(ch[0])\", \"name\": \"tool_orientation\"}]", None))
        self.tool_length_12.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_12.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.x_offset_touch_value_mt_3102.setText(QCoreApplication.translate("Form", u"0.000000", None))
        self.x_offset_touch_value_mt_3102.setPlaceholderText(QCoreApplication.translate("Form", u"0.000000", None))
        self.x_offset_touch_value_mt_3102.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.touch_x.setText(QCoreApplication.translate("Form", u"TOUCH X RAD", None))
        self.touch_x.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"g7_g8_display_mode\", \"property\": \"Text\", \"expression\": \"'TOUCH X DIAM' if \\\"G7\\\" in ch[0] else 'TOUCH X RAD'\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.touch_x.setProperty(u"filename", QCoreApplication.translate("Form", u"touch_off_x_mt.ngc", None))
        self.mt_z_offset_label_5.setText(QCoreApplication.translate("Form", u"MT", None))
        self.master_tool_number_3100.setText("")
        self.master_tool_number_3100.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.master_tool_number_3100.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.touch_z.setText(QCoreApplication.translate("Form", u"TOUCH  Z", None))
        self.touch_z.setProperty(u"filename", QCoreApplication.translate("Form", u"touch_off_z_mt.ngc", None))
        self.mt_z_offset_label_3.setText(QCoreApplication.translate("Form", u"GAGE BLOCK", None))
        self.gage_thickness_mt_3101.setText(QCoreApplication.translate("Form", u"0.000000", None))
        self.gage_thickness_mt_3101.setPlaceholderText(QCoreApplication.translate("Form", u"0.000000", None))
        self.gage_thickness_mt_3101.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.label_67.setText(QCoreApplication.translate("Form", u"T - TOOL NUMBER", None))
        self.tool_length_15.setText(QCoreApplication.translate("Form", u"0", None))
        self.tool_length_15.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_15.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_in_spindle?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"current_tool\"}]", None))
        self.tool_length_15.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_15.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_55.setText(QCoreApplication.translate("Form", u"X - OFFSET", None))
        self.tool_diameter_8.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_8.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_8.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?x\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"x_offset\"}]", None))
        self.tool_diameter_8.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_8.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_57.setText(QCoreApplication.translate("Form", u"Z - OFFSET", None))
        self.tool_diameter_9.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_9.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_9.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?z\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"z_offset\"}]", None))
        self.tool_diameter_9.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_9.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_68.setText(QCoreApplication.translate("Form", u"I - FRONT ANGLE", None))
        self.tool_length_16.setText(QCoreApplication.translate("Form", u"0.00", None))
        self.tool_length_16.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_16.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?I\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.2f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.2f}\\\".format(ch[0])\", \"name\": \"tool_front_angle\"}]", None))
        self.tool_length_16.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_16.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_69.setText(QCoreApplication.translate("Form", u"J - BACK ANGLE", None))
        self.tool_length_17.setText(QCoreApplication.translate("Form", u"0.00", None))
        self.tool_length_17.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_17.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?J\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.2f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.2f}\\\".format(ch[0])\", \"name\": \"tool_back_angle\"}]", None))
        self.tool_length_17.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_17.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_58.setText(QCoreApplication.translate("Form", u"D - DIAMETER", None))
        self.tool_diameter_10.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_10.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_10.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?diameter\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"tool_diameter\"}]", None))
        self.tool_diameter_10.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_10.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.label_70.setText(QCoreApplication.translate("Form", u"Q - ORIENTATION", None))
        self.tool_length_18.setText(QCoreApplication.translate("Form", u"1", None))
        self.tool_length_18.setProperty(u"format", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.tool_length_18.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?q\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.0f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.0f}\\\".format(ch[0])\", \"name\": \"tool_orientation\"}]", None))
        self.tool_length_18.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_18.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.touch_off_tab), QCoreApplication.translate("Form", u"TOUCH OFF", None))
        self.tooltable.setProperty(u"displayColumns", QCoreApplication.translate("Form", u"TXZIJDQR", None))
        self.tool_table_delete_button.setText(QCoreApplication.translate("Form", u"DELETE", None))
        self.tool_table_add_tool_button.setText(QCoreApplication.translate("Form", u"ADD TOOL", None))
        self.tool_table_save_button.setText(QCoreApplication.translate("Form", u"SAVE TABLE", None))
        self.tool_table_reload_button.setText(QCoreApplication.translate("Form", u"RELOAD TABLE", None))
        self.label_56.setText(QCoreApplication.translate("Form", u"REMARK", None))
        self.tool_length_7.setText(QCoreApplication.translate("Form", u"No Tool Loaded", None))
        self.tool_length_7.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_7.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?Remark\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"tool_remark\"}]", None))
        self.tool_length_7.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_7.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_59.setText(QCoreApplication.translate("Form", u"I - FRONT ANGLE", None))
        self.tool_length_5.setText(QCoreApplication.translate("Form", u"0.00", None))
        self.tool_length_5.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?I\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.2f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.2f}\\\".format(ch[0])\", \"name\": \"tool_front_angle\"}]", None))
        self.tool_length_5.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_5.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_49.setText(QCoreApplication.translate("Form", u"D - DIAMETER", None))
        self.tool_diameter_2.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_2.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?diameter\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"tool_diameter\"}]", None))
        self.tool_diameter_2.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_2.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_28.setText("")
        self.label_62.setText(QCoreApplication.translate("Form", u"J - BACK ANGLE", None))
        self.tool_length_9.setText(QCoreApplication.translate("Form", u"0.00", None))
        self.tool_length_9.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_9.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?J\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.2f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.2f}\\\".format(ch[0])\", \"name\": \"tool_back_angle\"}]", None))
        self.tool_length_9.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_9.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_60.setText(QCoreApplication.translate("Form", u"T - TOOL NUMBER", None))
        self.tool_length_6.setText(QCoreApplication.translate("Form", u"0", None))
        self.tool_length_6.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_length_6.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:tool_in_spindle?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"current_tool\"}]", None))
        self.tool_length_6.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_6.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_63.setText(QCoreApplication.translate("Form", u"Q - ORIENTATION", None))
        self.tool_length_10.setText(QCoreApplication.translate("Form", u"1", None))
        self.tool_length_10.setProperty(u"format", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.tool_length_10.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?q\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.0f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.0f}\\\".format(ch[0])\", \"name\": \"tool_orientation\"}]", None))
        self.tool_length_10.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_length_10.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_50.setText(QCoreApplication.translate("Form", u"X - OFFSET", None))
        self.tool_diameter_3.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_3.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_3.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?x\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"x_offset\"}]", None))
        self.tool_diameter_3.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_3.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_51.setText(QCoreApplication.translate("Form", u"Z - OFFSET", None))
        self.tool_diameter_4.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.tool_diameter_4.setProperty(u"format", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.tool_diameter_4.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?z\", \"trigger\": true}, {\"url\": \"status:linear_units?text\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"{:.4f}\\\".format(ch[0]) if ch[1] == 'in' else \\\"{:.4f}\\\".format(ch[0])\", \"name\": \"z_offset\"}]", None))
        self.tool_diameter_4.setProperty(u"statusItem", QCoreApplication.translate("Form", u"tool_offset.3", None))
        self.tool_diameter_4.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.mdi_entry_box_4.setPlaceholderText(QCoreApplication.translate("Form", u"MDI", None))
        self.mdi_entry_box_4.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tooling_tab), QCoreApplication.translate("Form", u"TOOL TABLE", None))
        self.label_90.setText(QCoreApplication.translate("Form", u" WORK OFFSETS", None))
        self.actionbutton_28.setText(QCoreApplication.translate("Form", u"G54", None))
        self.actionbutton_28.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G54", None))
        self.actionbutton_29.setText(QCoreApplication.translate("Form", u"G55", None))
        self.actionbutton_29.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G55", None))
        self.actionbutton_30.setText(QCoreApplication.translate("Form", u"G56", None))
        self.actionbutton_30.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G56", None))
        self.actionbutton_31.setText(QCoreApplication.translate("Form", u"G57", None))
        self.actionbutton_31.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G57", None))
        self.actionbutton_60.setText(QCoreApplication.translate("Form", u"G58", None))
        self.actionbutton_60.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G58", None))
        self.actionbutton_61.setText(QCoreApplication.translate("Form", u"G59", None))
        self.actionbutton_61.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59", None))
        self.actionbutton_62.setText(QCoreApplication.translate("Form", u"G59.1", None))
        self.actionbutton_62.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.1", None))
        self.actionbutton_63.setText(QCoreApplication.translate("Form", u"G59.2", None))
        self.actionbutton_63.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.2", None))
        self.actionbutton_64.setText(QCoreApplication.translate("Form", u"G59.3", None))
        self.actionbutton_64.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.3", None))
        self.probe_Position_only.setText(QCoreApplication.translate("Form", u"PROBE POSITION ONLY", None))
        self.label_91.setText(QCoreApplication.translate("Form", u" Probing Parameters", None))
        self.ref_coilumn_header_19.setText("")
        self.label_92.setText(QCoreApplication.translate("Form", u"Probe Tool #:", None))
        self.probe_tool_number.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.probe_tool_number.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_93.setText(QCoreApplication.translate("Form", u"Step Off Width:", None))
        self.step_off_width.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.step_off_width.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.ref_coilumn_header_20.setText("")
        self.label_94.setText(QCoreApplication.translate("Form", u"PROBE FAST FDRATE:", None))
        self.probe_fast_fr.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.probe_fast_fr.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_95.setText(QCoreApplication.translate("Form", u"PROBE SLOW FDRATE:", None))
        self.probe_slow_fr.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.probe_slow_fr.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.ref_coilumn_header_21.setText("")
        self.label_96.setText(QCoreApplication.translate("Form", u"Max X Distance:", None))
        self.max_x_distance.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.max_x_distance.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:0.4f}", None))
        self.max_x_distance.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_97.setText(QCoreApplication.translate("Form", u"X Clearance:", None))
        self.x_clearance.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.x_clearance.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.ref_coilumn_header_22.setText("")
        self.label_98.setText(QCoreApplication.translate("Form", u"Max Z Distance:", None))
        self.max_z_distance.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.max_z_distance.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_99.setText(QCoreApplication.translate("Form", u"Z Clearance:", None))
        self.z_clearance.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_clearance.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.ref_coilumn_header_23.setText("")
        self.label_100.setText(QCoreApplication.translate("Form", u"Extra Probe Depth:", None))
        self.extra_probe_depth.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.extra_probe_depth.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_101.setText(QCoreApplication.translate("Form", u"EDGE WIDTH:", None))
        self.edge_width.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.edge_width.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_102.setText(QCoreApplication.translate("Form", u" Probe Results", None))
        self.reset_all_data.setText(QCoreApplication.translate("Form", u"RESET ALL DATA", None))
        self.reset_all_data.setProperty(u"filename", QCoreApplication.translate("Form", u"reset_all_data.ngc", None))
        self.x_data_reset1.setText(QCoreApplication.translate("Form", u"X DATA RESET", None))
        self.x_data_reset1.setProperty(u"filename", QCoreApplication.translate("Form", u"x_data_reset.ngc", None))
        self.z_data_reset1.setText(QCoreApplication.translate("Form", u"Z DATA RESET", None))
        self.z_data_reset1.setProperty(u"filename", QCoreApplication.translate("Form", u"y_data_reset.ngc", None))
        self.label_108.setText(QCoreApplication.translate("Form", u"X- PROBED:", None))
        self.x_minus_probed_position.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.x_minus_probed_position.setProperty(u"format", QCoreApplication.translate("Form", u"{:6.4f}", None))
        self.x_minus_probed_position.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:6.4f}\\\".format(ch[0][36])\", \"name\": \"x_minus_probed_position\"}]", None))
        self.x_minus_probed_position.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_110.setText(QCoreApplication.translate("Form", u"Z- PROBED:", None))
        self.z_minus_probed_position.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_minus_probed_position.setProperty(u"format", QCoreApplication.translate("Form", u"{:6.4f}", None))
        self.z_minus_probed_position.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:6.4f}\\\".format(ch[0][38])\", \"name\": \"z_minus_probed_position\"}]", None))
        self.z_minus_probed_position.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_107.setText(QCoreApplication.translate("Form", u"DIAM:", None))
        self.avg_diameter.setProperty(u"format", QCoreApplication.translate("Form", u"{:6.4f}", None))
        self.avg_diameter.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:6.4f}\\\".format(ch[0][33])\", \"name\": \"averaged_diam\"}]", None))
        self.avg_diameter.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_111.setText(QCoreApplication.translate("Form", u"<html><head/><body><p>TAPER DELTA:</p></body></html>", None))
        self.edge_delta.setProperty(u"format", QCoreApplication.translate("Form", u"{:6.4f}", None))
        self.edge_delta.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:6.4f}\\\".format(ch[0][35])\", \"name\": \"edge_delta\"}]", None))
        self.edge_delta.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_112.setText(QCoreApplication.translate("Form", u"TAPER ANGLE", None))
        self.edge_angle.setProperty(u"format", QCoreApplication.translate("Form", u"{:6.4f}", None))
        self.edge_angle.setProperty(u"expression", QCoreApplication.translate("Form", u"val", None))
        self.edge_angle.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:6.4f}\\u00b0\\\".format(ch[0][34])\", \"name\": \"edge_angle\"}]", None))
        self.edge_angle.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_114.setText(QCoreApplication.translate("Form", u"Y CENTER:", None))
        self.y_center_probed.setText(QCoreApplication.translate("Form", u"0.0000", None))
        self.y_center_probed.setProperty(u"format", QCoreApplication.translate("Form", u"{:6.4f}", None))
        self.y_center_probed.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:aout\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:6.4f}\\\".format(ch[0][42])\", \"name\": \"y_center_probed\"}]", None))
        self.y_center_probed.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.mdi_entry_box_6.setPlaceholderText(QCoreApplication.translate("Form", u"MDI", None))
        self.mdi_entry_box_6.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField15", None))
        self.probe_tab_widget.setTabText(self.probe_tab_widget.indexOf(self.outside_corners_tab), QCoreApplication.translate("Form", u"        LATHE PROBE 1        ", None))
        self.probe_tab_widget.setTabText(self.probe_tab_widget.indexOf(self.inside_corners_tab), QCoreApplication.translate("Form", u"       LATHE PROBE 2       ", None))
        self.probe_tab_widget.setTabText(self.probe_tab_widget.indexOf(self.boss_and_pocket_tab), QCoreApplication.translate("Form", u"       LATHE PROBE 3       ", None))
        self.probe_tab_widget.setTabText(self.probe_tab_widget.indexOf(self.valley_and_ridge_tab), QCoreApplication.translate("Form", u"       LATHE PROBE 4       ", None))
        self.probe_tab_widget.setTabText(self.probe_tab_widget.indexOf(self.rotary_axis_tab), QCoreApplication.translate("Form", u"       LATHE PROBE 5       ", None))
        self.probe_tab_widget.setTabText(self.probe_tab_widget.indexOf(self.multi_axis_tab), QCoreApplication.translate("Form", u"       LATHE PROBE 6       ", None))
        self.label.setText("")
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_5), QCoreApplication.translate("Form", u"     STEP OFF WIDTH     ", None))
        self.label_2.setText("")
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_6), QCoreApplication.translate("Form", u"     EXTRA PROBE DEPTH     ", None))
        self.label_3.setText("")
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_8), QCoreApplication.translate("Form", u"     MAX DISTANCE     ", None))
        self.label_4.setText("")
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_9), QCoreApplication.translate("Form", u"     CLEARANCE     ", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_11), QCoreApplication.translate("Form", u"     PROBE FAST FR     ", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_12), QCoreApplication.translate("Form", u"     PROBE SLOW FR     ", None))
        self.probe_tab_widget.setTabText(self.probe_tab_widget.indexOf(self.probe_help_tab), QCoreApplication.translate("Form", u"        PROBE HELP        ", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.probing_tab), QCoreApplication.translate("Form", u"PROBING", None))
        self.work_column_header_11.setText(QCoreApplication.translate("Form", u"Spindle speed display rpm source", None))
        self.spindle_calculated_rpm.setText(QCoreApplication.translate("Form", u"Calculated Spindle RPM", None))
        self.spindle_encodr_rpm.setText(QCoreApplication.translate("Form", u"encoder spindle rpm", None))
        self.startup_settings_label.setText(QCoreApplication.translate("Form", u"START UP SETTINGS", None))
        self.startup_tab_label.setText(QCoreApplication.translate("Form", u"START UP TAB TO DISPLAY ", None))
        self.startup_tab_combobox.setItemText(0, QCoreApplication.translate("Form", u"MAIN", None))
        self.startup_tab_combobox.setItemText(1, QCoreApplication.translate("Form", u"FILE", None))
        self.startup_tab_combobox.setItemText(2, QCoreApplication.translate("Form", u"OFFSETS", None))
        self.startup_tab_combobox.setItemText(3, QCoreApplication.translate("Form", u"TOUCH OFF", None))
        self.startup_tab_combobox.setItemText(4, QCoreApplication.translate("Form", u"TOOL TABLE", None))
        self.startup_tab_combobox.setItemText(5, QCoreApplication.translate("Form", u"PROBING", None))
        self.startup_tab_combobox.setItemText(6, QCoreApplication.translate("Form", u"CONVERSATIONAL", None))
        self.startup_tab_combobox.setItemText(7, QCoreApplication.translate("Form", u"SETTINGS", None))
        self.startup_tab_combobox.setItemText(8, QCoreApplication.translate("Form", u"STATUS", None))
        self.startup_tab_combobox.setItemText(9, QCoreApplication.translate("Form", u"USER", None))

        self.startup_tab_combobox.setCurrentText(QCoreApplication.translate("Form", u"MAIN", None))
        self.startup_tab_label_2.setText(QCoreApplication.translate("Form", u"START UP SB TAB ", None))
        self.startup_sb_tab_combobox.setItemText(0, QCoreApplication.translate("Form", u"JOG", None))
        self.startup_sb_tab_combobox.setItemText(1, QCoreApplication.translate("Form", u"OFFSET", None))
        self.startup_sb_tab_combobox.setItemText(2, QCoreApplication.translate("Form", u"DRO", None))
        self.startup_sb_tab_combobox.setItemText(3, QCoreApplication.translate("Form", u"USER", None))

        self.startup_sb_tab_combobox.setCurrentText(QCoreApplication.translate("Form", u"JOG", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.settings_tab), QCoreApplication.translate("Form", u"SETTINGS", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"<html><head/><body><p><a href=\"https://kcjengr.github.io/probe_basic/update_notes.html\"><span style=\" font-size:12pt; font-weight:600; text-decoration: underline; color:#0000ff;\">Probe Basic Update Release Notes and Instructions</span></a></p></body></html>", None))
        self.label_5.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.status_tab), QCoreApplication.translate("Form", u"STATUS", None))
        self.label_239.setText(QCoreApplication.translate("Form", u"MACHINE STATUS:", None))
        self.x_plus_jogbutton.setText("")
        self.x_plus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,pos", None))
        self.x_minus_jogbutton.setText("")
        self.x_minus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,neg", None))
        self.z_plus_jogbutton.setText("")
        self.z_plus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,pos", None))
        self.z_minus_jogbutton.setText("")
        self.z_minus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,neg", None))
        self.z_plus_jogbutton_2.setText("")
        self.z_plus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,pos", None))
        self.z_minus_jogbutton_2.setText("")
        self.z_minus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,neg", None))
        self.x_plus_jogbutton_2.setText("")
        self.x_plus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,pos", None))
        self.x_minus_jogbutton_2.setText("")
        self.x_minus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,neg", None))
        self.c_minus_jogbutton.setText("")
        self.c_minus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,neg", None))
        self.z_minus_jogbutton_3.setText("")
        self.z_minus_jogbutton_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,neg", None))
        self.c_plus_jogbutton.setText("")
        self.c_plus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,pos", None))
        self.z_plus_jogbutton_3.setText("")
        self.z_plus_jogbutton_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,pos", None))
        self.x_minus_jogbutton_3.setText("")
        self.x_minus_jogbutton_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,neg", None))
        self.x_plus_jogbutton_3.setText("")
        self.x_plus_jogbutton_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,pos", None))
        self.z_plus_jogbutton_4.setText("")
        self.z_plus_jogbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,pos", None))
        self.x_plus_jogbutton_4.setText("")
        self.x_plus_jogbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,pos", None))
        self.z_minus_jogbutton_4.setText("")
        self.z_minus_jogbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,neg", None))
        self.x_minus_jogbutton_4.setText("")
        self.x_minus_jogbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,neg", None))
        self.c_plus_jogbutton_2.setText("")
        self.c_plus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,pos", None))
        self.c_minus_jogbutton_2.setText("")
        self.c_minus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,neg", None))
        self.z_plus_jogbutton_5.setText("")
        self.z_plus_jogbutton_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,pos", None))
        self.z_minus_jogbutton_5.setText("")
        self.z_minus_jogbutton_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,neg", None))
        self.c_plus_jogbutton_3.setText("")
        self.c_plus_jogbutton_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,pos", None))
        self.c_minus_jogbutton_3.setText("")
        self.c_minus_jogbutton_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,neg", None))
        self.y_minus_jogbutton.setText("")
        self.y_minus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:y,neg", None))
        self.y_plus_jogbutton.setText("")
        self.y_plus_jogbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:y,pos", None))
        self.x_minus_jogbutton_5.setText("")
        self.x_minus_jogbutton_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,neg", None))
        self.x_plus_jogbutton_5.setText("")
        self.x_plus_jogbutton_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,pos", None))
        self.z_plus_jogbutton_6.setText("")
        self.z_plus_jogbutton_6.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,pos", None))
        self.x_plus_jogbutton_6.setText("")
        self.x_plus_jogbutton_6.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,pos", None))
        self.z_minus_jogbutton_6.setText("")
        self.z_minus_jogbutton_6.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:z,neg", None))
        self.x_minus_jogbutton_6.setText("")
        self.x_minus_jogbutton_6.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:x,neg", None))
        self.c_plus_jogbutton_4.setText("")
        self.c_plus_jogbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,pos", None))
        self.c_minus_jogbutton_4.setText("")
        self.c_minus_jogbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:c,neg", None))
        self.y_minus_jogbutton_2.setText("")
        self.y_minus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:y,neg", None))
        self.y_plus_jogbutton_2.setText("")
        self.y_plus_jogbutton_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.jog.axis:y,pos", None))
        self.fr_override_dro.setText(QCoreApplication.translate("Form", u"30%", None))
        self.fr_override_dro.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"settings:machine.jog.linear-speed-percentage\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"%s%%\\\" % ch[0]\", \"name\": \"New Rule\"}]", None))
        self.fr_override_dro.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.linear_jog_slider.setProperty(u"settingName", QCoreApplication.translate("Form", u"machine.jog.linear-speed-percentage", None))
        self.actionbutton_g58_5.setText(QCoreApplication.translate("Form", u"G58", None))
        self.actionbutton_g58_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 5\", \"name\": \"g58_offset_status\"}]", None))
        self.actionbutton_g58_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G58", None))
        self.actionbutton_g59_16.setText(QCoreApplication.translate("Form", u"G59.3", None))
        self.actionbutton_g59_16.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 9\", \"name\": \"g59_3_offset_status\"}]", None))
        self.actionbutton_g59_16.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.3", None))
        self.actionbutton_g54_5.setText(QCoreApplication.translate("Form", u"G54", None))
        self.actionbutton_g54_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 1\", \"name\": \"g54_offset_status\"}]", None))
        self.actionbutton_g54_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G54", None))
        self.actionbutton_g56_5.setText(QCoreApplication.translate("Form", u"G56", None))
        self.actionbutton_g56_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 3\", \"name\": \"g56_offset_status\"}]", None))
        self.actionbutton_g56_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G56", None))
        self.actionbutton_g55_5.setText(QCoreApplication.translate("Form", u"G55", None))
        self.actionbutton_g55_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 2\", \"name\": \"g55_offset_status\"}]", None))
        self.actionbutton_g55_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G55", None))
        self.actionbutton_g57_5.setText(QCoreApplication.translate("Form", u"G57", None))
        self.actionbutton_g57_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 4\", \"name\": \"g57_offset_status\"}]", None))
        self.actionbutton_g57_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G57", None))
        self.actionbutton_g59_17.setText(QCoreApplication.translate("Form", u"G59", None))
        self.actionbutton_g59_17.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 6\", \"name\": \"g59_offset_status\"}]", None))
        self.actionbutton_g59_17.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59", None))
        self.actionbutton_g59_18.setText(QCoreApplication.translate("Form", u"G59.2", None))
        self.actionbutton_g59_18.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 8\", \"name\": \"g59_2_offset_status\"}]", None))
        self.actionbutton_g59_18.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.2", None))
        self.actionbutton_g59_19.setText(QCoreApplication.translate("Form", u"G59.1", None))
        self.actionbutton_g59_19.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"ch[0] == 7\", \"name\": \"g59_1_offset_status\"}]", None))
        self.actionbutton_g59_19.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G59.1", None))
        self.ref_all_button_3.setText(QCoreApplication.translate("Form", u"UN REF ALL", None))
        self.ref_all_button_3.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.ref_all_button_3.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.unhome.all", None))
        self.axisactionbutton_12.setText(QCoreApplication.translate("Form", u"UN REF X", None))
        self.axisactionbutton_12.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.unhome.axis:x", None))
        self.axisactionbutton_14.setText(QCoreApplication.translate("Form", u"UN REF Z", None))
        self.axisactionbutton_14.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.unhome.axis:z", None))
        self.statuslabel.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'G7 DIAMETER MODE' if 'G7' in ch[0] else 'G8 RADIUS MODE'\", \"name\": \"diam_rad_mode_display\"}]", None))
        self.statuslabel_2.setText(QCoreApplication.translate("Form", u"R", None))
        self.statuslabel_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'D' if 'G7' in ch[0] else 'R'\", \"name\": \"diam_rad_mode_display\"}]", None))
        self.dro_entry_x_main_3.setProperty(u"inchFormat", QCoreApplication.translate("Form", u"%9.4f", None))
        self.dro_entry_x_main_3.setProperty(u"millimeterFormat", QCoreApplication.translate("Form", u"%10.3f", None))
        self.dro_entry_x_main_3.setProperty(u"degreeFormat", QCoreApplication.translate("Form", u"%10.2f", None))
        self.statuslabel_3.setText(QCoreApplication.translate("Form", u"Z", None))
        self.statuslabel_3.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.dro_entry_z_main_3.setProperty(u"inchFormat", QCoreApplication.translate("Form", u"%9.4f", None))
        self.dro_entry_z_main_3.setProperty(u"millimeterFormat", QCoreApplication.translate("Form", u"%10.3f", None))
        self.dro_entry_z_main_3.setProperty(u"degreeFormat", QCoreApplication.translate("Form", u"%10.2f", None))
        self.manual_mode_button.setText(QCoreApplication.translate("Form", u"MAN", None))
        self.manual_mode_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.mode.manual", None))
        self.auto_mode_button.setText(QCoreApplication.translate("Form", u"AUTO", None))
        self.auto_mode_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.mode.auto", None))
        self.mdi_mode_button.setText(QCoreApplication.translate("Form", u"MDI", None))
        self.mdi_mode_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.mode.mdi", None))
        self.statuslabel_19.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:gcodes?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"active_g_codes\"}]", None))
        self.statuslabel_19.setProperty(u"statusItem", "")
        self.label_240.setText("")
        self.statuslabel_26.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:mcodes?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0]\", \"name\": \"active_m_codes\"}]", None))
        self.statuslabel_26.setProperty(u"statusItem", "")
        self.label_241.setText("")
        self.jog_tab.setText(QCoreApplication.translate("Form", u"JOG", None))
        self.offset_tab.setText(QCoreApplication.translate("Form", u"OFFSET", None))
        self.dro_tab.setText(QCoreApplication.translate("Form", u"DRO", None))
        self.user_sb_tab.setText(QCoreApplication.translate("Form", u"USER", None))
        self.cycle_start_button.setText(QCoreApplication.translate("Form", u"CYCLE START", None))
        self.cycle_start_button.setProperty(u"flashOnStyleClass", QCoreApplication.translate("Form", u"active", None))
        self.cycle_start_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"probe_safety_lockout\", \"property\": \"Enable\", \"expression\": \"False if ch[0]['T'] == 99 else True\", \"channels\": [{\"url\": \"tooltable:current_tool\", \"trigger\": true}]}, {\"name\": \"resume_program\", \"property\": \"Text\", \"expression\": \"'RESUME FEED' if ch[0] else 'CYCLE START'\", \"channels\": [{\"url\": \"status:paused\", \"trigger\": true}]}, {\"name\": \"resume_program_style\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:paused\", \"trigger\": true}]}]", None))
        self.cycle_start_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.run", None))
        self.ref_coilumn_header_25.setText("")
        self.stop_button.setText(QCoreApplication.translate("Form", u"STOP", None))
        self.stop_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.abort", None))
        self.power_button.setText(QCoreApplication.translate("Form", u"POWER", None))
        self.power_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.power.toggle", None))
        self.ref_coilumn_header_16.setText("")
        self.timerhours.setText(QCoreApplication.translate("Form", u"00", None))
        self.timerhours.setProperty(u"valueFormat", QCoreApplication.translate("Form", u"02.0f", None))
        self.timerhours.setProperty(u"pinType", QCoreApplication.translate("Form", u"u32", None))
        self.timer_div1.setText(QCoreApplication.translate("Form", u":", None))
        self.timerminutes.setText(QCoreApplication.translate("Form", u"00", None))
        self.timerminutes.setProperty(u"valueFormat", QCoreApplication.translate("Form", u"02.0f", None))
        self.timerminutes.setProperty(u"pinType", QCoreApplication.translate("Form", u"u32", None))
        self.timer_div.setText(QCoreApplication.translate("Form", u":", None))
        self.timerseconds.setText(QCoreApplication.translate("Form", u"00", None))
        self.timerseconds.setProperty(u"valueFormat", QCoreApplication.translate("Form", u"02.0f", None))
        self.timerseconds.setProperty(u"pinType", QCoreApplication.translate("Form", u"u32", None))
        self.ref_coilumn_header_18.setText("")
        self.exit_button.setText(QCoreApplication.translate("Form", u"E-STOP", None))
        self.exit_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"estop_button_color\", \"property\": \"Style Sheet\", \"expression\": \"\\\"background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgba(213, 218, 216, 255), stop:0.169312 rgba(82, 82, 83, 255), stop:0.328042 rgba(72, 70, 73, 255), stop:0.492063 rgba(78, 77, 79, 255), stop:0.703704 rgba(72, 70, 73, 255), stop:0.86 rgba(82, 82, 83, 255), stop:1 rgba(213, 218, 216, 255))\\\" if ch[0] else \\\"background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(226, 64, 64, 255), stop:0.446154 rgba(204, 0, 0, 255), stop:0.764103 rgba(225, 67, 67, 255), stop:1 rgba(249, 142, 142, 255))\\\"\", \"channels\": [{\"url\": \"status:estop\", \"trigger\": true}]}]", None))
        self.exit_button.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.estop.toggle", None))
        self.m6_tool_call_main_panel.setText(QCoreApplication.translate("Form", u"T", None))
        self.m6_tool_call_main_panel.setProperty(u"filename", QCoreApplication.translate("Form", u"m6_tool_call_main_panel.ngc", None))
        self.tool_number_entry_main_panel.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.tool_number_entry_main_panel.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?tool_number\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"str(ch[0])\", \"name\": \"update tool num\"}, {\"channels\": [{\"url\": \"status:task_state?text\", \"trigger\": true}, {\"url\": \"status:interp_state?text\", \"trigger\": true}], \"property\": \"Enable\", \"expression\": \"ch[0] == 'On' and ch[1] == 'Idle'\", \"name\": \"enable/disable\"}]", None))
        self.tool_number_entry_main_panel.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.diameter_mode_button_2.setText(QCoreApplication.translate("Form", u"G7  DIAMETER", None))
        self.diameter_mode_button_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.diameter_mode_button_2.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G7", None))
        self.radius_mode_button_2.setText(QCoreApplication.translate("Form", u"G8  RADIUS", None))
        self.radius_mode_button_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.radius_mode_button_2.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G8", None))
        self.go_to_g30_button_2.setText(QCoreApplication.translate("Form", u"GO TO G30", None))
        self.go_to_g30_button_2.setProperty(u"filename", QCoreApplication.translate("Form", u"go_to_g30.ngc", None))
        self.go_to_zero_button_2.setText(QCoreApplication.translate("Form", u"GO TO ZERO", None))
        self.go_to_zero_button_2.setProperty(u"filename", QCoreApplication.translate("Form", u"go_to_zero.ngc", None))
        self.go_to_home_button_2.setText(QCoreApplication.translate("Form", u"GO TO HOME", None))
        self.go_to_home_button_2.setProperty(u"filename", QCoreApplication.translate("Form", u"go_to_home.ngc", None))
        self.g96_rpm_mode_button.setText(QCoreApplication.translate("Form", u"G96", None))
        self.g96_rpm_mode_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"check_g96\", \"property\": \"Checked\", \"expression\": \"True if \\\"G96\\\" in ch[0] else False\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.g96_rpm_mode_button.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G96 D#<css_max_rpm> S#<css_surface_speed>", None))
        self.g97_rpm_mode_button.setText(QCoreApplication.translate("Form", u"G97", None))
        self.g97_rpm_mode_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"check_g97\", \"property\": \"Checked\", \"expression\": \"True if \\\"G97\\\" in ch[0] else False\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.g97_rpm_mode_button.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G97 S#<rpm_s_word>", None))
        self.feed_upm_button.setText(QCoreApplication.translate("Form", u"G94 F MM/M", None))
        self.feed_upm_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if \\\"G94\\\" in ch[0] else False\", \"name\": \"check_g94\"}, {\"channels\": [{\"url\": \"status:program_units\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'G94  F/IPM' if ch[0] == 1 else 'G94 F MM/M'\\n\", \"name\": \"inch_metric_display\"}]", None))
        self.feed_upm_button.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G94 F#<feed_per_unit>", None))
        self.feed_per_unit.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.feed_per_unit.setProperty(u"settingName", QCoreApplication.translate("Form", u"feed-settings.feed-per-unit", None))
        self.feed_per_unit.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"g94_active\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"G94\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.feed_per_unit.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:0.1f}", None))
        self.feed_per_unit.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.feed_per_rev_button.setText(QCoreApplication.translate("Form", u"G95  F/REV", None))
        self.feed_per_rev_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}], \"property\": \"Checked\", \"expression\": \"True if \\\"G95\\\" in ch[0] else False\", \"name\": \"check_g95\"}]", None))
        self.feed_per_rev_button.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G95 F#<feed_unit_per_rev>", None))
        self.feed_unit_per_rev.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.feed_unit_per_rev.setProperty(u"settingName", QCoreApplication.translate("Form", u"feed-settings.feed-per-rev", None))
        self.feed_unit_per_rev.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"g95_active\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"G95\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.feed_unit_per_rev.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:0.4f}", None))
        self.feed_unit_per_rev.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.statuslabel_9.setText(QCoreApplication.translate("Form", u"S WORD", None))
        self.statuslabel_9.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.rpm_s_word.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.rpm_s_word.setProperty(u"settingName", QCoreApplication.translate("Form", u"rpm-settings.rpm-s-word", None))
        self.rpm_s_word.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"g97_active\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"G97\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.rpm_s_word.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.rpm_s_word.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.statuslabel_7.setText(QCoreApplication.translate("Form", u"MAX RPM", None))
        self.statuslabel_7.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.css_max_rpm.setText("")
        self.css_max_rpm.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.css_max_rpm.setProperty(u"settingName", QCoreApplication.translate("Form", u"css-settings.max-rpm", None))
        self.css_max_rpm.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"g96_active\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"G96\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.css_max_rpm.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.css_max_rpm.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.statuslabel_6.setText(QCoreApplication.translate("Form", u"SM/MIN", None))
        self.statuslabel_6.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"units_display\", \"property\": \"Text\", \"expression\": \"'SF/MIN' if ch[0] == 1 else 'SM/MIN'\", \"channels\": [{\"url\": \"status:program_units\", \"trigger\": true}]}]", None))
        self.css_surface_speed.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.css_surface_speed.setProperty(u"settingName", QCoreApplication.translate("Form", u"css-settings.surface-speed", None))
        self.css_surface_speed.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"g96_active\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"G96\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.css_surface_speed.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.css_surface_speed.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField17", None))
        self.statuslabel_4.setText(QCoreApplication.translate("Form", u"FEED", None))
        self.statuslabel_4.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.statuslabel_27.setProperty(u"format", QCoreApplication.translate("Form", u"{:.1f}", None))
        self.statuslabel_27.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:current_vel\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'%.1f' % (ch[0] * 60)\", \"name\": \"cur vel\"}]", None))
        self.statuslabel_27.setProperty(u"statusItem", "")
        self.statuslabel_8.setText(QCoreApplication.translate("Form", u"MM/M", None))
        self.statuslabel_8.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"units_display\", \"property\": \"Text\", \"expression\": \"'IN/M' if ch[0] == 1 else 'MM/M'\", \"channels\": [{\"url\": \"status:program_units\", \"trigger\": true}]}]", None))
        self.spindle_stat_rpm.setText(QCoreApplication.translate("Form", u"0", None))
        self.spindle_stat_rpm.setProperty(u"format", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.spindle_stat_rpm.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:spindle.0.speed\", \"trigger\": true}, {\"url\": \"status:spindle.0.override\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"f\\\"{(ch[0] * ch[1]):.0f}\\\"\", \"name\": \"Speed\"}]", None))
        self.spindle_encoder_rpm.setText(QCoreApplication.translate("Form", u"0", None))
        self.spindle_encoder_rpm.setProperty(u"valueFormat", QCoreApplication.translate("Form", u".0f", None))
        self.spindle_encoder_rpm.setProperty(u"pinType", QCoreApplication.translate("Form", u"float", None))
        self.spindle_encoder_rpm.setProperty(u"pinBaseName", QCoreApplication.translate("Form", u"spindle-encoder-rpm", None))
        self.rpm_label_9.setText(QCoreApplication.translate("Form", u"RPM", None))
        self.spindle_controls_stacked_widget.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"current_index\", \"property\": \"currentIndex\", \"expression\": \"0 if \\\"G97\\\" in ch[0] else 1\", \"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}]}]", None))
        self.spindle_rev_m4_mdi_button.setText(QCoreApplication.translate("Form", u" REVERSE", None))
        self.spindle_rev_m4_mdi_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"check_m4\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"M4\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:mcodes\", \"trigger\": true}]}]", None))
        self.spindle_rev_m4_mdi_button.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G97 S#<rpm_s_word> M4", None))
        self.spindle_stop_m5_mdi_button.setText(QCoreApplication.translate("Form", u"STOP", None))
        self.spindle_stop_m5_mdi_button.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"M5", None))
        self.spindle_fwd_m3_mdi_button.setText(QCoreApplication.translate("Form", u"FORWARD ", None))
        self.spindle_fwd_m3_mdi_button.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"check_m3\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"M3\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:mcodes\", \"trigger\": true}]}]", None))
        self.spindle_fwd_m3_mdi_button.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G97 S#<rpm_s_word> M3", None))
        self.spindle_rev_m4_mdi_button_2.setText(QCoreApplication.translate("Form", u" REVERSE", None))
        self.spindle_rev_m4_mdi_button_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"check_m4\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"M4\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:mcodes\", \"trigger\": true}]}]", None))
        self.spindle_rev_m4_mdi_button_2.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G96 D#<css_max_rpm> S#<css_surface_speed> M4", None))
        self.spindle_stop_m5_mdi_button_2.setText(QCoreApplication.translate("Form", u"STOP", None))
        self.spindle_stop_m5_mdi_button_2.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"M5", None))
        self.spindle_fwd_m3_mdi_button_2.setText(QCoreApplication.translate("Form", u"FORWARD ", None))
        self.spindle_fwd_m3_mdi_button_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"name\": \"check_m3\", \"property\": \"Style Class\", \"expression\": \"\\\"active\\\" if \\\"M3\\\" in ch[0] else \\\"inactive\\\"\", \"channels\": [{\"url\": \"status:mcodes\", \"trigger\": true}]}]", None))
        self.spindle_fwd_m3_mdi_button_2.setProperty(u"MDICommand", QCoreApplication.translate("Form", u"G96 D#<css_max_rpm> S#<css_surface_speed> M3", None))
        self.actionslider_7.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.rapid-override.set", None))
        self.statuslabel_22.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:rapidrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'{:.0%}'.format(ch[0])\", \"name\": \"rapid_rate_percentage\"}]", None))
        self.statuslabel_22.setProperty(u"statusItem", QCoreApplication.translate("Form", u"rapidrate", None))
        self.statuslabel_22.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.spindle_load_indicator.setProperty(u"sufix", QCoreApplication.translate("Form", u"%", None))
        self.spindle_load_indicator.setProperty(u"format", QCoreApplication.translate("Form", u".0f", None))
        self.spindle_load_indicator.setProperty(u"barGradient", [
            QCoreApplication.translate("Form", u"0.0, 170, 170, 236", None),
            QCoreApplication.translate("Form", u"0.63, 85, 85, 238", None),
            QCoreApplication.translate("Form", u"0.65, 171, 171, 158", None),
            QCoreApplication.translate("Form", u"0.79, 227, 237, 106", None),
            QCoreApplication.translate("Form", u"0.84, 219, 124, 55", None),
            QCoreApplication.translate("Form", u"1.0, 209, 0, 0", None)])
        self.work_column_header_9.setText(QCoreApplication.translate("Form", u"SPINDLE\n"
"LOAD", None))
        self.statuslabel_24.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:max_velocity\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'{:.0f}'.format(ch[0] * 60)\", \"name\": \"max_velocity\"}]", None))
        self.statuslabel_24.setProperty(u"statusItem", QCoreApplication.translate("Form", u"max_velocity", None))
        self.statuslabel_24.setProperty(u"fromat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.statuslabel_24.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.statuslabel_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:feedrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'{:.0%}'.format(ch[0])\", \"name\": \"feedrate_percentage\"}]", None))
        self.statuslabel_5.setProperty(u"statusItem", QCoreApplication.translate("Form", u"feedrate", None))
        self.statuslabel_5.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.actionbutton_59.setText(QCoreApplication.translate("Form", u"RAPID\n"
"100%", None))
        self.actionbutton_59.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.rapid-override.reset", None))
        self.actionslider_6.setProperty(u"actionName", QCoreApplication.translate("Form", u"spindle.override", None))
        self.actionbutton_58.setText(QCoreApplication.translate("Form", u"MVEL\n"
"100%", None))
        self.actionbutton_58.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.max-velocity.reset", None))
        self.statuslabel_32.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:spindle.0.override\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'{:.0%}'.format(ch[0])\", \"name\": \"spindle_override_percentage\"}]", None))
        self.statuslabel_32.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.actionbutton_56.setText(QCoreApplication.translate("Form", u"RPM\n"
"100%", None))
        self.actionbutton_56.setProperty(u"actionName", QCoreApplication.translate("Form", u"spindle.override.reset", None))
        self.actionslider_9.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.feed-override.set", None))
        self.actionbutton_57.setText(QCoreApplication.translate("Form", u"FEED\n"
"100%", None))
        self.actionbutton_57.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.feed-override.reset", None))
        self.max_velocity_slider.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.max-velocity.set", None))
        self.menuExit.setTitle(QCoreApplication.translate("Form", u"File", None))
        self.menuRecentFiles.setTitle(QCoreApplication.translate("Form", u"Recent &Files", None))
        self.menuMachine.setTitle(QCoreApplication.translate("Form", u"Machine", None))
        self.menuHoming.setTitle(QCoreApplication.translate("Form", u"Homing", None))
        self.menuCooling.setTitle(QCoreApplication.translate("Form", u"Cooling", None))
        self.menuView.setTitle(QCoreApplication.translate("Form", u"View", None))
    # retranslateUi

