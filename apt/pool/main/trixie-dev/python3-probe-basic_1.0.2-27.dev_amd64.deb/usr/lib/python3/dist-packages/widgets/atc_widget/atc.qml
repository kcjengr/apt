import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: rectangle
    visible: true
    width: widget_width
    height: widget_height
    color: bg_color
    opacity: 1

    Image {
        id: atc_holder
        width: widget_width
        height: widget_height
        visible: true
        x: parent.width / 2 - width / 2
        y: parent.height / 2 - height / 2
        antialiasing: true
        z: 0
        rotation: rectangle.carousel_angle
        transformOrigin: Item.Center
        source: "images/carousel_"+pocket_slots+".png"


        NumberAnimation {
            id: atc_anim
            target: rectangle
            property: "carousel_angle"
            duration: anim_duration
            easing.type: Easing.Linear
            running: false
        }

        Repeater {
            id: pocket_slot
            model: pocket_slots
            rotation: 0

            delegate: Item {

                id: pocket_item

                height: atc_holder.height/2
                transformOrigin: Item.Bottom
                rotation: -index * 360/pocket_slots - 90
                x: atc_holder.width/2
                y: 0

                property string pocket_num: index+1
                property alias pocketRect: pocket_rectangle
                property alias pocketLabel: pocket_text

                Rectangle {
                    id: pocket_rectangle

                    height: pocket_diam
                    width: pocket_diam
//                    radius: tool_diam/2
                    color: "white"
//                    border.color: "black"
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.top: parent.top
                    anchors.topMargin: pocket_position
                    border.width: 0
                    rotation: 360/pocket_slots * index + 90


                    Text {
                        id: pocket_text
                        text: "P" + pocket_item.pocket_num
                        color: "black"
                        font.family: "Probe Basic Bebas Mono"
                        font.bold: false
                        verticalAlignment: Text.AlignVCenter
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 24
                        x: parent.width / 2 - width / 2
                        y: parent.height / 2 - height / 2
                        rotation: -rectangle.carousel_angle
                    }
                }
            }
        }

        Repeater {
            id: tool_slot
            model: pocket_slots
            rotation: 0

            delegate: Item {

                id: tool_item
                height: atc_holder.height/2
                transformOrigin: Item.Bottom
                rotation: -index * 360/pocket_slots + 90
                x: atc_holder.width/2
                y: 0

                state: "visible"

                property int tool_num: index+1
                property alias toolRect: tool_rectangle
                property alias toolLabel: tool_text

                Rectangle {
                    id: tool_rectangle

                    height: tool_diam
                    width: tool_diam
                    radius: tool_diam/2
                    color: "white"
                    border.color: "grey"
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.top: parent.top
                    anchors.topMargin: 4
                    border.width: 2
                    rotation: 360/pocket_slots * index - 90

                    Text {
                        id: tool_text
                        text: "T" + tool_item.tool_num
                        font.family: "Probe Basic Bebas Mono"
                        font.bold: false
                        verticalAlignment: Text.AlignVCenter
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 24
                        x: parent.width / 2 - width / 2
                        y: parent.height / 2 - height / 2
                        rotation: -rectangle.carousel_angle
                    }
                }

                states: [
                    State {
                        name: "hidden"
                        PropertyChanges { target: tool_slot.itemAt(index); visible: false}
                    },
                    State {
                        name: "visible"
                        PropertyChanges { target: tool_slot.itemAt(index); visible: true}
                    }
                ]
            }
        }
    }


    Text {
        id: msg_text
        width: 206
        height: 91
        x: parent.width/2 - width/2
        y: parent.height/2 - height/2
        text: qsTr("UN REFERENCED")
        visible: true
        font.capitalization: Font.AllUppercase
        font.pixelSize: 36
        font.family: "Probe Basic Bebas Mono"
        fontSizeMode: Text.Fit
        verticalAlignment: Text.AlignVCenter
        horizontalAlignment: Text.AlignHCenter

        Behavior on text {
            // FadeAnimation was Qt5-only; use a fade-out/in sequence for Qt6
            SequentialAnimation {
                NumberAnimation { target: msg_text; property: "opacity"; to: 0; duration: 150; easing.type: Easing.InOutQuad }
                PropertyAction  { target: msg_text; property: "text" }
                NumberAnimation { target: msg_text; property: "opacity"; to: 1; duration: 150; easing.type: Easing.InOutQuad }
            }
        }
    }


    function rotate_atc(anim, duration, from, to) {

        anim.duration = duration;
        anim.from = from;
        anim.to = to;
        anim.restart();
    }

    // carousel size
    property int widget_width: 500
    property int widget_height: 500

    // color properties
    property color bg_color: "grey"

    // Animation Properties
    property real carousel_angle: 0;
    property real anim_to: 0;
    property int anim_duration: 0;

    // Carousel Properties
    property int pocket_slots: 12;

    property int pocket_position: 100;
    property int pocket_diam: 32;
    property int tool_diam: 70;

    property int prev_pocket: 1;

    property int rotation_duration: 100;


    function rotate(steps, direction) {
        var step_angle = (360 / pocket_slots) * steps;
        var current_angle = rectangle.carousel_angle;

        if (direction === 1)
            anim_to = current_angle + step_angle;
        else if (direction === -1)
            anim_to = current_angle - step_angle;
        else
            return;

        anim_duration = Math.max(1, rotation_duration * Math.abs(steps));

        rotate_atc(atc_anim, anim_duration, current_angle, anim_to);
    }

    Connections {
        target: atc_spiner;

        function onAtcInitSig(pockets, step_duration) {
            rotation_duration = step_duration;
            carousel_angle = 0;
            anim_to = 0;

            pocket_slots = pockets;
            if (pocket_slots == 8) {
                pocket_position = 130;
                pocket_diam = 32;
                tool_diam = 85;
            }
            else if (pocket_slots == 10){
                pocket_position = 130;
                pocket_diam = 32;
                tool_diam = 85;
            }
            else if (pocket_slots == 12){
                pocket_position = 100;
                pocket_diam = 32;
                tool_diam = 70;
            }
            else if (pocket_slots == 14){
                pocket_position = 100;
                pocket_diam = 32;
                tool_diam = 63;
            }
            else if (pocket_slots == 16){
                pocket_position = 100;
                pocket_diam = 32;
                tool_diam = 67;
            }
            else if (pocket_slots == 18){
                pocket_position = 90;
                pocket_diam = 32;
                tool_diam = 60;
            }
            else if (pocket_slots == 20){
                pocket_position = 80;
                pocket_diam = 32;
                tool_diam = 55;
            }
            else if (pocket_slots == 21){
                pocket_position = 80;
                pocket_diam = 32;
                tool_diam = 50;
            }
            else if (pocket_slots == 24){
                pocket_position = 70;
                pocket_diam = 32;
                tool_diam = 45;
            }
        }

        function onResizeSig(width, height) {
            widget_width = width;
            widget_height = height;
            pocket_position = width - ((width/2) * 0.5);
            tool_diam = width/ 7.85;
        }
        function onBgColorSig(color) {
            bg_color = color;
        }

        function onHideToolSig(pocket) {
            tool_slot.itemAt(pocket - 1).state = "hidden";
        }

        function onShowToolSig(pocket, tool_num) {
            tool_slot.itemAt(pocket - 1).tool_num = tool_num;
            tool_slot.itemAt(pocket - 1).state = "visible";
        }

        function onHighlightPocketSig(pocket, highlight) {
            var item = tool_slot.itemAt(pocket - 1);
            if (!item) {
                return;
            }

            item.toolRect.color = highlight ? "#8381ff" : "white";
            item.toolRect.border.color = highlight ? "gray" : "gray";
            item.toolLabel.color = highlight ? "white" : "black";
        }

        function onRotateSig(steps, direction) {
            rotate(steps, direction);
        }

        function onHomeMsgSig(message) {
            msg_text.text = message;
        }
    }
}
