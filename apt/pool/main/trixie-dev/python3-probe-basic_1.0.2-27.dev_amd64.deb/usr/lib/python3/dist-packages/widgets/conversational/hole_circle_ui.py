# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'hole_circle.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QSizePolicy,
    QVBoxLayout, QWidget)

from qtpyvcp.widgets.input_widgets.setting_slider import (VCPSettingsComboBox, VCPSettingsLineEdit)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1326, 540)
        Form.setStyleSheet(u"QLabel{\n"
"color: rgb(255, 255, 255);\n"
"}\n"
"\n"
"{\n"
"font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout = QHBoxLayout(Form)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.bolt_hole_diagram_widget = QWidget(Form)
        self.bolt_hole_diagram_widget.setObjectName(u"bolt_hole_diagram_widget")
        self.bolt_hole_diagram_widget.setMinimumSize(QSize(820, 530))
        self.bolt_hole_diagram_widget.setMaximumSize(QSize(820, 530))
        self.bolt_hole_diagram_widget.setStyleSheet(u"")
        self.frame_24 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_24.setObjectName(u"frame_24")
        self.frame_24.setGeometry(QRect(41, 182, 140, 50))
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_24.sizePolicy().hasHeightForWidth())
        self.frame_24.setSizePolicy(sizePolicy)
        self.frame_24.setMinimumSize(QSize(140, 50))
        self.frame_24.setMaximumSize(QSize(140, 50))
        self.frame_24.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_191 = QHBoxLayout(self.frame_24)
        self.horizontalLayout_191.setObjectName(u"horizontalLayout_191")
        self.horizontalLayout_191.setContentsMargins(2, 2, 2, 2)
        self.label_138 = QLabel(self.frame_24)
        self.label_138.setObjectName(u"label_138")
        sizePolicy.setHeightForWidth(self.label_138.sizePolicy().hasHeightForWidth())
        self.label_138.setSizePolicy(sizePolicy)
        self.label_138.setMinimumSize(QSize(50, 33))
        self.label_138.setMaximumSize(QSize(50, 33))
        self.label_138.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_138.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_138.setWordWrap(True)

        self.horizontalLayout_191.addWidget(self.label_138)

        self.diameter_input = VCPSettingsLineEdit(self.frame_24)
        self.diameter_input.setObjectName(u"diameter_input")
        sizePolicy.setHeightForWidth(self.diameter_input.sizePolicy().hasHeightForWidth())
        self.diameter_input.setSizePolicy(sizePolicy)
        self.diameter_input.setMinimumSize(QSize(70, 33))
        self.diameter_input.setMaximumSize(QSize(70, 33))
        self.diameter_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.diameter_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_191.addWidget(self.diameter_input)

        self.frame_25 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_25.setObjectName(u"frame_25")
        self.frame_25.setGeometry(QRect(556, 20, 140, 50))
        sizePolicy.setHeightForWidth(self.frame_25.sizePolicy().hasHeightForWidth())
        self.frame_25.setSizePolicy(sizePolicy)
        self.frame_25.setMinimumSize(QSize(140, 50))
        self.frame_25.setMaximumSize(QSize(140, 50))
        self.frame_25.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_193 = QHBoxLayout(self.frame_25)
        self.horizontalLayout_193.setObjectName(u"horizontalLayout_193")
        self.horizontalLayout_193.setContentsMargins(2, 2, 2, 2)
        self.label_139 = QLabel(self.frame_25)
        self.label_139.setObjectName(u"label_139")
        sizePolicy.setHeightForWidth(self.label_139.sizePolicy().hasHeightForWidth())
        self.label_139.setSizePolicy(sizePolicy)
        self.label_139.setMinimumSize(QSize(50, 33))
        self.label_139.setMaximumSize(QSize(50, 33))
        self.label_139.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_139.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_139.setWordWrap(True)

        self.horizontalLayout_193.addWidget(self.label_139)

        self.num_holes_input = VCPSettingsLineEdit(self.frame_25)
        self.num_holes_input.setObjectName(u"num_holes_input")
        sizePolicy.setHeightForWidth(self.num_holes_input.sizePolicy().hasHeightForWidth())
        self.num_holes_input.setSizePolicy(sizePolicy)
        self.num_holes_input.setMinimumSize(QSize(70, 33))
        self.num_holes_input.setMaximumSize(QSize(70, 33))
        self.num_holes_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.num_holes_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_193.addWidget(self.num_holes_input)

        self.frame_42 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_42.setObjectName(u"frame_42")
        self.frame_42.setGeometry(QRect(632, 142, 140, 50))
        sizePolicy.setHeightForWidth(self.frame_42.sizePolicy().hasHeightForWidth())
        self.frame_42.setSizePolicy(sizePolicy)
        self.frame_42.setMinimumSize(QSize(140, 50))
        self.frame_42.setMaximumSize(QSize(140, 50))
        self.frame_42.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_195 = QHBoxLayout(self.frame_42)
        self.horizontalLayout_195.setObjectName(u"horizontalLayout_195")
        self.horizontalLayout_195.setContentsMargins(2, 2, 2, 2)
        self.label_140 = QLabel(self.frame_42)
        self.label_140.setObjectName(u"label_140")
        sizePolicy.setHeightForWidth(self.label_140.sizePolicy().hasHeightForWidth())
        self.label_140.setSizePolicy(sizePolicy)
        self.label_140.setMinimumSize(QSize(50, 33))
        self.label_140.setMaximumSize(QSize(35, 33))
        self.label_140.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_140.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_140.setWordWrap(True)

        self.horizontalLayout_195.addWidget(self.label_140)

        self.start_angle_input = VCPSettingsLineEdit(self.frame_42)
        self.start_angle_input.setObjectName(u"start_angle_input")
        sizePolicy.setHeightForWidth(self.start_angle_input.sizePolicy().hasHeightForWidth())
        self.start_angle_input.setSizePolicy(sizePolicy)
        self.start_angle_input.setMinimumSize(QSize(70, 33))
        self.start_angle_input.setMaximumSize(QSize(70, 33))
        self.start_angle_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.start_angle_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_195.addWidget(self.start_angle_input)

        self.frame_46 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_46.setObjectName(u"frame_46")
        self.frame_46.setGeometry(QRect(599, 296, 140, 50))
        sizePolicy.setHeightForWidth(self.frame_46.sizePolicy().hasHeightForWidth())
        self.frame_46.setSizePolicy(sizePolicy)
        self.frame_46.setMinimumSize(QSize(140, 50))
        self.frame_46.setMaximumSize(QSize(140, 50))
        self.frame_46.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_199 = QHBoxLayout(self.frame_46)
        self.horizontalLayout_199.setObjectName(u"horizontalLayout_199")
        self.horizontalLayout_199.setContentsMargins(2, 2, 2, 2)
        self.label_141 = QLabel(self.frame_46)
        self.label_141.setObjectName(u"label_141")
        sizePolicy.setHeightForWidth(self.label_141.sizePolicy().hasHeightForWidth())
        self.label_141.setSizePolicy(sizePolicy)
        self.label_141.setMinimumSize(QSize(50, 33))
        self.label_141.setMaximumSize(QSize(50, 33))
        self.label_141.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_141.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_141.setWordWrap(True)

        self.horizontalLayout_199.addWidget(self.label_141)

        self.center_x_input = VCPSettingsLineEdit(self.frame_46)
        self.center_x_input.setObjectName(u"center_x_input")
        sizePolicy.setHeightForWidth(self.center_x_input.sizePolicy().hasHeightForWidth())
        self.center_x_input.setSizePolicy(sizePolicy)
        self.center_x_input.setMinimumSize(QSize(70, 33))
        self.center_x_input.setMaximumSize(QSize(70, 33))
        self.center_x_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.center_x_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_199.addWidget(self.center_x_input)

        self.frame_47 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_47.setObjectName(u"frame_47")
        self.frame_47.setGeometry(QRect(599, 353, 140, 50))
        sizePolicy.setHeightForWidth(self.frame_47.sizePolicy().hasHeightForWidth())
        self.frame_47.setSizePolicy(sizePolicy)
        self.frame_47.setMinimumSize(QSize(140, 50))
        self.frame_47.setMaximumSize(QSize(140, 50))
        self.frame_47.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_201 = QHBoxLayout(self.frame_47)
        self.horizontalLayout_201.setObjectName(u"horizontalLayout_201")
        self.horizontalLayout_201.setContentsMargins(2, 2, 2, 2)
        self.label_142 = QLabel(self.frame_47)
        self.label_142.setObjectName(u"label_142")
        sizePolicy.setHeightForWidth(self.label_142.sizePolicy().hasHeightForWidth())
        self.label_142.setSizePolicy(sizePolicy)
        self.label_142.setMinimumSize(QSize(50, 33))
        self.label_142.setMaximumSize(QSize(50, 33))
        self.label_142.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_142.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_142.setWordWrap(True)

        self.horizontalLayout_201.addWidget(self.label_142)

        self.center_y_input = VCPSettingsLineEdit(self.frame_47)
        self.center_y_input.setObjectName(u"center_y_input")
        sizePolicy.setHeightForWidth(self.center_y_input.sizePolicy().hasHeightForWidth())
        self.center_y_input.setSizePolicy(sizePolicy)
        self.center_y_input.setMinimumSize(QSize(70, 33))
        self.center_y_input.setMaximumSize(QSize(70, 33))
        self.center_y_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.center_y_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_201.addWidget(self.center_y_input)

        self.verticalLayoutWidget_2 = QWidget(self.bolt_hole_diagram_widget)
        self.verticalLayoutWidget_2.setObjectName(u"verticalLayoutWidget_2")
        self.verticalLayoutWidget_2.setGeometry(QRect(1217, 20, 161, 362))
        self.verticalLayout_59 = QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_59.setObjectName(u"verticalLayout_59")
        self.verticalLayout_59.setContentsMargins(0, 0, 0, 0)
        self.frame_55 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_55.setObjectName(u"frame_55")
        self.frame_55.setGeometry(QRect(618, 459, 140, 50))
        sizePolicy.setHeightForWidth(self.frame_55.sizePolicy().hasHeightForWidth())
        self.frame_55.setSizePolicy(sizePolicy)
        self.frame_55.setMinimumSize(QSize(140, 50))
        self.frame_55.setMaximumSize(QSize(140, 50))
        self.frame_55.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_207 = QHBoxLayout(self.frame_55)
        self.horizontalLayout_207.setObjectName(u"horizontalLayout_207")
        self.horizontalLayout_207.setContentsMargins(2, 2, 2, 2)
        self.label_147 = QLabel(self.frame_55)
        self.label_147.setObjectName(u"label_147")
        sizePolicy.setHeightForWidth(self.label_147.sizePolicy().hasHeightForWidth())
        self.label_147.setSizePolicy(sizePolicy)
        self.label_147.setMinimumSize(QSize(50, 33))
        self.label_147.setMaximumSize(QSize(35, 33))
        self.label_147.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_147.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_147.setWordWrap(True)

        self.horizontalLayout_207.addWidget(self.label_147)

        self.retract_height_input = VCPSettingsLineEdit(self.frame_55)
        self.retract_height_input.setObjectName(u"retract_height_input")
        sizePolicy.setHeightForWidth(self.retract_height_input.sizePolicy().hasHeightForWidth())
        self.retract_height_input.setSizePolicy(sizePolicy)
        self.retract_height_input.setMinimumSize(QSize(70, 33))
        self.retract_height_input.setMaximumSize(QSize(70, 33))
        self.retract_height_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.retract_height_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_207.addWidget(self.retract_height_input)

        self.frame_56 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_56.setObjectName(u"frame_56")
        self.frame_56.setGeometry(QRect(26, 406, 140, 50))
        sizePolicy.setHeightForWidth(self.frame_56.sizePolicy().hasHeightForWidth())
        self.frame_56.setSizePolicy(sizePolicy)
        self.frame_56.setMinimumSize(QSize(140, 50))
        self.frame_56.setMaximumSize(QSize(140, 50))
        self.frame_56.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_209 = QHBoxLayout(self.frame_56)
        self.horizontalLayout_209.setObjectName(u"horizontalLayout_209")
        self.horizontalLayout_209.setContentsMargins(2, 2, 2, 2)
        self.label_151 = QLabel(self.frame_56)
        self.label_151.setObjectName(u"label_151")
        sizePolicy.setHeightForWidth(self.label_151.sizePolicy().hasHeightForWidth())
        self.label_151.setSizePolicy(sizePolicy)
        self.label_151.setMinimumSize(QSize(50, 33))
        self.label_151.setMaximumSize(QSize(50, 33))
        self.label_151.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_151.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_151.setWordWrap(True)

        self.horizontalLayout_209.addWidget(self.label_151)

        self.z_start_input = VCPSettingsLineEdit(self.frame_56)
        self.z_start_input.setObjectName(u"z_start_input")
        sizePolicy.setHeightForWidth(self.z_start_input.sizePolicy().hasHeightForWidth())
        self.z_start_input.setSizePolicy(sizePolicy)
        self.z_start_input.setMinimumSize(QSize(70, 33))
        self.z_start_input.setMaximumSize(QSize(70, 33))
        self.z_start_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_start_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_209.addWidget(self.z_start_input)

        self.frame_57 = QFrame(self.bolt_hole_diagram_widget)
        self.frame_57.setObjectName(u"frame_57")
        self.frame_57.setGeometry(QRect(26, 473, 140, 50))
        sizePolicy.setHeightForWidth(self.frame_57.sizePolicy().hasHeightForWidth())
        self.frame_57.setSizePolicy(sizePolicy)
        self.frame_57.setMinimumSize(QSize(140, 50))
        self.frame_57.setMaximumSize(QSize(140, 50))
        self.frame_57.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_211 = QHBoxLayout(self.frame_57)
        self.horizontalLayout_211.setObjectName(u"horizontalLayout_211")
        self.horizontalLayout_211.setContentsMargins(2, 2, 2, 2)
        self.label_152 = QLabel(self.frame_57)
        self.label_152.setObjectName(u"label_152")
        sizePolicy.setHeightForWidth(self.label_152.sizePolicy().hasHeightForWidth())
        self.label_152.setSizePolicy(sizePolicy)
        self.label_152.setMinimumSize(QSize(50, 33))
        self.label_152.setMaximumSize(QSize(50, 33))
        self.label_152.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_152.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_152.setWordWrap(True)

        self.horizontalLayout_211.addWidget(self.label_152)

        self.z_end_input = VCPSettingsLineEdit(self.frame_57)
        self.z_end_input.setObjectName(u"z_end_input")
        sizePolicy.setHeightForWidth(self.z_end_input.sizePolicy().hasHeightForWidth())
        self.z_end_input.setSizePolicy(sizePolicy)
        self.z_end_input.setMinimumSize(QSize(70, 33))
        self.z_end_input.setMaximumSize(QSize(70, 33))
        self.z_end_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_end_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_211.addWidget(self.z_end_input)

        self.label_2 = QLabel(self.bolt_hole_diagram_widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(0, -13, 800, 550))
        self.label_2.setMinimumSize(QSize(800, 550))
        self.label_2.setMaximumSize(QSize(800, 550))
        self.label_2.setPixmap(QPixmap(u":/images/drill_circle.png"))
        self.label_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_2.raise_()
        self.frame_24.raise_()
        self.frame_25.raise_()
        self.frame_42.raise_()
        self.frame_46.raise_()
        self.frame_47.raise_()
        self.verticalLayoutWidget_2.raise_()
        self.frame_55.raise_()
        self.frame_56.raise_()
        self.frame_57.raise_()

        self.horizontalLayout.addWidget(self.bolt_hole_diagram_widget)

        self.bolt_hole_setup_frame_3 = QFrame(Form)
        self.bolt_hole_setup_frame_3.setObjectName(u"bolt_hole_setup_frame_3")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.bolt_hole_setup_frame_3.sizePolicy().hasHeightForWidth())
        self.bolt_hole_setup_frame_3.setSizePolicy(sizePolicy1)
        self.bolt_hole_setup_frame_3.setMinimumSize(QSize(500, 540))
        self.bolt_hole_setup_frame_3.setMaximumSize(QSize(500, 540))
        self.bolt_hole_setup_frame_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.bolt_hole_setup_frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout = QVBoxLayout(self.bolt_hole_setup_frame_3)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(9, 9, 9, 9)
        self.widget = QWidget(self.bolt_hole_setup_frame_3)
        self.widget.setObjectName(u"widget")
        self.widget.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")
        self.gridLayout_2 = QGridLayout(self.widget)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setHorizontalSpacing(6)
        self.gridLayout_2.setContentsMargins(1, 1, 1, 1)
        self.label_169 = QLabel(self.widget)
        self.label_169.setObjectName(u"label_169")
        sizePolicy.setHeightForWidth(self.label_169.sizePolicy().hasHeightForWidth())
        self.label_169.setSizePolicy(sizePolicy)
        self.label_169.setMinimumSize(QSize(120, 35))
        self.label_169.setMaximumSize(QSize(120, 35))
        font = QFont()
        font.setFamilies([u"Probe Basic Bebas Mono"])
        font.setPointSize(14)
        font.setBold(False)
        font.setItalic(False)
        self.label_169.setFont(font)
        self.label_169.setLineWidth(0)
        self.label_169.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_169.setIndent(0)

        self.gridLayout_2.addWidget(self.label_169, 2, 0, 1, 1)

        self.label_174 = QLabel(self.widget)
        self.label_174.setObjectName(u"label_174")
        sizePolicy.setHeightForWidth(self.label_174.sizePolicy().hasHeightForWidth())
        self.label_174.setSizePolicy(sizePolicy)
        self.label_174.setMinimumSize(QSize(120, 35))
        self.label_174.setMaximumSize(QSize(120, 35))
        self.label_174.setFont(font)
        self.label_174.setLineWidth(0)
        self.label_174.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_174.setIndent(0)

        self.gridLayout_2.addWidget(self.label_174, 10, 0, 1, 1)

        self.label_173 = QLabel(self.widget)
        self.label_173.setObjectName(u"label_173")
        sizePolicy.setHeightForWidth(self.label_173.sizePolicy().hasHeightForWidth())
        self.label_173.setSizePolicy(sizePolicy)
        self.label_173.setMinimumSize(QSize(120, 35))
        self.label_173.setMaximumSize(QSize(120, 35))
        self.label_173.setFont(font)
        self.label_173.setLineWidth(0)
        self.label_173.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_173.setIndent(0)

        self.gridLayout_2.addWidget(self.label_173, 9, 0, 1, 1)

        self.label_168 = QLabel(self.widget)
        self.label_168.setObjectName(u"label_168")
        sizePolicy.setHeightForWidth(self.label_168.sizePolicy().hasHeightForWidth())
        self.label_168.setSizePolicy(sizePolicy)
        self.label_168.setMinimumSize(QSize(120, 35))
        self.label_168.setMaximumSize(QSize(120, 35))
        self.label_168.setFont(font)
        self.label_168.setLineWidth(0)
        self.label_168.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_168.setIndent(0)

        self.gridLayout_2.addWidget(self.label_168, 0, 0, 1, 1)

        self.label_175 = QLabel(self.widget)
        self.label_175.setObjectName(u"label_175")
        sizePolicy.setHeightForWidth(self.label_175.sizePolicy().hasHeightForWidth())
        self.label_175.setSizePolicy(sizePolicy)
        self.label_175.setMinimumSize(QSize(120, 35))
        self.label_175.setMaximumSize(QSize(120, 35))
        self.label_175.setFont(font)
        self.label_175.setLineWidth(0)
        self.label_175.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_175.setIndent(0)

        self.gridLayout_2.addWidget(self.label_175, 11, 0, 1, 1)

        self.tool_number_label_3 = QLabel(self.widget)
        self.tool_number_label_3.setObjectName(u"tool_number_label_3")
        sizePolicy.setHeightForWidth(self.tool_number_label_3.sizePolicy().hasHeightForWidth())
        self.tool_number_label_3.setSizePolicy(sizePolicy)
        self.tool_number_label_3.setMinimumSize(QSize(120, 35))
        self.tool_number_label_3.setMaximumSize(QSize(120, 35))
        self.tool_number_label_3.setFont(font)
        self.tool_number_label_3.setLineWidth(0)
        self.tool_number_label_3.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.tool_number_label_3.setIndent(0)

        self.gridLayout_2.addWidget(self.tool_number_label_3, 6, 0, 1, 1)

        self.name_input = QLineEdit(self.widget)
        self.name_input.setObjectName(u"name_input")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.name_input.sizePolicy().hasHeightForWidth())
        self.name_input.setSizePolicy(sizePolicy2)
        self.name_input.setMinimumSize(QSize(0, 35))
        self.name_input.setMaximumSize(QSize(16777215, 35))
        self.name_input.setStyleSheet(u"padding-left: 6px;")
        self.name_input.setCursorPosition(9)

        self.gridLayout_2.addWidget(self.name_input, 0, 2, 1, 3)

        self.drill_type_param_label = QLabel(self.widget)
        self.drill_type_param_label.setObjectName(u"drill_type_param_label")
        sizePolicy2.setHeightForWidth(self.drill_type_param_label.sizePolicy().hasHeightForWidth())
        self.drill_type_param_label.setSizePolicy(sizePolicy2)
        self.drill_type_param_label.setMinimumSize(QSize(115, 35))
        self.drill_type_param_label.setMaximumSize(QSize(115, 35))
        self.drill_type_param_label.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";\n"
"")
        self.drill_type_param_label.setLineWidth(0)
        self.drill_type_param_label.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drill_type_param_label.setIndent(0)

        self.gridLayout_2.addWidget(self.drill_type_param_label, 3, 3, 1, 1)

        self.tool_description = QLabel(self.widget)
        self.tool_description.setObjectName(u"tool_description")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(1)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.tool_description.sizePolicy().hasHeightForWidth())
        self.tool_description.setSizePolicy(sizePolicy3)
        self.tool_description.setMinimumSize(QSize(115, 35))
        self.tool_description.setMaximumSize(QSize(16777215, 35))
        self.tool_description.setFont(font)
        self.tool_description.setLineWidth(0)
        self.tool_description.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.tool_description.setIndent(0)

        self.gridLayout_2.addWidget(self.tool_description, 6, 3, 1, 1)

        self.label_172 = QLabel(self.widget)
        self.label_172.setObjectName(u"label_172")
        sizePolicy.setHeightForWidth(self.label_172.sizePolicy().hasHeightForWidth())
        self.label_172.setSizePolicy(sizePolicy)
        self.label_172.setMinimumSize(QSize(120, 35))
        self.label_172.setMaximumSize(QSize(120, 35))
        self.label_172.setFont(font)
        self.label_172.setLineWidth(0)
        self.label_172.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_172.setIndent(0)

        self.gridLayout_2.addWidget(self.label_172, 8, 0, 1, 1)

        self.label_132 = QLabel(self.widget)
        self.label_132.setObjectName(u"label_132")
        sizePolicy.setHeightForWidth(self.label_132.sizePolicy().hasHeightForWidth())
        self.label_132.setSizePolicy(sizePolicy)
        self.label_132.setMinimumSize(QSize(120, 35))
        self.label_132.setMaximumSize(QSize(120, 35))
        self.label_132.setFont(font)
        self.label_132.setLineWidth(0)
        self.label_132.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_132.setIndent(0)

        self.gridLayout_2.addWidget(self.label_132, 1, 0, 1, 1)

        self.label_170 = QLabel(self.widget)
        self.label_170.setObjectName(u"label_170")
        sizePolicy.setHeightForWidth(self.label_170.sizePolicy().hasHeightForWidth())
        self.label_170.setSizePolicy(sizePolicy)
        self.label_170.setMinimumSize(QSize(120, 35))
        self.label_170.setMaximumSize(QSize(120, 35))
        self.label_170.setFont(font)
        self.label_170.setLineWidth(0)
        self.label_170.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_170.setIndent(0)

        self.gridLayout_2.addWidget(self.label_170, 7, 0, 1, 1)

        self.label_176 = QLabel(self.widget)
        self.label_176.setObjectName(u"label_176")
        sizePolicy.setHeightForWidth(self.label_176.sizePolicy().hasHeightForWidth())
        self.label_176.setSizePolicy(sizePolicy)
        self.label_176.setMinimumSize(QSize(120, 35))
        self.label_176.setMaximumSize(QSize(120, 35))
        self.label_176.setFont(font)
        self.label_176.setLineWidth(0)
        self.label_176.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_176.setIndent(0)

        self.gridLayout_2.addWidget(self.label_176, 5, 0, 1, 1)

        self.drill_type_label = QLabel(self.widget)
        self.drill_type_label.setObjectName(u"drill_type_label")
        sizePolicy.setHeightForWidth(self.drill_type_label.sizePolicy().hasHeightForWidth())
        self.drill_type_label.setSizePolicy(sizePolicy)
        self.drill_type_label.setMinimumSize(QSize(120, 35))
        self.drill_type_label.setMaximumSize(QSize(120, 35))
        self.drill_type_label.setFont(font)
        self.drill_type_label.setLineWidth(0)
        self.drill_type_label.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.drill_type_label.setIndent(0)

        self.gridLayout_2.addWidget(self.drill_type_label, 3, 0, 1, 1)

        self.label_171 = QLabel(self.widget)
        self.label_171.setObjectName(u"label_171")
        sizePolicy3.setHeightForWidth(self.label_171.sizePolicy().hasHeightForWidth())
        self.label_171.setSizePolicy(sizePolicy3)
        self.label_171.setMinimumSize(QSize(115, 35))
        self.label_171.setMaximumSize(QSize(115, 35))
        self.label_171.setFont(font)
        self.label_171.setLineWidth(0)
        self.label_171.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_171.setIndent(0)

        self.gridLayout_2.addWidget(self.label_171, 7, 3, 1, 1)

        self.wcs_input = VCPSettingsComboBox(self.widget)
        self.wcs_input.setObjectName(u"wcs_input")
        sizePolicy.setHeightForWidth(self.wcs_input.sizePolicy().hasHeightForWidth())
        self.wcs_input.setSizePolicy(sizePolicy)
        self.wcs_input.setMinimumSize(QSize(100, 35))
        self.wcs_input.setMaximumSize(QSize(100, 35))
        self.wcs_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_2.addWidget(self.wcs_input, 1, 2, 1, 1)

        self.unit_input = VCPSettingsComboBox(self.widget)
        self.unit_input.setObjectName(u"unit_input")
        sizePolicy.setHeightForWidth(self.unit_input.sizePolicy().hasHeightForWidth())
        self.unit_input.setSizePolicy(sizePolicy)
        self.unit_input.setMinimumSize(QSize(100, 35))
        self.unit_input.setMaximumSize(QSize(100, 35))
        self.unit_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_2.addWidget(self.unit_input, 2, 2, 1, 1)

        self.drill_type_input = VCPSettingsComboBox(self.widget)
        self.drill_type_input.setObjectName(u"drill_type_input")
        sizePolicy.setHeightForWidth(self.drill_type_input.sizePolicy().hasHeightForWidth())
        self.drill_type_input.setSizePolicy(sizePolicy)
        self.drill_type_input.setMinimumSize(QSize(100, 35))
        self.drill_type_input.setMaximumSize(QSize(100, 35))
        self.drill_type_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_2.addWidget(self.drill_type_input, 3, 2, 1, 1)

        self.drill_retract_mode_input = VCPSettingsComboBox(self.widget)
        self.drill_retract_mode_input.setObjectName(u"drill_retract_mode_input")
        sizePolicy.setHeightForWidth(self.drill_retract_mode_input.sizePolicy().hasHeightForWidth())
        self.drill_retract_mode_input.setSizePolicy(sizePolicy)
        self.drill_retract_mode_input.setMinimumSize(QSize(100, 35))
        self.drill_retract_mode_input.setMaximumSize(QSize(100, 35))
        self.drill_retract_mode_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_2.addWidget(self.drill_retract_mode_input, 5, 2, 1, 1)

        self.tool_number_input = VCPSettingsLineEdit(self.widget)
        self.tool_number_input.setObjectName(u"tool_number_input")
        sizePolicy.setHeightForWidth(self.tool_number_input.sizePolicy().hasHeightForWidth())
        self.tool_number_input.setSizePolicy(sizePolicy)
        self.tool_number_input.setMinimumSize(QSize(100, 33))
        self.tool_number_input.setMaximumSize(QSize(100, 33))
        self.tool_number_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_2.addWidget(self.tool_number_input, 6, 2, 1, 1)

        self.spindle_rpm_input = VCPSettingsLineEdit(self.widget)
        self.spindle_rpm_input.setObjectName(u"spindle_rpm_input")
        sizePolicy.setHeightForWidth(self.spindle_rpm_input.sizePolicy().hasHeightForWidth())
        self.spindle_rpm_input.setSizePolicy(sizePolicy)
        self.spindle_rpm_input.setMinimumSize(QSize(100, 33))
        self.spindle_rpm_input.setMaximumSize(QSize(100, 33))
        self.spindle_rpm_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_2.addWidget(self.spindle_rpm_input, 7, 2, 1, 1)

        self.coolant_input = VCPSettingsComboBox(self.widget)
        self.coolant_input.setObjectName(u"coolant_input")
        sizePolicy.setHeightForWidth(self.coolant_input.sizePolicy().hasHeightForWidth())
        self.coolant_input.setSizePolicy(sizePolicy)
        self.coolant_input.setMinimumSize(QSize(100, 35))
        self.coolant_input.setMaximumSize(QSize(100, 35))
        self.coolant_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_2.addWidget(self.coolant_input, 8, 2, 1, 1)

        self.xy_feed_rate_input = VCPSettingsLineEdit(self.widget)
        self.xy_feed_rate_input.setObjectName(u"xy_feed_rate_input")
        sizePolicy.setHeightForWidth(self.xy_feed_rate_input.sizePolicy().hasHeightForWidth())
        self.xy_feed_rate_input.setSizePolicy(sizePolicy)
        self.xy_feed_rate_input.setMinimumSize(QSize(100, 33))
        self.xy_feed_rate_input.setMaximumSize(QSize(100, 33))
        self.xy_feed_rate_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_2.addWidget(self.xy_feed_rate_input, 9, 2, 1, 1)

        self.z_feed_rate_input = VCPSettingsLineEdit(self.widget)
        self.z_feed_rate_input.setObjectName(u"z_feed_rate_input")
        sizePolicy.setHeightForWidth(self.z_feed_rate_input.sizePolicy().hasHeightForWidth())
        self.z_feed_rate_input.setSizePolicy(sizePolicy)
        self.z_feed_rate_input.setMinimumSize(QSize(100, 33))
        self.z_feed_rate_input.setMaximumSize(QSize(100, 33))
        self.z_feed_rate_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_2.addWidget(self.z_feed_rate_input, 10, 2, 1, 1)

        self.clearance_height_input = VCPSettingsLineEdit(self.widget)
        self.clearance_height_input.setObjectName(u"clearance_height_input")
        sizePolicy.setHeightForWidth(self.clearance_height_input.sizePolicy().hasHeightForWidth())
        self.clearance_height_input.setSizePolicy(sizePolicy)
        self.clearance_height_input.setMinimumSize(QSize(100, 33))
        self.clearance_height_input.setMaximumSize(QSize(100, 33))
        self.clearance_height_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_2.addWidget(self.clearance_height_input, 11, 2, 1, 1)

        self.spindle_direction_input = VCPSettingsComboBox(self.widget)
        self.spindle_direction_input.setObjectName(u"spindle_direction_input")
        sizePolicy.setHeightForWidth(self.spindle_direction_input.sizePolicy().hasHeightForWidth())
        self.spindle_direction_input.setSizePolicy(sizePolicy)
        self.spindle_direction_input.setMinimumSize(QSize(100, 35))
        self.spindle_direction_input.setMaximumSize(QSize(100, 35))
        self.spindle_direction_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_2.addWidget(self.spindle_direction_input, 7, 4, 1, 1)

        self.drill_type_param_value = VCPSettingsLineEdit(self.widget)
        self.drill_type_param_value.setObjectName(u"drill_type_param_value")
        sizePolicy.setHeightForWidth(self.drill_type_param_value.sizePolicy().hasHeightForWidth())
        self.drill_type_param_value.setSizePolicy(sizePolicy)
        self.drill_type_param_value.setMinimumSize(QSize(100, 33))
        self.drill_type_param_value.setMaximumSize(QSize(100, 33))
        self.drill_type_param_value.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_2.addWidget(self.drill_type_param_value, 3, 4, 1, 1)


        self.verticalLayout.addWidget(self.widget)

        self.post_to_file = QPushButton(self.bolt_hole_setup_frame_3)
        self.post_to_file.setObjectName(u"post_to_file")
        sizePolicy2.setHeightForWidth(self.post_to_file.sizePolicy().hasHeightForWidth())
        self.post_to_file.setSizePolicy(sizePolicy2)
        self.post_to_file.setMinimumSize(QSize(0, 42))
        self.post_to_file.setMaximumSize(QSize(16777215, 42))
        self.post_to_file.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.verticalLayout.addWidget(self.post_to_file)


        self.horizontalLayout.addWidget(self.bolt_hole_setup_frame_3)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label_138.setText(QCoreApplication.translate("Form", u"DIAM", None))
        self.diameter_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.diameter_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.diameter_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.base-diameter", None))
        self.diameter_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_139.setText(QCoreApplication.translate("Form", u"Num\n"
"Holes", None))
        self.num_holes_input.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.num_holes_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.num_holes_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.num-holes", None))
        self.num_holes_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_140.setText(QCoreApplication.translate("Form", u"START\n"
"ANGLE", None))
        self.start_angle_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.000", None))
        self.start_angle_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.3f}", None))
        self.start_angle_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.start-angle", None))
        self.start_angle_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_141.setText(QCoreApplication.translate("Form", u"CENTER X", None))
        self.center_x_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.center_x_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.center_x_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.center-x", None))
        self.center_x_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_142.setText(QCoreApplication.translate("Form", u"CENTER Y", None))
        self.center_y_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.center_y_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.center_y_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.center-y", None))
        self.center_y_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_147.setText(QCoreApplication.translate("Form", u"RETRACT", None))
        self.retract_height_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.retract_height_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.retract_height_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.retract", None))
        self.retract_height_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_151.setText(QCoreApplication.translate("Form", u"HOLE START", None))
        self.z_start_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_start_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.z_start_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.z-start", None))
        self.z_start_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_152.setText(QCoreApplication.translate("Form", u"HOLE END", None))
        self.z_end_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_end_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.z_end_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.z-end", None))
        self.z_end_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_2.setText("")
        self.label_169.setText(QCoreApplication.translate("Form", u"PROGRAM UNIT", None))
        self.label_174.setText(QCoreApplication.translate("Form", u"Z FEEDRATE", None))
        self.label_173.setText(QCoreApplication.translate("Form", u"XY FEEDRATE", None))
        self.label_168.setText(QCoreApplication.translate("Form", u"NAME", None))
        self.label_175.setText(QCoreApplication.translate("Form", u"CLEARANCE HEIGHT", None))
        self.tool_number_label_3.setText(QCoreApplication.translate("Form", u"TOOL NUMBER", None))
        self.name_input.setText(QCoreApplication.translate("Form", u" Untitled", None))
        self.name_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.drill_type_param_label.setText("")
        self.tool_description.setText(QCoreApplication.translate("Form", u"NO TOOL SELECTED", None))
        self.label_172.setText(QCoreApplication.translate("Form", u"COOLANT", None))
        self.label_132.setText(QCoreApplication.translate("Form", u"WCS", None))
        self.label_170.setText(QCoreApplication.translate("Form", u"SPINDLE RPM", None))
        self.label_176.setText(QCoreApplication.translate("Form", u"RETRACT MODE", None))
        self.drill_type_label.setText(QCoreApplication.translate("Form", u"DRILL TYPE", None))
        self.label_171.setText(QCoreApplication.translate("Form", u"DIRECTION", None))
        self.wcs_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.wcs", None))
        self.unit_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.unit", None))
        self.drill_type_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.drill-type-select", None))
        self.drill_retract_mode_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.drill-retract-mode", None))
        self.tool_number_input.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.tool_number_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.tool_number_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.tool-number", None))
        self.tool_number_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.spindle_rpm_input.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.spindle_rpm_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.spindle_rpm_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.spindle-rpm", None))
        self.spindle_rpm_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.coolant_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.coolant", None))
        self.xy_feed_rate_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.xy_feed_rate_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.1f}", None))
        self.xy_feed_rate_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.xy-feed", None))
        self.xy_feed_rate_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.z_feed_rate_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.z_feed_rate_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.1f}", None))
        self.z_feed_rate_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.z-feed", None))
        self.z_feed_rate_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.clearance_height_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.clearance_height_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.clearance_height_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.clearance-height", None))
        self.clearance_height_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.spindle_direction_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.spindle-direction", None))
        self.drill_type_param_value.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.drill_type_param_value.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.drill_type_param_value.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-hole.drill-type", None))
        self.drill_type_param_value.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.post_to_file.setText(QCoreApplication.translate("Form", u"POST TO FILE", None))
    # retranslateUi

