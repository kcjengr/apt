# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'xy_coord.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QPushButton,
    QSizePolicy, QTableView, QVBoxLayout, QWidget)

from qtpyvcp.widgets.input_widgets.setting_slider import (VCPSettingsComboBox, VCPSettingsLineEdit)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1394, 540)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        Form.setStyleSheet(u"QLabel{\n"
"color: rgb(255, 255, 255);\n"
"}\n"
"\n"
"{\n"
"font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout = QHBoxLayout(Form)
        self.horizontalLayout.setSpacing(50)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.widget = QWidget(Form)
        self.widget.setObjectName(u"widget")
        self.widget.setMaximumSize(QSize(16777215, 580))
        self.horizontalLayout_2 = QHBoxLayout(self.widget)
        self.horizontalLayout_2.setSpacing(50)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 6, 6)
        self.widget_1 = QWidget(self.widget)
        self.widget_1.setObjectName(u"widget_1")
        sizePolicy.setHeightForWidth(self.widget_1.sizePolicy().hasHeightForWidth())
        self.widget_1.setSizePolicy(sizePolicy)
        self.widget_1.setMinimumSize(QSize(0, 530))
        self.widget_1.setMaximumSize(QSize(16777215, 550))
        self.verticalLayout = QVBoxLayout(self.widget_1)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(-1, 9, -1, -1)
        self.widget_2 = QWidget(self.widget_1)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setMaximumSize(QSize(880, 16777215))
        self.verticalLayout_2 = QVBoxLayout(self.widget_2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(-1, -1, -1, 1)
        self.widget_3 = QWidget(self.widget_2)
        self.widget_3.setObjectName(u"widget_3")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.widget_3.sizePolicy().hasHeightForWidth())
        self.widget_3.setSizePolicy(sizePolicy1)
        self.widget_3.setMinimumSize(QSize(500, 0))
        self.verticalLayout_4 = QVBoxLayout(self.widget_3)
        self.verticalLayout_4.setSpacing(9)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(1, 1, 1, 1)
        self.xy_coord_header = QLabel(self.widget_3)
        self.xy_coord_header.setObjectName(u"xy_coord_header")
        self.xy_coord_header.setMinimumSize(QSize(0, 33))
        self.xy_coord_header.setMaximumSize(QSize(16777215, 33))
        self.xy_coord_header.setStyleSheet(u"QLabel{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179, 172);\n"
"    border-width: 2px;\n"
"    border-radius: 5px;\n"
"    color: white;\n"
"    background: rgb(90, 90, 90);\n"
"	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.xy_coord_header.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_4.addWidget(self.xy_coord_header)

        self.xy_coord_input = QTableView(self.widget_3)
        self.xy_coord_input.setObjectName(u"xy_coord_input")
        self.xy_coord_input.setMouseTracking(True)
        self.xy_coord_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.xy_coord_input.setStyleSheet(u"QTableView,\n"
"QHeaderView {\n"
"    font: 14pt \"Probe Basic Bebas Mono\";\n"
"    background-color: rgb(108, 108, 108);\n"
"	color: white;\n"
"    border: none;\n"
"}\n"
"\n"
"QTableView {\n"
"    color: white;\n"
"   	border-top: 8px rgb(120, 120, 120);\n"
"	border-left: 4px  rgb(120, 120, 120);\n"
"	border-bottom: 5px rgb(120, 120, 120);\n"
"	border-right: 4px rgb(120, 120, 120);\n"
"	border-radius: 5px;\n"
"	border-color: rgb(120, 120, 120);\n"
"	border-style: solid;\n"
"	background-color: rgb(120, 120, 120);\n"
"    gridline-color: rgb(203, 203, 203);\n"
"	alternate-background-color: rgb(90, 90, 90);\n"
"}\n"
"\n"
"QTableView::item:selected {\n"
"    background-color: rgb(87, 87, 238); \n"
"    color: white;\n"
"}")
        self.xy_coord_input.horizontalHeader().setDefaultSectionSize(200)
        self.xy_coord_input.horizontalHeader().setStretchLastSection(True)

        self.verticalLayout_4.addWidget(self.xy_coord_input)

        self.widget_4 = QWidget(self.widget_3)
        self.widget_4.setObjectName(u"widget_4")
        self.horizontalLayout_3 = QHBoxLayout(self.widget_4)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(-1, 1, -1, -1)
        self.delete_selected_input = QPushButton(self.widget_4)
        self.delete_selected_input.setObjectName(u"delete_selected_input")
        self.delete_selected_input.setMinimumSize(QSize(150, 42))
        self.delete_selected_input.setMaximumSize(QSize(16777215, 42))
        self.delete_selected_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.delete_selected_input.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_3.addWidget(self.delete_selected_input)

        self.delete_all_input = QPushButton(self.widget_4)
        self.delete_all_input.setObjectName(u"delete_all_input")
        self.delete_all_input.setMinimumSize(QSize(150, 42))
        self.delete_all_input.setMaximumSize(QSize(16777215, 42))
        self.delete_all_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.delete_all_input.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")

        self.horizontalLayout_3.addWidget(self.delete_all_input)


        self.verticalLayout_4.addWidget(self.widget_4)


        self.verticalLayout_2.addWidget(self.widget_3)


        self.verticalLayout.addWidget(self.widget_2, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_5 = QWidget(self.widget_1)
        self.widget_5.setObjectName(u"widget_5")
        self.widget_5.setMinimumSize(QSize(820, 150))
        self.widget_5.setMaximumSize(QSize(800, 150))
        self.label = QLabel(self.widget_5)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(124, 4, 555, 140))
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy2)
        self.label.setMinimumSize(QSize(555, 140))
        self.label.setMaximumSize(QSize(555, 140))
        self.label.setPixmap(QPixmap(u":/images/drill_block_front.png"))
        self.label.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.frame_55 = QFrame(self.widget_5)
        self.frame_55.setObjectName(u"frame_55")
        self.frame_55.setGeometry(QRect(670, 58, 140, 45))
        sizePolicy2.setHeightForWidth(self.frame_55.sizePolicy().hasHeightForWidth())
        self.frame_55.setSizePolicy(sizePolicy2)
        self.frame_55.setMinimumSize(QSize(140, 45))
        self.frame_55.setMaximumSize(QSize(140, 45))
        self.frame_55.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_215 = QHBoxLayout(self.frame_55)
        self.horizontalLayout_215.setObjectName(u"horizontalLayout_215")
        self.horizontalLayout_215.setContentsMargins(2, 2, 2, 2)
        self.label_149 = QLabel(self.frame_55)
        self.label_149.setObjectName(u"label_149")
        sizePolicy2.setHeightForWidth(self.label_149.sizePolicy().hasHeightForWidth())
        self.label_149.setSizePolicy(sizePolicy2)
        self.label_149.setMinimumSize(QSize(50, 33))
        self.label_149.setMaximumSize(QSize(35, 33))
        self.label_149.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_149.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_149.setWordWrap(True)

        self.horizontalLayout_215.addWidget(self.label_149)

        self.retract_height_input = VCPSettingsLineEdit(self.frame_55)
        self.retract_height_input.setObjectName(u"retract_height_input")
        sizePolicy2.setHeightForWidth(self.retract_height_input.sizePolicy().hasHeightForWidth())
        self.retract_height_input.setSizePolicy(sizePolicy2)
        self.retract_height_input.setMinimumSize(QSize(70, 33))
        self.retract_height_input.setMaximumSize(QSize(70, 33))
        self.retract_height_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.retract_height_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_215.addWidget(self.retract_height_input)

        self.frame_57 = QFrame(self.widget_5)
        self.frame_57.setObjectName(u"frame_57")
        self.frame_57.setGeometry(QRect(8, 92, 140, 45))
        sizePolicy2.setHeightForWidth(self.frame_57.sizePolicy().hasHeightForWidth())
        self.frame_57.setSizePolicy(sizePolicy2)
        self.frame_57.setMinimumSize(QSize(140, 45))
        self.frame_57.setMaximumSize(QSize(140, 45))
        self.frame_57.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_217 = QHBoxLayout(self.frame_57)
        self.horizontalLayout_217.setObjectName(u"horizontalLayout_217")
        self.horizontalLayout_217.setContentsMargins(2, 2, 2, 2)
        self.label_153 = QLabel(self.frame_57)
        self.label_153.setObjectName(u"label_153")
        sizePolicy2.setHeightForWidth(self.label_153.sizePolicy().hasHeightForWidth())
        self.label_153.setSizePolicy(sizePolicy2)
        self.label_153.setMinimumSize(QSize(50, 33))
        self.label_153.setMaximumSize(QSize(50, 33))
        self.label_153.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_153.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_153.setWordWrap(True)

        self.horizontalLayout_217.addWidget(self.label_153)

        self.z_end_input = VCPSettingsLineEdit(self.frame_57)
        self.z_end_input.setObjectName(u"z_end_input")
        sizePolicy2.setHeightForWidth(self.z_end_input.sizePolicy().hasHeightForWidth())
        self.z_end_input.setSizePolicy(sizePolicy2)
        self.z_end_input.setMinimumSize(QSize(70, 33))
        self.z_end_input.setMaximumSize(QSize(70, 33))
        self.z_end_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_end_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_217.addWidget(self.z_end_input)

        self.frame_56 = QFrame(self.widget_5)
        self.frame_56.setObjectName(u"frame_56")
        self.frame_56.setGeometry(QRect(8, 20, 140, 45))
        sizePolicy2.setHeightForWidth(self.frame_56.sizePolicy().hasHeightForWidth())
        self.frame_56.setSizePolicy(sizePolicy2)
        self.frame_56.setMinimumSize(QSize(140, 45))
        self.frame_56.setMaximumSize(QSize(140, 45))
        self.frame_56.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_219 = QHBoxLayout(self.frame_56)
        self.horizontalLayout_219.setObjectName(u"horizontalLayout_219")
        self.horizontalLayout_219.setContentsMargins(2, 2, 2, 2)
        self.label_154 = QLabel(self.frame_56)
        self.label_154.setObjectName(u"label_154")
        sizePolicy2.setHeightForWidth(self.label_154.sizePolicy().hasHeightForWidth())
        self.label_154.setSizePolicy(sizePolicy2)
        self.label_154.setMinimumSize(QSize(50, 33))
        self.label_154.setMaximumSize(QSize(50, 33))
        self.label_154.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_154.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_154.setWordWrap(True)

        self.horizontalLayout_219.addWidget(self.label_154)

        self.z_start_input = VCPSettingsLineEdit(self.frame_56)
        self.z_start_input.setObjectName(u"z_start_input")
        sizePolicy2.setHeightForWidth(self.z_start_input.sizePolicy().hasHeightForWidth())
        self.z_start_input.setSizePolicy(sizePolicy2)
        self.z_start_input.setMinimumSize(QSize(70, 33))
        self.z_start_input.setMaximumSize(QSize(70, 33))
        self.z_start_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_start_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_219.addWidget(self.z_start_input)


        self.verticalLayout.addWidget(self.widget_5, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter)


        self.horizontalLayout_2.addWidget(self.widget_1, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter)


        self.horizontalLayout.addWidget(self.widget)

        self.bolt_hole_setup_frame_3 = QFrame(Form)
        self.bolt_hole_setup_frame_3.setObjectName(u"bolt_hole_setup_frame_3")
        sizePolicy1.setHeightForWidth(self.bolt_hole_setup_frame_3.sizePolicy().hasHeightForWidth())
        self.bolt_hole_setup_frame_3.setSizePolicy(sizePolicy1)
        self.bolt_hole_setup_frame_3.setMinimumSize(QSize(500, 540))
        self.bolt_hole_setup_frame_3.setMaximumSize(QSize(500, 540))
        self.bolt_hole_setup_frame_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.bolt_hole_setup_frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.bolt_hole_setup_frame_3)
        self.verticalLayout_3.setSpacing(6)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(9, 9, 9, 9)
        self.widget_6 = QWidget(self.bolt_hole_setup_frame_3)
        self.widget_6.setObjectName(u"widget_6")
        self.widget_6.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")
        self.gridLayout_3 = QGridLayout(self.widget_6)
        self.gridLayout_3.setSpacing(6)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setContentsMargins(1, 1, 1, 1)
        self.label_171 = QLabel(self.widget_6)
        self.label_171.setObjectName(u"label_171")
        sizePolicy2.setHeightForWidth(self.label_171.sizePolicy().hasHeightForWidth())
        self.label_171.setSizePolicy(sizePolicy2)
        self.label_171.setMinimumSize(QSize(115, 35))
        self.label_171.setMaximumSize(QSize(115, 35))
        font = QFont()
        font.setFamilies([u"Probe Basic Bebas Mono"])
        font.setPointSize(14)
        font.setBold(False)
        font.setItalic(False)
        self.label_171.setFont(font)
        self.label_171.setLineWidth(0)
        self.label_171.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_171.setIndent(0)

        self.gridLayout_3.addWidget(self.label_171, 7, 2, 1, 1)

        self.drill_type_param_label = QLabel(self.widget_6)
        self.drill_type_param_label.setObjectName(u"drill_type_param_label")
        sizePolicy2.setHeightForWidth(self.drill_type_param_label.sizePolicy().hasHeightForWidth())
        self.drill_type_param_label.setSizePolicy(sizePolicy2)
        self.drill_type_param_label.setMinimumSize(QSize(115, 35))
        self.drill_type_param_label.setMaximumSize(QSize(115, 35))
        self.drill_type_param_label.setLineWidth(0)
        self.drill_type_param_label.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drill_type_param_label.setIndent(0)

        self.gridLayout_3.addWidget(self.drill_type_param_label, 3, 2, 1, 1)

        self.label_173 = QLabel(self.widget_6)
        self.label_173.setObjectName(u"label_173")
        sizePolicy2.setHeightForWidth(self.label_173.sizePolicy().hasHeightForWidth())
        self.label_173.setSizePolicy(sizePolicy2)
        self.label_173.setMinimumSize(QSize(120, 35))
        self.label_173.setMaximumSize(QSize(120, 35))
        self.label_173.setFont(font)
        self.label_173.setLineWidth(0)
        self.label_173.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_173.setIndent(0)

        self.gridLayout_3.addWidget(self.label_173, 9, 0, 1, 1)

        self.label_170 = QLabel(self.widget_6)
        self.label_170.setObjectName(u"label_170")
        sizePolicy2.setHeightForWidth(self.label_170.sizePolicy().hasHeightForWidth())
        self.label_170.setSizePolicy(sizePolicy2)
        self.label_170.setMinimumSize(QSize(120, 35))
        self.label_170.setMaximumSize(QSize(120, 35))
        self.label_170.setFont(font)
        self.label_170.setLineWidth(0)
        self.label_170.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_170.setIndent(0)

        self.gridLayout_3.addWidget(self.label_170, 7, 0, 1, 1)

        self.drill_type_label = QLabel(self.widget_6)
        self.drill_type_label.setObjectName(u"drill_type_label")
        sizePolicy2.setHeightForWidth(self.drill_type_label.sizePolicy().hasHeightForWidth())
        self.drill_type_label.setSizePolicy(sizePolicy2)
        self.drill_type_label.setMinimumSize(QSize(120, 35))
        self.drill_type_label.setMaximumSize(QSize(120, 35))
        self.drill_type_label.setFont(font)
        self.drill_type_label.setLineWidth(0)
        self.drill_type_label.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.drill_type_label.setIndent(0)

        self.gridLayout_3.addWidget(self.drill_type_label, 3, 0, 1, 1)

        self.tool_description = QLabel(self.widget_6)
        self.tool_description.setObjectName(u"tool_description")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.tool_description.sizePolicy().hasHeightForWidth())
        self.tool_description.setSizePolicy(sizePolicy3)
        self.tool_description.setMinimumSize(QSize(120, 35))
        self.tool_description.setMaximumSize(QSize(16777215, 35))
        self.tool_description.setFont(font)
        self.tool_description.setLineWidth(0)
        self.tool_description.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.tool_description.setIndent(0)

        self.gridLayout_3.addWidget(self.tool_description, 6, 2, 1, 2)

        self.wcs_input = VCPSettingsComboBox(self.widget_6)
        self.wcs_input.setObjectName(u"wcs_input")
        sizePolicy2.setHeightForWidth(self.wcs_input.sizePolicy().hasHeightForWidth())
        self.wcs_input.setSizePolicy(sizePolicy2)
        self.wcs_input.setMinimumSize(QSize(100, 35))
        self.wcs_input.setMaximumSize(QSize(100, 35))
        self.wcs_input.setMouseTracking(True)
        self.wcs_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_3.addWidget(self.wcs_input, 1, 1, 1, 1)

        self.label_169 = QLabel(self.widget_6)
        self.label_169.setObjectName(u"label_169")
        sizePolicy2.setHeightForWidth(self.label_169.sizePolicy().hasHeightForWidth())
        self.label_169.setSizePolicy(sizePolicy2)
        self.label_169.setMinimumSize(QSize(120, 35))
        self.label_169.setMaximumSize(QSize(120, 35))
        self.label_169.setFont(font)
        self.label_169.setLineWidth(0)
        self.label_169.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_169.setIndent(0)

        self.gridLayout_3.addWidget(self.label_169, 2, 0, 1, 1)

        self.tool_number_label_3 = QLabel(self.widget_6)
        self.tool_number_label_3.setObjectName(u"tool_number_label_3")
        sizePolicy2.setHeightForWidth(self.tool_number_label_3.sizePolicy().hasHeightForWidth())
        self.tool_number_label_3.setSizePolicy(sizePolicy2)
        self.tool_number_label_3.setMinimumSize(QSize(120, 35))
        self.tool_number_label_3.setMaximumSize(QSize(120, 35))
        self.tool_number_label_3.setFont(font)
        self.tool_number_label_3.setLineWidth(0)
        self.tool_number_label_3.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.tool_number_label_3.setIndent(0)

        self.gridLayout_3.addWidget(self.tool_number_label_3, 6, 0, 1, 1)

        self.drill_retract_mode_input = VCPSettingsComboBox(self.widget_6)
        self.drill_retract_mode_input.setObjectName(u"drill_retract_mode_input")
        sizePolicy2.setHeightForWidth(self.drill_retract_mode_input.sizePolicy().hasHeightForWidth())
        self.drill_retract_mode_input.setSizePolicy(sizePolicy2)
        self.drill_retract_mode_input.setMinimumSize(QSize(100, 35))
        self.drill_retract_mode_input.setMaximumSize(QSize(100, 35))
        self.drill_retract_mode_input.setMouseTracking(True)
        self.drill_retract_mode_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_3.addWidget(self.drill_retract_mode_input, 4, 1, 1, 1)

        self.label_172 = QLabel(self.widget_6)
        self.label_172.setObjectName(u"label_172")
        sizePolicy2.setHeightForWidth(self.label_172.sizePolicy().hasHeightForWidth())
        self.label_172.setSizePolicy(sizePolicy2)
        self.label_172.setMinimumSize(QSize(120, 35))
        self.label_172.setMaximumSize(QSize(120, 35))
        self.label_172.setFont(font)
        self.label_172.setLineWidth(0)
        self.label_172.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_172.setIndent(0)

        self.gridLayout_3.addWidget(self.label_172, 8, 0, 1, 1)

        self.coolant_input = VCPSettingsComboBox(self.widget_6)
        self.coolant_input.setObjectName(u"coolant_input")
        sizePolicy2.setHeightForWidth(self.coolant_input.sizePolicy().hasHeightForWidth())
        self.coolant_input.setSizePolicy(sizePolicy2)
        self.coolant_input.setMinimumSize(QSize(100, 35))
        self.coolant_input.setMaximumSize(QSize(100, 35))
        self.coolant_input.setMouseTracking(True)
        self.coolant_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_3.addWidget(self.coolant_input, 8, 1, 1, 1)

        self.drill_type_input = VCPSettingsComboBox(self.widget_6)
        self.drill_type_input.setObjectName(u"drill_type_input")
        sizePolicy2.setHeightForWidth(self.drill_type_input.sizePolicy().hasHeightForWidth())
        self.drill_type_input.setSizePolicy(sizePolicy2)
        self.drill_type_input.setMinimumSize(QSize(100, 35))
        self.drill_type_input.setMaximumSize(QSize(100, 35))
        self.drill_type_input.setMouseTracking(True)
        self.drill_type_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_3.addWidget(self.drill_type_input, 3, 1, 1, 1)

        self.spindle_direction_input = VCPSettingsComboBox(self.widget_6)
        self.spindle_direction_input.setObjectName(u"spindle_direction_input")
        sizePolicy2.setHeightForWidth(self.spindle_direction_input.sizePolicy().hasHeightForWidth())
        self.spindle_direction_input.setSizePolicy(sizePolicy2)
        self.spindle_direction_input.setMinimumSize(QSize(100, 35))
        self.spindle_direction_input.setMaximumSize(QSize(100, 35))
        self.spindle_direction_input.setMouseTracking(True)
        self.spindle_direction_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_3.addWidget(self.spindle_direction_input, 7, 3, 1, 1)

        self.label_168 = QLabel(self.widget_6)
        self.label_168.setObjectName(u"label_168")
        sizePolicy2.setHeightForWidth(self.label_168.sizePolicy().hasHeightForWidth())
        self.label_168.setSizePolicy(sizePolicy2)
        self.label_168.setMinimumSize(QSize(120, 35))
        self.label_168.setMaximumSize(QSize(120, 35))
        self.label_168.setFont(font)
        self.label_168.setLineWidth(0)
        self.label_168.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_168.setIndent(0)

        self.gridLayout_3.addWidget(self.label_168, 0, 0, 1, 1)

        self.label_132 = QLabel(self.widget_6)
        self.label_132.setObjectName(u"label_132")
        sizePolicy2.setHeightForWidth(self.label_132.sizePolicy().hasHeightForWidth())
        self.label_132.setSizePolicy(sizePolicy2)
        self.label_132.setMinimumSize(QSize(120, 35))
        self.label_132.setMaximumSize(QSize(120, 35))
        self.label_132.setFont(font)
        self.label_132.setLineWidth(0)
        self.label_132.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_132.setIndent(0)

        self.gridLayout_3.addWidget(self.label_132, 1, 0, 1, 1)

        self.unit_input = VCPSettingsComboBox(self.widget_6)
        self.unit_input.setObjectName(u"unit_input")
        sizePolicy2.setHeightForWidth(self.unit_input.sizePolicy().hasHeightForWidth())
        self.unit_input.setSizePolicy(sizePolicy2)
        self.unit_input.setMinimumSize(QSize(100, 35))
        self.unit_input.setMaximumSize(QSize(100, 35))
        self.unit_input.setMouseTracking(True)
        self.unit_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_3.addWidget(self.unit_input, 2, 1, 1, 1)

        self.label_175 = QLabel(self.widget_6)
        self.label_175.setObjectName(u"label_175")
        sizePolicy2.setHeightForWidth(self.label_175.sizePolicy().hasHeightForWidth())
        self.label_175.setSizePolicy(sizePolicy2)
        self.label_175.setMinimumSize(QSize(120, 35))
        self.label_175.setMaximumSize(QSize(120, 35))
        self.label_175.setFont(font)
        self.label_175.setLineWidth(0)
        self.label_175.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_175.setIndent(0)

        self.gridLayout_3.addWidget(self.label_175, 11, 0, 1, 1)

        self.label_174 = QLabel(self.widget_6)
        self.label_174.setObjectName(u"label_174")
        sizePolicy2.setHeightForWidth(self.label_174.sizePolicy().hasHeightForWidth())
        self.label_174.setSizePolicy(sizePolicy2)
        self.label_174.setMinimumSize(QSize(120, 35))
        self.label_174.setMaximumSize(QSize(120, 35))
        self.label_174.setFont(font)
        self.label_174.setLineWidth(0)
        self.label_174.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_174.setIndent(0)

        self.gridLayout_3.addWidget(self.label_174, 10, 0, 1, 1)

        self.label_176 = QLabel(self.widget_6)
        self.label_176.setObjectName(u"label_176")
        sizePolicy2.setHeightForWidth(self.label_176.sizePolicy().hasHeightForWidth())
        self.label_176.setSizePolicy(sizePolicy2)
        self.label_176.setMinimumSize(QSize(120, 35))
        self.label_176.setMaximumSize(QSize(120, 35))
        self.label_176.setFont(font)
        self.label_176.setLineWidth(0)
        self.label_176.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_176.setIndent(0)

        self.gridLayout_3.addWidget(self.label_176, 4, 0, 1, 1)

        self.name_input = QLineEdit(self.widget_6)
        self.name_input.setObjectName(u"name_input")
        sizePolicy3.setHeightForWidth(self.name_input.sizePolicy().hasHeightForWidth())
        self.name_input.setSizePolicy(sizePolicy3)
        self.name_input.setMinimumSize(QSize(0, 35))
        self.name_input.setMaximumSize(QSize(16777215, 35))
        self.name_input.setStyleSheet(u"padding-left: 6px;")
        self.name_input.setCursorPosition(8)

        self.gridLayout_3.addWidget(self.name_input, 0, 1, 1, 3)

        self.drill_type_param_value = VCPSettingsLineEdit(self.widget_6)
        self.drill_type_param_value.setObjectName(u"drill_type_param_value")
        self.drill_type_param_value.setEnabled(True)
        sizePolicy2.setHeightForWidth(self.drill_type_param_value.sizePolicy().hasHeightForWidth())
        self.drill_type_param_value.setSizePolicy(sizePolicy2)
        self.drill_type_param_value.setMinimumSize(QSize(100, 33))
        self.drill_type_param_value.setMaximumSize(QSize(100, 33))
        self.drill_type_param_value.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.drill_type_param_value.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_3.addWidget(self.drill_type_param_value, 3, 3, 1, 1)

        self.xy_feed_rate_input = VCPSettingsLineEdit(self.widget_6)
        self.xy_feed_rate_input.setObjectName(u"xy_feed_rate_input")
        sizePolicy2.setHeightForWidth(self.xy_feed_rate_input.sizePolicy().hasHeightForWidth())
        self.xy_feed_rate_input.setSizePolicy(sizePolicy2)
        self.xy_feed_rate_input.setMinimumSize(QSize(100, 33))
        self.xy_feed_rate_input.setMaximumSize(QSize(100, 33))
        self.xy_feed_rate_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.xy_feed_rate_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_3.addWidget(self.xy_feed_rate_input, 9, 1, 1, 1)

        self.z_feed_rate_input = VCPSettingsLineEdit(self.widget_6)
        self.z_feed_rate_input.setObjectName(u"z_feed_rate_input")
        sizePolicy2.setHeightForWidth(self.z_feed_rate_input.sizePolicy().hasHeightForWidth())
        self.z_feed_rate_input.setSizePolicy(sizePolicy2)
        self.z_feed_rate_input.setMinimumSize(QSize(100, 33))
        self.z_feed_rate_input.setMaximumSize(QSize(100, 33))
        self.z_feed_rate_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_feed_rate_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_3.addWidget(self.z_feed_rate_input, 10, 1, 1, 1)

        self.clearance_height_input = VCPSettingsLineEdit(self.widget_6)
        self.clearance_height_input.setObjectName(u"clearance_height_input")
        sizePolicy2.setHeightForWidth(self.clearance_height_input.sizePolicy().hasHeightForWidth())
        self.clearance_height_input.setSizePolicy(sizePolicy2)
        self.clearance_height_input.setMinimumSize(QSize(100, 33))
        self.clearance_height_input.setMaximumSize(QSize(100, 33))
        self.clearance_height_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.clearance_height_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_3.addWidget(self.clearance_height_input, 11, 1, 1, 1)

        self.spindle_rpm_input = VCPSettingsLineEdit(self.widget_6)
        self.spindle_rpm_input.setObjectName(u"spindle_rpm_input")
        sizePolicy2.setHeightForWidth(self.spindle_rpm_input.sizePolicy().hasHeightForWidth())
        self.spindle_rpm_input.setSizePolicy(sizePolicy2)
        self.spindle_rpm_input.setMinimumSize(QSize(100, 33))
        self.spindle_rpm_input.setMaximumSize(QSize(100, 33))
        self.spindle_rpm_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.spindle_rpm_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_3.addWidget(self.spindle_rpm_input, 7, 1, 1, 1)

        self.tool_number_input = VCPSettingsLineEdit(self.widget_6)
        self.tool_number_input.setObjectName(u"tool_number_input")
        sizePolicy2.setHeightForWidth(self.tool_number_input.sizePolicy().hasHeightForWidth())
        self.tool_number_input.setSizePolicy(sizePolicy2)
        self.tool_number_input.setMinimumSize(QSize(100, 33))
        self.tool_number_input.setMaximumSize(QSize(100, 33))
        self.tool_number_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.tool_number_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_3.addWidget(self.tool_number_input, 6, 1, 1, 1)

        self.xy_coord_feed_per_rev = VCPSettingsLineEdit(self.widget_6)
        self.xy_coord_feed_per_rev.setObjectName(u"xy_coord_feed_per_rev")
        sizePolicy2.setHeightForWidth(self.xy_coord_feed_per_rev.sizePolicy().hasHeightForWidth())
        self.xy_coord_feed_per_rev.setSizePolicy(sizePolicy2)
        self.xy_coord_feed_per_rev.setMinimumSize(QSize(100, 33))
        self.xy_coord_feed_per_rev.setMaximumSize(QSize(100, 33))
        self.xy_coord_feed_per_rev.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.xy_coord_feed_per_rev.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_3.addWidget(self.xy_coord_feed_per_rev, 10, 3, 1, 1)

        self.label_177 = QLabel(self.widget_6)
        self.label_177.setObjectName(u"label_177")
        sizePolicy2.setHeightForWidth(self.label_177.sizePolicy().hasHeightForWidth())
        self.label_177.setSizePolicy(sizePolicy2)
        self.label_177.setMinimumSize(QSize(115, 35))
        self.label_177.setMaximumSize(QSize(115, 35))
        self.label_177.setFont(font)
        self.label_177.setLineWidth(0)
        self.label_177.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_177.setIndent(0)

        self.gridLayout_3.addWidget(self.label_177, 10, 2, 1, 1)


        self.verticalLayout_3.addWidget(self.widget_6, 0, Qt.AlignmentFlag.AlignHCenter)

        self.post_to_file = QPushButton(self.bolt_hole_setup_frame_3)
        self.post_to_file.setObjectName(u"post_to_file")
        sizePolicy3.setHeightForWidth(self.post_to_file.sizePolicy().hasHeightForWidth())
        self.post_to_file.setSizePolicy(sizePolicy3)
        self.post_to_file.setMinimumSize(QSize(0, 42))
        self.post_to_file.setMaximumSize(QSize(16777215, 42))
        self.post_to_file.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self.verticalLayout_3.addWidget(self.post_to_file)


        self.horizontalLayout.addWidget(self.bolt_hole_setup_frame_3, 0, Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignVCenter)

        QWidget.setTabOrder(self.delete_selected_input, self.delete_all_input)
        QWidget.setTabOrder(self.delete_all_input, self.name_input)
        QWidget.setTabOrder(self.name_input, self.wcs_input)
        QWidget.setTabOrder(self.wcs_input, self.unit_input)
        QWidget.setTabOrder(self.unit_input, self.coolant_input)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.xy_coord_header.setText(QCoreApplication.translate("Form", u"DRILL COORDINATES", None))
        self.delete_selected_input.setText(QCoreApplication.translate("Form", u"DELETE SELECTED", None))
        self.delete_all_input.setText(QCoreApplication.translate("Form", u"DELETE ALL", None))
        self.label.setText("")
        self.label_149.setText(QCoreApplication.translate("Form", u"RETRACT", None))
        self.retract_height_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.retract_height_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.retract_height_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.retract", None))
        self.retract_height_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_153.setText(QCoreApplication.translate("Form", u"HOLE END", None))
        self.z_end_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_end_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.z_end_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.z-end", None))
        self.z_end_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_154.setText(QCoreApplication.translate("Form", u"HOLE START", None))
        self.z_start_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_start_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.z_start_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.z-start", None))
        self.z_start_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_171.setText(QCoreApplication.translate("Form", u"DIRECTION", None))
        self.drill_type_param_label.setText("")
        self.label_173.setText(QCoreApplication.translate("Form", u"XY FEEDRATE", None))
        self.label_170.setText(QCoreApplication.translate("Form", u"SPINDLE RPM", None))
        self.drill_type_label.setText(QCoreApplication.translate("Form", u"DRILL TYPE", None))
        self.tool_description.setText(QCoreApplication.translate("Form", u"NO TOOL SELECTED", None))
        self.wcs_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.wcs", None))
        self.label_169.setText(QCoreApplication.translate("Form", u"PROGRAM UNIT", None))
        self.tool_number_label_3.setText(QCoreApplication.translate("Form", u"TOOL NUMBER", None))
        self.drill_retract_mode_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.drill-retract-mode", None))
        self.label_172.setText(QCoreApplication.translate("Form", u"COOLANT", None))
        self.coolant_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.coolant", None))
        self.drill_type_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.drill-type-select", None))
        self.spindle_direction_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.spindle-direction", None))
        self.label_168.setText(QCoreApplication.translate("Form", u"NAME", None))
        self.label_132.setText(QCoreApplication.translate("Form", u"WCS", None))
        self.unit_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.unit", None))
        self.label_175.setText(QCoreApplication.translate("Form", u"CLEARANCE HEIGHT", None))
        self.label_174.setText(QCoreApplication.translate("Form", u"Z FEEDRATE", None))
        self.label_176.setText(QCoreApplication.translate("Form", u"RETRACT MODE", None))
        self.name_input.setText(QCoreApplication.translate("Form", u"Untitled", None))
        self.name_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.drill_type_param_value.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.drill_type_param_value.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.drill_type_param_value.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.drill-type", None))
        self.drill_type_param_value.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.xy_feed_rate_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.xy_feed_rate_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.1f}", None))
        self.xy_feed_rate_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.xy-feed", None))
        self.xy_feed_rate_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.z_feed_rate_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.z_feed_rate_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.1f}", None))
        self.z_feed_rate_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.z-feed", None))
        self.z_feed_rate_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.clearance_height_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.clearance_height_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.clearance_height_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.clearance-height", None))
        self.clearance_height_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.spindle_rpm_input.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.spindle_rpm_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.spindle_rpm_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.spindle-rpm", None))
        self.spindle_rpm_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.tool_number_input.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.tool_number_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.tool_number_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.tool-number", None))
        self.tool_number_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.xy_coord_feed_per_rev.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.xy_coord_feed_per_rev.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.xy_coord_feed_per_rev.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-xy-coord.fpr", None))
        self.xy_coord_feed_per_rev.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_177.setText(QCoreApplication.translate("Form", u"FEED/REV", None))
        self.post_to_file.setText(QCoreApplication.translate("Form", u"POST TO FILE", None))
    # retranslateUi

