# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'facing.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLayout, QLineEdit, QPushButton,
    QSizePolicy, QVBoxLayout, QWidget)

from qtpyvcp.widgets.input_widgets.setting_slider import (VCPSettingsComboBox, VCPSettingsLineEdit)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.setEnabled(True)
        Form.resize(1350, 545)
        Form.setStyleSheet(u"QLabel{\n"
"color: rgb(255, 255, 255);\n"
"}\n"
"{\n"
"font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.horizontalLayout = QHBoxLayout(Form)
        self.horizontalLayout.setSpacing(50)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.facing_diagram_widget = QWidget(Form)
        self.facing_diagram_widget.setObjectName(u"facing_diagram_widget")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.facing_diagram_widget.sizePolicy().hasHeightForWidth())
        self.facing_diagram_widget.setSizePolicy(sizePolicy)
        self.facing_diagram_widget.setMinimumSize(QSize(800, 545))
        self.facing_diagram_widget.setMaximumSize(QSize(800, 545))
        self.facing_diagram_widget.setStyleSheet(u"")
        self.frame_24 = QFrame(self.facing_diagram_widget)
        self.frame_24.setObjectName(u"frame_24")
        self.frame_24.setGeometry(QRect(41, 154, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_24.sizePolicy().hasHeightForWidth())
        self.frame_24.setSizePolicy(sizePolicy)
        self.frame_24.setMinimumSize(QSize(140, 45))
        self.frame_24.setMaximumSize(QSize(140, 45))
        self.frame_24.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_191 = QHBoxLayout(self.frame_24)
        self.horizontalLayout_191.setObjectName(u"horizontalLayout_191")
        self.horizontalLayout_191.setContentsMargins(3, 1, 3, 1)
        self.label_138 = QLabel(self.frame_24)
        self.label_138.setObjectName(u"label_138")
        sizePolicy.setHeightForWidth(self.label_138.sizePolicy().hasHeightForWidth())
        self.label_138.setSizePolicy(sizePolicy)
        self.label_138.setMinimumSize(QSize(50, 33))
        self.label_138.setMaximumSize(QSize(50, 33))
        self.label_138.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_138.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_138.setWordWrap(True)

        self.horizontalLayout_191.addWidget(self.label_138)

        self.step_over_input = VCPSettingsLineEdit(self.frame_24)
        self.step_over_input.setObjectName(u"step_over_input")
        sizePolicy.setHeightForWidth(self.step_over_input.sizePolicy().hasHeightForWidth())
        self.step_over_input.setSizePolicy(sizePolicy)
        self.step_over_input.setMinimumSize(QSize(70, 33))
        self.step_over_input.setMaximumSize(QSize(70, 33))
        self.step_over_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.step_over_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_191.addWidget(self.step_over_input)

        self.frame_55 = QFrame(self.facing_diagram_widget)
        self.frame_55.setObjectName(u"frame_55")
        self.frame_55.setGeometry(QRect(658, 432, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_55.sizePolicy().hasHeightForWidth())
        self.frame_55.setSizePolicy(sizePolicy)
        self.frame_55.setMinimumSize(QSize(140, 45))
        self.frame_55.setMaximumSize(QSize(140, 45))
        self.frame_55.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_207 = QHBoxLayout(self.frame_55)
        self.horizontalLayout_207.setObjectName(u"horizontalLayout_207")
        self.horizontalLayout_207.setContentsMargins(3, 1, 3, 1)
        self.label_147 = QLabel(self.frame_55)
        self.label_147.setObjectName(u"label_147")
        sizePolicy.setHeightForWidth(self.label_147.sizePolicy().hasHeightForWidth())
        self.label_147.setSizePolicy(sizePolicy)
        self.label_147.setMinimumSize(QSize(50, 33))
        self.label_147.setMaximumSize(QSize(35, 33))
        self.label_147.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_147.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_147.setWordWrap(True)

        self.horizontalLayout_207.addWidget(self.label_147)

        self.step_down_input = VCPSettingsLineEdit(self.frame_55)
        self.step_down_input.setObjectName(u"step_down_input")
        sizePolicy.setHeightForWidth(self.step_down_input.sizePolicy().hasHeightForWidth())
        self.step_down_input.setSizePolicy(sizePolicy)
        self.step_down_input.setMinimumSize(QSize(70, 33))
        self.step_down_input.setMaximumSize(QSize(70, 33))
        self.step_down_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.step_down_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_207.addWidget(self.step_down_input)

        self.frame_56 = QFrame(self.facing_diagram_widget)
        self.frame_56.setObjectName(u"frame_56")
        self.frame_56.setGeometry(QRect(1, 442, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_56.sizePolicy().hasHeightForWidth())
        self.frame_56.setSizePolicy(sizePolicy)
        self.frame_56.setMinimumSize(QSize(140, 45))
        self.frame_56.setMaximumSize(QSize(140, 45))
        self.frame_56.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_209 = QHBoxLayout(self.frame_56)
        self.horizontalLayout_209.setObjectName(u"horizontalLayout_209")
        self.horizontalLayout_209.setContentsMargins(3, 1, 3, 1)
        self.label_151 = QLabel(self.frame_56)
        self.label_151.setObjectName(u"label_151")
        sizePolicy.setHeightForWidth(self.label_151.sizePolicy().hasHeightForWidth())
        self.label_151.setSizePolicy(sizePolicy)
        self.label_151.setMinimumSize(QSize(50, 33))
        self.label_151.setMaximumSize(QSize(50, 33))
        self.label_151.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_151.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_151.setWordWrap(True)

        self.horizontalLayout_209.addWidget(self.label_151)

        self.z_start_input = VCPSettingsLineEdit(self.frame_56)
        self.z_start_input.setObjectName(u"z_start_input")
        sizePolicy.setHeightForWidth(self.z_start_input.sizePolicy().hasHeightForWidth())
        self.z_start_input.setSizePolicy(sizePolicy)
        self.z_start_input.setMinimumSize(QSize(70, 33))
        self.z_start_input.setMaximumSize(QSize(70, 33))
        self.z_start_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_start_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_209.addWidget(self.z_start_input)

        self.frame_57 = QFrame(self.facing_diagram_widget)
        self.frame_57.setObjectName(u"frame_57")
        self.frame_57.setGeometry(QRect(19, 499, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_57.sizePolicy().hasHeightForWidth())
        self.frame_57.setSizePolicy(sizePolicy)
        self.frame_57.setMinimumSize(QSize(140, 45))
        self.frame_57.setMaximumSize(QSize(140, 45))
        self.frame_57.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_211 = QHBoxLayout(self.frame_57)
        self.horizontalLayout_211.setObjectName(u"horizontalLayout_211")
        self.horizontalLayout_211.setContentsMargins(3, 1, 3, 1)
        self.label_152 = QLabel(self.frame_57)
        self.label_152.setObjectName(u"label_152")
        sizePolicy.setHeightForWidth(self.label_152.sizePolicy().hasHeightForWidth())
        self.label_152.setSizePolicy(sizePolicy)
        self.label_152.setMinimumSize(QSize(50, 33))
        self.label_152.setMaximumSize(QSize(50, 33))
        self.label_152.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_152.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_152.setWordWrap(True)

        self.horizontalLayout_211.addWidget(self.label_152)

        self.z_end_input = VCPSettingsLineEdit(self.frame_57)
        self.z_end_input.setObjectName(u"z_end_input")
        sizePolicy.setHeightForWidth(self.z_end_input.sizePolicy().hasHeightForWidth())
        self.z_end_input.setSizePolicy(sizePolicy)
        self.z_end_input.setMinimumSize(QSize(70, 33))
        self.z_end_input.setMaximumSize(QSize(70, 33))
        self.z_end_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_end_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_211.addWidget(self.z_end_input)

        self.label_2 = QLabel(self.facing_diagram_widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(133, 29, 555, 500))
        self.label_2.setMinimumSize(QSize(555, 500))
        self.label_2.setMaximumSize(QSize(555, 500))
        self.label_2.setPixmap(QPixmap(u":/images/face_milling.png"))
        self.label_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.frame_58 = QFrame(self.facing_diagram_widget)
        self.frame_58.setObjectName(u"frame_58")
        self.frame_58.setGeometry(QRect(23, 55, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_58.sizePolicy().hasHeightForWidth())
        self.frame_58.setSizePolicy(sizePolicy)
        self.frame_58.setMinimumSize(QSize(140, 45))
        self.frame_58.setMaximumSize(QSize(140, 45))
        self.frame_58.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_213 = QHBoxLayout(self.frame_58)
        self.horizontalLayout_213.setObjectName(u"horizontalLayout_213")
        self.horizontalLayout_213.setContentsMargins(3, 1, 3, 1)
        self.label_153 = QLabel(self.frame_58)
        self.label_153.setObjectName(u"label_153")
        sizePolicy.setHeightForWidth(self.label_153.sizePolicy().hasHeightForWidth())
        self.label_153.setSizePolicy(sizePolicy)
        self.label_153.setMinimumSize(QSize(50, 33))
        self.label_153.setMaximumSize(QSize(50, 33))
        self.label_153.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_153.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_153.setWordWrap(True)

        self.horizontalLayout_213.addWidget(self.label_153)

        self.y_start_input = VCPSettingsLineEdit(self.frame_58)
        self.y_start_input.setObjectName(u"y_start_input")
        sizePolicy.setHeightForWidth(self.y_start_input.sizePolicy().hasHeightForWidth())
        self.y_start_input.setSizePolicy(sizePolicy)
        self.y_start_input.setMinimumSize(QSize(70, 33))
        self.y_start_input.setMaximumSize(QSize(70, 33))
        self.y_start_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.y_start_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_213.addWidget(self.y_start_input)

        self.frame_59 = QFrame(self.facing_diagram_widget)
        self.frame_59.setObjectName(u"frame_59")
        self.frame_59.setGeometry(QRect(23, 2, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_59.sizePolicy().hasHeightForWidth())
        self.frame_59.setSizePolicy(sizePolicy)
        self.frame_59.setMinimumSize(QSize(140, 45))
        self.frame_59.setMaximumSize(QSize(140, 45))
        self.frame_59.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_215 = QHBoxLayout(self.frame_59)
        self.horizontalLayout_215.setObjectName(u"horizontalLayout_215")
        self.horizontalLayout_215.setContentsMargins(3, 1, 3, 1)
        self.label_154 = QLabel(self.frame_59)
        self.label_154.setObjectName(u"label_154")
        sizePolicy.setHeightForWidth(self.label_154.sizePolicy().hasHeightForWidth())
        self.label_154.setSizePolicy(sizePolicy)
        self.label_154.setMinimumSize(QSize(50, 33))
        self.label_154.setMaximumSize(QSize(50, 33))
        self.label_154.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_154.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_154.setWordWrap(True)

        self.horizontalLayout_215.addWidget(self.label_154)

        self.x_start_input = VCPSettingsLineEdit(self.frame_59)
        self.x_start_input.setObjectName(u"x_start_input")
        sizePolicy.setHeightForWidth(self.x_start_input.sizePolicy().hasHeightForWidth())
        self.x_start_input.setSizePolicy(sizePolicy)
        self.x_start_input.setMinimumSize(QSize(70, 33))
        self.x_start_input.setMaximumSize(QSize(70, 33))
        self.x_start_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_start_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_215.addWidget(self.x_start_input)

        self.frame_60 = QFrame(self.facing_diagram_widget)
        self.frame_60.setObjectName(u"frame_60")
        self.frame_60.setGeometry(QRect(639, 376, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_60.sizePolicy().hasHeightForWidth())
        self.frame_60.setSizePolicy(sizePolicy)
        self.frame_60.setMinimumSize(QSize(140, 45))
        self.frame_60.setMaximumSize(QSize(140, 45))
        self.frame_60.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_217 = QHBoxLayout(self.frame_60)
        self.horizontalLayout_217.setObjectName(u"horizontalLayout_217")
        self.horizontalLayout_217.setContentsMargins(3, 1, 3, 1)
        self.label_148 = QLabel(self.frame_60)
        self.label_148.setObjectName(u"label_148")
        sizePolicy.setHeightForWidth(self.label_148.sizePolicy().hasHeightForWidth())
        self.label_148.setSizePolicy(sizePolicy)
        self.label_148.setMinimumSize(QSize(50, 33))
        self.label_148.setMaximumSize(QSize(35, 33))
        self.label_148.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_148.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_148.setWordWrap(True)

        self.horizontalLayout_217.addWidget(self.label_148)

        self.retract_height_input = VCPSettingsLineEdit(self.frame_60)
        self.retract_height_input.setObjectName(u"retract_height_input")
        sizePolicy.setHeightForWidth(self.retract_height_input.sizePolicy().hasHeightForWidth())
        self.retract_height_input.setSizePolicy(sizePolicy)
        self.retract_height_input.setMinimumSize(QSize(70, 33))
        self.retract_height_input.setMaximumSize(QSize(70, 33))
        self.retract_height_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.retract_height_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_217.addWidget(self.retract_height_input)

        self.frame_61 = QFrame(self.facing_diagram_widget)
        self.frame_61.setObjectName(u"frame_61")
        self.frame_61.setGeometry(QRect(644, 12, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_61.sizePolicy().hasHeightForWidth())
        self.frame_61.setSizePolicy(sizePolicy)
        self.frame_61.setMinimumSize(QSize(140, 45))
        self.frame_61.setMaximumSize(QSize(140, 45))
        self.frame_61.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_219 = QHBoxLayout(self.frame_61)
        self.horizontalLayout_219.setObjectName(u"horizontalLayout_219")
        self.horizontalLayout_219.setContentsMargins(3, 1, 3, 1)
        self.label_149 = QLabel(self.frame_61)
        self.label_149.setObjectName(u"label_149")
        sizePolicy.setHeightForWidth(self.label_149.sizePolicy().hasHeightForWidth())
        self.label_149.setSizePolicy(sizePolicy)
        self.label_149.setMinimumSize(QSize(50, 33))
        self.label_149.setMaximumSize(QSize(35, 33))
        self.label_149.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_149.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_149.setWordWrap(True)

        self.horizontalLayout_219.addWidget(self.label_149)

        self.x_end_input = VCPSettingsLineEdit(self.frame_61)
        self.x_end_input.setObjectName(u"x_end_input")
        sizePolicy.setHeightForWidth(self.x_end_input.sizePolicy().hasHeightForWidth())
        self.x_end_input.setSizePolicy(sizePolicy)
        self.x_end_input.setMinimumSize(QSize(70, 33))
        self.x_end_input.setMaximumSize(QSize(70, 33))
        self.x_end_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.x_end_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_219.addWidget(self.x_end_input)

        self.frame_62 = QFrame(self.facing_diagram_widget)
        self.frame_62.setObjectName(u"frame_62")
        self.frame_62.setGeometry(QRect(2, 375, 140, 45))
        sizePolicy.setHeightForWidth(self.frame_62.sizePolicy().hasHeightForWidth())
        self.frame_62.setSizePolicy(sizePolicy)
        self.frame_62.setMinimumSize(QSize(140, 45))
        self.frame_62.setMaximumSize(QSize(140, 45))
        self.frame_62.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: black;\n"
"    border-width: 2px;\n"
"    border-radius: 6px;\n"
"    color: rgb(238, 238, 236);\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgb(81, 86, 85), stop:0.489795 rgb(99, 102, 102), stop:0.699799 rgb(85, 88, 94), stop:0.90444 rgb(77, 84, 86), stop:0.160246 rgb(83, 84, 91), stop:1 rgb(109, 115, 118));\n"
"}")
        self.horizontalLayout_221 = QHBoxLayout(self.frame_62)
        self.horizontalLayout_221.setObjectName(u"horizontalLayout_221")
        self.horizontalLayout_221.setContentsMargins(3, 1, 3, 1)
        self.label_155 = QLabel(self.frame_62)
        self.label_155.setObjectName(u"label_155")
        sizePolicy.setHeightForWidth(self.label_155.sizePolicy().hasHeightForWidth())
        self.label_155.setSizePolicy(sizePolicy)
        self.label_155.setMinimumSize(QSize(50, 33))
        self.label_155.setMaximumSize(QSize(50, 33))
        self.label_155.setStyleSheet(u"QLabel{\n"
"font: 75 13pt \"Probe Basic Bebas Mono\";\n"
"color: rgb(255, 255, 255);\n"
"}")
        self.label_155.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_155.setWordWrap(True)

        self.horizontalLayout_221.addWidget(self.label_155)

        self.y_end_input = VCPSettingsLineEdit(self.frame_62)
        self.y_end_input.setObjectName(u"y_end_input")
        sizePolicy.setHeightForWidth(self.y_end_input.sizePolicy().hasHeightForWidth())
        self.y_end_input.setSizePolicy(sizePolicy)
        self.y_end_input.setMinimumSize(QSize(70, 33))
        self.y_end_input.setMaximumSize(QSize(70, 33))
        self.y_end_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.y_end_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_221.addWidget(self.y_end_input)

        self.label_2.raise_()
        self.frame_24.raise_()
        self.frame_55.raise_()
        self.frame_56.raise_()
        self.frame_57.raise_()
        self.frame_58.raise_()
        self.frame_59.raise_()
        self.frame_60.raise_()
        self.frame_61.raise_()
        self.frame_62.raise_()

        self.horizontalLayout.addWidget(self.facing_diagram_widget)

        self.facing_setup_frame = QFrame(Form)
        self.facing_setup_frame.setObjectName(u"facing_setup_frame")
        sizePolicy.setHeightForWidth(self.facing_setup_frame.sizePolicy().hasHeightForWidth())
        self.facing_setup_frame.setSizePolicy(sizePolicy)
        self.facing_setup_frame.setMinimumSize(QSize(500, 540))
        self.facing_setup_frame.setMaximumSize(QSize(500, 540))
        self.facing_setup_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.facing_setup_frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout = QVBoxLayout(self.facing_setup_frame)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(9, 9, 9, 9)
        self.widget_1 = QWidget(self.facing_setup_frame)
        self.widget_1.setObjectName(u"widget_1")
        self.widget_1.setMouseTracking(False)
        self.widget_1.setStyleSheet(u"font: 14pt \"Probe Basic Bebas Mono\";")
        self.gridLayout_4 = QGridLayout(self.widget_1)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.gridLayout_4.setHorizontalSpacing(6)
        self.gridLayout_4.setContentsMargins(1, 1, 1, 1)
        self.label_172 = QLabel(self.widget_1)
        self.label_172.setObjectName(u"label_172")
        sizePolicy.setHeightForWidth(self.label_172.sizePolicy().hasHeightForWidth())
        self.label_172.setSizePolicy(sizePolicy)
        self.label_172.setMinimumSize(QSize(120, 35))
        self.label_172.setMaximumSize(QSize(120, 35))
        font = QFont()
        font.setFamilies([u"Probe Basic Bebas Mono"])
        font.setPointSize(14)
        font.setBold(False)
        font.setItalic(False)
        self.label_172.setFont(font)
        self.label_172.setLineWidth(0)
        self.label_172.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_172.setIndent(0)

        self.gridLayout_4.addWidget(self.label_172, 5, 0, 1, 1)

        self.label_171 = QLabel(self.widget_1)
        self.label_171.setObjectName(u"label_171")
        sizePolicy.setHeightForWidth(self.label_171.sizePolicy().hasHeightForWidth())
        self.label_171.setSizePolicy(sizePolicy)
        self.label_171.setMinimumSize(QSize(115, 35))
        self.label_171.setMaximumSize(QSize(115, 35))
        self.label_171.setFont(font)
        self.label_171.setLineWidth(0)
        self.label_171.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.label_171.setIndent(0)

        self.gridLayout_4.addWidget(self.label_171, 4, 3, 1, 1)

        self.name_input = QLineEdit(self.widget_1)
        self.name_input.setObjectName(u"name_input")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.name_input.sizePolicy().hasHeightForWidth())
        self.name_input.setSizePolicy(sizePolicy1)
        self.name_input.setMinimumSize(QSize(0, 35))
        self.name_input.setMaximumSize(QSize(16777215, 35))
        self.name_input.setStyleSheet(u"padding-left: 6px;")
        self.name_input.setCursorPosition(8)

        self.gridLayout_4.addWidget(self.name_input, 0, 2, 1, 3)

        self.tool_description = QLabel(self.widget_1)
        self.tool_description.setObjectName(u"tool_description")
        sizePolicy1.setHeightForWidth(self.tool_description.sizePolicy().hasHeightForWidth())
        self.tool_description.setSizePolicy(sizePolicy1)
        self.tool_description.setMinimumSize(QSize(115, 35))
        self.tool_description.setMaximumSize(QSize(16777215, 35))
        self.tool_description.setFont(font)
        self.tool_description.setLineWidth(0)
        self.tool_description.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.tool_description.setIndent(0)

        self.gridLayout_4.addWidget(self.tool_description, 3, 3, 1, 2)

        self.tool_number_label_3 = QLabel(self.widget_1)
        self.tool_number_label_3.setObjectName(u"tool_number_label_3")
        sizePolicy.setHeightForWidth(self.tool_number_label_3.sizePolicy().hasHeightForWidth())
        self.tool_number_label_3.setSizePolicy(sizePolicy)
        self.tool_number_label_3.setMinimumSize(QSize(120, 35))
        self.tool_number_label_3.setMaximumSize(QSize(120, 35))
        self.tool_number_label_3.setFont(font)
        self.tool_number_label_3.setLineWidth(0)
        self.tool_number_label_3.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.tool_number_label_3.setIndent(0)

        self.gridLayout_4.addWidget(self.tool_number_label_3, 3, 0, 1, 1)

        self.label_170 = QLabel(self.widget_1)
        self.label_170.setObjectName(u"label_170")
        sizePolicy.setHeightForWidth(self.label_170.sizePolicy().hasHeightForWidth())
        self.label_170.setSizePolicy(sizePolicy)
        self.label_170.setMinimumSize(QSize(120, 35))
        self.label_170.setMaximumSize(QSize(120, 35))
        self.label_170.setFont(font)
        self.label_170.setLineWidth(0)
        self.label_170.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_170.setIndent(0)

        self.gridLayout_4.addWidget(self.label_170, 4, 0, 1, 1)

        self.label_132 = QLabel(self.widget_1)
        self.label_132.setObjectName(u"label_132")
        sizePolicy.setHeightForWidth(self.label_132.sizePolicy().hasHeightForWidth())
        self.label_132.setSizePolicy(sizePolicy)
        self.label_132.setMinimumSize(QSize(120, 35))
        self.label_132.setMaximumSize(QSize(120, 35))
        self.label_132.setFont(font)
        self.label_132.setLineWidth(0)
        self.label_132.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_132.setIndent(0)

        self.gridLayout_4.addWidget(self.label_132, 1, 0, 1, 1)

        self.label_173 = QLabel(self.widget_1)
        self.label_173.setObjectName(u"label_173")
        sizePolicy.setHeightForWidth(self.label_173.sizePolicy().hasHeightForWidth())
        self.label_173.setSizePolicy(sizePolicy)
        self.label_173.setMinimumSize(QSize(120, 35))
        self.label_173.setMaximumSize(QSize(120, 35))
        self.label_173.setFont(font)
        self.label_173.setLineWidth(0)
        self.label_173.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_173.setIndent(0)

        self.gridLayout_4.addWidget(self.label_173, 6, 0, 1, 1)

        self.label_175 = QLabel(self.widget_1)
        self.label_175.setObjectName(u"label_175")
        sizePolicy.setHeightForWidth(self.label_175.sizePolicy().hasHeightForWidth())
        self.label_175.setSizePolicy(sizePolicy)
        self.label_175.setMinimumSize(QSize(120, 35))
        self.label_175.setMaximumSize(QSize(120, 35))
        self.label_175.setFont(font)
        self.label_175.setLineWidth(0)
        self.label_175.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_175.setIndent(0)

        self.gridLayout_4.addWidget(self.label_175, 9, 0, 1, 1)

        self.label_169 = QLabel(self.widget_1)
        self.label_169.setObjectName(u"label_169")
        sizePolicy.setHeightForWidth(self.label_169.sizePolicy().hasHeightForWidth())
        self.label_169.setSizePolicy(sizePolicy)
        self.label_169.setMinimumSize(QSize(120, 35))
        self.label_169.setMaximumSize(QSize(120, 35))
        self.label_169.setFont(font)
        self.label_169.setLineWidth(0)
        self.label_169.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_169.setIndent(0)

        self.gridLayout_4.addWidget(self.label_169, 2, 0, 1, 1)

        self.label_168 = QLabel(self.widget_1)
        self.label_168.setObjectName(u"label_168")
        sizePolicy.setHeightForWidth(self.label_168.sizePolicy().hasHeightForWidth())
        self.label_168.setSizePolicy(sizePolicy)
        self.label_168.setMinimumSize(QSize(120, 35))
        self.label_168.setMaximumSize(QSize(120, 35))
        self.label_168.setFont(font)
        self.label_168.setLineWidth(0)
        self.label_168.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_168.setIndent(0)

        self.gridLayout_4.addWidget(self.label_168, 0, 0, 1, 1)

        self.label_174 = QLabel(self.widget_1)
        self.label_174.setObjectName(u"label_174")
        sizePolicy.setHeightForWidth(self.label_174.sizePolicy().hasHeightForWidth())
        self.label_174.setSizePolicy(sizePolicy)
        self.label_174.setMinimumSize(QSize(120, 35))
        self.label_174.setMaximumSize(QSize(120, 35))
        self.label_174.setFont(font)
        self.label_174.setLineWidth(0)
        self.label_174.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        self.label_174.setIndent(0)

        self.gridLayout_4.addWidget(self.label_174, 7, 0, 1, 1)

        self.xy_feed_rate_input = VCPSettingsLineEdit(self.widget_1)
        self.xy_feed_rate_input.setObjectName(u"xy_feed_rate_input")
        sizePolicy.setHeightForWidth(self.xy_feed_rate_input.sizePolicy().hasHeightForWidth())
        self.xy_feed_rate_input.setSizePolicy(sizePolicy)
        self.xy_feed_rate_input.setMinimumSize(QSize(100, 33))
        self.xy_feed_rate_input.setMaximumSize(QSize(100, 33))
        self.xy_feed_rate_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.xy_feed_rate_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_4.addWidget(self.xy_feed_rate_input, 6, 2, 1, 1)

        self.z_feed_rate_input = VCPSettingsLineEdit(self.widget_1)
        self.z_feed_rate_input.setObjectName(u"z_feed_rate_input")
        sizePolicy.setHeightForWidth(self.z_feed_rate_input.sizePolicy().hasHeightForWidth())
        self.z_feed_rate_input.setSizePolicy(sizePolicy)
        self.z_feed_rate_input.setMinimumSize(QSize(100, 33))
        self.z_feed_rate_input.setMaximumSize(QSize(100, 33))
        self.z_feed_rate_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.z_feed_rate_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_4.addWidget(self.z_feed_rate_input, 7, 2, 1, 1)

        self.clearance_height_input = VCPSettingsLineEdit(self.widget_1)
        self.clearance_height_input.setObjectName(u"clearance_height_input")
        sizePolicy.setHeightForWidth(self.clearance_height_input.sizePolicy().hasHeightForWidth())
        self.clearance_height_input.setSizePolicy(sizePolicy)
        self.clearance_height_input.setMinimumSize(QSize(100, 33))
        self.clearance_height_input.setMaximumSize(QSize(100, 33))
        self.clearance_height_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.clearance_height_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_4.addWidget(self.clearance_height_input, 9, 2, 1, 1)

        self.spindle_rpm_input = VCPSettingsLineEdit(self.widget_1)
        self.spindle_rpm_input.setObjectName(u"spindle_rpm_input")
        sizePolicy.setHeightForWidth(self.spindle_rpm_input.sizePolicy().hasHeightForWidth())
        self.spindle_rpm_input.setSizePolicy(sizePolicy)
        self.spindle_rpm_input.setMinimumSize(QSize(100, 33))
        self.spindle_rpm_input.setMaximumSize(QSize(100, 33))
        self.spindle_rpm_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.spindle_rpm_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_4.addWidget(self.spindle_rpm_input, 4, 2, 1, 1)

        self.tool_number_input = VCPSettingsLineEdit(self.widget_1)
        self.tool_number_input.setObjectName(u"tool_number_input")
        sizePolicy.setHeightForWidth(self.tool_number_input.sizePolicy().hasHeightForWidth())
        self.tool_number_input.setSizePolicy(sizePolicy)
        self.tool_number_input.setMinimumSize(QSize(100, 33))
        self.tool_number_input.setMaximumSize(QSize(100, 33))
        self.tool_number_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.tool_number_input.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.gridLayout_4.addWidget(self.tool_number_input, 3, 2, 1, 1)

        self.coolant_input = VCPSettingsComboBox(self.widget_1)
        self.coolant_input.setObjectName(u"coolant_input")
        sizePolicy.setHeightForWidth(self.coolant_input.sizePolicy().hasHeightForWidth())
        self.coolant_input.setSizePolicy(sizePolicy)
        self.coolant_input.setMinimumSize(QSize(100, 35))
        self.coolant_input.setMaximumSize(QSize(100, 35))
        self.coolant_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_4.addWidget(self.coolant_input, 5, 2, 1, 1)

        self.spindle_direction_input = VCPSettingsComboBox(self.widget_1)
        self.spindle_direction_input.setObjectName(u"spindle_direction_input")
        sizePolicy.setHeightForWidth(self.spindle_direction_input.sizePolicy().hasHeightForWidth())
        self.spindle_direction_input.setSizePolicy(sizePolicy)
        self.spindle_direction_input.setMinimumSize(QSize(100, 35))
        self.spindle_direction_input.setMaximumSize(QSize(100, 35))
        self.spindle_direction_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_4.addWidget(self.spindle_direction_input, 4, 4, 1, 1)

        self.unit_input = VCPSettingsComboBox(self.widget_1)
        self.unit_input.setObjectName(u"unit_input")
        sizePolicy.setHeightForWidth(self.unit_input.sizePolicy().hasHeightForWidth())
        self.unit_input.setSizePolicy(sizePolicy)
        self.unit_input.setMinimumSize(QSize(100, 35))
        self.unit_input.setMaximumSize(QSize(100, 35))
        self.unit_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_4.addWidget(self.unit_input, 2, 2, 1, 1)

        self.wcs_input = VCPSettingsComboBox(self.widget_1)
        self.wcs_input.setObjectName(u"wcs_input")
        sizePolicy.setHeightForWidth(self.wcs_input.sizePolicy().hasHeightForWidth())
        self.wcs_input.setSizePolicy(sizePolicy)
        self.wcs_input.setMinimumSize(QSize(100, 35))
        self.wcs_input.setMaximumSize(QSize(100, 35))
        self.wcs_input.setStyleSheet(u"padding-left: 10px;")

        self.gridLayout_4.addWidget(self.wcs_input, 1, 2, 1, 1)


        self.verticalLayout.addWidget(self.widget_1)

        self.post_to_file = QPushButton(self.facing_setup_frame)
        self.post_to_file.setObjectName(u"post_to_file")
        sizePolicy1.setHeightForWidth(self.post_to_file.sizePolicy().hasHeightForWidth())
        self.post_to_file.setSizePolicy(sizePolicy1)
        self.post_to_file.setMinimumSize(QSize(0, 42))
        self.post_to_file.setMaximumSize(QSize(16777215, 42))
        font1 = QFont()
        font1.setFamilies([u"Probe Basic Bebas Mono"])
        font1.setPointSize(15)
        font1.setBold(False)
        font1.setItalic(False)
        self.post_to_file.setFont(font1)

        self.verticalLayout.addWidget(self.post_to_file)


        self.horizontalLayout.addWidget(self.facing_setup_frame)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label_138.setText(QCoreApplication.translate("Form", u"STEP OVER", None))
        self.step_over_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.step_over_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.step_over_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.step-over", None))
        self.step_over_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_147.setText(QCoreApplication.translate("Form", u"STEP DOWN", None))
        self.step_down_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.step_down_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.step_down_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.step-down", None))
        self.step_down_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_151.setText(QCoreApplication.translate("Form", u"Z START", None))
        self.z_start_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_start_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.z_start_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.z-start", None))
        self.z_start_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_152.setText(QCoreApplication.translate("Form", u"Z END", None))
        self.z_end_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.z_end_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.z_end_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.z-end", None))
        self.z_end_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_2.setText("")
        self.label_153.setText(QCoreApplication.translate("Form", u"Y START", None))
        self.y_start_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.y_start_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.y_start_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.y-start", None))
        self.y_start_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_154.setText(QCoreApplication.translate("Form", u"X START", None))
        self.x_start_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.x_start_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.x_start_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.x-start", None))
        self.x_start_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_148.setText(QCoreApplication.translate("Form", u"RETRACT", None))
        self.retract_height_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.retract_height_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.retract_height_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.retract", None))
        self.retract_height_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_149.setText(QCoreApplication.translate("Form", u"X END", None))
        self.x_end_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.x_end_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.x_end_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.x-end", None))
        self.x_end_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_155.setText(QCoreApplication.translate("Form", u"Y END", None))
        self.y_end_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.y_end_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.y_end_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.y-end", None))
        self.y_end_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.label_172.setText(QCoreApplication.translate("Form", u"COOLANT", None))
        self.label_171.setText(QCoreApplication.translate("Form", u"DIRECTION", None))
        self.name_input.setText(QCoreApplication.translate("Form", u"Untitled", None))
        self.name_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.tool_description.setText(QCoreApplication.translate("Form", u"NO TOOL SELECTED", None))
        self.tool_number_label_3.setText(QCoreApplication.translate("Form", u"TOOL NUMBER", None))
        self.label_170.setText(QCoreApplication.translate("Form", u"SPINDLE RPM", None))
        self.label_132.setText(QCoreApplication.translate("Form", u"WCS", None))
        self.label_173.setText(QCoreApplication.translate("Form", u"XY FEEDRATE", None))
        self.label_175.setText(QCoreApplication.translate("Form", u"CLEARANCE HEIGHT", None))
        self.label_169.setText(QCoreApplication.translate("Form", u"PROGRAM UNIT", None))
        self.label_168.setText(QCoreApplication.translate("Form", u"NAME", None))
        self.label_174.setText(QCoreApplication.translate("Form", u"Z FEEDRATE", None))
        self.xy_feed_rate_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.xy_feed_rate_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.1f}", None))
        self.xy_feed_rate_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.xy-feed", None))
        self.xy_feed_rate_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.z_feed_rate_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0", None))
        self.z_feed_rate_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.1f}", None))
        self.z_feed_rate_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.z-feed", None))
        self.z_feed_rate_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.clearance_height_input.setPlaceholderText(QCoreApplication.translate("Form", u"0.0000", None))
        self.clearance_height_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.4f}", None))
        self.clearance_height_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.clearance-height", None))
        self.clearance_height_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.spindle_rpm_input.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.spindle_rpm_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.spindle_rpm_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.spindle-rpm", None))
        self.spindle_rpm_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.tool_number_input.setPlaceholderText(QCoreApplication.translate("Form", u"0", None))
        self.tool_number_input.setProperty(u"textFormat", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.tool_number_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.tool-number", None))
        self.tool_number_input.setProperty(u"styleSet", QCoreApplication.translate("Form", u"dataField14", None))
        self.coolant_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.coolant", None))
        self.spindle_direction_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.spindle-direction", None))
        self.unit_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.unit", None))
        self.wcs_input.setProperty(u"settingName", QCoreApplication.translate("Form", u"conv-facing.wcs", None))
        self.post_to_file.setText(QCoreApplication.translate("Form", u"POST TO FILE", None))
    # retranslateUi

