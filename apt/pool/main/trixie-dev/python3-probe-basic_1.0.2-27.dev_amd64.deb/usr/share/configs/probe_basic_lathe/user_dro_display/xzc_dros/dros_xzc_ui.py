# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'dros_xzc.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QSizePolicy, QVBoxLayout, QWidget)

from qtpyvcp.widgets.button_widgets.action_button import ActionButton
from qtpyvcp.widgets.button_widgets.mdi_button import MDIButton
from qtpyvcp.widgets.display_widgets.dro_label import DROLabel
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel
from qtpyvcp.widgets.input_widgets.dro_line_edit import DROLineEdit
import probe_basic_rc
import probe_basic_lathe_rc

class Ui_dros_xzc(object):
    def setupUi(self, dros_xzc):
        if not dros_xzc.objectName():
            dros_xzc.setObjectName(u"dros_xzc")
        dros_xzc.resize(479, 254)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(dros_xzc.sizePolicy().hasHeightForWidth())
        dros_xzc.setSizePolicy(sizePolicy)
        dros_xzc.setLayoutDirection(Qt.LeftToRight)
        self.verticalLayout = QVBoxLayout(dros_xzc)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.widget_xz = QWidget(dros_xzc)
        self.widget_xz.setObjectName(u"widget_xz")
        self.verticalLayout_55 = QVBoxLayout(self.widget_xz)
        self.verticalLayout_55.setSpacing(19)
        self.verticalLayout_55.setObjectName(u"verticalLayout_55")
        self.verticalLayout_55.setContentsMargins(0, 0, 0, 0)
        self.widget_87 = QWidget(self.widget_xz)
        self.widget_87.setObjectName(u"widget_87")
        self.widget_87.setMinimumSize(QSize(0, 42))
        self.horizontalLayout_79 = QHBoxLayout(self.widget_87)
        self.horizontalLayout_79.setObjectName(u"horizontalLayout_79")
        self.horizontalLayout_79.setContentsMargins(0, 0, 0, 0)
        self.zero_all_button = MDIButton(self.widget_87)
        self.zero_all_button.setObjectName(u"zero_all_button")
        self.zero_all_button.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.zero_all_button.sizePolicy().hasHeightForWidth())
        self.zero_all_button.setSizePolicy(sizePolicy1)
        self.zero_all_button.setMinimumSize(QSize(60, 40))
        self.zero_all_button.setMaximumSize(QSize(60, 40))
        self.zero_all_button.setFocusPolicy(Qt.NoFocus)
        self.zero_all_button.setLayoutDirection(Qt.LeftToRight)
        self.zero_all_button.setStyleSheet(u"MDIButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        icon = QIcon()
        icon.addFile(u":/images/zero.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.zero_all_button.setIcon(icon)
        self.zero_all_button.setIconSize(QSize(20, 20))

        self.horizontalLayout_79.addWidget(self.zero_all_button)

        self.frame_53 = QFrame(self.widget_87)
        self.frame_53.setObjectName(u"frame_53")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.frame_53.sizePolicy().hasHeightForWidth())
        self.frame_53.setSizePolicy(sizePolicy2)
        self.frame_53.setMinimumSize(QSize(0, 40))
        self.frame_53.setMaximumSize(QSize(16777215, 40))
        self.frame_53.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 1px;\n"
"    border-radius: 4px;\n"
"    background-color: rgb(90, 90, 90);\n"
"    padding: -5px;\n"
"}")
        self.frame_53.setFrameShape(QFrame.StyledPanel)
        self.frame_53.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_168 = QHBoxLayout(self.frame_53)
        self.horizontalLayout_168.setSpacing(18)
        self.horizontalLayout_168.setObjectName(u"horizontalLayout_168")
        self.horizontalLayout_168.setContentsMargins(9, -1, 0, -1)
        self.work_column_header = StatusLabel(self.frame_53)
        self.work_column_header.setObjectName(u"work_column_header")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.work_column_header.sizePolicy().hasHeightForWidth())
        self.work_column_header.setSizePolicy(sizePolicy3)
        self.work_column_header.setMinimumSize(QSize(100, 17))
        self.work_column_header.setMaximumSize(QSize(100, 17))
        self.work_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"    padding-left: 6px;\n"
"}")
        self.work_column_header.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_168.addWidget(self.work_column_header)

        self.machine_column_header = QLabel(self.frame_53)
        self.machine_column_header.setObjectName(u"machine_column_header")
        self.machine_column_header.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.machine_column_header.sizePolicy().hasHeightForWidth())
        self.machine_column_header.setSizePolicy(sizePolicy3)
        self.machine_column_header.setMinimumSize(QSize(100, 17))
        self.machine_column_header.setMaximumSize(QSize(100, 17))
        self.machine_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.machine_column_header.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_168.addWidget(self.machine_column_header)

        self.dtg_column_header = QLabel(self.frame_53)
        self.dtg_column_header.setObjectName(u"dtg_column_header")
        sizePolicy3.setHeightForWidth(self.dtg_column_header.sizePolicy().hasHeightForWidth())
        self.dtg_column_header.setSizePolicy(sizePolicy3)
        self.dtg_column_header.setMinimumSize(QSize(100, 17))
        self.dtg_column_header.setMaximumSize(QSize(100, 17))
        self.dtg_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.dtg_column_header.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_168.addWidget(self.dtg_column_header)


        self.horizontalLayout_79.addWidget(self.frame_53)

        self.ref_all_button = ActionButton(self.widget_87)
        self.ref_all_button.setObjectName(u"ref_all_button")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.ref_all_button.sizePolicy().hasHeightForWidth())
        self.ref_all_button.setSizePolicy(sizePolicy4)
        self.ref_all_button.setMinimumSize(QSize(62, 40))
        self.ref_all_button.setMaximumSize(QSize(62, 40))
        self.ref_all_button.setFocusPolicy(Qt.NoFocus)
        self.ref_all_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_79.addWidget(self.ref_all_button)


        self.verticalLayout_55.addWidget(self.widget_87)

        self.widget_88 = QWidget(self.widget_xz)
        self.widget_88.setObjectName(u"widget_88")
        self.widget_88.setMinimumSize(QSize(0, 42))
        self.x_axis_dro_layout_3 = QHBoxLayout(self.widget_88)
        self.x_axis_dro_layout_3.setSpacing(8)
        self.x_axis_dro_layout_3.setObjectName(u"x_axis_dro_layout_3")
        self.x_axis_dro_layout_3.setContentsMargins(0, 2, 0, 2)
        self.zero_x_button = MDIButton(self.widget_88)
        self.zero_x_button.setObjectName(u"zero_x_button")
        self.zero_x_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_x_button.sizePolicy().hasHeightForWidth())
        self.zero_x_button.setSizePolicy(sizePolicy)
        self.zero_x_button.setMinimumSize(QSize(60, 40))
        self.zero_x_button.setMaximumSize(QSize(60, 40))
        self.zero_x_button.setLayoutDirection(Qt.LeftToRight)
        self.zero_x_button.setStyleSheet(u"MDIButton {\n"
"   	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_x_button.setIconSize(QSize(20, 20))

        self.x_axis_dro_layout_3.addWidget(self.zero_x_button)

        self.dro_entry_x_main = DROLineEdit(self.widget_88)
        self.dro_entry_x_main.setObjectName(u"dro_entry_x_main")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(1)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.dro_entry_x_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_x_main.setSizePolicy(sizePolicy5)
        self.dro_entry_x_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_x_main.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry_x_main.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry_x_main.setProperty(u"referenceType", 1)
        self.dro_entry_x_main.setProperty(u"axisNumber", 0)
        self.dro_entry_x_main.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.dro_entry_x_main)

        self.drolabel_machine_x = DROLabel(self.widget_88)
        self.drolabel_machine_x.setObjectName(u"drolabel_machine_x")
        sizePolicy5.setHeightForWidth(self.drolabel_machine_x.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_x.setSizePolicy(sizePolicy5)
        self.drolabel_machine_x.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_x.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_machine_x.setProperty(u"referenceType", 0)
        self.drolabel_machine_x.setProperty(u"axisNumber", 0)
        self.drolabel_machine_x.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.drolabel_machine_x)

        self.dro_dtg_x = DROLabel(self.widget_88)
        self.dro_dtg_x.setObjectName(u"dro_dtg_x")
        sizePolicy5.setHeightForWidth(self.dro_dtg_x.sizePolicy().hasHeightForWidth())
        self.dro_dtg_x.setSizePolicy(sizePolicy5)
        self.dro_dtg_x.setMinimumSize(QSize(100, 35))
        self.dro_dtg_x.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_dtg_x.setProperty(u"referenceType", 2)
        self.dro_dtg_x.setProperty(u"axisNumber", 0)
        self.dro_dtg_x.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.dro_dtg_x)

        self.ref_x_button = ActionButton(self.widget_88)
        self.ref_x_button.setObjectName(u"ref_x_button")
        sizePolicy3.setHeightForWidth(self.ref_x_button.sizePolicy().hasHeightForWidth())
        self.ref_x_button.setSizePolicy(sizePolicy3)
        self.ref_x_button.setMinimumSize(QSize(60, 40))
        self.ref_x_button.setMaximumSize(QSize(60, 40))
        self.ref_x_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.x_axis_dro_layout_3.addWidget(self.ref_x_button)


        self.verticalLayout_55.addWidget(self.widget_88)

        self.widget_89 = QWidget(self.widget_xz)
        self.widget_89.setObjectName(u"widget_89")
        self.widget_89.setMinimumSize(QSize(0, 42))
        self.z_axis_dro_layout_6 = QHBoxLayout(self.widget_89)
        self.z_axis_dro_layout_6.setSpacing(8)
        self.z_axis_dro_layout_6.setObjectName(u"z_axis_dro_layout_6")
        self.z_axis_dro_layout_6.setContentsMargins(0, 2, 0, 2)
        self.zero_z_button = MDIButton(self.widget_89)
        self.zero_z_button.setObjectName(u"zero_z_button")
        self.zero_z_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_z_button.sizePolicy().hasHeightForWidth())
        self.zero_z_button.setSizePolicy(sizePolicy)
        self.zero_z_button.setMinimumSize(QSize(60, 40))
        self.zero_z_button.setMaximumSize(QSize(60, 40))
        self.zero_z_button.setStyleSheet(u"MDIButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_z_button.setIcon(icon)
        self.zero_z_button.setIconSize(QSize(20, 20))

        self.z_axis_dro_layout_6.addWidget(self.zero_z_button)

        self.dro_entry_z_main = DROLineEdit(self.widget_89)
        self.dro_entry_z_main.setObjectName(u"dro_entry_z_main")
        sizePolicy5.setHeightForWidth(self.dro_entry_z_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_z_main.setSizePolicy(sizePolicy5)
        self.dro_entry_z_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_z_main.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry_z_main.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry_z_main.setProperty(u"referenceType", 1)
        self.dro_entry_z_main.setProperty(u"axisNumber", 2)
        self.dro_entry_z_main.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.dro_entry_z_main)

        self.drolabel_machine_z = DROLabel(self.widget_89)
        self.drolabel_machine_z.setObjectName(u"drolabel_machine_z")
        sizePolicy5.setHeightForWidth(self.drolabel_machine_z.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_z.setSizePolicy(sizePolicy5)
        self.drolabel_machine_z.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_z.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_machine_z.setProperty(u"referenceType", 0)
        self.drolabel_machine_z.setProperty(u"axisNumber", 2)
        self.drolabel_machine_z.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.drolabel_machine_z)

        self.dro_dtg_z = DROLabel(self.widget_89)
        self.dro_dtg_z.setObjectName(u"dro_dtg_z")
        sizePolicy5.setHeightForWidth(self.dro_dtg_z.sizePolicy().hasHeightForWidth())
        self.dro_dtg_z.setSizePolicy(sizePolicy5)
        self.dro_dtg_z.setMinimumSize(QSize(100, 35))
        self.dro_dtg_z.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_dtg_z.setProperty(u"referenceType", 2)
        self.dro_dtg_z.setProperty(u"axisNumber", 2)
        self.dro_dtg_z.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.dro_dtg_z)

        self.ref_z_button = ActionButton(self.widget_89)
        self.ref_z_button.setObjectName(u"ref_z_button")
        sizePolicy3.setHeightForWidth(self.ref_z_button.sizePolicy().hasHeightForWidth())
        self.ref_z_button.setSizePolicy(sizePolicy3)
        self.ref_z_button.setMinimumSize(QSize(60, 40))
        self.ref_z_button.setMaximumSize(QSize(60, 40))
        self.ref_z_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.z_axis_dro_layout_6.addWidget(self.ref_z_button)


        self.verticalLayout_55.addWidget(self.widget_89)

        self.widget_93 = QWidget(self.widget_xz)
        self.widget_93.setObjectName(u"widget_93")
        self.widget_93.setMinimumSize(QSize(0, 42))
        self.z_axis_dro_layout_10 = QHBoxLayout(self.widget_93)
        self.z_axis_dro_layout_10.setSpacing(8)
        self.z_axis_dro_layout_10.setObjectName(u"z_axis_dro_layout_10")
        self.z_axis_dro_layout_10.setContentsMargins(0, 2, 0, 2)
        self.zero_c_button = MDIButton(self.widget_93)
        self.zero_c_button.setObjectName(u"zero_c_button")
        self.zero_c_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_c_button.sizePolicy().hasHeightForWidth())
        self.zero_c_button.setSizePolicy(sizePolicy)
        self.zero_c_button.setMinimumSize(QSize(60, 40))
        self.zero_c_button.setMaximumSize(QSize(60, 40))
        self.zero_c_button.setStyleSheet(u"MDIButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_c_button.setIcon(icon)
        self.zero_c_button.setIconSize(QSize(20, 20))

        self.z_axis_dro_layout_10.addWidget(self.zero_c_button)

        self.dro_entry_c_main = DROLineEdit(self.widget_93)
        self.dro_entry_c_main.setObjectName(u"dro_entry_c_main")
        sizePolicy5.setHeightForWidth(self.dro_entry_c_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_c_main.setSizePolicy(sizePolicy5)
        self.dro_entry_c_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_c_main.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry_c_main.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry_c_main.setProperty(u"referenceType", 1)
        self.dro_entry_c_main.setProperty(u"axisNumber", 5)
        self.dro_entry_c_main.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_10.addWidget(self.dro_entry_c_main)

        self.drolabel_machine_c = DROLabel(self.widget_93)
        self.drolabel_machine_c.setObjectName(u"drolabel_machine_c")
        sizePolicy5.setHeightForWidth(self.drolabel_machine_c.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_c.setSizePolicy(sizePolicy5)
        self.drolabel_machine_c.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_c.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_machine_c.setProperty(u"referenceType", 0)
        self.drolabel_machine_c.setProperty(u"axisNumber", 5)
        self.drolabel_machine_c.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_10.addWidget(self.drolabel_machine_c)

        self.dro_dtg_c = DROLabel(self.widget_93)
        self.dro_dtg_c.setObjectName(u"dro_dtg_c")
        sizePolicy5.setHeightForWidth(self.dro_dtg_c.sizePolicy().hasHeightForWidth())
        self.dro_dtg_c.setSizePolicy(sizePolicy5)
        self.dro_dtg_c.setMinimumSize(QSize(100, 35))
        self.dro_dtg_c.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_dtg_c.setProperty(u"referenceType", 2)
        self.dro_dtg_c.setProperty(u"axisNumber", 5)
        self.dro_dtg_c.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_10.addWidget(self.dro_dtg_c)

        self.ref_c_button = ActionButton(self.widget_93)
        self.ref_c_button.setObjectName(u"ref_c_button")
        sizePolicy3.setHeightForWidth(self.ref_c_button.sizePolicy().hasHeightForWidth())
        self.ref_c_button.setSizePolicy(sizePolicy3)
        self.ref_c_button.setMinimumSize(QSize(60, 40))
        self.ref_c_button.setMaximumSize(QSize(60, 40))
        self.ref_c_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.z_axis_dro_layout_10.addWidget(self.ref_c_button)


        self.verticalLayout_55.addWidget(self.widget_93)

        self.widget = QWidget(self.widget_xz)
        self.widget.setObjectName(u"widget")

        self.verticalLayout_55.addWidget(self.widget)


        self.verticalLayout.addWidget(self.widget_xz)


        self.retranslateUi(dros_xzc)

        QMetaObject.connectSlotsByName(dros_xzc)
    # setupUi

    def retranslateUi(self, dros_xzc):
        dros_xzc.setWindowTitle(QCoreApplication.translate("dros_xzc", u"dros_xzc", None))
        self.zero_all_button.setText(QCoreApplication.translate("dros_xzc", u"ALL", None))
        self.zero_all_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_all_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xzc", u"G10 L20 P{ch[0]} X0.0 Z0.0", None))
        self.work_column_header.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[{\"channels\": [{\"url\": \"status:g5x_index?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0] + ' WORK'\\n\", \"name\": \"WCS Header\"}]", None))
        self.machine_column_header.setText(QCoreApplication.translate("dros_xzc", u"MACHINE", None))
        self.dtg_column_header.setText(QCoreApplication.translate("dros_xzc", u"DTG", None))
        self.ref_all_button.setText(QCoreApplication.translate("dros_xzc", u"REF ALL", None))
        self.ref_all_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[{\"channels\": [{\"url\": \"status:all_axes_homed\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'HOMED' if ch[0] else 'REF ALL'\", \"name\": \"reference_all\"}, {\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}]}]", None))
        self.ref_all_button.setProperty(u"actionName", QCoreApplication.translate("dros_xzc", u"machine.home.all", None))
        self.zero_x_button.setText(QCoreApplication.translate("dros_xzc", u"X RAD", None))
        self.zero_x_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true, \"type\": \"int\"}], \"property\": \"None\", \"expression\": \"\", \"name\": \"G5x Index\"}, {\"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'X DIA' if 'G7' in ch[0] else 'X RAD'\", \"name\": \"diam_rad_mode_display\"}]", None))
        self.zero_x_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xzc", u"G10 L20 P{ch[0]} X0.0", None))
        self.dro_entry_x_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.dro_entry_x_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.dro_entry_x_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.dro_entry_x_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.drolabel_machine_x.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.drolabel_machine_x.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.drolabel_machine_x.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.drolabel_machine_x.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.dro_dtg_x.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.dro_dtg_x.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.dro_dtg_x.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.dro_dtg_x.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.ref_x_button.setText(QCoreApplication.translate("dros_xzc", u"REF X", None))
        self.ref_x_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[{\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.3.homing\", \"trigger\": true}]}]", None))
        self.ref_x_button.setProperty(u"actionName", QCoreApplication.translate("dros_xzc", u"machine.home.axis:x", None))
        self.zero_z_button.setText(QCoreApplication.translate("dros_xzc", u"Z", None))
        self.zero_z_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_z_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xzc", u"G10 L20 P{ch[0]} Z0.0", None))
        self.dro_entry_z_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.dro_entry_z_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.dro_entry_z_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.dro_entry_z_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.drolabel_machine_z.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.drolabel_machine_z.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.drolabel_machine_z.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.drolabel_machine_z.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.dro_dtg_z.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.dro_dtg_z.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.dro_dtg_z.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.dro_dtg_z.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.ref_z_button.setText(QCoreApplication.translate("dros_xzc", u"REF Z", None))
        self.ref_z_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[{\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}]}]", None))
        self.ref_z_button.setProperty(u"actionName", QCoreApplication.translate("dros_xzc", u"machine.home.axis:z", None))
        self.zero_c_button.setText(QCoreApplication.translate("dros_xzc", u"C", None))
        self.zero_c_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_c_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xzc", u"G10 L20 P{ch[0]} C0.0", None))
        self.dro_entry_c_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.dro_entry_c_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.dro_entry_c_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.dro_entry_c_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.drolabel_machine_c.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.drolabel_machine_c.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.drolabel_machine_c.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.drolabel_machine_c.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.dro_dtg_c.setProperty(u"inchFormat", QCoreApplication.translate("dros_xzc", u"%9.4f", None))
        self.dro_dtg_c.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xzc", u"%10.3f", None))
        self.dro_dtg_c.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xzc", u"%10.2f", None))
        self.dro_dtg_c.setProperty(u"styleSet", QCoreApplication.translate("dros_xzc", u"dataField17", None))
        self.ref_c_button.setText(QCoreApplication.translate("dros_xzc", u"REF C", None))
        self.ref_c_button.setProperty(u"rules", QCoreApplication.translate("dros_xzc", u"[{\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}]}]", None))
        self.ref_c_button.setProperty(u"actionName", QCoreApplication.translate("dros_xzc", u"machine.home.axis:c", None))
    # retranslateUi

