# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'dros_xz.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QSizePolicy, QVBoxLayout, QWidget)

from qtpyvcp.widgets.button_widgets.action_button import ActionButton
from qtpyvcp.widgets.button_widgets.mdi_button import MDIButton
from qtpyvcp.widgets.display_widgets.dro_label import DROLabel
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel
from qtpyvcp.widgets.input_widgets.dro_line_edit import DROLineEdit
import probe_basic_rc
import probe_basic_lathe_rc

class Ui_dros_xz(object):
    def setupUi(self, dros_xz):
        if not dros_xz.objectName():
            dros_xz.setObjectName(u"dros_xz")
        dros_xz.resize(491, 308)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(dros_xz.sizePolicy().hasHeightForWidth())
        dros_xz.setSizePolicy(sizePolicy)
        dros_xz.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.verticalLayout = QVBoxLayout(dros_xz)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.widget_xz = QWidget(dros_xz)
        self.widget_xz.setObjectName(u"widget_xz")
        self.verticalLayout_55 = QVBoxLayout(self.widget_xz)
        self.verticalLayout_55.setSpacing(15)
        self.verticalLayout_55.setObjectName(u"verticalLayout_55")
        self.verticalLayout_55.setContentsMargins(0, 2, 0, 0)
        self.widget_87 = QWidget(self.widget_xz)
        self.widget_87.setObjectName(u"widget_87")
        self.widget_87.setMinimumSize(QSize(0, 42))
        self.horizontalLayout_79 = QHBoxLayout(self.widget_87)
        self.horizontalLayout_79.setObjectName(u"horizontalLayout_79")
        self.horizontalLayout_79.setContentsMargins(0, 0, 0, 0)
        self.frame_53 = QFrame(self.widget_87)
        self.frame_53.setObjectName(u"frame_53")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame_53.sizePolicy().hasHeightForWidth())
        self.frame_53.setSizePolicy(sizePolicy1)
        self.frame_53.setMinimumSize(QSize(0, 40))
        self.frame_53.setMaximumSize(QSize(16777215, 40))
        self.frame_53.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 1px;\n"
"    border-radius: 4px;\n"
"    background-color: rgb(90, 90, 90);\n"
"    padding: -5px;\n"
"}")
        self.frame_53.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_53.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_168 = QHBoxLayout(self.frame_53)
        self.horizontalLayout_168.setSpacing(18)
        self.horizontalLayout_168.setObjectName(u"horizontalLayout_168")
        self.horizontalLayout_168.setContentsMargins(9, -1, 0, -1)
        self.machine_column_header_2 = QLabel(self.frame_53)
        self.machine_column_header_2.setObjectName(u"machine_column_header_2")
        self.machine_column_header_2.setEnabled(False)
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.machine_column_header_2.sizePolicy().hasHeightForWidth())
        self.machine_column_header_2.setSizePolicy(sizePolicy2)
        self.machine_column_header_2.setMinimumSize(QSize(48, 17))
        self.machine_column_header_2.setMaximumSize(QSize(48, 17))
        self.machine_column_header_2.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.machine_column_header_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_168.addWidget(self.machine_column_header_2)

        self.work_column_header = StatusLabel(self.frame_53)
        self.work_column_header.setObjectName(u"work_column_header")
        sizePolicy2.setHeightForWidth(self.work_column_header.sizePolicy().hasHeightForWidth())
        self.work_column_header.setSizePolicy(sizePolicy2)
        self.work_column_header.setMinimumSize(QSize(100, 17))
        self.work_column_header.setMaximumSize(QSize(100, 17))
        self.work_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"    padding-left: 6px;\n"
"}")
        self.work_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_168.addWidget(self.work_column_header)

        self.machine_column_header = QLabel(self.frame_53)
        self.machine_column_header.setObjectName(u"machine_column_header")
        self.machine_column_header.setEnabled(False)
        sizePolicy2.setHeightForWidth(self.machine_column_header.sizePolicy().hasHeightForWidth())
        self.machine_column_header.setSizePolicy(sizePolicy2)
        self.machine_column_header.setMinimumSize(QSize(100, 17))
        self.machine_column_header.setMaximumSize(QSize(100, 17))
        self.machine_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.machine_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_168.addWidget(self.machine_column_header)

        self.dtg_column_header = QLabel(self.frame_53)
        self.dtg_column_header.setObjectName(u"dtg_column_header")
        sizePolicy2.setHeightForWidth(self.dtg_column_header.sizePolicy().hasHeightForWidth())
        self.dtg_column_header.setSizePolicy(sizePolicy2)
        self.dtg_column_header.setMinimumSize(QSize(100, 17))
        self.dtg_column_header.setMaximumSize(QSize(100, 17))
        self.dtg_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.dtg_column_header.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_168.addWidget(self.dtg_column_header)

        self.machine_column_header_3 = QLabel(self.frame_53)
        self.machine_column_header_3.setObjectName(u"machine_column_header_3")
        self.machine_column_header_3.setEnabled(False)
        sizePolicy2.setHeightForWidth(self.machine_column_header_3.sizePolicy().hasHeightForWidth())
        self.machine_column_header_3.setSizePolicy(sizePolicy2)
        self.machine_column_header_3.setMinimumSize(QSize(60, 17))
        self.machine_column_header_3.setMaximumSize(QSize(60, 17))
        self.machine_column_header_3.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.machine_column_header_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_168.addWidget(self.machine_column_header_3)


        self.horizontalLayout_79.addWidget(self.frame_53)


        self.verticalLayout_55.addWidget(self.widget_87)

        self.widget_88 = QWidget(self.widget_xz)
        self.widget_88.setObjectName(u"widget_88")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(1)
        sizePolicy3.setHeightForWidth(self.widget_88.sizePolicy().hasHeightForWidth())
        self.widget_88.setSizePolicy(sizePolicy3)
        self.widget_88.setMinimumSize(QSize(0, 42))
        self.x_axis_dro_layout_3 = QHBoxLayout(self.widget_88)
        self.x_axis_dro_layout_3.setSpacing(8)
        self.x_axis_dro_layout_3.setObjectName(u"x_axis_dro_layout_3")
        self.x_axis_dro_layout_3.setContentsMargins(0, 2, 0, 2)
        self.zero_x_button = MDIButton(self.widget_88)
        self.zero_x_button.setObjectName(u"zero_x_button")
        self.zero_x_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_x_button.sizePolicy().hasHeightForWidth())
        self.zero_x_button.setSizePolicy(sizePolicy)
        self.zero_x_button.setMinimumSize(QSize(60, 40))
        self.zero_x_button.setMaximumSize(QSize(60, 40))
        self.zero_x_button.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.zero_x_button.setStyleSheet(u"MDIButton {\n"
"   	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_x_button.setIconSize(QSize(20, 20))

        self.x_axis_dro_layout_3.addWidget(self.zero_x_button)

        self.dro_entry_x_main = DROLineEdit(self.widget_88)
        self.dro_entry_x_main.setObjectName(u"dro_entry_x_main")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.dro_entry_x_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_x_main.setSizePolicy(sizePolicy4)
        self.dro_entry_x_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_x_main.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.dro_entry_x_main.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.dro_entry_x_main.setProperty(u"referenceType", 1)
        self.dro_entry_x_main.setProperty(u"axisNumber", 0)
        self.dro_entry_x_main.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.dro_entry_x_main)

        self.drolabel_machine_x = DROLabel(self.widget_88)
        self.drolabel_machine_x.setObjectName(u"drolabel_machine_x")
        sizePolicy4.setHeightForWidth(self.drolabel_machine_x.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_x.setSizePolicy(sizePolicy4)
        self.drolabel_machine_x.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_x.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_machine_x.setProperty(u"referenceType", 0)
        self.drolabel_machine_x.setProperty(u"axisNumber", 0)
        self.drolabel_machine_x.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.drolabel_machine_x)

        self.dro_dtg_x = DROLabel(self.widget_88)
        self.dro_dtg_x.setObjectName(u"dro_dtg_x")
        sizePolicy4.setHeightForWidth(self.dro_dtg_x.sizePolicy().hasHeightForWidth())
        self.dro_dtg_x.setSizePolicy(sizePolicy4)
        self.dro_dtg_x.setMinimumSize(QSize(100, 35))
        self.dro_dtg_x.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.dro_dtg_x.setProperty(u"referenceType", 2)
        self.dro_dtg_x.setProperty(u"axisNumber", 0)
        self.dro_dtg_x.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.dro_dtg_x)

        self.ref_x_button = ActionButton(self.widget_88)
        self.ref_x_button.setObjectName(u"ref_x_button")
        sizePolicy2.setHeightForWidth(self.ref_x_button.sizePolicy().hasHeightForWidth())
        self.ref_x_button.setSizePolicy(sizePolicy2)
        self.ref_x_button.setMinimumSize(QSize(60, 40))
        self.ref_x_button.setMaximumSize(QSize(60, 40))
        self.ref_x_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.x_axis_dro_layout_3.addWidget(self.ref_x_button)


        self.verticalLayout_55.addWidget(self.widget_88)

        self.widget_89 = QWidget(self.widget_xz)
        self.widget_89.setObjectName(u"widget_89")
        sizePolicy3.setHeightForWidth(self.widget_89.sizePolicy().hasHeightForWidth())
        self.widget_89.setSizePolicy(sizePolicy3)
        self.widget_89.setMinimumSize(QSize(0, 42))
        self.z_axis_dro_layout_6 = QHBoxLayout(self.widget_89)
        self.z_axis_dro_layout_6.setSpacing(8)
        self.z_axis_dro_layout_6.setObjectName(u"z_axis_dro_layout_6")
        self.z_axis_dro_layout_6.setContentsMargins(0, 2, 0, 2)
        self.zero_z_button = MDIButton(self.widget_89)
        self.zero_z_button.setObjectName(u"zero_z_button")
        self.zero_z_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_z_button.sizePolicy().hasHeightForWidth())
        self.zero_z_button.setSizePolicy(sizePolicy)
        self.zero_z_button.setMinimumSize(QSize(60, 40))
        self.zero_z_button.setMaximumSize(QSize(60, 40))
        self.zero_z_button.setStyleSheet(u"MDIButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        icon = QIcon()
        icon.addFile(u":/images/zero.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.zero_z_button.setIcon(icon)
        self.zero_z_button.setIconSize(QSize(20, 20))

        self.z_axis_dro_layout_6.addWidget(self.zero_z_button)

        self.dro_entry_z_main = DROLineEdit(self.widget_89)
        self.dro_entry_z_main.setObjectName(u"dro_entry_z_main")
        sizePolicy4.setHeightForWidth(self.dro_entry_z_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_z_main.setSizePolicy(sizePolicy4)
        self.dro_entry_z_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_z_main.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.dro_entry_z_main.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.dro_entry_z_main.setProperty(u"referenceType", 1)
        self.dro_entry_z_main.setProperty(u"axisNumber", 2)
        self.dro_entry_z_main.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.dro_entry_z_main)

        self.drolabel_machine_z = DROLabel(self.widget_89)
        self.drolabel_machine_z.setObjectName(u"drolabel_machine_z")
        sizePolicy4.setHeightForWidth(self.drolabel_machine_z.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_z.setSizePolicy(sizePolicy4)
        self.drolabel_machine_z.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_z.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.drolabel_machine_z.setProperty(u"referenceType", 0)
        self.drolabel_machine_z.setProperty(u"axisNumber", 2)
        self.drolabel_machine_z.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.drolabel_machine_z)

        self.dro_dtg_z = DROLabel(self.widget_89)
        self.dro_dtg_z.setObjectName(u"dro_dtg_z")
        sizePolicy4.setHeightForWidth(self.dro_dtg_z.sizePolicy().hasHeightForWidth())
        self.dro_dtg_z.setSizePolicy(sizePolicy4)
        self.dro_dtg_z.setMinimumSize(QSize(100, 35))
        self.dro_dtg_z.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)
        self.dro_dtg_z.setProperty(u"referenceType", 2)
        self.dro_dtg_z.setProperty(u"axisNumber", 2)
        self.dro_dtg_z.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.dro_dtg_z)

        self.ref_z_button = ActionButton(self.widget_89)
        self.ref_z_button.setObjectName(u"ref_z_button")
        sizePolicy2.setHeightForWidth(self.ref_z_button.sizePolicy().hasHeightForWidth())
        self.ref_z_button.setSizePolicy(sizePolicy2)
        self.ref_z_button.setMinimumSize(QSize(60, 40))
        self.ref_z_button.setMaximumSize(QSize(60, 40))
        self.ref_z_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.z_axis_dro_layout_6.addWidget(self.ref_z_button)


        self.verticalLayout_55.addWidget(self.widget_89)

        self.widget_2 = QWidget(self.widget_xz)
        self.widget_2.setObjectName(u"widget_2")
        sizePolicy3.setHeightForWidth(self.widget_2.sizePolicy().hasHeightForWidth())
        self.widget_2.setSizePolicy(sizePolicy3)

        self.verticalLayout_55.addWidget(self.widget_2)

        self.line_5 = QFrame(self.widget_xz)
        self.line_5.setObjectName(u"line_5")
        self.line_5.setMaximumSize(QSize(16777215, 2))
        self.line_5.setLineWidth(0)
        self.line_5.setMidLineWidth(1)
        self.line_5.setFrameShape(QFrame.Shape.HLine)
        self.line_5.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_55.addWidget(self.line_5)

        self.widget = QWidget(self.widget_xz)
        self.widget.setObjectName(u"widget")
        self.widget.setMaximumSize(QSize(16777215, 45))
        self.horizontalLayout = QHBoxLayout(self.widget)
        self.horizontalLayout.setSpacing(30)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.zero_all_button = MDIButton(self.widget)
        self.zero_all_button.setObjectName(u"zero_all_button")
        self.zero_all_button.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.zero_all_button.sizePolicy().hasHeightForWidth())
        self.zero_all_button.setSizePolicy(sizePolicy1)
        self.zero_all_button.setMinimumSize(QSize(60, 40))
        self.zero_all_button.setMaximumSize(QSize(16777215, 40))
        self.zero_all_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.zero_all_button.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.zero_all_button.setStyleSheet(u"MDIButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_all_button.setIcon(icon)
        self.zero_all_button.setIconSize(QSize(20, 20))

        self.horizontalLayout.addWidget(self.zero_all_button)

        self.ref_all_button = ActionButton(self.widget)
        self.ref_all_button.setObjectName(u"ref_all_button")
        sizePolicy1.setHeightForWidth(self.ref_all_button.sizePolicy().hasHeightForWidth())
        self.ref_all_button.setSizePolicy(sizePolicy1)
        self.ref_all_button.setMinimumSize(QSize(62, 40))
        self.ref_all_button.setMaximumSize(QSize(16777215, 40))
        self.ref_all_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.ref_all_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout.addWidget(self.ref_all_button)


        self.verticalLayout_55.addWidget(self.widget)


        self.verticalLayout.addWidget(self.widget_xz)


        self.retranslateUi(dros_xz)

        QMetaObject.connectSlotsByName(dros_xz)
    # setupUi

    def retranslateUi(self, dros_xz):
        dros_xz.setWindowTitle(QCoreApplication.translate("dros_xz", u"dros_xz", None))
        self.machine_column_header_2.setText(QCoreApplication.translate("dros_xz", u"AXIS", None))
        self.work_column_header.setProperty(u"rules", QCoreApplication.translate("dros_xz", u"[{\"channels\": [{\"url\": \"status:g5x_index?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0] + ' WORK'\\n\", \"name\": \"WCS Header\"}]", None))
        self.machine_column_header.setText(QCoreApplication.translate("dros_xz", u"MACHINE", None))
        self.dtg_column_header.setText(QCoreApplication.translate("dros_xz", u"DTG", None))
        self.machine_column_header_3.setText(QCoreApplication.translate("dros_xz", u"REF", None))
        self.zero_x_button.setText(QCoreApplication.translate("dros_xz", u"X RAD", None))
        self.zero_x_button.setProperty(u"rules", QCoreApplication.translate("dros_xz", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true, \"type\": \"int\"}], \"property\": \"None\", \"expression\": \"\", \"name\": \"G5x Index\"}, {\"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'X DIA' if 'G7' in ch[0] else 'X RAD'\", \"name\": \"diam_rad_mode_display\"}]", None))
        self.zero_x_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xz", u"G10 L20 P{ch[0]} X0.0", None))
        self.dro_entry_x_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xz", u"%9.4f", None))
        self.dro_entry_x_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xz", u"%10.3f", None))
        self.dro_entry_x_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xz", u"%10.2f", None))
        self.dro_entry_x_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xz", u"dataField17", None))
        self.drolabel_machine_x.setProperty(u"inchFormat", QCoreApplication.translate("dros_xz", u"%9.4f", None))
        self.drolabel_machine_x.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xz", u"%10.3f", None))
        self.drolabel_machine_x.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xz", u"%10.2f", None))
        self.drolabel_machine_x.setProperty(u"styleSet", QCoreApplication.translate("dros_xz", u"dataField17", None))
        self.dro_dtg_x.setProperty(u"inchFormat", QCoreApplication.translate("dros_xz", u"%9.4f", None))
        self.dro_dtg_x.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xz", u"%10.3f", None))
        self.dro_dtg_x.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xz", u"%10.2f", None))
        self.dro_dtg_x.setProperty(u"styleSet", QCoreApplication.translate("dros_xz", u"dataField17", None))
        self.ref_x_button.setText(QCoreApplication.translate("dros_xz", u"REF X", None))
        self.ref_x_button.setProperty(u"rules", QCoreApplication.translate("dros_xz", u"[{\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}]}]", None))
        self.ref_x_button.setProperty(u"actionName", QCoreApplication.translate("dros_xz", u"machine.home.axis:x", None))
        self.zero_z_button.setText(QCoreApplication.translate("dros_xz", u"Z", None))
        self.zero_z_button.setProperty(u"rules", QCoreApplication.translate("dros_xz", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_z_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xz", u"G10 L20 P{ch[0]} Z0.0", None))
        self.dro_entry_z_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xz", u"%9.4f", None))
        self.dro_entry_z_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xz", u"%10.3f", None))
        self.dro_entry_z_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xz", u"%10.2f", None))
        self.dro_entry_z_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xz", u"dataField17", None))
        self.drolabel_machine_z.setProperty(u"inchFormat", QCoreApplication.translate("dros_xz", u"%9.4f", None))
        self.drolabel_machine_z.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xz", u"%10.3f", None))
        self.drolabel_machine_z.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xz", u"%10.2f", None))
        self.drolabel_machine_z.setProperty(u"styleSet", QCoreApplication.translate("dros_xz", u"dataField17", None))
        self.dro_dtg_z.setProperty(u"inchFormat", QCoreApplication.translate("dros_xz", u"%9.4f", None))
        self.dro_dtg_z.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xz", u"%10.3f", None))
        self.dro_dtg_z.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xz", u"%10.2f", None))
        self.dro_dtg_z.setProperty(u"styleSet", QCoreApplication.translate("dros_xz", u"dataField17", None))
        self.ref_z_button.setText(QCoreApplication.translate("dros_xz", u"REF Z", None))
        self.ref_z_button.setProperty(u"rules", QCoreApplication.translate("dros_xz", u"[{\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}]}]", None))
        self.ref_z_button.setProperty(u"actionName", QCoreApplication.translate("dros_xz", u"machine.home.axis:z", None))
        self.zero_all_button.setText(QCoreApplication.translate("dros_xz", u"ALL", None))
        self.zero_all_button.setProperty(u"rules", QCoreApplication.translate("dros_xz", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_all_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xz", u"G10 L20 P{ch[0]} X0.0 Z0.0", None))
        self.ref_all_button.setText(QCoreApplication.translate("dros_xz", u"REF ALL", None))
        self.ref_all_button.setProperty(u"rules", QCoreApplication.translate("dros_xz", u"[{\"channels\": [{\"url\": \"status:all_axes_homed\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'HOMED' if ch[0] else 'REF ALL'\", \"name\": \"reference_all\"}, {\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}]}]", None))
        self.ref_all_button.setProperty(u"actionName", QCoreApplication.translate("dros_xz", u"machine.home.all", None))
    # retranslateUi

