# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'dros_xyzc.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QSizePolicy, QVBoxLayout, QWidget)

from qtpyvcp.widgets.button_widgets.action_button import ActionButton
from qtpyvcp.widgets.button_widgets.mdi_button import MDIButton
from qtpyvcp.widgets.display_widgets.dro_label import DROLabel
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel
from qtpyvcp.widgets.input_widgets.dro_line_edit import DROLineEdit
import probe_basic_rc
import probe_basic_lathe_rc

class Ui_dros_xyzc(object):
    def setupUi(self, dros_xyzc):
        if not dros_xyzc.objectName():
            dros_xyzc.setObjectName(u"dros_xyzc")
        dros_xyzc.resize(479, 315)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(dros_xyzc.sizePolicy().hasHeightForWidth())
        dros_xyzc.setSizePolicy(sizePolicy)
        dros_xyzc.setLayoutDirection(Qt.LeftToRight)
        self.verticalLayout = QVBoxLayout(dros_xyzc)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.widget_xyzc = QWidget(dros_xyzc)
        self.widget_xyzc.setObjectName(u"widget_xyzc")
        self.verticalLayout_55 = QVBoxLayout(self.widget_xyzc)
        self.verticalLayout_55.setSpacing(19)
        self.verticalLayout_55.setObjectName(u"verticalLayout_55")
        self.verticalLayout_55.setContentsMargins(0, 0, 0, 0)
        self.dros_header_layout = QWidget(self.widget_xyzc)
        self.dros_header_layout.setObjectName(u"dros_header_layout")
        self.dros_header_layout.setMinimumSize(QSize(0, 42))
        self.horizontalLayout_79 = QHBoxLayout(self.dros_header_layout)
        self.horizontalLayout_79.setObjectName(u"horizontalLayout_79")
        self.horizontalLayout_79.setContentsMargins(0, 0, 0, 0)
        self.zero_all_button = MDIButton(self.dros_header_layout)
        self.zero_all_button.setObjectName(u"zero_all_button")
        self.zero_all_button.setEnabled(False)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.zero_all_button.sizePolicy().hasHeightForWidth())
        self.zero_all_button.setSizePolicy(sizePolicy1)
        self.zero_all_button.setMinimumSize(QSize(60, 40))
        self.zero_all_button.setMaximumSize(QSize(60, 40))
        self.zero_all_button.setFocusPolicy(Qt.NoFocus)
        self.zero_all_button.setLayoutDirection(Qt.LeftToRight)
        self.zero_all_button.setStyleSheet(u"MDIButton {\n"
"   	font: 14pt \"Probe Basic Bebas Mono\";\n"
"}")
        icon = QIcon()
        icon.addFile(u":/images/zero.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.zero_all_button.setIcon(icon)
        self.zero_all_button.setIconSize(QSize(20, 20))

        self.horizontalLayout_79.addWidget(self.zero_all_button)

        self.column_header_frame = QFrame(self.dros_header_layout)
        self.column_header_frame.setObjectName(u"column_header_frame")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.column_header_frame.sizePolicy().hasHeightForWidth())
        self.column_header_frame.setSizePolicy(sizePolicy2)
        self.column_header_frame.setMinimumSize(QSize(0, 40))
        self.column_header_frame.setMaximumSize(QSize(16777215, 40))
        self.column_header_frame.setStyleSheet(u".QFrame{\n"
"    border-style: solid;\n"
"    border-color: rgb(176, 179,172);\n"
"    border-width: 1px;\n"
"    border-radius: 4px;\n"
"    background-color: rgb(90, 90, 90);\n"
"    padding: -5px;\n"
"}")
        self.column_header_frame.setFrameShape(QFrame.StyledPanel)
        self.column_header_frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_168 = QHBoxLayout(self.column_header_frame)
        self.horizontalLayout_168.setSpacing(18)
        self.horizontalLayout_168.setObjectName(u"horizontalLayout_168")
        self.horizontalLayout_168.setContentsMargins(9, -1, 0, -1)
        self.work_column_header = StatusLabel(self.column_header_frame)
        self.work_column_header.setObjectName(u"work_column_header")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.work_column_header.sizePolicy().hasHeightForWidth())
        self.work_column_header.setSizePolicy(sizePolicy3)
        self.work_column_header.setMinimumSize(QSize(100, 17))
        self.work_column_header.setMaximumSize(QSize(100, 17))
        self.work_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"    padding-left: 6px;\n"
"}")
        self.work_column_header.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_168.addWidget(self.work_column_header)

        self.machine_column_header = QLabel(self.column_header_frame)
        self.machine_column_header.setObjectName(u"machine_column_header")
        self.machine_column_header.setEnabled(False)
        sizePolicy3.setHeightForWidth(self.machine_column_header.sizePolicy().hasHeightForWidth())
        self.machine_column_header.setSizePolicy(sizePolicy3)
        self.machine_column_header.setMinimumSize(QSize(100, 17))
        self.machine_column_header.setMaximumSize(QSize(100, 17))
        self.machine_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.machine_column_header.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_168.addWidget(self.machine_column_header)

        self.dtg_column_header = QLabel(self.column_header_frame)
        self.dtg_column_header.setObjectName(u"dtg_column_header")
        sizePolicy3.setHeightForWidth(self.dtg_column_header.sizePolicy().hasHeightForWidth())
        self.dtg_column_header.setSizePolicy(sizePolicy3)
        self.dtg_column_header.setMinimumSize(QSize(100, 17))
        self.dtg_column_header.setMaximumSize(QSize(100, 17))
        self.dtg_column_header.setStyleSheet(u"QLabel{\n"
"    color: rgb(238, 238, 236);\n"
"	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.dtg_column_header.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_168.addWidget(self.dtg_column_header)


        self.horizontalLayout_79.addWidget(self.column_header_frame)

        self.ref_all_button = ActionButton(self.dros_header_layout)
        self.ref_all_button.setObjectName(u"ref_all_button")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.ref_all_button.sizePolicy().hasHeightForWidth())
        self.ref_all_button.setSizePolicy(sizePolicy4)
        self.ref_all_button.setMinimumSize(QSize(62, 40))
        self.ref_all_button.setMaximumSize(QSize(62, 40))
        self.ref_all_button.setFocusPolicy(Qt.NoFocus)
        self.ref_all_button.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.horizontalLayout_79.addWidget(self.ref_all_button)


        self.verticalLayout_55.addWidget(self.dros_header_layout)

        self.dros_x_layout = QWidget(self.widget_xyzc)
        self.dros_x_layout.setObjectName(u"dros_x_layout")
        self.dros_x_layout.setMinimumSize(QSize(0, 42))
        self.x_axis_dro_layout_3 = QHBoxLayout(self.dros_x_layout)
        self.x_axis_dro_layout_3.setSpacing(8)
        self.x_axis_dro_layout_3.setObjectName(u"x_axis_dro_layout_3")
        self.x_axis_dro_layout_3.setContentsMargins(0, 2, 0, 2)
        self.zero_x_button = MDIButton(self.dros_x_layout)
        self.zero_x_button.setObjectName(u"zero_x_button")
        self.zero_x_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_x_button.sizePolicy().hasHeightForWidth())
        self.zero_x_button.setSizePolicy(sizePolicy)
        self.zero_x_button.setMinimumSize(QSize(60, 40))
        self.zero_x_button.setMaximumSize(QSize(60, 40))
        self.zero_x_button.setLayoutDirection(Qt.LeftToRight)
        self.zero_x_button.setStyleSheet(u"MDIButton {\n"
"   	font: 16pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_x_button.setIconSize(QSize(20, 20))

        self.x_axis_dro_layout_3.addWidget(self.zero_x_button)

        self.dro_entry_x_main = DROLineEdit(self.dros_x_layout)
        self.dro_entry_x_main.setObjectName(u"dro_entry_x_main")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(1)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.dro_entry_x_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_x_main.setSizePolicy(sizePolicy5)
        self.dro_entry_x_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_x_main.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry_x_main.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry_x_main.setProperty(u"referenceType", 1)
        self.dro_entry_x_main.setProperty(u"axisNumber", 0)
        self.dro_entry_x_main.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.dro_entry_x_main)

        self.drolabel_machine_x = DROLabel(self.dros_x_layout)
        self.drolabel_machine_x.setObjectName(u"drolabel_machine_x")
        sizePolicy5.setHeightForWidth(self.drolabel_machine_x.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_x.setSizePolicy(sizePolicy5)
        self.drolabel_machine_x.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_x.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_machine_x.setProperty(u"referenceType", 0)
        self.drolabel_machine_x.setProperty(u"axisNumber", 0)
        self.drolabel_machine_x.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.drolabel_machine_x)

        self.dro_dtg_x = DROLabel(self.dros_x_layout)
        self.dro_dtg_x.setObjectName(u"dro_dtg_x")
        sizePolicy5.setHeightForWidth(self.dro_dtg_x.sizePolicy().hasHeightForWidth())
        self.dro_dtg_x.setSizePolicy(sizePolicy5)
        self.dro_dtg_x.setMinimumSize(QSize(100, 35))
        self.dro_dtg_x.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_dtg_x.setProperty(u"referenceType", 2)
        self.dro_dtg_x.setProperty(u"axisNumber", 0)
        self.dro_dtg_x.setProperty(u"latheMode", 0)

        self.x_axis_dro_layout_3.addWidget(self.dro_dtg_x)

        self.ref_x_button_2 = ActionButton(self.dros_x_layout)
        self.ref_x_button_2.setObjectName(u"ref_x_button_2")
        sizePolicy2.setHeightForWidth(self.ref_x_button_2.sizePolicy().hasHeightForWidth())
        self.ref_x_button_2.setSizePolicy(sizePolicy2)
        self.ref_x_button_2.setMinimumSize(QSize(62, 40))
        self.ref_x_button_2.setMaximumSize(QSize(62, 40))
        self.ref_x_button_2.setFocusPolicy(Qt.NoFocus)
        self.ref_x_button_2.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.x_axis_dro_layout_3.addWidget(self.ref_x_button_2)


        self.verticalLayout_55.addWidget(self.dros_x_layout)

        self.dros_y_layout = QWidget(self.widget_xyzc)
        self.dros_y_layout.setObjectName(u"dros_y_layout")
        self.dros_y_layout.setMinimumSize(QSize(0, 42))
        self.z_axis_dro_layout_7 = QHBoxLayout(self.dros_y_layout)
        self.z_axis_dro_layout_7.setSpacing(8)
        self.z_axis_dro_layout_7.setObjectName(u"z_axis_dro_layout_7")
        self.z_axis_dro_layout_7.setContentsMargins(0, 2, 0, 2)
        self.zero_y_button = MDIButton(self.dros_y_layout)
        self.zero_y_button.setObjectName(u"zero_y_button")
        self.zero_y_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_y_button.sizePolicy().hasHeightForWidth())
        self.zero_y_button.setSizePolicy(sizePolicy)
        self.zero_y_button.setMinimumSize(QSize(60, 40))
        self.zero_y_button.setMaximumSize(QSize(60, 40))
        self.zero_y_button.setStyleSheet(u"MDIButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_y_button.setIcon(icon)
        self.zero_y_button.setIconSize(QSize(20, 20))

        self.z_axis_dro_layout_7.addWidget(self.zero_y_button)

        self.dro_entry_y_main = DROLineEdit(self.dros_y_layout)
        self.dro_entry_y_main.setObjectName(u"dro_entry_y_main")
        sizePolicy5.setHeightForWidth(self.dro_entry_y_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_y_main.setSizePolicy(sizePolicy5)
        self.dro_entry_y_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_y_main.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry_y_main.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry_y_main.setProperty(u"referenceType", 1)
        self.dro_entry_y_main.setProperty(u"axisNumber", 1)
        self.dro_entry_y_main.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_7.addWidget(self.dro_entry_y_main)

        self.drolabel_machine_y = DROLabel(self.dros_y_layout)
        self.drolabel_machine_y.setObjectName(u"drolabel_machine_y")
        sizePolicy5.setHeightForWidth(self.drolabel_machine_y.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_y.setSizePolicy(sizePolicy5)
        self.drolabel_machine_y.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_y.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_machine_y.setProperty(u"referenceType", 0)
        self.drolabel_machine_y.setProperty(u"axisNumber", 1)
        self.drolabel_machine_y.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_7.addWidget(self.drolabel_machine_y)

        self.drolabel_12 = DROLabel(self.dros_y_layout)
        self.drolabel_12.setObjectName(u"drolabel_12")
        sizePolicy5.setHeightForWidth(self.drolabel_12.sizePolicy().hasHeightForWidth())
        self.drolabel_12.setSizePolicy(sizePolicy5)
        self.drolabel_12.setMinimumSize(QSize(100, 35))
        self.drolabel_12.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_12.setProperty(u"referenceType", 2)
        self.drolabel_12.setProperty(u"axisNumber", 1)
        self.drolabel_12.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_7.addWidget(self.drolabel_12)

        self.ref_y_button_2 = ActionButton(self.dros_y_layout)
        self.ref_y_button_2.setObjectName(u"ref_y_button_2")
        sizePolicy2.setHeightForWidth(self.ref_y_button_2.sizePolicy().hasHeightForWidth())
        self.ref_y_button_2.setSizePolicy(sizePolicy2)
        self.ref_y_button_2.setMinimumSize(QSize(62, 40))
        self.ref_y_button_2.setMaximumSize(QSize(62, 40))
        self.ref_y_button_2.setFocusPolicy(Qt.NoFocus)
        self.ref_y_button_2.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.z_axis_dro_layout_7.addWidget(self.ref_y_button_2)


        self.verticalLayout_55.addWidget(self.dros_y_layout)

        self.dros_z_layout = QWidget(self.widget_xyzc)
        self.dros_z_layout.setObjectName(u"dros_z_layout")
        self.dros_z_layout.setMinimumSize(QSize(0, 42))
        self.z_axis_dro_layout_6 = QHBoxLayout(self.dros_z_layout)
        self.z_axis_dro_layout_6.setSpacing(8)
        self.z_axis_dro_layout_6.setObjectName(u"z_axis_dro_layout_6")
        self.z_axis_dro_layout_6.setContentsMargins(0, 2, 0, 2)
        self.zero_z_button = MDIButton(self.dros_z_layout)
        self.zero_z_button.setObjectName(u"zero_z_button")
        self.zero_z_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_z_button.sizePolicy().hasHeightForWidth())
        self.zero_z_button.setSizePolicy(sizePolicy)
        self.zero_z_button.setMinimumSize(QSize(60, 40))
        self.zero_z_button.setMaximumSize(QSize(60, 40))
        self.zero_z_button.setStyleSheet(u"MDIButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_z_button.setIcon(icon)
        self.zero_z_button.setIconSize(QSize(20, 20))

        self.z_axis_dro_layout_6.addWidget(self.zero_z_button)

        self.dro_entry_z_main = DROLineEdit(self.dros_z_layout)
        self.dro_entry_z_main.setObjectName(u"dro_entry_z_main")
        sizePolicy5.setHeightForWidth(self.dro_entry_z_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_z_main.setSizePolicy(sizePolicy5)
        self.dro_entry_z_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_z_main.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry_z_main.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry_z_main.setProperty(u"referenceType", 1)
        self.dro_entry_z_main.setProperty(u"axisNumber", 2)
        self.dro_entry_z_main.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.dro_entry_z_main)

        self.drolabel_machine_z = DROLabel(self.dros_z_layout)
        self.drolabel_machine_z.setObjectName(u"drolabel_machine_z")
        sizePolicy5.setHeightForWidth(self.drolabel_machine_z.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_z.setSizePolicy(sizePolicy5)
        self.drolabel_machine_z.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_z.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_machine_z.setProperty(u"referenceType", 0)
        self.drolabel_machine_z.setProperty(u"axisNumber", 2)
        self.drolabel_machine_z.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.drolabel_machine_z)

        self.dro_dtg_z = DROLabel(self.dros_z_layout)
        self.dro_dtg_z.setObjectName(u"dro_dtg_z")
        sizePolicy5.setHeightForWidth(self.dro_dtg_z.sizePolicy().hasHeightForWidth())
        self.dro_dtg_z.setSizePolicy(sizePolicy5)
        self.dro_dtg_z.setMinimumSize(QSize(100, 35))
        self.dro_dtg_z.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_dtg_z.setProperty(u"referenceType", 2)
        self.dro_dtg_z.setProperty(u"axisNumber", 2)
        self.dro_dtg_z.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_6.addWidget(self.dro_dtg_z)

        self.ref_z_button_2 = ActionButton(self.dros_z_layout)
        self.ref_z_button_2.setObjectName(u"ref_z_button_2")
        sizePolicy2.setHeightForWidth(self.ref_z_button_2.sizePolicy().hasHeightForWidth())
        self.ref_z_button_2.setSizePolicy(sizePolicy2)
        self.ref_z_button_2.setMinimumSize(QSize(62, 40))
        self.ref_z_button_2.setMaximumSize(QSize(62, 40))
        self.ref_z_button_2.setFocusPolicy(Qt.NoFocus)
        self.ref_z_button_2.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.z_axis_dro_layout_6.addWidget(self.ref_z_button_2)


        self.verticalLayout_55.addWidget(self.dros_z_layout)

        self.dros_c_layout = QWidget(self.widget_xyzc)
        self.dros_c_layout.setObjectName(u"dros_c_layout")
        self.dros_c_layout.setMinimumSize(QSize(0, 42))
        self.z_axis_dro_layout_10 = QHBoxLayout(self.dros_c_layout)
        self.z_axis_dro_layout_10.setSpacing(8)
        self.z_axis_dro_layout_10.setObjectName(u"z_axis_dro_layout_10")
        self.z_axis_dro_layout_10.setContentsMargins(0, 2, 0, 2)
        self.zero_c_button = MDIButton(self.dros_c_layout)
        self.zero_c_button.setObjectName(u"zero_c_button")
        self.zero_c_button.setEnabled(False)
        sizePolicy.setHeightForWidth(self.zero_c_button.sizePolicy().hasHeightForWidth())
        self.zero_c_button.setSizePolicy(sizePolicy)
        self.zero_c_button.setMinimumSize(QSize(60, 40))
        self.zero_c_button.setMaximumSize(QSize(60, 40))
        self.zero_c_button.setStyleSheet(u"MDIButton {\n"
"   	font: 17pt \"Probe Basic Bebas Mono\";\n"
"}")
        self.zero_c_button.setIcon(icon)
        self.zero_c_button.setIconSize(QSize(20, 20))

        self.z_axis_dro_layout_10.addWidget(self.zero_c_button)

        self.dro_entry_c_main = DROLineEdit(self.dros_c_layout)
        self.dro_entry_c_main.setObjectName(u"dro_entry_c_main")
        sizePolicy5.setHeightForWidth(self.dro_entry_c_main.sizePolicy().hasHeightForWidth())
        self.dro_entry_c_main.setSizePolicy(sizePolicy5)
        self.dro_entry_c_main.setMinimumSize(QSize(100, 35))
        self.dro_entry_c_main.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry_c_main.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry_c_main.setProperty(u"referenceType", 1)
        self.dro_entry_c_main.setProperty(u"axisNumber", 5)
        self.dro_entry_c_main.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_10.addWidget(self.dro_entry_c_main)

        self.drolabel_machine_c = DROLabel(self.dros_c_layout)
        self.drolabel_machine_c.setObjectName(u"drolabel_machine_c")
        sizePolicy5.setHeightForWidth(self.drolabel_machine_c.sizePolicy().hasHeightForWidth())
        self.drolabel_machine_c.setSizePolicy(sizePolicy5)
        self.drolabel_machine_c.setMinimumSize(QSize(100, 35))
        self.drolabel_machine_c.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.drolabel_machine_c.setProperty(u"referenceType", 0)
        self.drolabel_machine_c.setProperty(u"axisNumber", 5)
        self.drolabel_machine_c.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_10.addWidget(self.drolabel_machine_c)

        self.dro_dtg_c = DROLabel(self.dros_c_layout)
        self.dro_dtg_c.setObjectName(u"dro_dtg_c")
        sizePolicy5.setHeightForWidth(self.dro_dtg_c.sizePolicy().hasHeightForWidth())
        self.dro_dtg_c.setSizePolicy(sizePolicy5)
        self.dro_dtg_c.setMinimumSize(QSize(100, 35))
        self.dro_dtg_c.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_dtg_c.setProperty(u"referenceType", 2)
        self.dro_dtg_c.setProperty(u"axisNumber", 5)
        self.dro_dtg_c.setProperty(u"latheMode", 0)

        self.z_axis_dro_layout_10.addWidget(self.dro_dtg_c)

        self.ref_c_button_2 = ActionButton(self.dros_c_layout)
        self.ref_c_button_2.setObjectName(u"ref_c_button_2")
        sizePolicy2.setHeightForWidth(self.ref_c_button_2.sizePolicy().hasHeightForWidth())
        self.ref_c_button_2.setSizePolicy(sizePolicy2)
        self.ref_c_button_2.setMinimumSize(QSize(62, 40))
        self.ref_c_button_2.setMaximumSize(QSize(62, 40))
        self.ref_c_button_2.setFocusPolicy(Qt.NoFocus)
        self.ref_c_button_2.setStyleSheet(u"QPushButton {\n"
"   	font: 15pt \"Probe Basic Bebas Mono\";\n"
"}")

        self.z_axis_dro_layout_10.addWidget(self.ref_c_button_2)


        self.verticalLayout_55.addWidget(self.dros_c_layout)

        self.spacer_widget = QWidget(self.widget_xyzc)
        self.spacer_widget.setObjectName(u"spacer_widget")

        self.verticalLayout_55.addWidget(self.spacer_widget)


        self.verticalLayout.addWidget(self.widget_xyzc)


        self.retranslateUi(dros_xyzc)

        QMetaObject.connectSlotsByName(dros_xyzc)
    # setupUi

    def retranslateUi(self, dros_xyzc):
        dros_xyzc.setWindowTitle(QCoreApplication.translate("dros_xyzc", u"dros_xyzc", None))
        self.zero_all_button.setText(QCoreApplication.translate("dros_xyzc", u"ALL", None))
        self.zero_all_button.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_all_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xyzc", u"G10 L20 P{ch[0]} X0.0 Y0.0 Z0.0 C0.0", None))
        self.work_column_header.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[{\"channels\": [{\"url\": \"status:g5x_index?text\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"ch[0] + ' WORK'\\n\", \"name\": \"WCS Header\"}]", None))
        self.machine_column_header.setText(QCoreApplication.translate("dros_xyzc", u"MACHINE", None))
        self.dtg_column_header.setText(QCoreApplication.translate("dros_xyzc", u"DTG", None))
        self.ref_all_button.setText(QCoreApplication.translate("dros_xyzc", u"REF ALL", None))
        self.ref_all_button.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[{\"channels\": [{\"url\": \"status:all_axes_homed\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'HOMED' if ch[0] else 'REF ALL'\", \"name\": \"reference_all\"}, {\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2] or ch[3])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}, {\"url\": \"status:joint.3.homing\", \"trigger\": true}]}]", None))
        self.ref_all_button.setProperty(u"actionName", QCoreApplication.translate("dros_xyzc", u"machine.home.all", None))
        self.zero_x_button.setText(QCoreApplication.translate("dros_xyzc", u"X RAD", None))
        self.zero_x_button.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[{\"channels\": [{\"url\": \"status:g5x_index\", \"trigger\": true, \"type\": \"int\"}], \"property\": \"None\", \"expression\": \"\", \"name\": \"G5x Index\"}, {\"channels\": [{\"url\": \"status:gcodes\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"'X DIA' if 'G7' in ch[0] else 'X RAD'\", \"name\": \"diam_rad_mode_display\"}]", None))
        self.zero_x_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xyzc", u"G10 L20 P{ch[0]} X0.0", None))
        self.dro_entry_x_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.dro_entry_x_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.dro_entry_x_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.dro_entry_x_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.drolabel_machine_x.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.drolabel_machine_x.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.drolabel_machine_x.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.drolabel_machine_x.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.dro_dtg_x.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.dro_dtg_x.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.dro_dtg_x.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.dro_dtg_x.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.ref_x_button_2.setText(QCoreApplication.translate("dros_xyzc", u"REF X", None))
        self.ref_x_button_2.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[{\"name\": \"home_prohibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2] or ch[3])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}, {\"url\": \"status:joint.3.homing\", \"trigger\": true}]}]", None))
        self.ref_x_button_2.setProperty(u"actionName", QCoreApplication.translate("dros_xyzc", u"machine.home.axis:x", None))
        self.zero_y_button.setText(QCoreApplication.translate("dros_xyzc", u"Y", None))
        self.zero_y_button.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_y_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xyzc", u"G10 L20 P{ch[0]} Y0.0", None))
        self.dro_entry_y_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.dro_entry_y_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.dro_entry_y_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.dro_entry_y_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.drolabel_machine_y.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.drolabel_machine_y.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.drolabel_machine_y.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.drolabel_machine_y.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.drolabel_12.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.drolabel_12.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.drolabel_12.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.drolabel_12.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.ref_y_button_2.setText(QCoreApplication.translate("dros_xyzc", u"REF Y", None))
        self.ref_y_button_2.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[{\"name\": \"home_prohibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2] or ch[3])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}, {\"url\": \"status:joint.3.homing\", \"trigger\": true}]}]", None))
        self.ref_y_button_2.setProperty(u"actionName", QCoreApplication.translate("dros_xyzc", u"machine.home.axis:y", None))
        self.zero_z_button.setText(QCoreApplication.translate("dros_xyzc", u"Z", None))
        self.zero_z_button.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_z_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xyzc", u"G10 L20 P{ch[0]} Z0.0", None))
        self.dro_entry_z_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.dro_entry_z_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.dro_entry_z_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.dro_entry_z_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.drolabel_machine_z.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.drolabel_machine_z.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.drolabel_machine_z.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.drolabel_machine_z.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.dro_dtg_z.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.dro_dtg_z.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.dro_dtg_z.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.dro_dtg_z.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.ref_z_button_2.setText(QCoreApplication.translate("dros_xyzc", u"REF Z", None))
        self.ref_z_button_2.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[{\"name\": \"home_prohibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2] or ch[3])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}, {\"url\": \"status:joint.3.homing\", \"trigger\": true}]}]", None))
        self.ref_z_button_2.setProperty(u"actionName", QCoreApplication.translate("dros_xyzc", u"machine.home.axis:z", None))
        self.zero_c_button.setText(QCoreApplication.translate("dros_xyzc", u"C", None))
        self.zero_c_button.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[\n"
"    {\n"
"        \"channels\": [\n"
"            {\n"
"                \"url\": \"status:g5x_index\",\n"
"                \"trigger\": true,\n"
"                \"type\": \"int\"\n"
"            }\n"
"        ],\n"
"        \"expression\": \"\",\n"
"        \"name\": \"G5x Index\",\n"
"        \"property\": \"None\"\n"
"    }\n"
"]", None))
        self.zero_c_button.setProperty(u"MDICommand", QCoreApplication.translate("dros_xyzc", u"G10 L20 P{ch[0]} C0.0", None))
        self.dro_entry_c_main.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.dro_entry_c_main.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.dro_entry_c_main.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.dro_entry_c_main.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.drolabel_machine_c.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.drolabel_machine_c.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.drolabel_machine_c.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.drolabel_machine_c.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.dro_dtg_c.setProperty(u"inchFormat", QCoreApplication.translate("dros_xyzc", u"%9.4f", None))
        self.dro_dtg_c.setProperty(u"millimeterFormat", QCoreApplication.translate("dros_xyzc", u"%10.3f", None))
        self.dro_dtg_c.setProperty(u"degreeFormat", QCoreApplication.translate("dros_xyzc", u"%10.2f", None))
        self.dro_dtg_c.setProperty(u"styleSet", QCoreApplication.translate("dros_xyzc", u"dataField17", None))
        self.ref_c_button_2.setText(QCoreApplication.translate("dros_xyzc", u"REF C", None))
        self.ref_c_button_2.setProperty(u"rules", QCoreApplication.translate("dros_xyzc", u"[{\"name\": \"home_inhibit\", \"property\": \"Enable\", \"expression\": \"not (ch[0] or ch[1] or ch[2] or ch[3])\", \"channels\": [{\"url\": \"status:joint.0.homing\", \"trigger\": true}, {\"url\": \"status:joint.1.homing\", \"trigger\": true}, {\"url\": \"status:joint.2.homing\", \"trigger\": true}, {\"url\": \"status:joint.3.homing\", \"trigger\": true}]}]", None))
        self.ref_c_button_2.setProperty(u"actionName", QCoreApplication.translate("dros_xyzc", u"machine.home.axis:c", None))
    # retranslateUi

