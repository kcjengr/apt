# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'template_main.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QSizePolicy, QWidget)

class Ui_user_main(object):
    def setupUi(self, user_main):
        if not user_main.objectName():
            user_main.setObjectName(u"user_main")
        user_main.resize(1645, 619)
        user_main.setMaximumSize(QSize(1645, 619))
        user_main.setProperty(u"sidebar", False)

        self.retranslateUi(user_main)

        QMetaObject.connectSlotsByName(user_main)
    # setupUi

    def retranslateUi(self, user_main):
        user_main.setWindowTitle(QCoreApplication.translate("user_main", u"USER MAIN", None))
    # retranslateUi

