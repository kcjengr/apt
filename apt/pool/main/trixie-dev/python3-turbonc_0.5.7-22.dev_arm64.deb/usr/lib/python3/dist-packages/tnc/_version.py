# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post38.dev0+a663ea3"
__version_tuple__ = (0, 5, 5, "post38", "dev0", "a663ea3")
