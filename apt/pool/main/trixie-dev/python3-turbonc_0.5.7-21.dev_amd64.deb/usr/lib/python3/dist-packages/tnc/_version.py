# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post37.dev0+03a2cf5"
__version_tuple__ = (0, 5, 5, "post37", "dev0", "03a2cf5")
