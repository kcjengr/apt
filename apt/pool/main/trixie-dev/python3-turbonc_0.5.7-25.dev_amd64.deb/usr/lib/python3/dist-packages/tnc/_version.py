# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post41.dev0+d1890e4"
__version_tuple__ = (0, 5, 5, "post41", "dev0", "d1890e4")
