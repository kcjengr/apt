# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post36.dev0+83911d3"
__version_tuple__ = (0, 5, 5, "post36", "dev0", "83911d3")
