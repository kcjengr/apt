# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QAbstractSpinBox, QApplication, QDoubleSpinBox,
    QFormLayout, QFrame, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QLayout, QListWidgetItem,
    QPushButton, QSizePolicy, QSpacerItem, QSpinBox,
    QTabWidget, QVBoxLayout, QWidget)

from monokrom.common.widgets.group_box import MkGroupBox
from monokrom.common.widgets.mdi_entry import MkMdiEntry
from monokrom.common.widgets.mk_dro.mk_dro import MonokromDroGroup
from monokrom.common.widgets.tab_widget import MkTabWidget
from qtpyvcp.widgets.button_widgets.action_button import ActionButton
from qtpyvcp.widgets.button_widgets.action_spinbox import ActionSpinBox
from qtpyvcp.widgets.button_widgets.dialog_button import DialogButton
from qtpyvcp.widgets.containers.stack import VCPStackedWidget
from qtpyvcp.widgets.display_widgets.active_gcodes_table import ActiveGcodesTable
from qtpyvcp.widgets.display_widgets.status_label import StatusLabel
from qtpyvcp.widgets.display_widgets.vtk_backplot.vtk_backplot import VTKBackPlot
from qtpyvcp.widgets.form_widgets.main_window import VCPMainWindow
from qtpyvcp.widgets.input_widgets.action_slider import ActionSlider
from qtpyvcp.widgets.input_widgets.dro_line_edit import DROLineEdit
from qtpyvcp.widgets.input_widgets.gcode_text_edit import GcodeTextEdit
from qtpyvcp.widgets.input_widgets.mdihistory_widget import MDIHistory
from qtpyvcp.widgets.input_widgets.offset_table import OffsetTable
from qtpyvcp.widgets.input_widgets.recent_file_combobox import RecentFileComboBox
from qtpyvcp.widgets.input_widgets.setting_slider import (VCPSettingsCheckBox, VCPSettingsComboBox, VCPSettingsLineEdit, VCPSettingsSlider)
from qtpyvcp.widgets.input_widgets.tool_table import ToolTable

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1024, 768)
        Form.setMinimumSize(QSize(1024, 768))
        icon = QIcon()
        icon.addFile(u"../common/icons/icon.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        Form.setWindowIcon(icon)
        self.centralwidget = QWidget(Form)
        self.centralwidget.setObjectName(u"centralwidget")
        self.horizontalLayout = QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.mainTabWidget = MkTabWidget(self.centralwidget)
        self.mainTabWidget.setObjectName(u"mainTabWidget")
        self.mainTabWidget.setTabPosition(QTabWidget.South)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.horizontalLayout_4 = QHBoxLayout(self.tab)
        self.horizontalLayout_4.setSpacing(15)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(10, 0, 10, 10)
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setSpacing(14)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.programStackedWidget = VCPStackedWidget(self.tab)
        self.programStackedWidget.setObjectName(u"programStackedWidget")
        self.page_1 = QWidget()
        self.page_1.setObjectName(u"page_1")
        self.verticalLayout_16 = QVBoxLayout(self.page_1)
        self.verticalLayout_16.setSpacing(0)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.file_frame = QFrame(self.page_1)
        self.file_frame.setObjectName(u"file_frame")
        self.file_frame.setFrameShape(QFrame.StyledPanel)
        self.file_frame.setFrameShadow(QFrame.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.file_frame)
        self.verticalLayout_8.setSpacing(2)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setSpacing(0)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_7 = QLabel(self.file_frame)
        self.label_7.setObjectName(u"label_7")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_7.sizePolicy().hasHeightForWidth())
        self.label_7.setSizePolicy(sizePolicy)

        self.horizontalLayout_6.addWidget(self.label_7)

        self.recentfilecombobox_2 = RecentFileComboBox(self.file_frame)
        self.recentfilecombobox_2.setObjectName(u"recentfilecombobox_2")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.recentfilecombobox_2.sizePolicy().hasHeightForWidth())
        self.recentfilecombobox_2.setSizePolicy(sizePolicy1)

        self.horizontalLayout_6.addWidget(self.recentfilecombobox_2)


        self.verticalLayout_8.addLayout(self.horizontalLayout_6)

        self.gcodetextedit_3 = GcodeTextEdit(self.file_frame)
        self.gcodetextedit_3.setObjectName(u"gcodetextedit_3")
        self.gcodetextedit_3.setProperty(u"currentLineBackground", QColor(40, 40, 28))
        self.gcodetextedit_3.setProperty(u"marginBackground", QColor(22, 22, 14))
        self.gcodetextedit_3.setProperty(u"marginCurrentLineBackground", QColor(33, 33, 24))

        self.verticalLayout_8.addWidget(self.gcodetextedit_3)


        self.verticalLayout_16.addWidget(self.file_frame)

        self.programStackedWidget.addWidget(self.page_1)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.verticalLayout_18 = QVBoxLayout(self.page_2)
        self.verticalLayout_18.setSpacing(0)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setContentsMargins(0, 0, 0, 0)
        self.mdi_groubox = MkGroupBox(self.page_2)
        self.mdi_groubox.setObjectName(u"mdi_groubox")
        self.verticalLayout_17 = QVBoxLayout(self.mdi_groubox)
        self.verticalLayout_17.setSpacing(0)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(0, 0, 0, 0)
        self.mdihistory = MDIHistory(self.mdi_groubox)
        self.mdihistory.setObjectName(u"mdihistory")
        self.mdihistory.setAlternatingRowColors(True)

        self.verticalLayout_17.addWidget(self.mdihistory)

        self.mkmdientry = MkMdiEntry(self.mdi_groubox)
        self.mkmdientry.setObjectName(u"mkmdientry")
        self.mkmdientry.setMinimumSize(QSize(0, 40))
        self.mkmdientry.setMaximumSize(QSize(16777215, 40))

        self.verticalLayout_17.addWidget(self.mkmdientry)


        self.verticalLayout_18.addWidget(self.mdi_groubox)

        self.programStackedWidget.addWidget(self.page_2)

        self.verticalLayout_3.addWidget(self.programStackedWidget)

        self.tabWidget_2 = MkTabWidget(self.tab)
        self.tabWidget_2.setObjectName(u"tabWidget_2")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.tabWidget_2.sizePolicy().hasHeightForWidth())
        self.tabWidget_2.setSizePolicy(sizePolicy2)
        self.tabWidget_2.setTabShape(QTabWidget.Rounded)
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.gridLayout_5 = QGridLayout(self.tab_4)
        self.gridLayout_5.setSpacing(10)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.gridLayout_5.setSizeConstraint(QLayout.SetMinimumSize)
        self.gridLayout_5.setContentsMargins(14, 14, 14, 14)
        self.actionbutton_13 = ActionButton(self.tab_4)
        self.actionbutton_13.setObjectName(u"actionbutton_13")
        self.actionbutton_13.setMinimumSize(QSize(34, 29))
        self.actionbutton_13.setFocusPolicy(Qt.NoFocus)

        self.gridLayout_5.addWidget(self.actionbutton_13, 0, 0, 1, 1)

        self.actionbutton_12 = ActionButton(self.tab_4)
        self.actionbutton_12.setObjectName(u"actionbutton_12")
        self.actionbutton_12.setMinimumSize(QSize(34, 29))
        self.actionbutton_12.setFocusPolicy(Qt.NoFocus)

        self.gridLayout_5.addWidget(self.actionbutton_12, 0, 1, 1, 1)

        self.actionbutton_11 = ActionButton(self.tab_4)
        self.actionbutton_11.setObjectName(u"actionbutton_11")
        self.actionbutton_11.setMinimumSize(QSize(34, 29))
        self.actionbutton_11.setFocusPolicy(Qt.NoFocus)

        self.gridLayout_5.addWidget(self.actionbutton_11, 0, 2, 1, 1)

        self.actionbutton_14 = ActionButton(self.tab_4)
        self.actionbutton_14.setObjectName(u"actionbutton_14")
        self.actionbutton_14.setMinimumSize(QSize(34, 29))
        self.actionbutton_14.setFocusPolicy(Qt.NoFocus)

        self.gridLayout_5.addWidget(self.actionbutton_14, 0, 3, 1, 1)

        self.compositedrogroup_2 = MonokromDroGroup(self.tab_4)
        self.compositedrogroup_2.setObjectName(u"compositedrogroup_2")
        self.compositedrogroup_2.setMaximumSize(QSize(10000, 200))

        self.gridLayout_5.addWidget(self.compositedrogroup_2, 1, 0, 1, 4)

        self.actionbutton_15 = ActionButton(self.tab_4)
        self.actionbutton_15.setObjectName(u"actionbutton_15")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.actionbutton_15.sizePolicy().hasHeightForWidth())
        self.actionbutton_15.setSizePolicy(sizePolicy3)
        self.actionbutton_15.setMaximumSize(QSize(44, 16777215))
        self.actionbutton_15.setStyleSheet(u"max-width: 40px;")
        icon1 = QIcon()
        icon1.addFile(u"../common/icons/homed.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        icon1.addFile(u"../common/icons/homed.png", QSize(), QIcon.Mode.Disabled, QIcon.State.Off)
        self.actionbutton_15.setIcon(icon1)
        self.actionbutton_15.setIconSize(QSize(20, 20))

        self.gridLayout_5.addWidget(self.actionbutton_15, 1, 4, 1, 1)

        icon2 = QIcon()
        icon2.addFile(u"../common/icons/crosshairs-solid.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        icon2.addFile(u"../common/icons/crosshairs-solid.bg.png", QSize(), QIcon.Mode.Normal, QIcon.State.On)
        self.tabWidget_2.addTab(self.tab_4, icon2, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        icon3 = QIcon()
        icon3.addFile(u"../common/icons/crosshairs-solid.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        icon3.addFile(u"../common/icons/crosshairs-solid.bg.png", QSize(), QIcon.Mode.Normal, QIcon.State.On)
        icon3.addFile(u"icons/crosshairs-solid.on.png", QSize(), QIcon.Mode.Active, QIcon.State.Off)
        icon3.addFile(u"icons/crosshairs-solid.on.png", QSize(), QIcon.Mode.Selected, QIcon.State.Off)
        self.tabWidget_2.addTab(self.tab_3, icon3, "")

        self.verticalLayout_3.addWidget(self.tabWidget_2)


        self.horizontalLayout_4.addLayout(self.verticalLayout_3)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setSpacing(14)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.groupbox_5 = MkGroupBox(self.tab)
        self.groupbox_5.setObjectName(u"groupbox_5")
        self.gridLayout = QGridLayout(self.groupbox_5)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(14, 14, 14, 14)
        self.dialogbutton = DialogButton(self.groupbox_5)
        self.dialogbutton.setObjectName(u"dialogbutton")
        self.dialogbutton.setFocusPolicy(Qt.NoFocus)

        self.gridLayout.addWidget(self.dialogbutton, 0, 0, 1, 1)

        self.dialogbutton_2 = DialogButton(self.groupbox_5)
        self.dialogbutton_2.setObjectName(u"dialogbutton_2")
        self.dialogbutton_2.setFocusPolicy(Qt.NoFocus)

        self.gridLayout.addWidget(self.dialogbutton_2, 0, 1, 1, 1)

        self.actionbutton_2 = ActionButton(self.groupbox_5)
        self.actionbutton_2.setObjectName(u"actionbutton_2")
        self.actionbutton_2.setFocusPolicy(Qt.NoFocus)

        self.gridLayout.addWidget(self.actionbutton_2, 1, 0, 1, 1)

        self.actionbutton_3 = ActionButton(self.groupbox_5)
        self.actionbutton_3.setObjectName(u"actionbutton_3")
        self.actionbutton_3.setFocusPolicy(Qt.NoFocus)

        self.gridLayout.addWidget(self.actionbutton_3, 1, 1, 1, 1)


        self.verticalLayout_2.addWidget(self.groupbox_5)

        self.groupbox_7 = MkGroupBox(self.tab)
        self.groupbox_7.setObjectName(u"groupbox_7")
        self.verticalLayout_14 = QVBoxLayout(self.groupbox_7)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(14, 14, 14, 14)
        self.actionspinbox = ActionSpinBox(self.groupbox_7)
        self.actionspinbox.setObjectName(u"actionspinbox")
        self.actionspinbox.setAlignment(Qt.AlignCenter)
        self.actionspinbox.setButtonSymbols(QAbstractSpinBox.PlusMinus)
        self.actionspinbox.setCorrectionMode(QAbstractSpinBox.CorrectToPreviousValue)
        self.actionspinbox.setMaximum(10000)
        self.actionspinbox.setSingleStep(100)

        self.verticalLayout_14.addWidget(self.actionspinbox)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.actionbutton_22 = ActionButton(self.groupbox_7)
        self.actionbutton_22.setObjectName(u"actionbutton_22")
        self.actionbutton_22.setFocusPolicy(Qt.NoFocus)

        self.horizontalLayout_8.addWidget(self.actionbutton_22)

        self.actionbutton_25 = ActionButton(self.groupbox_7)
        self.actionbutton_25.setObjectName(u"actionbutton_25")
        self.actionbutton_25.setFocusPolicy(Qt.NoFocus)

        self.horizontalLayout_8.addWidget(self.actionbutton_25)

        self.actionbutton_24 = ActionButton(self.groupbox_7)
        self.actionbutton_24.setObjectName(u"actionbutton_24")
        self.actionbutton_24.setFocusPolicy(Qt.NoFocus)

        self.horizontalLayout_8.addWidget(self.actionbutton_24)


        self.verticalLayout_14.addLayout(self.horizontalLayout_8)


        self.verticalLayout_2.addWidget(self.groupbox_7)

        self.groupbox_8 = MkGroupBox(self.tab)
        self.groupbox_8.setObjectName(u"groupbox_8")
        self.verticalLayout_19 = QVBoxLayout(self.groupbox_8)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(14, 14, 14, 14)
        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.actionbutton_28 = ActionButton(self.groupbox_8)
        self.actionbutton_28.setObjectName(u"actionbutton_28")
        self.actionbutton_28.setFocusPolicy(Qt.NoFocus)

        self.horizontalLayout_9.addWidget(self.actionbutton_28)

        self.actionbutton_30 = ActionButton(self.groupbox_8)
        self.actionbutton_30.setObjectName(u"actionbutton_30")
        self.actionbutton_30.setFocusPolicy(Qt.NoFocus)

        self.horizontalLayout_9.addWidget(self.actionbutton_30)


        self.verticalLayout_19.addLayout(self.horizontalLayout_9)


        self.verticalLayout_2.addWidget(self.groupbox_8)

        self.groupbox_3 = MkGroupBox(self.tab)
        self.groupbox_3.setObjectName(u"groupbox_3")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.groupbox_3.sizePolicy().hasHeightForWidth())
        self.groupbox_3.setSizePolicy(sizePolicy4)
        self.verticalLayout_11 = QVBoxLayout(self.groupbox_3)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(6, 6, 6, 6)
        self.gridLayout_2 = QGridLayout()
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setContentsMargins(-1, 10, -1, -1)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.statuslabel_4 = StatusLabel(self.groupbox_3)
        self.statuslabel_4.setObjectName(u"statuslabel_4")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.statuslabel_4.sizePolicy().hasHeightForWidth())
        self.statuslabel_4.setSizePolicy(sizePolicy5)
        self.statuslabel_4.setMinimumSize(QSize(50, 0))
        font = QFont()
        font.setFamilies([u"DSEG7 Classic"])
        font.setBold(True)
        font.setItalic(True)
        self.statuslabel_4.setFont(font)
        self.statuslabel_4.setStyleSheet(u"font: bold italic 10pt \"DSEG7 Classic\";")
        self.statuslabel_4.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.statuslabel_4)

        self.label_8 = QLabel(self.groupbox_3)
        self.label_8.setObjectName(u"label_8")
        font1 = QFont()
        font1.setFamilies([u"Sans"])
        font1.setBold(True)
        font1.setItalic(False)
        self.label_8.setFont(font1)
        self.label_8.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.label_8)


        self.gridLayout_2.addLayout(self.verticalLayout, 2, 4, 1, 1)

        self.verticalLayout_9 = QVBoxLayout()
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.statuslabel_6 = StatusLabel(self.groupbox_3)
        self.statuslabel_6.setObjectName(u"statuslabel_6")
        sizePolicy5.setHeightForWidth(self.statuslabel_6.sizePolicy().hasHeightForWidth())
        self.statuslabel_6.setSizePolicy(sizePolicy5)
        self.statuslabel_6.setMinimumSize(QSize(50, 0))
        font2 = QFont()
        font2.setFamilies([u"DSEG7 Classic"])
        font2.setPointSize(10)
        font2.setBold(True)
        font2.setItalic(True)
        self.statuslabel_6.setFont(font2)
        self.statuslabel_6.setStyleSheet(u"font: bold italic 10pt \"DSEG7 Classic\";")
        self.statuslabel_6.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.statuslabel_6)

        self.label_10 = QLabel(self.groupbox_3)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setFont(font1)
        self.label_10.setAlignment(Qt.AlignCenter)

        self.verticalLayout_9.addWidget(self.label_10)


        self.gridLayout_2.addLayout(self.verticalLayout_9, 2, 1, 1, 1)

        self.settings_slider = VCPSettingsSlider(self.groupbox_3)
        self.settings_slider.setObjectName(u"settings_slider")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.settings_slider.sizePolicy().hasHeightForWidth())
        self.settings_slider.setSizePolicy(sizePolicy6)

        self.gridLayout_2.addWidget(self.settings_slider, 0, 1, 1, 1)

        self.actionslider = ActionSlider(self.groupbox_3)
        self.actionslider.setObjectName(u"actionslider")
        sizePolicy6.setHeightForWidth(self.actionslider.sizePolicy().hasHeightForWidth())
        self.actionslider.setSizePolicy(sizePolicy6)

        self.gridLayout_2.addWidget(self.actionslider, 0, 4, 1, 1)

        self.actionslider_2 = ActionSlider(self.groupbox_3)
        self.actionslider_2.setObjectName(u"actionslider_2")
        self.actionslider_2.setEnabled(True)
        sizePolicy6.setHeightForWidth(self.actionslider_2.sizePolicy().hasHeightForWidth())
        self.actionslider_2.setSizePolicy(sizePolicy6)

        self.gridLayout_2.addWidget(self.actionslider_2, 0, 0, 1, 1)

        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.statuslabel_5 = StatusLabel(self.groupbox_3)
        self.statuslabel_5.setObjectName(u"statuslabel_5")
        sizePolicy5.setHeightForWidth(self.statuslabel_5.sizePolicy().hasHeightForWidth())
        self.statuslabel_5.setSizePolicy(sizePolicy5)
        self.statuslabel_5.setMinimumSize(QSize(50, 0))
        self.statuslabel_5.setFont(font2)
        self.statuslabel_5.setStyleSheet(u"font: bold italic 10pt \"DSEG7 Classic\";")
        self.statuslabel_5.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.statuslabel_5)

        self.label_9 = QLabel(self.groupbox_3)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font1)
        self.label_9.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.label_9)


        self.gridLayout_2.addLayout(self.verticalLayout_7, 2, 0, 1, 1)


        self.verticalLayout_11.addLayout(self.gridLayout_2)


        self.verticalLayout_2.addWidget(self.groupbox_3)


        self.horizontalLayout_4.addLayout(self.verticalLayout_2)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setSpacing(14)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.tabWidget_3 = MkTabWidget(self.tab)
        self.tabWidget_3.setObjectName(u"tabWidget_3")
        self.tab_7 = QWidget()
        self.tab_7.setObjectName(u"tab_7")
        self.verticalLayout_13 = QVBoxLayout(self.tab_7)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.vtkbackplot = VTKBackPlot(self.tab_7)
        self.vtkbackplot.setObjectName(u"vtkbackplot")
        self.vtkbackplot.setProperty(u"backgroundColor", QColor(22, 22, 14))
        self.vtkbackplot.setProperty(u"enableProgramTicks", False)
        self.verticalLayout_15 = QVBoxLayout(self.vtkbackplot)
        self.verticalLayout_15.setSpacing(0)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(0, 4, 0, 0)
        self.gridLayout_3 = QGridLayout()
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.gridLayout_3.setVerticalSpacing(0)
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_3.addItem(self.horizontalSpacer, 0, 1, 1, 1)

        self.statuslabel_3 = StatusLabel(self.vtkbackplot)
        self.statuslabel_3.setObjectName(u"statuslabel_3")
        sizePolicy.setHeightForWidth(self.statuslabel_3.sizePolicy().hasHeightForWidth())
        self.statuslabel_3.setSizePolicy(sizePolicy)
        font3 = QFont()
        font3.setFamilies([u"Sans"])
        font3.setBold(False)
        font3.setItalic(False)
        self.statuslabel_3.setFont(font3)

        self.gridLayout_3.addWidget(self.statuslabel_3, 0, 2, 1, 1)

        self.statuslabel_7 = StatusLabel(self.vtkbackplot)
        self.statuslabel_7.setObjectName(u"statuslabel_7")
        sizePolicy.setHeightForWidth(self.statuslabel_7.sizePolicy().hasHeightForWidth())
        self.statuslabel_7.setSizePolicy(sizePolicy)
        self.statuslabel_7.setFont(font3)

        self.gridLayout_3.addWidget(self.statuslabel_7, 1, 2, 1, 1)

        self.statuslabel = StatusLabel(self.vtkbackplot)
        self.statuslabel.setObjectName(u"statuslabel")
        sizePolicy.setHeightForWidth(self.statuslabel.sizePolicy().hasHeightForWidth())
        self.statuslabel.setSizePolicy(sizePolicy)
        self.statuslabel.setFont(font3)

        self.gridLayout_3.addWidget(self.statuslabel, 0, 0, 1, 1)

        self.statuslabel_2 = StatusLabel(self.vtkbackplot)
        self.statuslabel_2.setObjectName(u"statuslabel_2")
        sizePolicy.setHeightForWidth(self.statuslabel_2.sizePolicy().hasHeightForWidth())
        self.statuslabel_2.setSizePolicy(sizePolicy)
        self.statuslabel_2.setFont(font3)

        self.gridLayout_3.addWidget(self.statuslabel_2, 1, 0, 1, 1)


        self.verticalLayout_15.addLayout(self.gridLayout_3)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_15.addItem(self.verticalSpacer)

        self.statuslabel_8 = StatusLabel(self.vtkbackplot)
        self.statuslabel_8.setObjectName(u"statuslabel_8")
        sizePolicy.setHeightForWidth(self.statuslabel_8.sizePolicy().hasHeightForWidth())
        self.statuslabel_8.setSizePolicy(sizePolicy)
        self.statuslabel_8.setFont(font3)

        self.verticalLayout_15.addWidget(self.statuslabel_8)


        self.verticalLayout_13.addWidget(self.vtkbackplot)

        self.tabWidget_3.addTab(self.tab_7, "")

        self.verticalLayout_4.addWidget(self.tabWidget_3)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setSpacing(14)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.mainModeTabWidget = MkTabWidget(self.tab)
        self.mainModeTabWidget.setObjectName(u"mainModeTabWidget")
        sizePolicy2.setHeightForWidth(self.mainModeTabWidget.sizePolicy().hasHeightForWidth())
        self.mainModeTabWidget.setSizePolicy(sizePolicy2)
        self.mainModeTabWidget.setMinimumSize(QSize(0, 300))
        self.mainModeTabWidget.setMaximumSize(QSize(16777215, 300))
        self.tab_14 = QWidget()
        self.tab_14.setObjectName(u"tab_14")
        self.pushButton = QPushButton(self.tab_14)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(10, 70, 91, 29))
        self.pushButton.setFocusPolicy(Qt.NoFocus)
        self.pushButton_2 = QPushButton(self.tab_14)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(10, 110, 91, 29))
        self.pushButton_2.setFocusPolicy(Qt.NoFocus)
        self.pushButton_3 = QPushButton(self.tab_14)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(10, 150, 91, 29))
        self.pushButton_3.setFocusPolicy(Qt.NoFocus)
        self.actionbutton_10 = ActionButton(self.tab_14)
        self.actionbutton_10.setObjectName(u"actionbutton_10")
        self.actionbutton_10.setGeometry(QRect(10, 20, 91, 41))
        self.actionbutton_10.setFocusPolicy(Qt.NoFocus)
        self.actionbutton_10.setCheckable(True)
        self.statuslabel_9 = StatusLabel(self.tab_14)
        self.statuslabel_9.setObjectName(u"statuslabel_9")
        self.statuslabel_9.setGeometry(QRect(160, 50, 61, 21))
        self.statuslabel_9.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.layoutWidget = QWidget(self.tab_14)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(240, 10, 121, 214))
        self.verticalLayout_20 = QVBoxLayout(self.layoutWidget)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.verticalLayout_20.setContentsMargins(0, 0, 0, 0)
        self.actionbutton_27 = ActionButton(self.layoutWidget)
        self.actionbutton_27.setObjectName(u"actionbutton_27")
        self.actionbutton_27.setMinimumSize(QSize(34, 29))
        self.actionbutton_27.setStyleSheet(u"background: green;")

        self.verticalLayout_20.addWidget(self.actionbutton_27)

        self.actionbutton_26 = ActionButton(self.layoutWidget)
        self.actionbutton_26.setObjectName(u"actionbutton_26")
        sizePolicy6.setHeightForWidth(self.actionbutton_26.sizePolicy().hasHeightForWidth())
        self.actionbutton_26.setSizePolicy(sizePolicy6)
        self.actionbutton_26.setMinimumSize(QSize(34, 29))
        self.actionbutton_26.setStyleSheet(u"background: red;")

        self.verticalLayout_20.addWidget(self.actionbutton_26)

        self.actionbutton_18 = ActionButton(self.layoutWidget)
        self.actionbutton_18.setObjectName(u"actionbutton_18")
        self.actionbutton_18.setMinimumSize(QSize(34, 29))
        self.actionbutton_18.setStyleSheet(u"background: green;")

        self.verticalLayout_20.addWidget(self.actionbutton_18)

        self.mainModeTabWidget.addTab(self.tab_14, "")
        self.tab_11 = QWidget()
        self.tab_11.setObjectName(u"tab_11")
        self.mainModeTabWidget.addTab(self.tab_11, "")
        self.tab_10 = QWidget()
        self.tab_10.setObjectName(u"tab_10")
        self.actionbutton_5 = ActionButton(self.tab_10)
        self.actionbutton_5.setObjectName(u"actionbutton_5")
        self.actionbutton_5.setGeometry(QRect(260, 20, 91, 91))
        self.actionbutton_5.setStyleSheet(u"background: green;")
        self.actionbutton_6 = ActionButton(self.tab_10)
        self.actionbutton_6.setObjectName(u"actionbutton_6")
        self.actionbutton_6.setGeometry(QRect(260, 120, 91, 41))
        self.actionbutton_7 = ActionButton(self.tab_10)
        self.actionbutton_7.setObjectName(u"actionbutton_7")
        self.actionbutton_7.setGeometry(QRect(10, 110, 71, 36))
        self.actionbutton_7.setCheckable(True)
        self.actionbutton_8 = ActionButton(self.tab_10)
        self.actionbutton_8.setObjectName(u"actionbutton_8")
        self.actionbutton_8.setGeometry(QRect(260, 170, 91, 81))
        self.actionbutton_8.setStyleSheet(u"background: red;")
        self.actionbutton = ActionButton(self.tab_10)
        self.actionbutton.setObjectName(u"actionbutton")
        self.actionbutton.setGeometry(QRect(10, 10, 81, 29))
        self.actionbutton.setCheckable(True)
        self.actionbutton_4 = ActionButton(self.tab_10)
        self.actionbutton_4.setObjectName(u"actionbutton_4")
        self.actionbutton_4.setGeometry(QRect(10, 50, 81, 29))
        self.actionbutton_4.setCheckable(True)
        self.actionbutton_9 = ActionButton(self.tab_10)
        self.actionbutton_9.setObjectName(u"actionbutton_9")
        self.actionbutton_9.setGeometry(QRect(130, 80, 80, 29))
        self.actionbutton_19 = ActionButton(self.tab_10)
        self.actionbutton_19.setObjectName(u"actionbutton_19")
        self.actionbutton_19.setGeometry(QRect(130, 110, 80, 29))
        self.actionbutton_23 = ActionButton(self.tab_10)
        self.actionbutton_23.setObjectName(u"actionbutton_23")
        self.actionbutton_23.setGeometry(QRect(130, 200, 80, 29))
        self.actionbutton_20 = ActionButton(self.tab_10)
        self.actionbutton_20.setObjectName(u"actionbutton_20")
        self.actionbutton_20.setGeometry(QRect(130, 170, 80, 29))
        self.actionbutton_21 = ActionButton(self.tab_10)
        self.actionbutton_21.setObjectName(u"actionbutton_21")
        self.actionbutton_21.setGeometry(QRect(130, 140, 80, 29))
        self.mainModeTabWidget.addTab(self.tab_10, "")

        self.horizontalLayout_3.addWidget(self.mainModeTabWidget)


        self.verticalLayout_4.addLayout(self.horizontalLayout_3)


        self.horizontalLayout_4.addLayout(self.verticalLayout_4)

        self.horizontalLayout_4.setStretch(0, 4)
        self.horizontalLayout_4.setStretch(1, 1)
        self.horizontalLayout_4.setStretch(2, 6)
        self.mainTabWidget.addTab(self.tab, "")
        self.tab_6 = QWidget()
        self.tab_6.setObjectName(u"tab_6")
        self.horizontalLayout_2 = QHBoxLayout(self.tab_6)
        self.horizontalLayout_2.setSpacing(15)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(10, 0, 10, 10)
        self.tabWidget = MkTabWidget(self.tab_6)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tab_8 = QWidget()
        self.tab_8.setObjectName(u"tab_8")
        self.groupbox = MkGroupBox(self.tab_8)
        self.groupbox.setObjectName(u"groupbox")
        self.groupbox.setGeometry(QRect(570, 10, 401, 631))
        self.verticalLayout_6 = QVBoxLayout(self.groupbox)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.activegcodestable = ActiveGcodesTable(self.groupbox)
        self.activegcodestable.setObjectName(u"activegcodestable")
        self.activegcodestable.setStyleSheet(u"border-radius: 6px;")

        self.verticalLayout_6.addWidget(self.activegcodestable)

        self.groupbox_2 = MkGroupBox(self.tab_8)
        self.groupbox_2.setObjectName(u"groupbox_2")
        self.groupbox_2.setGeometry(QRect(20, 20, 391, 391))
        self.verticalLayout_10 = QVBoxLayout(self.groupbox_2)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.offset_table = OffsetTable(self.groupbox_2)
        self.offset_table.setObjectName(u"offset_table")
        self.offset_table.setStyleSheet(u"QTableView {border-radius: 6px}")
        self.offset_table.setAlternatingRowColors(True)
        self.offset_table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.offset_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.offset_table.setGridStyle(Qt.SolidLine)
        self.offset_table.setProperty(u"confirmActions", True)
        self.offset_table.setProperty(u"currentRowColor", QColor(78, 154, 6))
        self.offset_table.horizontalHeader().setStretchLastSection(True)

        self.verticalLayout_10.addWidget(self.offset_table)

        self.line_2 = QFrame(self.groupbox_2)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setFrameShape(QFrame.Shape.HLine)
        self.line_2.setFrameShadow(QFrame.Shadow.Sunken)

        self.verticalLayout_10.addWidget(self.line_2)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setSpacing(10)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(14, 14, 14, 14)
        self.pushButton_7 = QPushButton(self.groupbox_2)
        self.pushButton_7.setObjectName(u"pushButton_7")

        self.horizontalLayout_7.addWidget(self.pushButton_7)

        self.pushButton_6 = QPushButton(self.groupbox_2)
        self.pushButton_6.setObjectName(u"pushButton_6")

        self.horizontalLayout_7.addWidget(self.pushButton_6)

        self.pushButton_5 = QPushButton(self.groupbox_2)
        self.pushButton_5.setObjectName(u"pushButton_5")

        self.horizontalLayout_7.addWidget(self.pushButton_5)


        self.verticalLayout_10.addLayout(self.horizontalLayout_7)

        self.frame = QFrame(self.tab_8)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(50, 470, 441, 80))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.actionbutton_16 = ActionButton(self.frame)
        self.actionbutton_16.setObjectName(u"actionbutton_16")
        self.actionbutton_16.setGeometry(QRect(0, 0, 41, 81))
        self.actionbutton_17 = ActionButton(self.frame)
        self.actionbutton_17.setObjectName(u"actionbutton_17")
        self.actionbutton_17.setGeometry(QRect(400, 0, 41, 81))
        self.dro_entry = DROLineEdit(self.frame)
        self.dro_entry.setObjectName(u"dro_entry")
        self.dro_entry.setGeometry(QRect(110, 0, 291, 81))
        self.label_11 = QLabel(self.frame)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(40, 10, 71, 61))
        self.tabWidget.addTab(self.tab_8, "")
        self.tab_9 = QWidget()
        self.tab_9.setObjectName(u"tab_9")
        self.groupbox_6 = MkGroupBox(self.tab_9)
        self.groupbox_6.setObjectName(u"groupbox_6")
        self.groupbox_6.setGeometry(QRect(10, 20, 981, 461))
        self.verticalLayout_12 = QVBoxLayout(self.groupbox_6)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.tooltable = ToolTable(self.groupbox_6)
        self.tooltable.setObjectName(u"tooltable")

        self.verticalLayout_12.addWidget(self.tooltable)

        self.tabWidget.addTab(self.tab_9, "")
        self.tab_12 = QWidget()
        self.tab_12.setObjectName(u"tab_12")
        self.tabWidget.addTab(self.tab_12, "")

        self.horizontalLayout_2.addWidget(self.tabWidget)

        self.horizontalLayout_2.setStretch(0, 4)
        self.mainTabWidget.addTab(self.tab_6, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.tabWidget_6 = MkTabWidget(self.tab_2)
        self.tabWidget_6.setObjectName(u"tabWidget_6")
        self.tabWidget_6.setGeometry(QRect(20, 120, 291, 221))
        self.tabWidget_6Page1 = QWidget()
        self.tabWidget_6Page1.setObjectName(u"tabWidget_6Page1")
        self.formLayout = QFormLayout(self.tabWidget_6Page1)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setLabelAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.formLayout.setHorizontalSpacing(6)
        self.label = QLabel(self.tabWidget_6Page1)
        self.label.setObjectName(u"label")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label)

        self.settings_lineedit = VCPSettingsLineEdit(self.tabWidget_6Page1)
        self.settings_lineedit.setObjectName(u"settings_lineedit")

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.settings_lineedit)

        self.label_2 = QLabel(self.tabWidget_6Page1)
        self.label_2.setObjectName(u"label_2")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_2)

        self.settings_lineedit_2 = VCPSettingsLineEdit(self.tabWidget_6Page1)
        self.settings_lineedit_2.setObjectName(u"settings_lineedit_2")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.settings_lineedit_2)

        self.label_3 = QLabel(self.tabWidget_6Page1)
        self.label_3.setObjectName(u"label_3")

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.label_3)

        self.settings_lineedit_3 = VCPSettingsLineEdit(self.tabWidget_6Page1)
        self.settings_lineedit_3.setObjectName(u"settings_lineedit_3")

        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.settings_lineedit_3)

        self.label_4 = QLabel(self.tabWidget_6Page1)
        self.label_4.setObjectName(u"label_4")

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.label_4)

        self.label_5 = QLabel(self.tabWidget_6Page1)
        self.label_5.setObjectName(u"label_5")

        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.label_5)

        self.settingscombobox = VCPSettingsComboBox(self.tabWidget_6Page1)
        self.settingscombobox.setObjectName(u"settingscombobox")

        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.settingscombobox)

        self.settingscombobox_2 = VCPSettingsComboBox(self.tabWidget_6Page1)
        self.settingscombobox_2.setObjectName(u"settingscombobox_2")

        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.settingscombobox_2)

        self.tabWidget_6.addTab(self.tabWidget_6Page1, "")
        self.tabWidget_7 = MkTabWidget(self.tab_2)
        self.tabWidget_7.setObjectName(u"tabWidget_7")
        self.tabWidget_7.setGeometry(QRect(20, 20, 291, 91))
        self.tabWidget_7Page1 = QWidget()
        self.tabWidget_7Page1.setObjectName(u"tabWidget_7Page1")
        self.verticalLayout_5 = QVBoxLayout(self.tabWidget_7Page1)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.settings_checkbox = VCPSettingsCheckBox(self.tabWidget_7Page1)
        self.settings_checkbox.setObjectName(u"settings_checkbox")

        self.verticalLayout_5.addWidget(self.settings_checkbox)

        self.tabWidget_7.addTab(self.tabWidget_7Page1, "")
        self.spinBox = QSpinBox(self.tab_2)
        self.spinBox.setObjectName(u"spinBox")
        self.spinBox.setGeometry(QRect(620, 110, 171, 29))
        self.spinBox.setAlignment(Qt.AlignCenter)
        self.spinBox.setButtonSymbols(QAbstractSpinBox.PlusMinus)
        self.doubleSpinBox = QDoubleSpinBox(self.tab_2)
        self.doubleSpinBox.setObjectName(u"doubleSpinBox")
        self.doubleSpinBox.setGeometry(QRect(620, 160, 171, 29))
        self.doubleSpinBox.setAlignment(Qt.AlignCenter)
        self.doubleSpinBox.setButtonSymbols(QAbstractSpinBox.PlusMinus)
        self.doubleSpinBox_2 = QDoubleSpinBox(self.tab_2)
        self.doubleSpinBox_2.setObjectName(u"doubleSpinBox_2")
        self.doubleSpinBox_2.setGeometry(QRect(620, 210, 171, 29))
        self.doubleSpinBox_2.setAlignment(Qt.AlignCenter)
        self.groupbox_4 = MkGroupBox(self.tab_2)
        self.groupbox_4.setObjectName(u"groupbox_4")
        self.groupbox_4.setGeometry(QRect(20, 360, 291, 241))
        self.groupbox_4.setCheckable(True)
        self.groupbox_4.setChecked(True)
        self.pushButton_4 = QPushButton(self.groupbox_4)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setGeometry(QRect(20, 50, 83, 29))
        self.mainTabWidget.addTab(self.tab_2, "")
        self.tab_5 = QWidget()
        self.tab_5.setObjectName(u"tab_5")
        self.mainTabWidget.addTab(self.tab_5, "")

        self.horizontalLayout.addWidget(self.mainTabWidget)

        Form.setCentralWidget(self.centralwidget)

        self.retranslateUi(Form)
        self.pushButton_7.clicked.connect(self.offset_table.clearOffsetTable)
        self.pushButton_6.clicked.connect(self.offset_table.loadOffsetTable)
        self.pushButton_5.clicked.connect(self.offset_table.saveOffsetTable)

        self.mainTabWidget.setCurrentIndex(3)
        self.programStackedWidget.setCurrentIndex(0)
        self.tabWidget_2.setCurrentIndex(0)
        self.tabWidget_3.setCurrentIndex(0)
        self.mainModeTabWidget.setCurrentIndex(0)
        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.file_frame.setProperty(u"styleClass", QCoreApplication.translate("Form", u"comboFrame", None))
        self.label_7.setText(QCoreApplication.translate("Form", u"OPEN:", None))
        self.label_7.setProperty(u"styleClass", QCoreApplication.translate("Form", u"comboFrame", None))
        self.mdi_groubox.setTitle(QCoreApplication.translate("Form", u"MDI", None))
        self.actionbutton_13.setText(QCoreApplication.translate("Form", u"G54", None))
        self.actionbutton_13.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G54", None))
        self.actionbutton_12.setText(QCoreApplication.translate("Form", u"G55", None))
        self.actionbutton_12.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G55", None))
        self.actionbutton_11.setText(QCoreApplication.translate("Form", u"G56", None))
        self.actionbutton_11.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G56", None))
        self.actionbutton_14.setText(QCoreApplication.translate("Form", u"G57", None))
        self.actionbutton_14.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.set-work-coord:G57", None))
        self.actionbutton_15.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.home.all", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_4), QCoreApplication.translate("Form", u"WORK", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.tab_3), QCoreApplication.translate("Form", u"MACHINE", None))
        self.groupbox_5.setTitle(QCoreApplication.translate("Form", u"PROGRAM", None))
        self.dialogbutton.setText(QCoreApplication.translate("Form", u"OPEN", None))
        self.dialogbutton.setProperty(u"dialogName", QCoreApplication.translate("Form", u"open_file", None))
        self.dialogbutton_2.setText(QCoreApplication.translate("Form", u"RECENT", None))
        self.dialogbutton_2.setProperty(u"dialogName", QCoreApplication.translate("Form", u"recent_files", None))
        self.actionbutton_2.setText(QCoreApplication.translate("Form", u"EDIT", None))
        self.actionbutton_3.setText(QCoreApplication.translate("Form", u"CLEAR", None))
        self.groupbox_7.setTitle(QCoreApplication.translate("Form", u"SPINDLE", None))
        self.actionbutton_22.setText(QCoreApplication.translate("Form", u"CCW", None))
        self.actionbutton_25.setText(QCoreApplication.translate("Form", u"OFF", None))
        self.actionbutton_24.setText(QCoreApplication.translate("Form", u"CW", None))
        self.groupbox_8.setTitle(QCoreApplication.translate("Form", u"COOLING", None))
        self.actionbutton_28.setText(QCoreApplication.translate("Form", u"MIST", None))
        self.actionbutton_30.setText(QCoreApplication.translate("Form", u"FLOOD", None))
        self.groupbox_3.setTitle(QCoreApplication.translate("Form", u"OVERRIDES", None))
        self.statuslabel_4.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:rapidrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:.0%}\\\".format(ch[0])\", \"name\": \"New Rule\"}]", None))
        self.label_8.setText(QCoreApplication.translate("Form", u"RAPID", None))
        self.statuslabel_6.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:spindle.0.override\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:.0%}\\\".format(ch[0])\", \"name\": \"New Rule\"}]", None))
        self.label_10.setText(QCoreApplication.translate("Form", u"SPEED", None))
        self.settings_slider.setProperty(u"settingName", QCoreApplication.translate("Form", u"spindle.override", None))
        self.actionslider.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.rapid-override.set", None))
        self.actionslider_2.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.feed-override.set", None))
        self.statuslabel_5.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:feedrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"{:.0%}\\\".format(ch[0])\", \"name\": \"New Rule\"}]", None))
        self.label_9.setText(QCoreApplication.translate("Form", u"FEED", None))
        self.statuslabel_3.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:settings?speed\", \"trigger\": true}, {\"url\": \"status:spindle.0.override\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"S: {:.0f}\\\".format(ch[0] * ch[1])\", \"name\": \"New Rule\"}]", None))
        self.statuslabel_7.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:settings?feed\", \"trigger\": true}, {\"url\": \"status:feedrate\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"F: {:.0f}\\\".format(ch[0] * ch[1])\", \"name\": \"New Rule\"}]", None))
        self.statuslabel.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?t\", \"trigger\": true}, {\"url\": \"tooltable:current_tool?r\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"T{}: {}\\\".format(ch[0], ch[1])\", \"name\": \"New Rule\"}]", None))
        self.statuslabel_2.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"tooltable:current_tool?d\", \"trigger\": true}, {\"url\": \"tooltable:current_tool?z\", \"trigger\": false}], \"property\": \"Text\", \"expression\": \"\\\"Dia: {:0.3f}   Z-offset: {:0.3f}\\\".format(ch[0], ch[1])\", \"name\": \"New Rule\"}]", None))
        self.statuslabel_8.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:velocity\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"\\\"Vel: {:0.1f}\\\".format(ch[0])\", \"name\": \"New Rule\"}]", None))
        self.tabWidget_3.setTabText(self.tabWidget_3.indexOf(self.tab_7), QCoreApplication.translate("Form", u"TOOL PATH", None))
        self.pushButton.setText(QCoreApplication.translate("Form", u"JOG", None))
        self.pushButton_2.setText(QCoreApplication.translate("Form", u"PROBE", None))
        self.pushButton_3.setText(QCoreApplication.translate("Form", u"TOUCH OFF", None))
        self.actionbutton_10.setText(QCoreApplication.translate("Form", u"MACHINE\n"
"POWER", None))
        self.actionbutton_10.setProperty(u"actionName", QCoreApplication.translate("Form", u"machine.power.toggle", None))
        self.statuslabel_9.setText(QCoreApplication.translate("Form", u"300.0", None))
        self.statuslabel_9.setProperty(u"rules", QCoreApplication.translate("Form", u"[{\"channels\": [{\"url\": \"status:settings?speed\", \"trigger\": true}], \"property\": \"Text\", \"expression\": \"str( ch[0] )\", \"name\": \"S Word\"}]", None))
        self.statuslabel_9.setProperty(u"format", QCoreApplication.translate("Form", u"{:.0f}", None))
        self.actionbutton_27.setText(QCoreApplication.translate("Form", u"SPINDLE\n"
"FORWARD", None))
        self.actionbutton_27.setProperty(u"rules", QCoreApplication.translate("Form", u"[]", None))
        self.actionbutton_27.setProperty(u"actionName", QCoreApplication.translate("Form", u"spindle.forward", None))
        self.actionbutton_26.setText(QCoreApplication.translate("Form", u"SPINDLE\n"
"STOP", None))
        self.actionbutton_26.setProperty(u"actionName", QCoreApplication.translate("Form", u"spindle.off", None))
        self.actionbutton_18.setText(QCoreApplication.translate("Form", u"SPINDLE\n"
"REVERSE", None))
        self.actionbutton_18.setProperty(u"actionName", QCoreApplication.translate("Form", u"spindle.reverse", None))
        self.mainModeTabWidget.setTabText(self.mainModeTabWidget.indexOf(self.tab_14), QCoreApplication.translate("Form", u"MANUAL", None))
        self.mainModeTabWidget.setTabText(self.mainModeTabWidget.indexOf(self.tab_11), QCoreApplication.translate("Form", u"MDI", None))
        self.actionbutton_5.setText(QCoreApplication.translate("Form", u"CYCLE\n"
"START", None))
        self.actionbutton_5.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.run", None))
        self.actionbutton_6.setText(QCoreApplication.translate("Form", u"FEED\n"
"HOLD", None))
        self.actionbutton_6.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.pause", None))
        self.actionbutton_7.setText(QCoreApplication.translate("Form", u"M1\n"
"BREAK", None))
        self.actionbutton_7.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.optional-stop.toggle", None))
        self.actionbutton_8.setText(QCoreApplication.translate("Form", u"STOP\n"
"ABORT", None))
        self.actionbutton_8.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.abort", None))
        self.actionbutton.setText(QCoreApplication.translate("Form", u"MIST", None))
        self.actionbutton.setProperty(u"actionName", QCoreApplication.translate("Form", u"coolant.mist.toggle", None))
        self.actionbutton_4.setText(QCoreApplication.translate("Form", u"FLOOD", None))
        self.actionbutton_4.setProperty(u"actionName", QCoreApplication.translate("Form", u"coolant.flood.toggle", None))
        self.actionbutton_9.setText(QCoreApplication.translate("Form", u"Run", None))
        self.actionbutton_9.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.run", None))
        self.actionbutton_19.setText(QCoreApplication.translate("Form", u"Step", None))
        self.actionbutton_19.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.step", None))
        self.actionbutton_23.setText(QCoreApplication.translate("Form", u"Abort", None))
        self.actionbutton_23.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.abort", None))
        self.actionbutton_20.setText(QCoreApplication.translate("Form", u"Resume", None))
        self.actionbutton_20.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.resume", None))
        self.actionbutton_21.setText(QCoreApplication.translate("Form", u"Pause", None))
        self.actionbutton_21.setProperty(u"actionName", QCoreApplication.translate("Form", u"program.pause", None))
        self.mainModeTabWidget.setTabText(self.mainModeTabWidget.indexOf(self.tab_10), QCoreApplication.translate("Form", u"AUTO", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab), QCoreApplication.translate("Form", u"MAIN", None))
        self.groupbox.setTitle(QCoreApplication.translate("Form", u"ACTIVE G-CODES", None))
        self.groupbox_2.setTitle(QCoreApplication.translate("Form", u"OFFSETS", None))
        self.offset_table.setProperty(u"displayColumns", QCoreApplication.translate("Form", u"XYZ", None))
        self.pushButton_7.setText(QCoreApplication.translate("Form", u"CLEAR OFFSETS", None))
        self.pushButton_6.setText(QCoreApplication.translate("Form", u"LOAD OFFSET", None))
        self.pushButton_5.setText(QCoreApplication.translate("Form", u"SAVE OFFSETS", None))
        self.label_11.setText(QCoreApplication.translate("Form", u"X", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_8), QCoreApplication.translate("Form", u"STATUS", None))
        self.groupbox_6.setTitle(QCoreApplication.translate("Form", u"TOOL TABLE", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_9), QCoreApplication.translate("Form", u"CONFIG", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_12), QCoreApplication.translate("Form", u"STATISTICS", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_6), QCoreApplication.translate("Form", u"PARAMETERS", None))
        self.label.setText(QCoreApplication.translate("Form", u"Inch Format", None))
        self.settings_lineedit.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.inch-format", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"Millimeter Format", None))
        self.settings_lineedit_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.millimeter-format", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"Degree Format", None))
        self.settings_lineedit_3.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.degree-format", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"Display Units", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"Lathe X-axis Mode", None))
        self.settingscombobox.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.display-units", None))
        self.settingscombobox_2.setProperty(u"settingName", QCoreApplication.translate("Form", u"dro.lathe-radius-mode", None))
        self.tabWidget_6.setTabText(self.tabWidget_6.indexOf(self.tabWidget_6Page1), QCoreApplication.translate("Form", u"DRO FORMAT", None))
        self.settings_checkbox.setText(QCoreApplication.translate("Form", u"On-Screen Keyboard ", None))
        self.settings_checkbox.setProperty(u"settingName", QCoreApplication.translate("Form", u"virtual-input.enable", None))
        self.tabWidget_7.setTabText(self.tabWidget_7.indexOf(self.tabWidget_7Page1), QCoreApplication.translate("Form", u"USER INPUT", None))
        self.groupbox_4.setTitle(QCoreApplication.translate("Form", u"TOOL SETTER", None))
        self.pushButton_4.setText(QCoreApplication.translate("Form", u"PushButton", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_2), QCoreApplication.translate("Form", u"SETTINGS", None))
        self.mainTabWidget.setTabText(self.mainTabWidget.indexOf(self.tab_5), QCoreApplication.translate("Form", u"DIAGNOSTICS", None))
    # retranslateUi

