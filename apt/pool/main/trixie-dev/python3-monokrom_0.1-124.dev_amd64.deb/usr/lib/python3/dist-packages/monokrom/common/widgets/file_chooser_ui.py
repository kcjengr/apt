# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'file_chooser.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QFrame, QHBoxLayout,
    QHeaderView, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget)

from monokrom.common.widgets.file_list_view import (MkFileTableView, MkRemovableDeviceComboBox)
from monokrom.common.widgets.transparent_widget import MkTransparentWidget
from qtpyvcp.widgets.input_widgets.file_system import RemovableDeviceComboBox

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(800, 600)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        Form.setMinimumSize(QSize(800, 600))
        Form.setMaximumSize(QSize(800, 600))
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setSpacing(14)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.frame = QFrame(Form)
        self.frame.setObjectName(u"frame")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy1)
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.mkremovabledevicecombobox = MkRemovableDeviceComboBox(self.frame)
        self.mkremovabledevicecombobox.setObjectName(u"mkremovabledevicecombobox")
        self.mkremovabledevicecombobox.setIconSize(QSize(20, 20))

        self.verticalLayout_2.addWidget(self.mkremovabledevicecombobox)

        self.filelistview = MkFileTableView(self.frame)
        self.filelistview.setObjectName(u"filelistview")
        self.filelistview.setDragEnabled(True)
        self.filelistview.setDragDropMode(QAbstractItemView.DragDrop)
        self.filelistview.setDefaultDropAction(Qt.CopyAction)
        self.filelistview.setAlternatingRowColors(True)
        self.filelistview.setSelectionMode(QAbstractItemView.SingleSelection)
        self.filelistview.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.filelistview.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.filelistview.setShowGrid(False)
        self.filelistview.horizontalHeader().setStretchLastSection(True)

        self.verticalLayout_2.addWidget(self.filelistview)


        self.verticalLayout.addWidget(self.frame)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(14)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.btn_filechooser_removedev = QPushButton(Form)
        self.btn_filechooser_removedev.setObjectName(u"btn_filechooser_removedev")
        self.btn_filechooser_removedev.setMinimumSize(QSize(34, 44))
        self.btn_filechooser_removedev.setMaximumSize(QSize(34, 34))
        self.btn_filechooser_removedev.setStyleSheet(u"width: 30px;\n"
"height: 30px;")
        icon = QIcon()
        icon.addFile(u"../icons/eject.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.btn_filechooser_removedev.setIcon(icon)
        self.btn_filechooser_removedev.setIconSize(QSize(20, 20))

        self.horizontalLayout.addWidget(self.btn_filechooser_removedev)

        self.btn_filechooser_del = QPushButton(Form)
        self.btn_filechooser_del.setObjectName(u"btn_filechooser_del")
        self.btn_filechooser_del.setStyleSheet(u"width: 80px;\n"
"height: 30px;")

        self.horizontalLayout.addWidget(self.btn_filechooser_del)

        self.btn_filechooser_rename = QPushButton(Form)
        self.btn_filechooser_rename.setObjectName(u"btn_filechooser_rename")
        self.btn_filechooser_rename.setStyleSheet(u"width: 80px;\n"
"height: 30px;")

        self.horizontalLayout.addWidget(self.btn_filechooser_rename)

        self.btn_filechooser_open = QPushButton(Form)
        self.btn_filechooser_open.setObjectName(u"btn_filechooser_open")
        self.btn_filechooser_open.setStyleSheet(u"width: 80px;\n"
"height: 30px;")

        self.horizontalLayout.addWidget(self.btn_filechooser_open)


        self.verticalLayout.addLayout(self.horizontalLayout)


        self.retranslateUi(Form)
        self.btn_filechooser_open.clicked.connect(self.filelistview.openSelectedItem)
        self.mkremovabledevicecombobox.currentPathChanged.connect(self.filelistview.setRootPath)
        self.mkremovabledevicecombobox.currentDeviceEjectable.connect(self.btn_filechooser_removedev.setVisible)
        self.btn_filechooser_removedev.clicked.connect(self.mkremovabledevicecombobox.ejectDevice)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.frame.setProperty(u"styleClass", QCoreApplication.translate("Form", u"comboFrame", None))
        self.btn_filechooser_removedev.setText("")
        self.btn_filechooser_del.setText(QCoreApplication.translate("Form", u"DELETE", None))
        self.btn_filechooser_rename.setText(QCoreApplication.translate("Form", u"RENAME", None))
        self.btn_filechooser_open.setText(QCoreApplication.translate("Form", u"OPEN", None))
    # retranslateUi

