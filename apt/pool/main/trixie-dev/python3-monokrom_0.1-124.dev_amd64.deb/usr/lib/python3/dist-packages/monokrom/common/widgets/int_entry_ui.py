# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'int_entry.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGridLayout, QHBoxLayout, QLineEdit,
    QSizePolicy, QVBoxLayout, QWidget)

from monokrom.common.widgets.transparent_widget import MkTransparentWidget
from qtpyvcp.widgets.virtual_keyboards.vkb_key import VKBKey

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(356, 379)
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.lineEdit = QLineEdit(Form)
        self.lineEdit.setObjectName(u"lineEdit")

        self.verticalLayout.addWidget(self.lineEdit)

        self.widget = QWidget(Form)
        self.widget.setObjectName(u"widget")
        self.gridLayout = QGridLayout(self.widget)
        self.gridLayout.setSpacing(6)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.subtract_5 = VKBKey(self.widget)
        self.subtract_5.setObjectName(u"subtract_5")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.subtract_5.sizePolicy().hasHeightForWidth())
        self.subtract_5.setSizePolicy(sizePolicy)
        self.subtract_5.setFocusPolicy(Qt.NoFocus)
        self.subtract_5.setAutoDefault(False)

        self.gridLayout.addWidget(self.subtract_5, 0, 2, 1, 1)

        self.subtract_4 = VKBKey(self.widget)
        self.subtract_4.setObjectName(u"subtract_4")
        sizePolicy.setHeightForWidth(self.subtract_4.sizePolicy().hasHeightForWidth())
        self.subtract_4.setSizePolicy(sizePolicy)
        self.subtract_4.setFocusPolicy(Qt.NoFocus)
        self.subtract_4.setAutoDefault(False)

        self.gridLayout.addWidget(self.subtract_4, 0, 1, 1, 1)

        self.np7 = VKBKey(self.widget)
        self.np7.setObjectName(u"np7")
        sizePolicy.setHeightForWidth(self.np7.sizePolicy().hasHeightForWidth())
        self.np7.setSizePolicy(sizePolicy)
        self.np7.setFocusPolicy(Qt.NoFocus)
        self.np7.setAutoDefault(False)

        self.gridLayout.addWidget(self.np7, 1, 0, 1, 1)

        self.delete_2 = VKBKey(self.widget)
        self.delete_2.setObjectName(u"delete_2")
        sizePolicy.setHeightForWidth(self.delete_2.sizePolicy().hasHeightForWidth())
        self.delete_2.setSizePolicy(sizePolicy)
        self.delete_2.setBaseSize(QSize(0, 0))
        self.delete_2.setFocusPolicy(Qt.NoFocus)
        self.delete_2.setAutoDefault(False)

        self.gridLayout.addWidget(self.delete_2, 0, 0, 1, 1)

        self.np3 = VKBKey(self.widget)
        self.np3.setObjectName(u"np3")
        sizePolicy.setHeightForWidth(self.np3.sizePolicy().hasHeightForWidth())
        self.np3.setSizePolicy(sizePolicy)
        self.np3.setFocusPolicy(Qt.NoFocus)
        self.np3.setAutoDefault(False)

        self.gridLayout.addWidget(self.np3, 3, 2, 1, 1)

        self.np2 = VKBKey(self.widget)
        self.np2.setObjectName(u"np2")
        sizePolicy.setHeightForWidth(self.np2.sizePolicy().hasHeightForWidth())
        self.np2.setSizePolicy(sizePolicy)
        self.np2.setFocusPolicy(Qt.NoFocus)
        self.np2.setAutoDefault(False)

        self.gridLayout.addWidget(self.np2, 3, 1, 1, 1)

        self.np6 = VKBKey(self.widget)
        self.np6.setObjectName(u"np6")
        sizePolicy.setHeightForWidth(self.np6.sizePolicy().hasHeightForWidth())
        self.np6.setSizePolicy(sizePolicy)
        self.np6.setFocusPolicy(Qt.NoFocus)
        self.np6.setAutoDefault(False)

        self.gridLayout.addWidget(self.np6, 2, 2, 1, 1)

        self.np8 = VKBKey(self.widget)
        self.np8.setObjectName(u"np8")
        sizePolicy.setHeightForWidth(self.np8.sizePolicy().hasHeightForWidth())
        self.np8.setSizePolicy(sizePolicy)
        self.np8.setFocusPolicy(Qt.NoFocus)
        self.np8.setAutoDefault(False)

        self.gridLayout.addWidget(self.np8, 1, 1, 1, 1)

        self.np5 = VKBKey(self.widget)
        self.np5.setObjectName(u"np5")
        sizePolicy.setHeightForWidth(self.np5.sizePolicy().hasHeightForWidth())
        self.np5.setSizePolicy(sizePolicy)
        self.np5.setFocusPolicy(Qt.NoFocus)
        self.np5.setAutoDefault(False)

        self.gridLayout.addWidget(self.np5, 2, 1, 1, 1)

        self.np1 = VKBKey(self.widget)
        self.np1.setObjectName(u"np1")
        sizePolicy.setHeightForWidth(self.np1.sizePolicy().hasHeightForWidth())
        self.np1.setSizePolicy(sizePolicy)
        self.np1.setFocusPolicy(Qt.NoFocus)
        self.np1.setAutoDefault(False)

        self.gridLayout.addWidget(self.np1, 3, 0, 1, 1)

        self.np9 = VKBKey(self.widget)
        self.np9.setObjectName(u"np9")
        sizePolicy.setHeightForWidth(self.np9.sizePolicy().hasHeightForWidth())
        self.np9.setSizePolicy(sizePolicy)
        self.np9.setFocusPolicy(Qt.NoFocus)
        self.np9.setAutoDefault(False)

        self.gridLayout.addWidget(self.np9, 1, 2, 1, 1)

        self.np4 = VKBKey(self.widget)
        self.np4.setObjectName(u"np4")
        sizePolicy.setHeightForWidth(self.np4.sizePolicy().hasHeightForWidth())
        self.np4.setSizePolicy(sizePolicy)
        self.np4.setFocusPolicy(Qt.NoFocus)
        self.np4.setAutoDefault(False)

        self.gridLayout.addWidget(self.np4, 2, 0, 1, 1)

        self.subtract_2 = VKBKey(self.widget)
        self.subtract_2.setObjectName(u"subtract_2")
        sizePolicy.setHeightForWidth(self.subtract_2.sizePolicy().hasHeightForWidth())
        self.subtract_2.setSizePolicy(sizePolicy)
        self.subtract_2.setFocusPolicy(Qt.NoFocus)
        self.subtract_2.setAutoDefault(False)

        self.gridLayout.addWidget(self.subtract_2, 1, 4, 1, 1)

        self.subtract_3 = VKBKey(self.widget)
        self.subtract_3.setObjectName(u"subtract_3")
        sizePolicy.setHeightForWidth(self.subtract_3.sizePolicy().hasHeightForWidth())
        self.subtract_3.setSizePolicy(sizePolicy)
        self.subtract_3.setFocusPolicy(Qt.NoFocus)
        self.subtract_3.setAutoDefault(False)

        self.gridLayout.addWidget(self.subtract_3, 2, 4, 1, 1)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.subtract_6 = VKBKey(self.widget)
        self.subtract_6.setObjectName(u"subtract_6")
        sizePolicy.setHeightForWidth(self.subtract_6.sizePolicy().hasHeightForWidth())
        self.subtract_6.setSizePolicy(sizePolicy)
        self.subtract_6.setFocusPolicy(Qt.NoFocus)
        self.subtract_6.setStyleSheet(u"padding: 0px;\n"
"border-right-width: 1px;\n"
"border-top-right-radius: 0px;\n"
"border-bottom-right-radius: 0px;\n"
"")
        self.subtract_6.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.subtract_6)

        self.subtract_7 = VKBKey(self.widget)
        self.subtract_7.setObjectName(u"subtract_7")
        sizePolicy.setHeightForWidth(self.subtract_7.sizePolicy().hasHeightForWidth())
        self.subtract_7.setSizePolicy(sizePolicy)
        self.subtract_7.setFocusPolicy(Qt.NoFocus)
        self.subtract_7.setStyleSheet(u"border-left: none;\n"
"border-top-left-radius: 0px;\n"
"border-bottom-left-radius: 0px;\n"
"")
        self.subtract_7.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.subtract_7)


        self.gridLayout.addLayout(self.horizontalLayout, 0, 4, 1, 1)

        self.decimal = VKBKey(self.widget)
        self.decimal.setObjectName(u"decimal")
        sizePolicy.setHeightForWidth(self.decimal.sizePolicy().hasHeightForWidth())
        self.decimal.setSizePolicy(sizePolicy)
        self.decimal.setFocusPolicy(Qt.NoFocus)
        self.decimal.setAutoDefault(False)

        self.gridLayout.addWidget(self.decimal, 4, 2, 1, 1)

        self.np0 = VKBKey(self.widget)
        self.np0.setObjectName(u"np0")
        sizePolicy.setHeightForWidth(self.np0.sizePolicy().hasHeightForWidth())
        self.np0.setSizePolicy(sizePolicy)
        self.np0.setFocusPolicy(Qt.NoFocus)
        self.np0.setAutoDefault(False)

        self.gridLayout.addWidget(self.np0, 4, 0, 1, 2)

        self.enter = VKBKey(self.widget)
        self.enter.setObjectName(u"enter")
        sizePolicy.setHeightForWidth(self.enter.sizePolicy().hasHeightForWidth())
        self.enter.setSizePolicy(sizePolicy)
        self.enter.setFocusPolicy(Qt.NoFocus)
        self.enter.setAutoDefault(False)

        self.gridLayout.addWidget(self.enter, 3, 4, 2, 1)


        self.verticalLayout.addWidget(self.widget)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.subtract_5.setText(QCoreApplication.translate("Form", u"*", None))
        self.subtract_4.setText(QCoreApplication.translate("Form", u"/", None))
        self.np7.setText(QCoreApplication.translate("Form", u"7", None))
        self.delete_2.setText(QCoreApplication.translate("Form", u"DEL", None))
        self.delete_2.setProperty(u"key", QCoreApplication.translate("Form", u"Del", None))
        self.np3.setText(QCoreApplication.translate("Form", u"3", None))
        self.np2.setText(QCoreApplication.translate("Form", u"2", None))
        self.np6.setText(QCoreApplication.translate("Form", u"6", None))
        self.np8.setText(QCoreApplication.translate("Form", u"8", None))
        self.np5.setText(QCoreApplication.translate("Form", u"5", None))
        self.np1.setText(QCoreApplication.translate("Form", u"1", None))
        self.np9.setText(QCoreApplication.translate("Form", u"9", None))
        self.np4.setText(QCoreApplication.translate("Form", u"4", None))
        self.subtract_2.setText(QCoreApplication.translate("Form", u"+", None))
        self.subtract_3.setText(QCoreApplication.translate("Form", u"\u2212", None))
        self.subtract_6.setText(QCoreApplication.translate("Form", u"(", None))
        self.subtract_7.setText(QCoreApplication.translate("Form", u")", None))
        self.decimal.setText(QCoreApplication.translate("Form", u".", None))
        self.np0.setText(QCoreApplication.translate("Form", u"0", None))
        self.enter.setText(QCoreApplication.translate("Form", u"E\n"
"N\n"
"T\n"
"E\n"
"R", None))
        self.enter.setProperty(u"key", QCoreApplication.translate("Form", u"Return", None))
    # retranslateUi

