# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'new_process.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGridLayout, QPushButton, QSizePolicy,
    QVBoxLayout, QWidget)

from monokrom.common.widgets.group_box import MkGroupBox
from monokrom.common.widgets.transparent_widget import MkTransparentWidget
from monokrom.plasma.widgets.plasma_add_process import PlasmaAddProcess

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(700, 300)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        Form.setMinimumSize(QSize(700, 300))
        Form.setMaximumSize(QSize(700, 300))
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.groupbox = MkGroupBox(Form)
        self.groupbox.setObjectName(u"groupbox")
        self.gridLayout = QGridLayout(self.groupbox)
        self.gridLayout.setObjectName(u"gridLayout")
        self.new_process_add = QPushButton(self.groupbox)
        self.new_process_add.setObjectName(u"new_process_add")
        sizePolicy.setHeightForWidth(self.new_process_add.sizePolicy().hasHeightForWidth())
        self.new_process_add.setSizePolicy(sizePolicy)
        self.new_process_add.setMinimumSize(QSize(34, 44))
        self.new_process_add.setMaximumSize(QSize(120, 44))

        self.gridLayout.addWidget(self.new_process_add, 1, 1, 1, 1)

        self.new_process_name = PlasmaAddProcess(self.groupbox)
        self.new_process_name.setObjectName(u"new_process_name")
        self.new_process_name.setMinimumSize(QSize(0, 29))
        self.new_process_name.setMaximumSize(QSize(16777215, 48))
        self.new_process_name.setClearButtonEnabled(True)

        self.gridLayout.addWidget(self.new_process_name, 0, 0, 1, 3)


        self.verticalLayout.addWidget(self.groupbox)


        self.retranslateUi(Form)
        self.new_process_add.clicked.connect(self.new_process_name.addCutProcess)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.groupbox.setTitle(QCoreApplication.translate("Form", u"NEW CUT PROCESS", None))
        self.new_process_add.setText(QCoreApplication.translate("Form", u"ADD", None))
        self.new_process_name.setText("")
    # retranslateUi

