# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'tool_table_overlay.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QHBoxLayout, QHeaderView,
    QPushButton, QSizePolicy, QVBoxLayout, QWidget)

from monokrom.common.widgets.group_box import MkGroupBox
from monokrom.common.widgets.transparent_widget import MkTransparentWidget
from qtpyvcp.widgets.input_widgets.tool_table import ToolTable

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(900, 500)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        Form.setMinimumSize(QSize(900, 500))
        Form.setMaximumSize(QSize(900, 500))
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setSpacing(6)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(14, 14, 14, 14)
        self.groupbox_6 = MkGroupBox(Form)
        self.groupbox_6.setObjectName(u"groupbox_6")
        self.groupbox_6.setStyleSheet(u"::title {min-width: 872px;}")
        self.verticalLayout_12 = QVBoxLayout(self.groupbox_6)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.tooltable = ToolTable(self.groupbox_6)
        self.tooltable.setObjectName(u"tooltable")
        self.tooltable.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.tooltable.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)

        self.verticalLayout_12.addWidget(self.tooltable)


        self.verticalLayout.addWidget(self.groupbox_6)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(14)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(-1, 10, -1, -1)
        self.pushButton_2 = QPushButton(Form)
        self.pushButton_2.setObjectName(u"pushButton_2")

        self.horizontalLayout.addWidget(self.pushButton_2)

        self.pushButton = QPushButton(Form)
        self.pushButton.setObjectName(u"pushButton")

        self.horizontalLayout.addWidget(self.pushButton)

        self.pushButton_3 = QPushButton(Form)
        self.pushButton_3.setObjectName(u"pushButton_3")

        self.horizontalLayout.addWidget(self.pushButton_3)

        self.pushButton_5 = QPushButton(Form)
        self.pushButton_5.setObjectName(u"pushButton_5")

        self.horizontalLayout.addWidget(self.pushButton_5)

        self.pushButton_4 = QPushButton(Form)
        self.pushButton_4.setObjectName(u"pushButton_4")

        self.horizontalLayout.addWidget(self.pushButton_4)


        self.verticalLayout.addLayout(self.horizontalLayout)


        self.retranslateUi(Form)
        self.pushButton_2.clicked.connect(self.tooltable.addTool)
        self.pushButton.clicked.connect(self.tooltable.deleteSelectedTool)
        self.pushButton_3.clicked.connect(self.tooltable.loadSelectedTool)
        self.pushButton_5.clicked.connect(self.tooltable.loadToolTable)
        self.pushButton_4.clicked.connect(self.tooltable.saveToolTable)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.groupbox_6.setTitle(QCoreApplication.translate("Form", u"TOOL TABLE", None))
        self.pushButton_2.setText(QCoreApplication.translate("Form", u"ADD TOOL", None))
        self.pushButton.setText(QCoreApplication.translate("Form", u"DELETE TOOL", None))
        self.pushButton_3.setText(QCoreApplication.translate("Form", u"LOAD TOOL IN SPINDLE", None))
        self.pushButton_5.setText(QCoreApplication.translate("Form", u"RELOAD TABLE", None))
        self.pushButton_4.setText(QCoreApplication.translate("Form", u"SAVE CHANGES", None))
    # retranslateUi

