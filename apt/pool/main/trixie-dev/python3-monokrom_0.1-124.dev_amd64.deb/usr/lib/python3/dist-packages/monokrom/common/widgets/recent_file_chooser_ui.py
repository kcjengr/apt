# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'recent_file_chooser.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QHBoxLayout, QListView,
    QListWidgetItem, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

from monokrom.common.widgets.group_box import MkGroupBox
from monokrom.common.widgets.recent_file_list_view import MkRecentFileListView
from monokrom.common.widgets.transparent_widget import MkTransparentWidget

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(400, 600)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        Form.setMinimumSize(QSize(400, 600))
        Form.setMaximumSize(QSize(400, 600))
        self.verticalLayout_2 = QVBoxLayout(Form)
        self.verticalLayout_2.setSpacing(14)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.mkgroupbox = MkGroupBox(Form)
        self.mkgroupbox.setObjectName(u"mkgroupbox")
        self.verticalLayout = QVBoxLayout(self.mkgroupbox)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.mkrecentfilelistview = MkRecentFileListView(self.mkgroupbox)
        self.mkrecentfilelistview.setObjectName(u"mkrecentfilelistview")
        self.mkrecentfilelistview.setAlternatingRowColors(True)
        self.mkrecentfilelistview.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.mkrecentfilelistview.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.mkrecentfilelistview.setViewMode(QListView.ListMode)
        self.mkrecentfilelistview.setBatchSize(1)

        self.verticalLayout.addWidget(self.mkrecentfilelistview)


        self.verticalLayout_2.addWidget(self.mkgroupbox)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(14)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.pushButton = QPushButton(Form)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setStyleSheet(u"width: 80px;\n"
"height: 30px;")

        self.horizontalLayout.addWidget(self.pushButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.pushButton_3 = QPushButton(Form)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setStyleSheet(u"width: 80px;\n"
"height: 30px;")

        self.horizontalLayout.addWidget(self.pushButton_3)


        self.verticalLayout_2.addLayout(self.horizontalLayout)


        self.retranslateUi(Form)
        self.pushButton_3.clicked.connect(self.mkrecentfilelistview.openSelected)
        self.pushButton.clicked.connect(self.mkrecentfilelistview.removeSelected)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.mkgroupbox.setTitle(QCoreApplication.translate("Form", u"RECENT FILES", None))
        self.pushButton.setText(QCoreApplication.translate("Form", u"REMOVE", None))
        self.pushButton_3.setText(QCoreApplication.translate("Form", u"OPEN", None))
    # retranslateUi

