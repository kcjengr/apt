# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mk_dro.ui'
##
## Created by: Qt User Interface Compiler version 6.8.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QLayout, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

from qtpyvcp.widgets.input_widgets.dro_line_edit import DROLineEdit

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(276, 79)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        self.horizontalLayout_2 = QHBoxLayout(Form)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.frame = QFrame(Form)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout = QHBoxLayout(self.frame)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.axis_actions_button = QPushButton(self.frame)
        self.axis_actions_button.setObjectName(u"axis_actions_button")
        self.axis_actions_button.setEnabled(True)
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.MinimumExpanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.axis_actions_button.sizePolicy().hasHeightForWidth())
        self.axis_actions_button.setSizePolicy(sizePolicy1)
        self.axis_actions_button.setFocusPolicy(Qt.NoFocus)
        self.axis_actions_button.setIconSize(QSize(48, 48))

        self.horizontalLayout.addWidget(self.axis_actions_button)

        self.dro_entry = DROLineEdit(self.frame)
        self.dro_entry.setObjectName(u"dro_entry")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.dro_entry.sizePolicy().hasHeightForWidth())
        self.dro_entry.setSizePolicy(sizePolicy2)
        font = QFont()
        font.setFamilies([u"Sans"])
        font.setBold(False)
        font.setItalic(False)
        self.dro_entry.setFont(font)
        self.dro_entry.setFocusPolicy(Qt.ClickFocus)
        self.dro_entry.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.dro_entry.setProperty(u"referenceType", 1)
        self.dro_entry.setProperty(u"axisNumber", 0)
        self.dro_entry.setProperty(u"latheMode", 0)

        self.horizontalLayout.addWidget(self.dro_entry)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setSizeConstraint(QLayout.SetMinimumSize)
        self.homed_indicator = QLabel(self.frame)
        self.homed_indicator.setObjectName(u"homed_indicator")
        self.homed_indicator.setFrameShape(QFrame.NoFrame)
        self.homed_indicator.setPixmap(QPixmap(u"icons/homed.png"))
        self.homed_indicator.setAlignment(Qt.AlignHCenter|Qt.AlignTop)

        self.verticalLayout.addWidget(self.homed_indicator)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)


        self.horizontalLayout.addLayout(self.verticalLayout)


        self.horizontalLayout_2.addWidget(self.frame)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.axis_actions_button.setText(QCoreApplication.translate("Form", u"X", None))
        self.dro_entry.setText(QCoreApplication.translate("Form", u"0.000", None))
        self.dro_entry.setProperty(u"inchFormat", QCoreApplication.translate("Form", u"%.4f", None))
        self.dro_entry.setProperty(u"millimeterFormat", QCoreApplication.translate("Form", u"%.3f", None))
        self.dro_entry.setProperty(u"degreeFormat", QCoreApplication.translate("Form", u"%.2f", None))
    # retranslateUi

