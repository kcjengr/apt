# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post35.dev0+b58c7b6"
__version_tuple__ = (0, 5, 5, "post35", "dev0", "b58c7b6")
