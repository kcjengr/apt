# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post45.dev0+5c036b0"
__version_tuple__ = (0, 5, 5, "post45", "dev0", "5c036b0")
