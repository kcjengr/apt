# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post19.dev0+d23b3bd"
__version_tuple__ = (0, 5, 5, "post19", "dev0", "d23b3bd")
