# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post40.dev0+3060bc2"
__version_tuple__ = (0, 5, 5, "post40", "dev0", "3060bc2")
