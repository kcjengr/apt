# These version placeholders will be replaced later during substitution.
__version__ = "0.5.5.post44.dev0+7e14501"
__version_tuple__ = (0, 5, 5, "post44", "dev0", "7e14501")
